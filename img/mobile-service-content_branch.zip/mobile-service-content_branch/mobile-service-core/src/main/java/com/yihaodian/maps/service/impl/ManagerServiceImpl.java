package com.yihaodian.maps.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.yhd.pss.spi.common.vo.Response;
import com.yhd.pss.spi.common.vo.input.EmptyRequest;
import com.yhd.pss.spi.merchant.vo.MechantProvinceVo;
import com.yhd.shareservice.exceptions.HedwigException;
import com.yihaodian.cms.hessian.query.output.CmsDataOutput;
import com.yihaodian.cms.hessian.query.output.CmsProdVoOut;
import com.yihaodian.common.DateUtil;
import com.yihaodian.front.busystock.vo.BSProductVo;
import com.yihaodian.groupon.data.client.mobile.service.GrouponQueryForMobileService;
import com.yihaodian.groupon.data.client.query.model.output.GrouponBrandOut;
import com.yihaodian.groupon.data.client.query.service.GrouponPublicQueryService;
import com.yihaodian.maps.util.ManagerUtils;
import com.yihaodian.mobile.backend.maps.model.AcceptCouponEntity;
import com.yihaodian.mobile.backend.maps.model.MapsModuleProduct;
import com.yihaodian.mobile.backend.maps.model.MapsProductShopModule;
import com.yihaodian.mobile.backend.maps.vo.CategroyVO;
import com.yihaodian.mobile.backend.maps.vo.CouponVO;
import com.yihaodian.mobile.backend.maps.vo.GrouponBrandVO;
import com.yihaodian.mobile.backend.maps.vo.ProductInfoVO;
import com.yihaodian.mobile.service.common.business.util.busystock.MobileBusyStockClientUtil;
import com.yihaodian.mobile.service.map.spi.AcceptCouponLogService;
import com.yihaodian.mobile.service.map.spi.ManagerService;
import com.yihaodian.mobile.service.map.spi.MapsModuleProductService;
import com.yihaodian.mobile.service.map.spi.MapsProductShopModuleService;
import com.yihaodian.promotion.coupon.outputVo.CouponActivityOutputVo;

@Service("managerService")
public class ManagerServiceImpl implements ManagerService {

//	@Resource
//	private AreaService areaService;
	
	@Resource
	private GrouponQueryForMobileService grouponQueryForMobileService ;
	
	@Resource
	AcceptCouponLogService acceptCouponLogService ;
	
    /**
     * maps 模块管理
     */
    @Resource
    private MapsProductShopModuleService mapsProductShopModuleService;
    /**
     * maps 商品
     */
    @Resource
    private MapsModuleProductService mapsModuleProductService;
    
	

	/**
	 * 获取全部区域的信息
	 * @throws HedwigException 
	 */
	@Override
	public List<MechantProvinceVo> listAllArea() throws HedwigException {
		EmptyRequest param = new EmptyRequest();
		Response<List<MechantProvinceVo>> result = ManagerUtils.getPssClient().getQueryMerchantRemoteService() .queryVipMechantProvince(param);

		if (result != null
				&& CollectionUtils.isNotEmpty(result.getResult())) {
			return result.getResult();
		}
		return null;
	}

	
	@Autowired
	private GrouponPublicQueryService grouponPublicQueryService;
	/**
	 * 商品展现栏位：通过cms的栏位ID，同步展现相应商品的逻辑。
	 * 一个栏目只存在一种商品类型
	 * dataType---栏目商品类型如下
	 * 1  普通商品
	 * 2 LandingPage商品
	 * 4  团购商品
	 * 其他类型的栏目不返回
     * @see BSProductVo
	 */
	@Override
	public List<ProductInfoVO> queryCmsProductByMouldId(Long cmsMouldId, Long provinceId,boolean isPreView,Date preViewTime) {
		
	    //兼容二期模块id 9位数, cmsid 6位数
	    CmsDataOutput cmsDataOutput = null;
	    if( cmsMouldId>100000000 ){
	        //二期
	        cmsDataOutput=findModuleProducts(cmsMouldId, provinceId);
	    }else{ 
	    //Long cmsPageId = null;
		//cmsPageId 和 cmsMouldId重复，cmsPageId可以不传
		com.yihaodian.cms.hessian.query.output.Response<CmsDataOutput> resp = ManagerUtils.getCmsHandler().queryCmsProductByMouldId(null, cmsMouldId, provinceId);
		cmsDataOutput=resp.getDataResult();
	    }
		List<CmsProdVoOut>  ds = cmsDataOutput.getProdData();
		List<ProductInfoVO> l = new ArrayList<ProductInfoVO>();
		int dataType = cmsDataOutput.getDataType()==null?-1:cmsDataOutput.getDataType() ;//bug
		if(ds!=null){
			//依据相关信息获取产品库存和价格
			//产品分类
			switch (dataType) {
			case 1:// 1 普通商品:pmid
				l = ManagerUtils.loadProductInfoOrderByPmIdsFromCMS(provinceId, ds);
				break;
			case 2:// 2LandingPage商品   promotionId活动id，一个活动有多个商品
				List<Long> promotionIds = cmsDataOutput.getLandingIds();
				l = ManagerUtils.loadProductDetialByPromotionIdsFromCMS(provinceId,promotionIds,isPreView,preViewTime);
				break;
			case 4:// 4 团购商品  grouponId & productid
			    l= ManagerUtils.loadGrouponProductByGrouponIdsFromCMS(grouponPublicQueryService,ds,provinceId,isPreView,preViewTime);
				break;
			default:
				break;
			}
		}
		return l;
	}


//	@Override
//	public List<CmsPageVo> queryH5CmsPageDates(Long cmsId, String cmsName,
//			int pageSize, int currentPage, Map<String, Object> extendParam) {
//		return ManagerUtils.getCmsHandler().queryH5CmsPageDates(cmsId, cmsName, pageSize, currentPage, extendParam);
//	}
//
//	@Override
//	public int queryH5CmsPageCount(Long cmsId, String cmsName,
//			Map<String, Object> extendParam) {
//		return ManagerUtils.getCmsHandler().queryH5CmsPageCount(cmsId, cmsName, extendParam);
//	}
//
//	@Override
//	public com.yihaodian.cms.hessian.query.output.Response<List<CmsMouldOutput>> queryCmsMouldByPageId(
//			Long cmsPageId, Long provinceId, Map<String, Object> extendParams) {
//		return ManagerUtils.getCmsHandler().queryCmsMouldByPageId(cmsPageId, provinceId, extendParams);
//	}
	
	
	
	/**
	 * 根据抵用卷活动id查询抵用券相关信息
	 * @param activityId  抵用卷活动id
	 * @return
	 */
	public CouponVO queryCouponActiveInfoMapByActiveId(Long activityId){
		CouponVO couponVO = null;
		try {
			if(activityId!=null){
				CouponActivityOutputVo out = ManagerUtils.queryCouponActiveInfoMapByActiveId(activityId);
				if (out != null) {
					couponVO = new CouponVO();
					if(out.getActivityBeginDate()!=null){
						couponVO.setActiveBegin(DateUtil.getFormatTime(out.getActivityBeginDate()));
					}
					if(out.getActivityEndDate()!=null){
						couponVO.setActiveEnd(DateUtil.getFormatTime(out.getActivityEndDate()));
					}
					couponVO.setActiveName(out.getActiveName());
					couponVO.setDeductAmount(out.getDeductAmount() == null ? "0"
							: out.getDeductAmount().toString());
				}
			}
		} catch (Exception e) {
		}
		return couponVO;
	}
	
	/**
	 * 抵用卷发放
	 * @creator @wulibing
	 * @create @2015年4月29日 
	 * @param activityId
	 * @param userIdList
	 * @return
	 */
	public List<String> generateCouponToUsers(Long activityId,List<Long> userIdList){
		List<String> retList = ManagerUtils.generateCouponToUsers(activityId, userIdList);
		AcceptCouponEntity record = new AcceptCouponEntity();
		record.setActivityId(activityId);
		record.setCode(retList.get(0));
		record.setUserId(userIdList.get(0));		
		acceptCouponLogService.saveAcceptCoupon(record) ;		
		return retList;
	}
	
	/**
	 * 品牌团详情查询接口
	 * @param service 品牌团 服务
	 * @param brandId 品牌团id
	 * @return
	 */
	@Override
	public GrouponBrandVO getBrandGrouponById(Long brandId){		
		GrouponBrandVO gbVO = new GrouponBrandVO();
		GrouponBrandOut out = null;
		try {
			if(brandId!=null){
				out = ManagerUtils.getBrandGrouponById(grouponQueryForMobileService, brandId);
			}
		} catch (Exception e) {
		}
		if(out!=null){
			 if(out!=null){
				 gbVO.setId(out.getId());
				 gbVO.setIcon(out.getImageLogoUrl());
				 gbVO.setUrl(out.getH5DetailUrl());
				 gbVO.setTitle(out.getName());
				 gbVO.setDiscount(out.getRebate()==null?"0":out.getRebate().toString());
				 gbVO.setSales(out.getPeopleNumber()==null?0l:out.getPeopleNumber().longValue());
				 
				 Date endTime = out.getEndTime();
				 if(endTime!=null){
					 //向下取整，不满一天算0天：向上取整Math.ceil
					 gbVO.setDeadline((int)Math.floor((double)(endTime.getTime()-System.currentTimeMillis())/(3600*1000*24)));
				 }else{
					 gbVO.setDeadline(0);
				 }
			 }
		}
		return gbVO;
	}
	public List<CategroyVO> getCategoryByWirless(){
		List<CategroyVO> list = ManagerUtils.getWirlessCategory();
		return list;
	}
	
	
    /**
     * maps二期,找本地数据模拟cms返回
     * @param cmsMouldId
     * @param provinceId
     * @return
     */
    public  CmsDataOutput findModuleProducts(Long cmsMouldId, Long provinceId) {
        CmsDataOutput cmsDataOutput = new CmsDataOutput() ;
        try{
        MapsProductShopModule param= new MapsProductShopModule();
        param.setId(cmsMouldId);
        List<MapsProductShopModule> modules = mapsProductShopModuleService.queryEntitys(param, 0L, 1L);
        Assert.isTrue(modules.size()>0," findModuleProducts is null by cmsid "+cmsMouldId);
        // 商品类型
        cmsDataOutput.setDataType(modules.get(0).getType());
        List<Long> lanIds=new ArrayList();
        if (StringUtils.isNotBlank(modules.get(0).getRelatedPromotion())) {
            for (String lanId : modules.get(0).getRelatedPromotion().split("[|]")) {
                if( lanId.trim().length()>0 )
                    lanIds.add(Long.parseLong(lanId.trim()));
            }
        }
        //lpids
        cmsDataOutput.setLandingIds(lanIds);
        List<CmsProdVoOut> cmsProList=new ArrayList();
        
        MapsModuleProduct proParam= new MapsModuleProduct();
        proParam.setModuleId(modules.get(0).getId());
        proParam.setOrderByClause("show_priority");
        List<MapsModuleProduct> proList = mapsModuleProductService.queryEntitys(proParam, 1L, 1000L);
        for(  MapsModuleProduct pro: proList )  {
            CmsProdVoOut cmsPro= new CmsProdVoOut();
            Assert.notNull(pro.getProductCode() , "findModuleProducts  ProductCode is null ");
           Long productId=ManagerUtils.queryProductByCode(pro.getProductCode()).getId();
           Long pmid=MobileBusyStockClientUtil.getProductInfoWithoutMerchant(provinceId, productId).getPmId();
           Assert.notNull(pmid,"findModuleProducts pmid is null  ");
           
           cmsPro.setPmInfoId(pmid);
           //团购id  
           cmsPro.setGrouponId(pro.getGrouponId());
           cmsPro.setProductId(productId);
           cmsPro.setCustomName(pro.getName());
           cmsPro.setCustomLink( pro.getProductUrl());
           cmsPro.setCustomPic(pro.getImgUrl());
           cmsProList.add(cmsPro);
        }
        
        cmsDataOutput.setProdData(cmsProList);
        }catch(Exception e){
            e.printStackTrace();
             return null;
        }
        return cmsDataOutput;
    }
	
}
