package com.yihaodian.hedwig;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.newheight.advertise.dolphin.client.service.UserBasedBiddingWordService;
import com.newheight.advertise.dolphin.client.service.impl.UserBasedBiddingWordServiceImpl;
import com.newheight.advertise.dolphin.client.service.support.ServiceContainer;
import com.newheight.relatedCategory.service.RelatedCategoryService;
import com.newheight.wireless.home.jptj.service.AppHomeRecommendService;
import com.yihaodian.architecture.hedwig.client.HedwigClientFactoryBean;
import com.yihaodian.front.shopping.client.utils.ClientUtils;
import com.yihaodian.front.shopping.client.utils.VoParamValidator;
import com.yihaodian.front.shopping.interfaces.service.RemoteCartService;
import com.yihaodian.front.shopping.interfaces.vo.input.cart.ShoppingGetCartInput;
import com.yihaodian.front.shopping.interfaces.vo.output.cart.ShoppingCart;
import com.yihaodian.front.shopping.interfaces.vo.output.cart.ShoppingCartBaseOutput;

public class PmsHedwigBeanFactory implements ApplicationContextAware{
	private final static Logger logger = LoggerFactory.getLogger(PmsHedwigBeanFactory.class);
	
	public final static long readtimeout=1000l;
	public final static long timeout=1000l;
			
	private volatile static ApplicationContext applicationContext;  
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		logger.info("加载spring配置");
//		com.newheight.advertise.dolphin.client.service.support.ServiceContainer.configure(timeout);
//		com.newheight.advertise.libra.client.service.support.ServiceContainer.configure(timeout);
		PmsHedwigBeanFactory.init(applicationContext);
	}
	
	/**
	 * fixed:  高危 - 通过一个实例方法更新静态属性  
	 */
	private static synchronized void init(ApplicationContext applicationContext){
		PmsHedwigBeanFactory.applicationContext = applicationContext;
	}
	
	
	
	/**
	 * 为您推荐
	 */
	private static AppHomeRecommendService appHomeRecommendService;
	
	public static AppHomeRecommendService getAppHomeRecommendService() {
		if(appHomeRecommendService==null){
			/**
			 * 原pms获取方式：
			 * appHomeRecommendService = AppHomeRecommendServiceClientPlugin.getAppHomeRecommendService();
			 */
			initAppHomeRecommendServiceAndSetting();
		}
		return appHomeRecommendService;
    }
	
	private static synchronized void initAppHomeRecommendServiceAndSetting() {
		if (appHomeRecommendService == null) {
			logger.info("初始化pms接口appHomeRecommendService");
//			Map<String, HedwigClientFactoryBean> hcs = applicationContext
//					.getBeansOfType(HedwigClientFactoryBean.class);
//			HedwigClientFactoryBean hf = hcs.get("&appHomeRecommendService");
//			hf.setTimeout(timeout);
//			hf.setReadTimeout(readtimeout);
			
			appHomeRecommendService = (AppHomeRecommendService) applicationContext.getBean("appHomeRecommendService");
			logger.info("初始化pms接口appHomeRecommendService："+appHomeRecommendService.toString());
		}
	}
	
	/**
	 * 精准化推荐类目
	 */
	private static RelatedCategoryService relatedCategoryService;
	
	public static RelatedCategoryService getRelatedCategoryService() {
		if(relatedCategoryService==null){
			/**
			 * 原pms获取方式：
			 * appHomeRecommendService = AppHomeRecommendServiceClientPlugin.getAppHomeRecommendService();
			 */
			initRelatedCategoryService();
		}
		return relatedCategoryService;
    }
	
	private static synchronized void initRelatedCategoryService() {
		if(relatedCategoryService==null){
			logger.info("初始化pms接口RelatedCategoryService");
			Map<String, HedwigClientFactoryBean> hcs = applicationContext
					.getBeansOfType(HedwigClientFactoryBean.class);
			HedwigClientFactoryBean hf = hcs.get("&remoteRelatedCategoryService");
			hf.setTimeout(timeout);
			hf.setReadTimeout(readtimeout);
			relatedCategoryService = (RelatedCategoryService)applicationContext.getBean("remoteRelatedCategoryService");
			logger.info("初始化pms接口RelatedCategoryService："+relatedCategoryService.toString());
		}
	}

	/**
	 * userBasedBiddingWordService
	 */
	private volatile static UserBasedBiddingWordService userBasedBiddingWordService;
	
	public static UserBasedBiddingWordService getUserBasedBiddingWordService() {
		if(userBasedBiddingWordService==null){
			initUserBasedBiddingWordService();
		}
		return userBasedBiddingWordService;
    }
	
	private static synchronized void initUserBasedBiddingWordService() {
		if (userBasedBiddingWordService == null) {
			logger.info("初始化ad-dolphin接口userBasedBiddingWordService");
			Map<String, HedwigClientFactoryBean> hcs = applicationContext
					.getBeansOfType(HedwigClientFactoryBean.class);
			HedwigClientFactoryBean hf = hcs.get("&remoteUserBasedBiddingWordService");
			if(hf!=null){
				hf.setTimeout(timeout);
				hf.setReadTimeout(readtimeout);
				userBasedBiddingWordService = (UserBasedBiddingWordService) applicationContext.getBean("userBasedBiddingWordService");
			}
			
			if(userBasedBiddingWordService==null){
				userBasedBiddingWordService = ServiceContainer.getInstance().getServiceWithSpecifiedTimeout(UserBasedBiddingWordServiceImpl.class, "remoteUserBasedBiddingWordService_HESSIAN", readtimeout, timeout);
			}
			if(userBasedBiddingWordService==null){
				userBasedBiddingWordService = ServiceContainer.getInstance().getService("userBasedBiddingWordService");
			}
			logger.info("初始化ad-dolphin接口userBasedBiddingWordService："+userBasedBiddingWordService.toString());
		}
	}
	
//	/**
//	 * 设置调用广告接口超时
//	 */
//	private static RemoteAverageYdtService remoteAverageYdtService = null;
//	
//	public static RemoteAverageYdtService getRemoteAverageYdtService() {
//		if(remoteAverageYdtService==null){
//			initRemoteAverageYdtService();
//		}
//		return remoteAverageYdtService;
//	}
//	
//	private static synchronized void initRemoteAverageYdtService() {
//		if (remoteAverageYdtService == null) {
//			logger.info("初始化广告(ad-dolphin)接口RemoteAverageYdtService");
//			Map<String, HedwigClientFactoryBean> hcs = applicationContext
//					.getBeansOfType(HedwigClientFactoryBean.class);
//			HedwigClientFactoryBean hf = hcs.get("&remoteAverageBiddingAdvService");
//			if(hf!=null){
//				hf.setTimeout(timeout);
//				hf.setReadTimeout(readtimeout);
//				remoteAverageYdtService = (RemoteAverageYdtService) applicationContext.getBean("remoteAverageBiddingAdvService");
//			}
//			logger.info("初始化广告(ad-dolphin)接口RemoteAverageYdtService："+remoteAverageYdtService.toString());
//		}
//	}
	
	
	/**
	 * 设置调用购物车接口超时
	 */
	private static RemoteCartService cartService = null;
	
	public static RemoteCartService getRemoteCartService() {
		if(cartService==null){
			initRemoteCartService();
		}
		return cartService;
	}
	
	private static synchronized void initRemoteCartService() {
		if (cartService == null) {
			logger.info("初始化购物车接口接口cartService");
			Map<String, HedwigClientFactoryBean> hcs = applicationContext
					.getBeansOfType(HedwigClientFactoryBean.class);
			HedwigClientFactoryBean hf = hcs.get("&cart-remote-service");
			hf.setTimeout(4000L);
			hf.setReadTimeout(4000L);
			cartService = (RemoteCartService) applicationContext.getBean("cart-remote-service");
			logger.info("初始化购物车接口frontShoppingClient："+cartService.toString());
		}
	}
	
	public static ShoppingCartBaseOutput queryCartItemsForAppPromotionPage(ShoppingGetCartInput input) {
		VoParamValidator.validateInput(input);
		input.setPoolName(ClientUtils.getLocalPoolName());
		return getRemoteCartService().queryCartItemsForAppPromotionPage(input);
	}
	
    public static ShoppingCart getCart(ShoppingGetCartInput input) {
        VoParamValidator.validateInput(input);
        input.setPoolName(ClientUtils.getLocalPoolName());
        return getRemoteCartService().getCart(input);
    }
	
}
