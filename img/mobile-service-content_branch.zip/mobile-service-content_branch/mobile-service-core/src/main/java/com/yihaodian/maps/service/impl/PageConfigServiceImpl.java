package com.yihaodian.maps.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yihaodian.mobile.backend.maps.model.PageConfigEntity;
import com.yihaodian.mobile.service.dal.backend.maps.dao.PageConfigDao;
import com.yihaodian.mobile.service.map.spi.PageConfigService;

@Service
public class PageConfigServiceImpl implements PageConfigService {
	@Resource
	private PageConfigDao pageConfigDao;
	/**
	 * 根据id获得全局配置详细信息
	 */
	@Override
	public PageConfigEntity getEntity(Long configId) {
		PageConfigEntity pageConfigEntity = pageConfigDao.getPageConfigDetail(configId);
		return pageConfigEntity;
	}

	/**
	 * 新增或修改全局配置
	 */
	@Override
	public PageConfigEntity saveOrUpdate(PageConfigEntity pageConfig) {
		PageConfigEntity pageConfigEntity= pageConfigDao.saveOrUpdatePageConfig(pageConfig);
		return pageConfigEntity;
	}

}
