/**
 * 
 */
package com.yihaodian.mobile.backend.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.yihaodian.mobile.backend.model.Area;
import com.yihaodian.mobile.backend.model.Data;
import com.yihaodian.mobile.backend.model.DataLayout;
import com.yihaodian.mobile.backend.model.Platform;
import com.yihaodian.mobile.backend.model.Site;
import com.yihaodian.mobile.backend.model.ViewSuite;
import com.yihaodian.mobile.backend.model.ViewTemplate;
import com.yihaodian.mobile.framework.common.log.annotation.LogAnnotation;

// TODO: Auto-generated Javadoc
/**
 * <!-- begin-UML-doc --> <!-- end-UML-doc -->.
 *
 * @author luke
 * @generated            "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class DataManager {

	/** The area list. */
	private ArrayList<Area> areaList = new ArrayList<Area>();
	
	/** The site list. */
	private ArrayList<Site> siteList = new ArrayList<Site>();
	
	/** The platform list. */
	private ArrayList<Platform> platformList = new ArrayList<Platform>();
	
	/** The layout list. */
	private ArrayList<DataLayout> layoutList = new ArrayList<DataLayout>();
	
	/** The template list. */
	private ArrayList<ViewTemplate> templateList = new ArrayList<ViewTemplate>();
	
	/** The view suites. */
	private HashMap<String, ViewSuite> viewSuites = new HashMap<String, ViewSuite>();
	
	/** The data list. */
	private HashMap<Integer,Data> dataList = new HashMap<Integer,Data>();
	
	/** The instance. */
	private static DataManager instance;

	/**
	 * Instantiates a new data manager.
	 */
	private DataManager() {
		// init();

	}

	/**
	 * Gets the data manager.
	 *
	 * @return the data manager
	 */
	@LogAnnotation
	public static synchronized DataManager getDataManager() {
		if (instance == null) {
			instance = new DataManager();
		}
		return instance;
	}
	
	/**
	 * Gets the view templates.
	 *
	 * @return the view templates
	 */
	public List<ViewTemplate> getViewTemplates() {
		return templateList;
	}

	/**
	 * <!-- begin-UML-doc --> <!-- end-UML-doc -->.
	 *
	 * @return the sites
	 * @generated            "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public List<Site> getSites() {
		return siteList;
	}

	/**
	 * Gets the site.
	 *
	 * @param id the id
	 * @return the site
	 */
	@LogAnnotation
	public Site getSite(int id) {
		for (Site site : siteList) {
			if (site!=null&&site.getId()!=null&&site.getId() == id)
				return site;
		}
		return null;
	}

	/**
	 * Gets the site.
	 *
	 * @param name the name
	 * @return the site
	 */
	@LogAnnotation
	public Site getSite(String name) {
		for (Site site : siteList) {
			if (site.getName()!=null&&site.getName().equals(name))
				return site;
		}
		return null;
	}

	/**
	 * <!-- begin-UML-doc --> <!-- end-UML-doc -->.
	 *
	 * @return the areaes
	 * @generated            "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public List<Area> getAreaes() {
		return areaList;
	}

	/**
	 * <!-- begin-UML-doc --> <!-- end-UML-doc -->.
	 *
	 * @return the platforms
	 * @generated            "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public List<Platform> getPlatforms() {
		return platformList;
	}

	/**
	 * <!-- begin-UML-doc --> <!-- end-UML-doc -->.
	 *
	 * @param id the id
	 * @return the platform
	 * @generated            "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	@LogAnnotation
	public Platform getPlatform(int id) {
		for (Platform platform : platformList) {
			if (platform.getId()!=null && platform.getId() == id)
				return platform;
		}
		return null;
	}

	/**
	 * Gets the platform.
	 *
	 * @param name the name
	 * @return the platform
	 */
	@LogAnnotation
	public Platform getPlatform(String name) {
		for (Platform platform : platformList) {
			if (platform.getName()!=null&&platform.getName().equals(name))
				return platform;
		}
		return null;
	}

	/**
	 * Gets the data.
	 *
	 * @param id the id
	 * @return the data
	 */
	@LogAnnotation
	public Data getData(int id){
		return dataList.get(id);
	}
	
	/**
	 * Put data.
	 *
	 * @param id the id
	 * @param data the data
	 * @return the data
	 */
	public Data putData(int id,Data data){
		return dataList.put(id, data);
	}
	
	/**
	 * <!-- begin-UML-doc --> <!-- end-UML-doc -->.
	 *
	 * @param id the id
	 * @return the area
	 * @generated            "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Area getArea(int id) {
		for (Area area : areaList) {
			if (area.getId()!=null && area.getId() == id)
				return area;
		}
		return null;
	}

	/**
	 * Gets the area.
	 *
	 * @param name the name
	 * @return the area
	 */
	@LogAnnotation
	public Area getArea(String name) {
		for (Area area : areaList) {
			if (area.getName()!=null && area.getName().equals(name))
				return area;
		}
		return null;
	}

	/**
	 * Gets the view suite.
	 *
	 * @param site the site
	 * @param area the area
	 * @param platform the platform
	 * @return the view suite
	 */
	@LogAnnotation
	public ViewSuite getViewSuite(Site site, Area area, Platform platform) {
		String key = "" + site.getId() + "_" + area.getId() + "_"
				+ platform.getId();
		if (!viewSuites.containsKey(key)) {
			ViewSuite vs = new ViewSuite();
			vs.setId(generateId());
			vs.setArea(area);
			vs.setPlatform(platform);
			vs.setSite(site);
			viewSuites.put(key, vs);
			// createViewTemplate(vs);

		}
		return viewSuites.get(key);
	}
	
	/**
	 * Gets the view template.
	 *
	 * @param type the type
	 * @return the view template
	 */
	@LogAnnotation
	public ViewTemplate getViewTemplate(Integer type) {
		for (ViewTemplate vt : DataManager.getDataManager().getViewTemplates()) {
			if (vt.getType()!=null && vt.getType().intValue()==type)
				return vt;
		}
		return null;
	}

	/** The count. */
	private static int count = 0;

	/**
	 * Generate id.
	 *
	 * @return the int
	 */
	public static int generateId() {
		return count++;
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		
	}

	/**
	 * Parses the date.
	 *
	 * @param dateString the date string
	 * @return the date
	 */
	@LogAnnotation
	public static Date parseDate(String dateString) {
		try {
			final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return sdf.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Parses the date to string.
	 *
	 * @param date the date
	 * @return the string
	 */
	
	@LogAnnotation
	public static String parseDateToString(Date date) {
		try {
			final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return sdf.format(date);
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}
	@LogAnnotation
	/**
	 * Creates the platform.
	 *
	 * @param platform the platform
	 */
	public void createPlatform(Platform platform) {
		platformList.add(platform);

	}

	/**
	 * Creates the area.
	 *
	 * @param area the area
	 */
	@LogAnnotation
	public void createArea(Area area) {
		areaList.add(area);
	}

	/**
	 * Creates the site.
	 *
	 * @param site the site
	 */
	@LogAnnotation
	public void createSite(Site site) {
		siteList.add(site);

	}
}