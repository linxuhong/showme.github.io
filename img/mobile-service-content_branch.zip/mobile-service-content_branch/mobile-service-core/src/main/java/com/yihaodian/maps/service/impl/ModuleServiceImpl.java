package com.yihaodian.maps.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yihaodian.mobile.backend.maps.model.BaseModuleEntity;
import com.yihaodian.mobile.backend.maps.model.ModuleEntity;
import com.yihaodian.mobile.backend.maps.vo.ModuleContentVO;
import com.yihaodian.mobile.service.dal.backend.maps.dao.ModuleDao;
import com.yihaodian.mobile.service.map.spi.ModuleService;
@Service
public class ModuleServiceImpl implements ModuleService {
	@Resource
	private ModuleDao moduleDao;
	/**
	 * 使用活动页id查询所有相关有效的栏位信息
	 */
	@Override
	public List<ModuleContentVO> findModuleVOByPageId(long id) {
		//1.依据关联表ref_p_m,按顺序获取有效的栏位信息
		List<ModuleContentVO> allVO = new ArrayList<ModuleContentVO>();
		ModuleContentVO contentVO = null;
		List<Long> mIds = moduleDao.findREFPMByPageId(id);
		List<ModuleEntity> list = moduleDao.findVaildModuleCfgByIds(mIds);
		if(list!=null&&list.size()>0){
			//排序
			List<ModuleEntity> orderList = new ArrayList<ModuleEntity>();
			Map<Long,ModuleEntity> mMaps = new HashMap<Long, ModuleEntity>();
			for (ModuleEntity moduleCfg : list) {
				mMaps.put(moduleCfg.getId(), moduleCfg);
			}
			for (Long mid : mIds) {
				if(mMaps.containsKey(mid)){
					orderList.add(mMaps.get(mid));
				}
			}
			
			//通过 ModuleEntity 和 具体的栏位信息  来拼装 ModuleContentVO
			Long mId=null;
			Integer type=null;
			BaseModuleEntity module =null;
			for (ModuleEntity moduleCfg : orderList) {
				contentVO = new ModuleContentVO();
				contentVO.setModuleCfg(moduleCfg);
				mId = moduleCfg.getInstanceId();
				type = moduleCfg.getInstanceType();
				if(mId!=null&&type!=null){
					//2通过遍历栏位ModuleEntity查找 具体的栏位信息：类型可以通过BaseModuleEntity来查找
					module = moduleDao.getValidModuleEntity(mId,type);
					if(module!=null){
						contentVO.setModule(module);
					}
				}
				allVO.add(contentVO);
			}
		}
		return allVO;
	}

	
	

	/**
	 *  新增或修改整个栏位的信息（包括配置）
	 *  1.注意以配置为主，如果配置下面没有module 则不管，如果下面有对应module 则需要级联创建或更新
	 *  2.对应module 需要注意栏位类型的定位
	 *  3.已产生的module数据可能因为类型变更而形成垃圾数据暂时不去删除
	 */
	@Override
	public ModuleContentVO saveOrUpdate(ModuleContentVO moduleContentVO) {
		ModuleContentVO contentVO =new ModuleContentVO();
		ModuleEntity moduleCfg = moduleContentVO.getModuleCfg();
		BaseModuleEntity module = moduleContentVO.getModule();
		
		//新增或修改栏位实体
		module = moduleDao.saveOrUpdateModuleEntity(module);
		
		if(module!=null){
			moduleCfg.setInstanceId(module.getId());
			moduleCfg.setInstanceType(module.getType());
		}
		
		//新增或修改栏位配置
		moduleCfg = moduleDao.saveOrUpdateModuleCfg(moduleCfg);
		
		contentVO.setModuleCfg(moduleCfg);
		contentVO.setModule(module);
		return contentVO;
	}

	
	
	
	/**
	 * 逻辑删除一个栏位:修改valid
	 */
	@Override
	public boolean invalidModuleCfg(Long moduleCfgId) {
		boolean str = false;
		if(moduleCfgId !=null){
			moduleDao.updateModuleValid(moduleCfgId);
			str = true;
		}
		return str;
	}



	/**
	 * 设置级联关系
	 */
	@Override
	public void insertRefPM(Long id, Long pageId, int orderNum) {
		moduleDao.insertRefPM(id, pageId,  orderNum);
	}
	@Override
	public void deleteModuleCfg(Long id) {
		if(id!=null){
			moduleDao.deleteModuleCfg(id);
		}
	}
	@Override
	public void deleteModule(Long id, int type) {
		moduleDao.deleteModule(id,type);
	}
	@Override
	public void deleteModuleRefPMByPageId(Long pageId) {
		if(pageId !=null){
			moduleDao.deleteModuleRefPMByPageId(pageId);
		}
	}
}
