package com.yihaodian.mobile.app;

import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.yihaodian.mobile.app.domain.AppActivationStatService;
import com.yihaodian.mobile.backend.app.entity.AppActivation;
import com.yihaodian.mobile.backend.app.entity.AppActivationExample;
import com.yihaodian.mobile.backend.app.vo.JdActivationDataVO;
import com.yihaodian.mobile.backend.app.vo.ServerInfoVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.service.app.spi.AppActivationService;
import com.yihaodian.mobile.service.common.business.util.httpclient.HttpClientUtil;
import com.yihaodian.mobile.service.common.util.DateUtil;
import com.yihaodian.mobile.service.core.util.SwitchUtil;
import com.yihaodian.mobile.service.dal.app.dao.AppActivationDAO;
import com.yihaodian.mobile.service.domain.business.emuns.CommonResultCode;
import com.yihaodian.mobile.vo.system.AppFunctionSwitchVO;

@Service("appActivationService")
public class AppActivationServiceImpl implements AppActivationService {
	private static final Logger logger = LoggerFactory.getLogger(AppActivationServiceImpl.class);
	private static final String JD_CPA_APPNAME = "yhdcpa";
	private static String JD_CPA_URL = "http://jdeye.m.jd.com/bypass";
	
	@Resource(name = "logspool")
	private ThreadPoolTaskExecutor logpool;
	
	@Autowired
	private AppActivationDAO appActivationDAO;
	
	@Autowired
	private AppActivationStatService appActivationStatService;
	
	@Override
	public Result jdActivationDataReceive(final String jdData, final String deviceCode, final String clientIp, 
			final String channelId, final Integer provinceId, final Long appCallTime) {
		Result result = new ResultModel();
		
		try {
			//1. 接收数据，返回result
			if (StringUtils.isBlank(jdData) || StringUtils.isBlank(deviceCode) || StringUtils.isBlank(clientIp)
					|| StringUtils.isBlank(channelId) || provinceId==null || appCallTime==null) {
				result.setSuccess(false);
				result.setBaseResultCode(CommonResultCode.PARAMS_EXCEPTION);
				return result;
			}

			//2. 异步线程处理数据，反作弊逻辑
			logpool.execute(new Runnable() {
				@Override
				public void run() {
					try {
						int receiveCount=1, sendSuccessCount=0, error4xxCount=0, 
								error5xxCount=0, errorOtherCount=0;
						
						//2.1 检查激活表数据，如存在则说明已经被激活过
						AppActivationExample example = new AppActivationExample();
						example.createCriteria().andDevicecodeEqualTo(deviceCode);
						int count = appActivationDAO.countByExample(example);
						//2.2 如果不存在，则调用京东反作弊http接口，
						if (count<=0) {
							//2.3 插入反作弊数据
							AppActivation activation = new AppActivation();
							activation.setAppcalltime(appCallTime);
							activation.setDevicecode(deviceCode);
							activation.setTrackerId(channelId);
							appActivationDAO.insert(activation);
							
							//2.4 call jd cpa for risk check
							JdActivationDataVO dataVO = new JdActivationDataVO();
							dataVO.setClientinfo(jdData);
							dataVO.setAppname(JD_CPA_APPNAME);
							ServerInfoVO serverInfo = new ServerInfoVO();
							serverInfo.setAppcalltime(DateUtil.parseDateToString(new Date(appCallTime*1000L)));
							serverInfo.setChannelid(channelId);
							serverInfo.setClientip(clientIp);
							serverInfo.setDevicecode(deviceCode);
							serverInfo.setTime(DateUtil.parseDateToString(new Date()));
							serverInfo.setProvince(provinceId); // fill province with id
							dataVO.setServerinfo(serverInfo);
							Map<String, String> params = Maps.newHashMap();
							params.put("body", JSON.toJSONString(dataVO));
							AppFunctionSwitchVO propCpaUrl = SwitchUtil.getAppSwitchVoByType("JD_URL");
							if (propCpaUrl!=null && StringUtils.isNotBlank(propCpaUrl.getFunctionValue())) {
								JD_CPA_URL = propCpaUrl.getFunctionValue();
							}
							HttpResponse response = HttpClientUtil.doPost(JD_CPA_URL, params);
							sendSuccessCount++;
							if (response==null || response.getStatusLine()==null) {
								errorOtherCount++;
							} else {
								int statusCode = response.getStatusLine().getStatusCode();
								if (statusCode==200) {
									boolean jdSuccess = false;
									HttpEntity entity = response.getEntity();
						            if (entity != null) {
						                String responseBody = EntityUtils.toString(entity);
						        		if (StringUtils.isNotBlank(responseBody)) {
											JSONObject respObj = JSON.parseObject(responseBody);
											Integer code = respObj.getInteger("code");
											if (code!=null && code==0) { // {"code":0} means success
												jdSuccess=true;
											} 
										}
						            }
						            if (!jdSuccess) {
						            	logger.error("JD http 200 response error with params "+params);
										errorOtherCount++;
						            }
								} else if (statusCode>=400 && statusCode<500) {
									error4xxCount++;
								} else if (statusCode>=500 && statusCode<600) {
									error5xxCount++;
								} else {
									errorOtherCount++;
								}
							}
						} // else JD device already activated
						appActivationStatService.saveOrUpdateStat(new Date(), receiveCount, sendSuccessCount, error4xxCount, error5xxCount, errorOtherCount, 0);
					} catch (Exception e) {
						logger.error("Exception running task for jdActivationDataReceive", e);
					}
				}
			});
			
			result.setSuccess(true);
			result.setResultDesc("success");
			return result;
		} catch (Exception e) {
			logger.error("Exception in jdActivationDataReceive", e);
			result.setSuccess(false);
			result.setBaseResultCode(CommonResultCode.SYSTEM_EXCEPTION);
			result.setResultDesc(e.getMessage());
			return result;
		}
	}

}
