package com.yihaodian.mobile.app.domain;

import java.io.File;


public interface GdtAdsService {
	
	/**
	 * 自定义人群创建接口
	 * @param advertiserId
	 * @param appKey 
	 * @param audienceName
	 * @param payloadFile
	 * @return
	 */
	Long createTargetingAudience(Long advertiserId, String appKey, String audienceName, File payloadFile);
	
	/**
	 * 自定义人群更新接口
	 * @param advertiserId
	 * @param appKey
	 * @param audienceId
	 * @param payloadFile
	 * @return
	 */
	void updateTargetingAudience(Long advertiserId, String appKey, Long audienceId, File payloadFile);
}
