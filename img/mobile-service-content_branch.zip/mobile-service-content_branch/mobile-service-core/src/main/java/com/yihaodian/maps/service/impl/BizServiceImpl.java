package com.yihaodian.maps.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.yihaodian.mobile.backend.maps.model.biz.BaseBizEntity;
import com.yihaodian.mobile.service.dal.backend.maps.dao.BizDao;
import com.yihaodian.mobile.service.map.spi.BizService;
@Service
@SuppressWarnings("rawtypes")
public class BizServiceImpl implements BizService {
	@Resource
	private BizDao bizDao;
	@Override
	public Object saveOrUpdateEntity(Object entity) {
		if(entity!=null){
			return bizDao.saveOrUpdateEntity(entity);
		}
		return null;
	}
	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public Object getEntity(Class cls,Long id) {
		if(id!=null){
			return bizDao.getEntity(cls,id);
		}
		return null;
	}
	@Override
	public boolean deleteEntity(Class cls,Long id) {
		if(id!=null){
			return bizDao.deleteEntity(cls,id);
		}
		return false;
	}
    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public List findRefEntity(Class cls, Long id) {
       
        return bizDao.findEntitysByRefId(cls, id);
    }
    @Override
    public void updateEntityOrderNum(Object entity) {
          bizDao.updateEntityOrderNum( entity);
    }
    
    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public void saveBizEntitys(List entityList) {
        //validation
        for( Object entity:entityList  ){
           if(((BaseBizEntity)entity).getId()!=null ){
               ((BaseBizEntity)entity).setId(null);
           }
           
        }
        bizDao.deleteEntitysByModuleId(entityList.get(0));
        for( Object entity:entityList  ){
            bizDao.saveOrUpdateEntity(entity);
        }
        
    }
	@Override
	public Long getCouponActivityId(Long mId, String checkCode) {
		return bizDao.getCouponActivityId(mId,checkCode);
	}
	@Override
	public Long getCouponActivityIdFromShop(Long shopId, String checkCode) {
		return bizDao.getCouponActivityIdFromShop(shopId,checkCode);
	}
    
}
