package com.yihaodian.mobile.app.domain.impl;

import gdt.dmp.DmpDataProto;
import gdt.dmp.DmpDataProto.DmpData;
import gdt.dmp.DmpDataProto.DmpData.VerticalType;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.protobuf.ByteString;
import com.yihaodian.mobile.app.domain.GdtDmpService;
import com.yihaodian.mobile.backend.app.dmp.CommonData;
import com.yihaodian.mobile.backend.app.dmp.IdLocator;
import com.yihaodian.mobile.backend.app.dmp.Payload;
import com.yihaodian.mobile.backend.app.enums.DataFormatEnum;
import com.yihaodian.mobile.backend.app.enums.LocatorTypeEnum;
import com.yihaodian.mobile.backend.app.enums.VerticalTypeEnum;
import com.yihaodian.mobile.service.common.business.util.httpclient.HttpClientUtil;
import com.yihaodian.mobile.service.common.util.MD5Support;

@Service("gdtDmpService")
public class GdtDmpServiceImpl implements GdtDmpService {
	
	private static final Logger logger = LoggerFactory.getLogger(GdtDmpServiceImpl.class);
	
	private static final String RT_ADD_URL = "https://api.e.qq.com/dmp/v1/rt_data_source/add";
	private static final String RT_APPEND_URL = "https://api.e.qq.com/dmp/v1/rt_data_source/append";
	private static final String FILE_ADD_URL = "https://api.e.qq.com/dmp/v1/file_data_source/add";
	private static final String FILE_APPEND_URL = "https://api.e.qq.com/dmp/v1/file_data_source/append";
	private static final String FILE_DMP_PATH = "file.dmp";
	private static final String ZIP_FILE_DMP_PATH = "file";
	
	protected Map<String, String> buildDmpHttpHeaders() {
		Map<String, String> headers = Maps.newHashMap();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", "Bearer ");
		
		return headers;
	}

	@Override
	public Long addRtDataSource(Long memberId, String dataSourceName) {
		try {
			Map<String, String> params = Maps.newHashMap();
			params.put("member_id", memberId.toString());
			params.put("data_source_name", dataSourceName);
			HttpResponse response = HttpClientUtil.doPost(RT_ADD_URL, params, buildDmpHttpHeaders());
			if (response!=null && response.getStatusLine()!=null && response.getStatusLine().getStatusCode()==200) {
				HttpEntity entity = response.getEntity();
	            if (entity != null) {
	            	String responseBody = EntityUtils.toString(entity);
	            	JSONObject rtJson = JSON.parseObject(responseBody);
	            	Integer code = rtJson.getInteger("code");
	            	if (code!=null && code==0) {
	            		JSONObject rtData = rtJson.getJSONObject("data");
	            		return rtData.getLong("data_source_id");
	            	}
	            }
			}
		} catch (Exception e) {
			logger.error("Exception in addRtDataSource", e);
		}
		
		return null;
	}

	@Override
	public void appendRtData(Long memberId, Long dataSourceId, List<Payload> payload) {
		try {
			Map<String, String> params = Maps.newHashMap();
			params.put("member_id", memberId.toString());
			params.put("data_source_id", dataSourceId.toString());
			params.put("data_format", DataFormatEnum.JSON.name());
			params.put("payload", JSON.toJSONString(payload));
			HttpResponse response = HttpClientUtil.doPost(RT_APPEND_URL, params, buildDmpHttpHeaders());
			if (response!=null && response.getStatusLine()!=null && response.getStatusLine().getStatusCode()==200) {
				HttpEntity entity = response.getEntity();
	            if (entity != null) {
	            	String responseBody = EntityUtils.toString(entity);
	            	JSONObject rtJson = JSON.parseObject(responseBody);
	            	Integer code = rtJson.getInteger("code");
	            	if (code!=null) {
	            		switch (code) {
	            		case 0:
	            			logger.info("Success in appendRtData for member "+memberId+" data source "+dataSourceId);
	            			break;
	            		case 1:
	            			logger.warn("Partial success in appendRtData for member "+memberId+" data source "+dataSourceId);
	            			break;
	            		case 2:
	            			logger.error("All Failed in appendRtData for member "+memberId+" data source "+dataSourceId);
	            			break;
	            		default:
	            			logger.error("Failed in appendRtData for member "+memberId+" data source "+dataSourceId+" code: "+code);
	            			break;
	            		}
	            	}
	            }
			}
		} catch (Exception e) {
			logger.error("Exception in appendRtData", e);
		}
	}

	@Override
	public Long addFileDataSource(Long memberId, String dataSourceName, List<Payload> payloads) {
		try {
			File file = buildFileFromPayload(payloads);
			
			Map<String, String> params = Maps.newHashMap();
			params.put("member_id", memberId.toString());
			params.put("data_source_name", dataSourceName);
			params.put("data_format", DataFormatEnum.PB.name());
			String responseBody = HttpClientUtil.doMultipartPost(FILE_ADD_URL, params, buildDmpHttpHeaders(), file);
			if (responseBody!=null) {
				JSONObject rtJson = JSON.parseObject(responseBody);
		    	Integer code = rtJson.getInteger("code");
		    	if (code!=null && code==0) {
		    		JSONObject rtData = rtJson.getJSONObject("data");
		    		return rtData.getLong("data_source_id");
		    	}
			}
		} catch (IOException e) {
			logger.error("IOException in addFileDataSource", e);
		}
		
		return null;
	}
	
	@Override
	public void appendFileData(Long memberId, Long dataSourceId, List<Payload> payloads) {
		try {
			File file = buildFileFromPayload(payloads);
			
			Map<String, String> params = Maps.newHashMap();
			params.put("member_id", memberId.toString());
			params.put("data_source_id", dataSourceId.toString());
			params.put("data_format", DataFormatEnum.PB.name());
			String responseBody = HttpClientUtil.doMultipartPost(FILE_APPEND_URL, params, buildDmpHttpHeaders(), file);
			if (responseBody!=null) {
				JSONObject rtJson = JSON.parseObject(responseBody);
		    	Integer code = rtJson.getInteger("code");
		    	if (code!=null) {
            		switch (code) {
            		case 0:
            			logger.info("Success in appendFileData for member "+memberId+" data source "+dataSourceId);
            			break;
            		case 1:
            			logger.warn("Partial success in appendFileData for member "+memberId+" data source "+dataSourceId+" response: "+responseBody);
            			break;
            		case 2:
            			logger.error("All Failed in appendFileData for member "+memberId+" data source "+dataSourceId);
            			break;
            		default:
            			logger.error("Failed in appendFileData for member "+memberId+" data source "+dataSourceId+" response: "+responseBody);
            			break;
            		}
            	}
			}
		} catch (IOException e) {
			logger.error("IOException in appendFileData", e);
		}
	}
	
	private File buildFileFromPayload(List<Payload> payloads) throws IOException {
		FileOutputStream dmpOutput = new FileOutputStream(FILE_DMP_PATH);
		for (Payload payload: payloads) {
			DmpDataProto.IdLocator.Builder idLocator = DmpDataProto.IdLocator.newBuilder();
			idLocator.setType(DmpDataProto.IdLocator.Type.HASH_IMEI);
			idLocator.setId(ByteString.copyFromUtf8(payload.getIdLocator().getId()));
			DmpDataProto.CommonData.Builder commonData = DmpDataProto.CommonData.newBuilder();
			commonData.setTimestamp((int)new Date().getTime()/1000);
			DmpData dmpData = DmpData.newBuilder().setCommonData(commonData)
					.setIdLocator(idLocator).setVerticalType(VerticalType.VERTICAL_GENERAL_EC)
					.build();
			dmpData.writeDelimitedTo(dmpOutput);
		}
		dmpOutput.close();
		
		FileOutputStream fos = new FileOutputStream(ZIP_FILE_DMP_PATH);
		ZipOutputStream zos = new ZipOutputStream(fos);
		ZipEntry ze= new ZipEntry(FILE_DMP_PATH);
		zos.putNextEntry(ze);
		FileInputStream in = new FileInputStream(FILE_DMP_PATH);
		int len;
		byte[] buffer = new byte[1024];
		while ((len = in.read(buffer)) > 0) {
			zos.write(buffer, 0, len);
		}
		in.close();
		zos.closeEntry();
		zos.close();
		
		return new File(ZIP_FILE_DMP_PATH);
	}
	
	public static void main(String[]args) {
		GdtDmpService dmpService = new GdtDmpServiceImpl();
		Long memberId = 10000L;
		Long dataSourceId = 1000L;
		
		List<Payload> payload = Lists.newArrayList();
		Payload pay = new Payload();
		pay.setVerticalType(VerticalTypeEnum.VERTICAL_GENERAL_EC);
		CommonData commonData = new CommonData();
		commonData.setTimestamp(new Date().getTime()/1000);
		pay.setCommonData(commonData);
		IdLocator idLocator = new IdLocator();
		idLocator.setId(MD5Support.MD5(StringUtils.lowerCase("A000002C9060F7"))); //imei：首先对用户的imei号进行全部小写，然后对全部小写的imei号进行标准的md5操作。
		idLocator.setType(LocatorTypeEnum.IMEI);
		pay.setIdLocator(idLocator);
		payload.add(pay);
		dmpService.appendRtData(memberId, dataSourceId, payload);
	}

}
