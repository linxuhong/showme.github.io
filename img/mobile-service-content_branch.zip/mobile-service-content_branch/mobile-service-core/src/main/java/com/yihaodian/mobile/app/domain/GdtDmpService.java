package com.yihaodian.mobile.app.domain;

import java.util.List;

import com.yihaodian.mobile.backend.app.dmp.Payload;


public interface GdtDmpService {
	/**
	 * 实时数据源创建接口
	 * @param memberId
	 * @param dataSourceName
	 * @return
	 */
	Long addRtDataSource(Long memberId, String dataSourceName);
	
	/**
	 * 实时数据源追加接口
	 * @param memberId
	 * @param dataSourceId
	 * @param payload limited to max size 100
	 */
	void appendRtData(Long memberId, Long dataSourceId, List<Payload> payload);
	
	/**
	 * 文件数据源创建接口
	 * @param memberId
	 * @param dataSourceName
	 * @param payloads
	 * @return
	 */
	Long addFileDataSource(Long memberId, String dataSourceName, List<Payload> payloads);
	
	/**
	 * 文件数据源追加接口
	 * @param memberId
	 * @param dataSourceId
	 * @param payloads
	 */
	void appendFileData(Long memberId, Long dataSourceId, List<Payload> payloads);
}
