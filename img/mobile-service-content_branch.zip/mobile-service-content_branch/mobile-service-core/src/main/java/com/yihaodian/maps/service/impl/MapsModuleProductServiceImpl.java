package com.yihaodian.maps.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yihaodian.mobile.backend.maps.model.MapsModuleProduct;
import com.yihaodian.mobile.service.dal.backend.maps.dao.MapsModuleProductDAO;
import com.yihaodian.mobile.service.map.spi.MapsModuleProductService;

@Service
public class MapsModuleProductServiceImpl implements MapsModuleProductService {

	@Resource
	private MapsModuleProductDAO mapsModuleProductDAO;
	
	
    //批量删除
    @Override
    public void delEntitys(List<MapsModuleProduct> mapsModuleProducts) {
          mapsModuleProductDAO.delEntitys(mapsModuleProducts);
    }




    //按条件查询分页
    @Override
    public List<MapsModuleProduct> queryEntitys(MapsModuleProduct mapsModuleProduct, Long pageStart,
                                                Long pageSize) {
        return mapsModuleProductDAO.queryEntitys(mapsModuleProduct,pageStart,pageSize);
    }




    @Override
    public Long countEntitys(MapsModuleProduct mapsModuleProduct) {
         return mapsModuleProductDAO.countEntitys(mapsModuleProduct);
    }




    /**
	 * 批量新增
     * @throws Exception 
	 */
	@Override
	public void batchInsert(List<MapsModuleProduct> list) throws Exception {
		if(list != null && list.size() > 0){
			mapsModuleProductDAO.batchInsert(list);
		}
	}

	/**
	 * 批量更新
	 * @throws Exception 
	 */
	@Override
	public void updateEntitys(List<MapsModuleProduct> list) throws Exception {
		mapsModuleProductDAO.updateEntitys(list);
	}

	/**
	 * 根据条件获取count数
	 */
	@Override
	public Long getCountByCondition(MapsModuleProduct mapsModuleProduct) {
		return mapsModuleProductDAO.getCountByCondition(mapsModuleProduct);
	}

}
