package com.yihaodian.mobile.backend.service;

import java.util.Calendar;
import java.util.HashMap;

import com.yihaodian.mobile.backend.model.Advertisement;
import com.yihaodian.mobile.backend.model.Area;
import com.yihaodian.mobile.backend.model.BannerImageADLayout;
import com.yihaodian.mobile.backend.model.CouponListActivity;
import com.yihaodian.mobile.backend.model.DailyXProductActivityLayout;
import com.yihaodian.mobile.backend.model.FloorADLayout;
import com.yihaodian.mobile.backend.model.GrouponProductListActivity;
import com.yihaodian.mobile.backend.model.Image;
import com.yihaodian.mobile.backend.model.List2ColumnProductActivityLayout;
import com.yihaodian.mobile.backend.model.List2ColumnTitleADLayout;
import com.yihaodian.mobile.backend.model.ListProductActivityLayout;
import com.yihaodian.mobile.backend.model.MainEntryADLayout;
import com.yihaodian.mobile.backend.model.ModelFilterOption;
import com.yihaodian.mobile.backend.model.Platform;
import com.yihaodian.mobile.backend.model.ProductListActivity;
import com.yihaodian.mobile.backend.model.PromotionActivity;
import com.yihaodian.mobile.backend.model.PromotionAdvertisement;
import com.yihaodian.mobile.backend.model.SeckillActivity;
import com.yihaodian.mobile.backend.model.Site;
import com.yihaodian.mobile.backend.model.SmallImage2ColumnADLayout;
import com.yihaodian.mobile.backend.model.TitleOnlyADLayout;
import com.yihaodian.mobile.backend.model.View;
import com.yihaodian.mobile.backend.model.ViewDataContainer;
import com.yihaodian.mobile.backend.model.ViewSuite;
import com.yihaodian.mobile.backend.model.ViewTemplate;
import com.yihaodian.mobile.backend.model.WeeklyShowLayout;
import com.yihaodian.mobile.framework.common.log.annotation.LogAnnotation;

public class FakeDataManager {
	//private SiteDao siteDao;
	
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args){
		//System.out.println(createFakeData());
//		JsonObject obj=new InterfaceService().getBannerData("", 1 ,1);
//		JsonArray array=obj.get("data").getAsJsonArray();
//		for(int i=0;i<array.size();i++){
//			System.out.println(array.get(i).getAsJsonObject().get("linktype"));
//		}
		System.out.println(createFakeData());
		
		BannerImageADLayout banner=new BannerImageADLayout(1);
		banner.setImgHeight(123);
		banner.setImgSize(12);
		banner.setImgWidth(123);
	    banner.setParameters(banner.getParameters());
	    System.out.println(banner.getImgSize());
	}
	
	/**
	 * 拷贝页面到其他区域平台
	 * @param vs
	 * @param targetSite
	 * @param targetPlatform
	 * @param targetArea
	 */
	@LogAnnotation
	public static void cloneViewSuite(ViewSuite vs,Site targetSite,Platform targetPlatform,Area targetArea){
		if(vs.getArea()==targetArea && vs.getSite()==targetSite && vs.getPlatform()==targetPlatform){
			return;
		}
		ViewService viewService = new ViewService();
		ViewDataService viewDataService = new ViewDataService();
        
		HashMap<Integer,View> clonedIdMap=new HashMap<Integer,View>(); 
		//两次遍历
		for(View view:vs.getViews()){
			View targetView=viewService.cloneView(view,targetSite,targetPlatform,targetArea);
			clonedIdMap.put(view.getId(), targetView);
			
		}
		for(View view:vs.getViews()){
		   viewDataService.cloneViewData(view,clonedIdMap.get(view.getId()),clonedIdMap);
		}
	}
	
	@LogAnnotation
	public static void cloneView(View view){
		
	}
	
	@LogAnnotation
	public static String createFakeData() {
		ViewService viewService = new ViewService();
		CommonDataService cService = new CommonDataService();
		ViewDataService viewDataService = new ViewDataService();

		createSites(cService);
		createAreaes(cService);
		createPlatforms(cService);

		//create page template
        
		//创建页面类型
		createTemplates(viewService, cService);

		// create page layout

		// get info
		Site site = cService.getSite("Yihaodian"); 
		Platform platform = cService.getPlatform("Iphone");
		Area area = cService.getArea("Shanghai");

		try {
	        
			//创建一个普通活动页，无栏目只有产品列表
			View activityView = createActivityView(viewService,
					viewDataService, site, platform, area);
		
			System.out.println(activityView.validate());
			
			//团购列表页
			View groupnActivityView = createGrouponActivityView(viewService,
					viewDataService, site, platform, area);
			
			
			System.out.println(groupnActivityView.validate());
			
			View couponActivityView = createCouponActivityView(viewService,
					viewDataService, site, platform, area);
			
			System.out.println(couponActivityView.validate());
			
			
			//创建无栏目的促销活动（原来的Landingpage活动)
			View promotionView = createPromotionView(viewService,
					viewDataService, site, platform, area);
			System.out.println(promotionView.validate());
			//创建多栏目的列表页面，栏目中可以设置各种活动，有促销的也可能只是产品列表
			View acticityListView = createActivityListView(viewService,
					viewDataService, site, platform, area);
			System.out.println(acticityListView.validate());
			//创建活动聚合页面（见柠檬的邮件,首先图片活动说明，然后分会场，然后列表）
			View compositeActivityView = createCompositeActivityView(viewService,
					viewDataService, site, platform, area);
			
			System.out.println(compositeActivityView.validate());	
			
			
			// 创建首页
			ViewTemplate indexTemplate = viewService.getTemplate(1);
            View index = viewService.createView(site, platform, area,
					indexTemplate.getType(), "首页");
			int order = 0;
			// create banner 
			ViewDataContainer banner = viewService.createContainer(index,
					new BannerImageADLayout(1), order++, "轮播图");
			// create main entry
			// ViewDataContainer indexMain =
			// viewService.createContainer(index,new
			// IndexMainEntryLayout(),order++,"主入口");
			// create keyword entry
			// ViewDataContainer keywordLayout =
			// viewService.createContainer(index,new
			// IndexKeywordOnlyLayout(),order++,"快速入口");
		
			// create 楼层1
			ViewDataContainer floor1 = viewService.createContainer(index,
					new FloorADLayout(4), order++, "楼层1");
			// create 楼层2 右侧图片
			ViewDataContainer floor2 = viewService.createContainer(index,
					new FloorADLayout(4,true), order++, "楼层2");
			// create Floor3
			ViewDataContainer floor3 = viewService.createContainer(index,
					new FloorADLayout(4), order++, "楼层3");
			
			// create Floor4 右侧图片
			ViewDataContainer floor4 = viewService.createContainer(index,
					new FloorADLayout(4,true), order++, "楼层4");
		
			// create recommend
			ViewDataContainer recommend = viewService.createContainer(index,
					new SmallImage2ColumnADLayout(5), order++, "促销推广");

			
	

//			// create banner AD
			Advertisement lifeAD = viewDataService.createLinkAdvertisement(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"),
					new String[] { "生活电器中心","副标题" }, "生活电器主中心",
					"http://特殊链接" , null);
			viewDataService.createImageToAD(lifeAD, 120, 120,
					"http://d6.yihaodianimg.com/N03/M05/67/CE/CgQCtVG6hdCATnLcAAEHFe1GdSo10900.jpg", 12345l);
			viewDataService.createImageToAD(lifeAD, 40, 40,
					"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_40x40.jpg", 12345l);
			viewDataService.setDataToContainer(banner, lifeAD,activityView);
			
			
			Advertisement lifeAD2 = viewDataService.createLinkAdvertisement(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"),
					new String[] { "无栏目促销广告","副标题" }, "无栏目促销广告",
					  null, null);
			viewDataService.createImageToAD(lifeAD2, 120, 120,
					"http://d6.yihaodianimg.com/N03/M05/67/CE/CgQCtVG6hdCATnLcAAEHFe1GdSo10900.jpg", 12345l);
			viewDataService.createImageToAD(lifeAD2, 40, 40,
					"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_40x40.jpg", 12345l);
			viewDataService.setDataToContainer(banner, lifeAD2,promotionView);
			
			
			Advertisement lifeAD3 = viewDataService.createLinkAdvertisement(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"),
					new String[] { "多栏目促销广告","副标题" }, "多栏目促销广告",
					 null, null);
			viewDataService.createImageToAD(lifeAD3, 120, 120,
					"http://d6.yihaodianimg.com/N03/M05/67/CE/CgQCtVG6hdCATnLcAAEHFe1GdSo10900.jpg", 12345l);
			viewDataService.createImageToAD(lifeAD3, 40, 40,
					"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_40x40.jpg", 12345l);
			viewDataService.setDataToContainer(banner, lifeAD3,acticityListView);
			
			Advertisement lifeAD4 = viewDataService.createLinkAdvertisement(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"),
					new String[] { "cms聚合广告","副标题" }, "cms聚合促销广告",
					null, null);
			viewDataService.createImageToAD(lifeAD4, 120, 120,
					"http://d6.yihaodianimg.com/N03/M05/67/CE/CgQCtVG6hdCATnLcAAEHFe1GdSo10900.jpg", 12345l);
			viewDataService.createImageToAD(lifeAD4, 40, 40,
					"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_40x40.jpg", 12345l);
			viewDataService.setDataToContainer(banner, lifeAD4,compositeActivityView);
			
		
			
			Advertisement lifeAD5 = viewDataService.createLinkAdvertisement(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"),
					new String[] { "团购商品列表广告","副标题" }, "团购商品列表",
					null, null);
			viewDataService.createImageToAD(lifeAD5, 120, 120,
					"http://d6.yihaodianimg.com/N03/M05/67/CE/CgQCtVG6hdCATnLcAAEHFe1GdSo10900.jpg", 12345l);
			viewDataService.createImageToAD(lifeAD5, 40, 40,
					"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_10x10.jpg", 12345l);
			viewDataService.setDataToContainer(banner, lifeAD5,groupnActivityView);
			
			
			
			
			PromotionAdvertisement N2NAD = viewDataService.createPromotionGiftActivity(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"),
					new String[]{"N元N件促销活动","副标题"}, "N元N件列表数据",
					"43425",3,200,10);
			viewDataService.createImageToAD(N2NAD, 120, 120,
					"http://d6.yihaodianimg.com/N03/M05/67/CE/CgQCtVG6hdCATnLcAAEHFe1GdSo10900.jpg", 12345l);
			viewDataService.createImageToAD(N2NAD, 40, 40,
					"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_10x10.jpg", 12345l);
			
			//楼层一
			//左图
			viewDataService.setDataToContainer(floor1, lifeAD,couponActivityView);
            //右上 
			viewDataService.setDataToContainer(floor1, lifeAD2,promotionView);
            //快速字入口
			Advertisement milkAD = viewDataService.createSearchAdvertisement(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"), new String[] { "牛奶" },
					"牛奶", new String[] { "牛奶","milk" }, null,null);
		    viewDataService.setDataToContainer(floor1, milkAD,null);

			Advertisement beerAD = viewDataService.createCategoryAdvertisement(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"),
					new String[] { "进化器" }, "啤酒", 123,"三级类目名",
					null,null);
			viewDataService.setDataToContainer(floor1, beerAD,null);

			Advertisement cleanerAD = viewDataService.createBrandAdvertisement(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"),
					new String[] { "进化器" }, "净化器",
					12345,"品牌名",null,null);
		
			viewDataService.setDataToContainer(floor1, cleanerAD,null);

			Advertisement coffeeAD = viewDataService.createSearchAdvertisement(
					new Integer[] { site.getId() },
					DataManager.parseDate("2013-05-21 00:00:00"),
					DataManager.parseDate("2013-06-23 00:00:00"),
					new String[] { "牛奶咖啡奶茶" }, "牛奶咖啡奶茶",
					new String[] { "牛奶","咖啡","奶茶" }, null,null);
			viewDataService.setDataToContainer(floor1, coffeeAD,null);

			//楼层2
			//左上
			viewDataService.setDataToContainer(floor2, lifeAD3,acticityListView);
			viewDataService.setDataToContainer(floor2, milkAD,null);
			viewDataService.setDataToContainer(floor2, beerAD,null);
			viewDataService.setDataToContainer(floor2, cleanerAD,null);
			viewDataService.setDataToContainer(floor2, N2NAD,null);
			//右图
			viewDataService.setDataToContainer(floor2, lifeAD4,compositeActivityView);

			viewDataService.setDataToContainer(floor3, lifeAD2,promotionView);
			viewDataService.setDataToContainer(floor3, lifeAD3,acticityListView);
			viewDataService.setDataToContainer(floor3, milkAD,null);
			viewDataService.setDataToContainer(floor3, beerAD,null);
			viewDataService.setDataToContainer(floor3, cleanerAD,null);
			viewDataService.setDataToContainer(floor3, coffeeAD,null);

			viewDataService.setDataToContainer(floor4, coffeeAD,null);
			viewDataService.setDataToContainer(floor4, milkAD,null);
			viewDataService.setDataToContainer(floor4, beerAD,null);
			viewDataService.setDataToContainer(floor4, cleanerAD,null);
			viewDataService.setDataToContainer(floor4, N2NAD,null);
			viewDataService.setDataToContainer(floor4, lifeAD4,compositeActivityView);

			viewDataService.setDataToContainer(recommend, lifeAD,activityView);
			viewDataService.setDataToContainer(recommend, lifeAD2,promotionView);
			viewDataService.setDataToContainer(recommend, lifeAD3,acticityListView);
				
			viewDataService.setDataToContainer(recommend, N2NAD,null);
			
			System.out.println(index.validate());	
			
			
			View calanderView=createCalendar(viewService, site, platform, area,viewDataService);
		
//			ViewTemplate brandlistTemplate = viewService.getTemplate(site,
//					platform, area, "brandlist");
//			View brandListView = viewService.createView(site, platform, area,
//					brandlistTemplate.getType(), "品牌旗舰");
//			ViewDataContainer brandlistContainer = viewService.createContainer(
//					brandListView, new BrandActivityListLayout(14), 0, "活动列表");
//
//			ViewTemplate dailyProductTemplate = viewService.getTemplate(site,
//					platform, area, "dailyproduct");
//			View dailyProductView = viewService.createView(site, platform,
//					area, dailyProductTemplate.getType(), "每日一款简化版");
//			ViewDataContainer dailyProductContainer = viewService
//					.createContainer(dailyProductView,
//							new DailyXProductActivityLayout(7,true,2), 0, "活动列表");

			

		
	

			

			
           
			//clone to website
			cloneViewSuite(DataManager.getDataManager().getViewSuite(site, area, platform),site,cService.getPlatform("Web"),area);
			//change index page of website
			ViewSuite vs=DataManager.getDataManager().getViewSuite(site, area, cService.getPlatform("Web"));
			if(vs!=null){
				View webIndex= vs.getView(viewService.getTemplate(1));
				ViewTemplate activityWithColumnTemplate = viewService.getTemplate(
						 6);
				View activityViewForWeb=vs.getView(activityWithColumnTemplate);
				
				ViewTemplate calendarDayTemplate = viewService.getTemplate(
						 3);
				View calendarDayForWeb=vs.getView(calendarDayTemplate);
				
				// create keyword entry
				 ViewDataContainer fastKeyword = viewService.createContainer(webIndex,
						 new  TitleOnlyADLayout(3),2,"快速入口");
				// create main entry
				  ViewDataContainer indexMain = viewService.createContainer(webIndex,
						    new MainEntryADLayout(2),3,"主入口");
				  
				  viewDataService.setDataToContainer(fastKeyword, lifeAD3,activityViewForWeb);
				  viewDataService.setDataToContainer(fastKeyword, milkAD,null);
				  viewDataService.setDataToContainer(fastKeyword, beerAD,null);
				  viewDataService.setDataToContainer(fastKeyword, cleanerAD,null);
				  viewDataService.setDataToContainer(fastKeyword, coffeeAD,null);
				  viewDataService.setDataToContainer(fastKeyword, lifeAD4,activityViewForWeb);
				  
				  Advertisement main1AD = viewDataService.createLinkAdvertisement(
							new Integer[] { site.getId() },
							DataManager.parseDate("2013-05-21 00:00:00"),
							DataManager.parseDate("2013-06-23 00:00:00"),
							new String[] { "限时抢" }, "限时抢购",
							null , null);
				
					viewDataService.createImageToAD(main1AD, 80, 80,
							"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_80x80.jpg", 12345l);
				  viewDataService.setDataToContainer(indexMain, main1AD,calendarDayForWeb);
				  
				  Advertisement defaultGrouponAD = viewDataService.createDefaultGrouponAdvertisement(
							new Integer[] { site.getId() },
							DataManager.parseDate("2013-05-21 00:00:00"),
							DataManager.parseDate("2013-06-23 00:00:00"),
							new String[] { "一号团" }, "一号团",
							null , null);
				  viewDataService.createImageToAD(defaultGrouponAD, 80, 80,
							"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_80x80.jpg", 12345l);
				  viewDataService.setDataToContainer(indexMain, defaultGrouponAD,null);
				
				// ViewDataContainer keywordLayout =
				// viewService.createContainer(index,new
				// IndexKeywordOnlyLayout(),order++,"快速入口");
			}
				
			
			
			
			
			
			
		    ModelFilterOption option=new ModelFilterOption();
		    option.setSiteType(site);
			return calanderView.generateJSONString(option);

		} catch (Exception e) {
              e.printStackTrace();
		}
         return "";
	}

	@LogAnnotation
	private static View createCalendar(ViewService viewService, Site site,
			Platform platform, Area area,ViewDataService viewDataService) throws Exception {
		
		int order;
			

		// create calendar
//		View calendarMondayView = viewService.createView(site, platform,
//				area, calendardayTemplate.getType(), "日历周一详情页");
//		order = 0;
//		
//		ViewDataContainer mondayDailyoneContainer = viewService
//				.createContainer(calendarMondayView,
//						new DailyXProductActivityLayout(7), order++, "每日一款");
//		
//		ViewDataContainer mondayBanner = viewService.createContainer(
//				calendarMondayView, new BannerImageADLayout(1,1), order++,
//				"促销推荐");
//		
//		ViewDataContainer mondayDailytwoContainer = viewService
//				.createContainer(calendarMondayView,
//						new DailyXProductActivityLayout(7), order++, "热门活动");
//		
//		ViewDataContainer mondayPromotionList = viewService
//				.createContainer(calendarMondayView,
//						new List2ColumnProductActivityLayout(8), order++, "推荐列表");
        
		//创建每日一款
		View dailyOneView = createDailyOneView(viewService,
						viewDataService, site, platform, area);
		
		View tuesdayView = createCalendarDay(viewService, site,
				platform, area, viewDataService,dailyOneView,"日历周二详情页");
		View wednesdayView = createCalendarDay(viewService, site,
				platform, area, viewDataService,dailyOneView,"日历周三详情页");
		View thursdayView = createCalendarDay(viewService, site,
				platform, area, viewDataService,dailyOneView,"日历周四详情页");
		View fridayView = createCalendarDay(viewService, site,
				platform, area, viewDataService,dailyOneView,"日历周五详情页");
		View saturdayView = createCalendarDay(viewService, site,
				platform, area, viewDataService,dailyOneView,"日历周六详情页");
		View sundayView = createCalendarDay(viewService, site,
				platform, area, viewDataService,dailyOneView,"日历周日详情页");			
			
		
		//创造日历首页
		
				ViewTemplate calendarTemplate = viewService.getTemplate(2);
				// create calendar
				View calendarView = viewService.createView(site, platform, area,
						calendarTemplate.getType(), "日历首页");
				order = 0;
		          
		        
				ViewDataContainer mondayContainer = viewService.createContainer(
						calendarView, new WeeklyShowLayout(6,Calendar.MONDAY), order++, "星期一");
				ViewDataContainer tuesdayContainer = viewService.createContainer(
						calendarView, new WeeklyShowLayout(6,Calendar.TUESDAY), order++, "星期二");
				ViewDataContainer wednesdayContainer = viewService.createContainer(
						calendarView, new WeeklyShowLayout(6,Calendar.WEDNESDAY), order++, "星期三");
				ViewDataContainer thursdayContainer = viewService.createContainer(
						calendarView, new WeeklyShowLayout(6,Calendar.THURSDAY), order++, "星期四");
				ViewDataContainer fridayContainer = viewService.createContainer(
						calendarView, new WeeklyShowLayout(6,Calendar.FRIDAY), order++, "星期五");
				ViewDataContainer saturdayContainer = viewService.createContainer(
						calendarView, new WeeklyShowLayout(6,Calendar.SATURDAY), order++, "星期六");
				ViewDataContainer sundayContainer = viewService.createContainer(
						calendarView, new WeeklyShowLayout(6,Calendar.SUNDAY), order++, "星期日");
		        
				ViewDataContainer dailyOneContainer = viewService.createContainer(
						calendarView, new DailyXProductActivityLayout(7), order++, "每日一款");
				
				
				
				View redeemView = createRedeemView(viewService,
						viewDataService, site, platform, area);
				
				//add data to container
				Advertisement redeemAD = viewDataService.createLinkAdvertisement(
						new Integer[] { site.getId() },
						DataManager.parseDate("2013-05-21 00:00:00"),
						DataManager.parseDate("2013-06-23 00:00:00"),
						new String[] { "积分换购"}, "积分换购广告",
						 null, null);
				viewDataService.setDataToContainer(mondayContainer, redeemAD,redeemView);
				
				
				Advertisement complexAD = viewDataService.createLinkAdvertisement(
						new Integer[] { site.getId() },
						DataManager.parseDate("2013-05-21 00:00:00"),
						DataManager.parseDate("2013-06-23 00:00:00"),
						new String[] { "N元N件","随心购"}, "随心购广告",
						 null, null);
				viewDataService.setDataToContainer(tuesdayContainer, complexAD,tuesdayView);
				
				
				Advertisement ad2 = viewDataService.createLinkAdvertisement(
						new Integer[] { site.getId() },
						DataManager.parseDate("2013-05-21 00:00:00"),
						DataManager.parseDate("2013-06-23 00:00:00"),
						new String[] { "买一送一"}, "买一送一广告",
						 null, null);
				viewDataService.setDataToContainer(wednesdayContainer, ad2,wednesdayView);
				
				
				Advertisement ad3 = viewDataService.createLinkAdvertisement(
						new Integer[] { site.getId() },
						DataManager.parseDate("2013-05-21 00:00:00"),
						DataManager.parseDate("2013-06-23 00:00:00"),
						new String[] { "买就送"}, "买就送广告",
						 null, null);
				viewDataService.setDataToContainer(thursdayContainer, ad3,thursdayView);
				
				Advertisement ad4 = viewDataService.createLinkAdvertisement(
						new Integer[] { site.getId() },
						DataManager.parseDate("2013-05-21 00:00:00"),
						DataManager.parseDate("2013-06-23 00:00:00"),
						new String[] { "秒杀"}, "秒杀广告",
						 null, null);
				viewDataService.setDataToContainer(fridayContainer, ad4,fridayView);
				
				Advertisement ad5 = viewDataService.createLinkAdvertisement(
						new Integer[] { site.getId() },
						DataManager.parseDate("2013-05-21 00:00:00"),
						DataManager.parseDate("2013-06-23 00:00:00"),
						new String[] { "周末购"}, "周末购广告",
						 null, null);
				viewDataService.setDataToContainer(saturdayContainer, ad5,saturdayView);
				
				Advertisement ad6 = viewDataService.createLinkAdvertisement(
						new Integer[] { site.getId() },
						DataManager.parseDate("2013-05-21 00:00:00"),
						DataManager.parseDate("2013-06-23 00:00:00"),
						new String[] { "秒杀"}, "秒杀广告",
						 null, null);
				viewDataService.setDataToContainer(sundayContainer, ad6,sundayView);
				
				viewDataService.setDataToContainer(dailyOneContainer,dailyOneView);
				System.out.println(calendarView.validate());	
				
				return calendarView;
	}

	@LogAnnotation
	private static View createCalendarDay(ViewService viewService,
			Site site, Platform platform, Area area,
			ViewDataService viewDataService,View dailyOneView,String name) throws Exception {
		int order;
				
		View activityView = createActivityView(viewService,
				viewDataService, site, platform, area);
		
		ViewTemplate calendardayTemplate = viewService.getTemplate(3);
		
		View calendarTuesdayView = viewService.createView(site, platform,
				area, calendardayTemplate.getType(), name);
		order = 0;
		ViewDataContainer tuesdayDailyoneContainer = viewService
				.createContainer(calendarTuesdayView,
						new DailyXProductActivityLayout(7), order++, "每日一款");
		viewDataService.setDataToContainer(tuesdayDailyoneContainer,dailyOneView);
		
		
		ViewDataContainer tuesdayBanner = viewService.createContainer(
				calendarTuesdayView, new BannerImageADLayout(1,1), order++,
				"促销推荐");
		
		Advertisement bannerAD = viewDataService.createLinkAdvertisement(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				new String[] { "活动banner","副标题" }, "生活电器主中心",
				null , null);
		viewDataService.createImageToAD(bannerAD, 120, 120,
				"http://d6.yihaodianimg.com/N03/M05/67/CE/CgQCtVG6hdCATnLcAAEHFe1GdSo10900.jpg", 12345l);
		viewDataService.createImageToAD(bannerAD, 40, 40,
				"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_40x40.jpg", 12345l);
		viewDataService.setDataToContainer(tuesdayBanner, bannerAD,activityView);
		
		
		DailyXProductActivityLayout dxpLayout=new DailyXProductActivityLayout(7,true,2);
		dxpLayout.setUseOrder(false);
		dxpLayout.setUseRandom(true);
		ViewDataContainer tuesdayDailytwoContainer = viewService
				.createContainer(calendarTuesdayView,
						dxpLayout, order++, "热门活动");
		SeckillActivity pa = viewDataService.createSeckillActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				"秒杀活动", "秒杀列表数据",
				"43425",11);
		viewDataService.setDataToContainer(tuesdayDailytwoContainer, pa,null);
				
				
		ViewDataContainer tuesdayPromotionList = viewService
				.createContainer(calendarTuesdayView,
						new List2ColumnTitleADLayout(8), order++, "推荐列表");
        
		Advertisement recommendAD = viewDataService.createLinkAdvertisement(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				new String[] { "活动标题","副标题" }, "生活电器主中心tips",
				null, null);
		viewDataService.createImageToAD(recommendAD, 120, 120,
				"http://d6.yihaodianimg.com/N03/M05/67/CE/CgQCtVG6hdCATnLcAAEHFe1GdSo10900.jpg", 12345l);
		viewDataService.createImageToAD(recommendAD, 40, 40,
				"http://d1.yihaodianimg.com/t1/2012/04/23/5494123_40x40.jpg", 12345l);
		
		viewDataService.setDataToContainer(tuesdayPromotionList, recommendAD,activityView);
		viewDataService.setDataToContainer(tuesdayPromotionList, recommendAD,activityView);
		viewDataService.setDataToContainer(tuesdayPromotionList, recommendAD,activityView);
		viewDataService.setDataToContainer(tuesdayPromotionList, recommendAD,activityView);
		viewDataService.setDataToContainer(tuesdayPromotionList, recommendAD,activityView);
		viewDataService.setDataToContainer(tuesdayPromotionList, recommendAD,activityView);
		
		System.out.println(calendarTuesdayView.validate());	
		return calendarTuesdayView;
	}
    
//	private static View createN2NView(ViewService viewService,
//			ViewDataService viewDataService, Site site, Platform platform,
//			Area area) throws Exception{
//		ViewTemplate n2nactivityTemplate = viewService.getTemplate(5);
//		View n2nactivityView = viewService.createView(site, platform, area,
//				n2nactivityTemplate.getType(), "n元n件页");
//		ViewDataContainer activityContainer = viewService.createContainer(
//				n2nactivityView,new ListProductActivityLayout(9), 0, "产品列表");
//		
//		PromotionAdvertisement pa = viewDataService.createPromotionGiftActivity(
//				new Integer[] { site.getId() },
//				DataManager.parseDate("2013-05-21"),
//				DataManager.parseDate("2013-06-23"),
//				new String[]{"N元N件促销活动","副标题"}, "N元N件列表数据",
//				"20130614105033",3,200,10);
//		viewDataService.setDataToContainer(activityContainer, pa,null);
//		return n2nactivityView;
//	}

	@LogAnnotation
	private static View createCompositeActivityView(ViewService viewService,
			ViewDataService viewDataService, Site site, Platform platform,
			Area area) throws Exception{
		ViewTemplate activitypageTemplate = viewService.getTemplate(7);
		View activitypageView = viewService.createView(site, platform,
				area, activitypageTemplate.getType(), "促销聚合页");
		Image image=new Image();
		image.setWidth(100);
		image.setHeight(100);
		image.setSrcUrl("http://d6.yihaodianimg.com/N00/M03/69/D4/CgMBmFGxm2eAUE0GAACxEZoGZEE73100.jpg");
		activitypageView.setTopImage(image);
		activitypageView.setDescription("cms聚合页面的文字说明");
		
		ViewDataContainer kewordLayout = viewService.createContainer(
				activitypageView, new  TitleOnlyADLayout(3), 1,
				"分会场");
		
		View view=createActivityView(viewService,viewDataService,site,platform,area);
		Advertisement ad1 = viewDataService.createLinkAdvertisement(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"), new String[] { "新生宝贝礼物区" },
				"新生宝贝礼物区",null,null);
	    
		
				
		viewDataService.setDataToContainer(kewordLayout, ad1,view);
		viewDataService.setDataToContainer(kewordLayout, ad1,view);
		viewDataService.setDataToContainer(kewordLayout, ad1,view);
		viewDataService.setDataToContainer(kewordLayout, ad1,view);
		viewDataService.setDataToContainer(kewordLayout, ad1,view);
		viewDataService.setDataToContainer(kewordLayout, ad1,view);
		
		
		ProductListActivity pla = viewDataService.createProductListActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				 "生活电器中心", "生活电器中心列表数据",
				"0000392358,0000392359,0000392360,0000392361");
		ViewDataContainer listProductContainer = viewService
				.createContainer(activitypageView,
						new List2ColumnProductActivityLayout(10,true), 2, "热门商品");
		viewDataService.setDataToContainer(listProductContainer, pla,null);
		
		ViewDataContainer listProductContainer2 = viewService
				.createContainer(activitypageView,
						new List2ColumnProductActivityLayout(10,true), 2, "积分换购");
		viewDataService.setDataToContainer(listProductContainer2, pla,null);
		
		return activitypageView;
	}

	
	@LogAnnotation
	private static View createActivityListView(ViewService viewService,
			ViewDataService viewDataService, Site site, Platform platform,
			Area area) throws Exception{
		ViewTemplate activityWithColumnTemplate = viewService.getTemplate(
				 6);
		View activityWithColumnView = viewService.createView(site,
				platform, area, activityWithColumnTemplate.getType(),
				"多栏目列表页");
		Image image=new Image();
		image.setWidth(100);
		image.setHeight(100);
		image.setSrcUrl("http://d6.yihaodianimg.com/N00/M03/69/D4/CgMBmFGxm2eAUE0GAACxEZoGZEE73100.jpg");
		activityWithColumnView.setTopImage(image);
		activityWithColumnView.setDescription("多栏目页的文字说明");
		// 注意可以自由添加,栏目一
		ViewDataContainer activityWithColumnContainer1 = viewService
				.createContainer(activityWithColumnView,
						new ListProductActivityLayout(9,true), 0, "活动列表");
	
		ProductListActivity pla = viewDataService.createProductListActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				"生活电器中心", "生活电器中心列表数据",
				"0000392358,0000392359,0000392360,0000392361");

		
		viewDataService.setDataToContainer(activityWithColumnContainer1, pla,null);
		
		//栏目2
		ViewDataContainer activityWithColumnContainer2 = viewService
				.createContainer(activityWithColumnView,
						new ListProductActivityLayout(9,true), 1, "活动列表2");
		
		PromotionActivity pa = viewDataService.createPromotionActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				 "无栏目促销活动", "无栏目促销列表数据",
				"43425",11);
		viewDataService.setDataToContainer(activityWithColumnContainer2, pa,null);
		
		return activityWithColumnView;
	}

	//创建促销活动页，无栏目
	@LogAnnotation
	private static View createPromotionView(ViewService viewService,
			ViewDataService viewDataService, Site site, Platform platform,
			Area area) throws Exception {
		ViewTemplate activityTemplate = viewService.getTemplate(5);
		View activityView = viewService.createView(site, platform, area,
				activityTemplate.getType(), "促销列表页");
		ViewDataContainer activityContainer = viewService.createContainer(
				activityView, new ListProductActivityLayout(9), 0, "产品列表");
		
		PromotionActivity pa = viewDataService.createPromotionActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				"无栏目促销活动", "无栏目促销列表数据",
				"43425",11);
		viewDataService.setDataToContainer(activityContainer, pa,null);
		return activityView;
	}	
		
	//创建促销活动页，无栏目
	@LogAnnotation
	private static View createDailyOneView(ViewService viewService,
			ViewDataService viewDataService, Site site, Platform platform,
			Area area) throws Exception {
		ViewTemplate activityTemplate = viewService.getTemplate(8);
		View activityView = viewService.createView(site, platform, area,
				activityTemplate.getType(), "每日一款页");
		ViewDataContainer activityContainer = viewService.createContainer(
				activityView, new DailyXProductActivityLayout(7), 0, "单个产品");
		
		PromotionActivity pa = viewDataService.createPromotionActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				"每日一款活动", "每天一个数据",
				"43425",11);
		viewDataService.setDataToContainer(activityContainer, pa,null);
		return activityView;
	}
	
	@LogAnnotation
	private static View createRedeemView(ViewService viewService,
			ViewDataService viewDataService, Site site, Platform platform,
			Area area) throws Exception {
		ViewTemplate activityTemplate = viewService.getTemplate(5);
		View activityView = viewService.createView(site, platform, area,
				activityTemplate.getType(), "积分兑换列表页");
		ViewDataContainer activityContainer = viewService.createContainer(
				activityView, new List2ColumnProductActivityLayout(10), 0, "产品列表");
		
		PromotionActivity pa = viewDataService.createRedeemActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				"积分兑换活动", "积分兑换双列展示",
				"20130614105033",11);
		viewDataService.setDataToContainer(activityContainer, pa,null);
		return activityView;
	}
	
	
	@LogAnnotation
	private static View createCouponActivityView(ViewService viewService,
			ViewDataService viewDataService, Site site, Platform platform,
			Area area) throws Exception {
		ViewTemplate activityTemplate = viewService.getTemplate(9);
		View activityView = viewService.createView(site, platform, area,
				activityTemplate.getType(), "列表页");
		ViewDataContainer activityContainer = viewService.createContainer(
				activityView, new ListProductActivityLayout(9), 0, "产品列表");
		// create advertisement data
		// create 生活电器中心活动： 也就是没有栏目的普通活动，只是产品列表，输入产品id
		CouponListActivity pla = viewDataService.createCouponActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				 "抵购卷列表", "抵购卷列表数据",
				"20748,20575,20386,20539,16786,20682,20742");

		
		viewDataService.setDataToContainer(activityContainer, pla,null);
		return activityView;
	}
	@LogAnnotation
	private static View createActivityView(ViewService viewService,
			ViewDataService viewDataService, Site site, Platform platform,
			Area area) throws Exception {
		ViewTemplate activityTemplate = viewService.getTemplate( 5);
		View activityView = viewService.createView(site, platform, area,
				activityTemplate.getType(), "列表页");
		ViewDataContainer activityContainer = viewService.createContainer(
				activityView, new ListProductActivityLayout(9), 0, "产品列表");
		// create advertisement data
		// create 生活电器中心活动： 也就是没有栏目的普通活动，只是产品列表，输入产品id
		ProductListActivity pla = viewDataService.createProductListActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				 "生活电器中心", "生活电器中心列表数据",
				"39235,39235,39236,39236");

		
		viewDataService.setDataToContainer(activityContainer, pla,null);
		return activityView;
	}
	
	@LogAnnotation
	private static View createGrouponActivityView(ViewService viewService,
			ViewDataService viewDataService, Site site, Platform platform,
			Area area) throws Exception {
		ViewTemplate activityTemplate = viewService.getTemplate(10);
		View activityView = viewService.createView(site, platform, area,
				activityTemplate.getType(), "列表页");
		ViewDataContainer activityContainer = viewService.createContainer(
				activityView, new ListProductActivityLayout(9), 0, "产品列表");
		// create advertisement data
		// create 生活电器中心活动： 也就是没有栏目的普通活动，只是产品列表，输入产品id
		GrouponProductListActivity pla = viewDataService.createGrouponProductListActivity(
				new Integer[] { site.getId() },
				DataManager.parseDate("2013-05-21 00:00:00"),
				DataManager.parseDate("2013-06-23 00:00:00"),
				 "团购列表", "团购列表数据",
				"17430,43436,17432");

		
		viewDataService.setDataToContainer(activityContainer, pla,null);
		return activityView;
	}

	@LogAnnotation
	private static void createTemplates(ViewService viewService,
			CommonDataService cService) {
		viewService.createTemplate("首页", 1);
		viewService.createTemplate("日历首页", 2);
		viewService.createTemplate("日历详情", 3);
		viewService.createTemplate("品牌旗舰", 4);
		
		viewService.createTemplate("无栏目产品列表或普通促销页", 5);
		
		viewService.createTemplate("多栏目活动页面 ", 6);
		
		viewService.createTemplate("活动广告聚合页", 7);
		
		viewService.createTemplate("每日N款", 8);
		
		viewService.createTemplate("无栏目抵购卷列表页", 9);
	
		viewService.createTemplate("无栏目团购商品列表页", 10);
		
	}

	@LogAnnotation
	private static void createPlatforms(CommonDataService cService) {
		cService.createPlatform("Web");
		cService.createPlatform("Wap");
		cService.createPlatform("Iphone");
		cService.createPlatform("Ipad");
		cService.createPlatform("Android");
		cService.createPlatform("AndroidPad");
	}

	@LogAnnotation
	private static void createAreaes(CommonDataService cService) {
		cService.createArea("Beijing");
		cService.createArea("Shanghai");
		cService.createArea("Guangzhou");
		cService.createArea("Chengdu");
	}

	@LogAnnotation
	private static void createSites(CommonDataService cService) {
		cService.createSite("Yihaodian");
		cService.createSite("Yihaomall");
	}
//	public void testSite(){
//		Site temp=new Site();
//		temp.setId(1);
//		temp.setName("mobile");
//		siteDao.saveSite(temp);
//		Site temp1=siteDao.getSite(1);
//		System.out.println(temp1.getName());
//	}
//	public void setSiteDao(SiteDao siteDao) {
//		this.siteDao = siteDao;
//	}
//	public SiteDao getSiteDao() {
//		return siteDao;
//	}
}
