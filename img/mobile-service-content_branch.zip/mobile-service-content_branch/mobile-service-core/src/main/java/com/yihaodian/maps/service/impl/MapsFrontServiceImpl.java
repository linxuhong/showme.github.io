package com.yihaodian.maps.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.yihaodian.common.ycache.CacheProxy;
import com.yihaodian.front.shopping.client.FrontShoppingClient;
import com.yihaodian.front.shopping.interfaces.vo.CommInputVo;
import com.yihaodian.front.shopping.interfaces.vo.input.cart.ShoppingAddNormalInput;
import com.yihaodian.front.shopping.interfaces.vo.input.cart.ShoppingAddPromotionInput;
import com.yihaodian.front.shopping.interfaces.vo.output.cart.ShoppingCartBaseOutput;
import com.yihaodian.maps.util.ManagerUtils;
import com.yihaodian.mobile.backend.maps.core.BizContants;
import com.yihaodian.mobile.backend.maps.model.ModuleEntity;
import com.yihaodian.mobile.backend.maps.model.PageEntity;
import com.yihaodian.mobile.backend.maps.model.PageSearchEntity;
import com.yihaodian.mobile.backend.maps.model.biz.BaseBizEntity;
import com.yihaodian.mobile.backend.maps.vo.BizVO;
import com.yihaodian.mobile.backend.maps.vo.CouponVO;
import com.yihaodian.mobile.backend.maps.vo.GrouponBrandVO;
import com.yihaodian.mobile.backend.maps.vo.ModuleContentVO;
import com.yihaodian.mobile.backend.maps.vo.PageWholeVO;
import com.yihaodian.mobile.backend.maps.vo.ProductInfoVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.service.core.util.SwitchUtil;
import com.yihaodian.mobile.service.map.spi.APIManagerService;
import com.yihaodian.mobile.service.map.spi.BizService;
import com.yihaodian.mobile.service.map.spi.ManagerService;
import com.yihaodian.mobile.service.map.spi.MapsFrontService;
import com.yihaodian.mobile.service.map.spi.PageSearchService;
import com.yihaodian.mobile.vo.constant.SwitchCode;
@Service("mapsFrontService")
public class MapsFrontServiceImpl implements MapsFrontService {
	
	public static final Logger logger = Logger.getLogger(MapsFrontServiceImpl.class.getName());
	
	@Resource
	APIManagerService aPIManagerService;
	@Resource
	ManagerService managerService;
	@Resource
	BizService bizService;
	@Resource
	private CacheProxy wl2DataCache;
	@Resource
	private PageSearchService pageSearchService;
	
	@Override
	public PageWholeVO loadCachedPage(Long pageId, Long provinceId) {
		PageWholeVO pagevo = null ;
		if (provinceId == null) {
			pagevo = new PageWholeVO();
			pagevo.setStatus(false);
			pagevo.setCode("001");
			pagevo.setMsg("无地区参数");
			return pagevo;
		}
		Date nowTime = new Date();
		try{
			String key = BizContants.LOAD_PAGE+"_"+pageId.toString();
			pagevo = (PageWholeVO)wl2DataCache.get(key);
			if(pagevo == null){				
				pagevo = aPIManagerService.getPageContentById(pageId);
				if(pagevo != null && pagevo.getPage()!= null && pagevo.getPage().getOfflineTime()!=null){
					int expirMins = (int)((pagevo.getPage().getOfflineTime().getTime()-nowTime.getTime())/(1000*60));
					if(expirMins>0){//时间 过期 则不缓存
						wl2DataCache.put(key, pagevo, expirMins);
					}else{
						//过期，缓存一天防止恶意刷数据：后台修改会自动清除缓存
						pagevo = new PageWholeVO();
						pagevo.setStatus(false);
						pagevo.setCode("003");
						pagevo.setMsg("时间无效的活动页");
						wl2DataCache.put(key, pagevo, BizContants.EXPIRMINS_1D);
						return pagevo;
					}
				}else{
					pagevo = new PageWholeVO();
					pagevo.setStatus(false);
					pagevo.setCode("002");
					pagevo.setMsg("无对应活动页信息");
					return pagevo;
				}
			}
			// 时间过滤
			if (pagevo != null) {
				PageEntity page = pagevo.getPage();
				if (page != null) {
					if (!(page.getOfflineTime().after(nowTime) && page
							.getOnlineTime().before(nowTime))) {
						pagevo = new PageWholeVO();
						pagevo.setStatus(false);
						pagevo.setCode("003");
						pagevo.setMsg("时间无效的活动页");
						return pagevo;
					}
				}

				page = pagevo.getPage();
				List<ModuleContentVO> mList = pagevo.getModuleList();
				if (page != null && mList != null && mList.size() > 0) {
					// 栏位时间过滤
					ModuleEntity cfg = null;
					ModuleContentVO moduleContentVO = null;
					String showArea=null;
					boolean isShow = false;
					for (Iterator<ModuleContentVO> iterator = mList.iterator(); iterator.hasNext();) {
						moduleContentVO = (ModuleContentVO) iterator.next();
						cfg = moduleContentVO.getModuleCfg();
						if (cfg.getOfflineTime() == null) {
							cfg.setOfflineTime(page.getOfflineTime());
						}
						if (cfg.getOnlineTime() == null) {
							cfg.setOnlineTime(page.getOnlineTime());
						}
						if (!(cfg.getOfflineTime().after(nowTime) && cfg
								.getOnlineTime().before(nowTime))) {
							iterator.remove();
						} else {
							isShow = false;
							// 过滤区域
							showArea = cfg.getShowArea();
							if (StringUtils.isNotBlank(showArea)) {
								String strs[] = showArea.split(",");
								for (String string : strs) {
									if (string.equals(provinceId.toString())) {
										isShow = true;
										break;
									}
								}
								if (!isShow) {
									iterator.remove();
								}
							}
						}
					}
				}
			}
		}catch(Exception e){
			pagevo = new PageWholeVO();
			pagevo.setStatus(false);
			pagevo.setCode("004");
			pagevo.setMsg("系统异常");
			return pagevo;
		}		
		return pagevo;	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ProductInfoVO> loadCachedProducts(Long cmsMouldId,
			Long provinceId, int startnum, int endnum) {
		List<ProductInfoVO> listR = new ArrayList<ProductInfoVO>();
		if(cmsMouldId == null || provinceId==null){
			return listR;
		}
		String key = BizContants.LOAD_PRODUCTS+"_"+cmsMouldId.toString()+"_"+provinceId.toString();
		listR =(List<ProductInfoVO>) wl2DataCache.get(key);		
		if(listR ==null){
			try {
				listR = managerService.queryCmsProductByMouldId(cmsMouldId, provinceId, false, null);	
			} catch (Exception e) {
				logger.error(" cms 商品获取失败：",e);
			}
			if(listR != null){
				wl2DataCache.put(key, listR, BizContants.EXPIRMINS_10);
			}
		}
		
		if (startnum < 0) {
			startnum = 0;
		}
		boolean isUpdated = false;
		if (listR != null && listR.size() > 0) {
			if (endnum > listR.size()) {
				endnum = listR.size() ;
			}
			if(startnum<endnum){
				listR = listR.subList(startnum, endnum);
				if(listR!=null&&listR.size()>0){
					listR = ManagerUtils.updatePriceAndStock(provinceId,listR,false, null);
					isUpdated=true;
				}
			}
		}
		if(!isUpdated){
			listR = new ArrayList<ProductInfoVO>();
		}
		return listR;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<BizVO> loadCachedPageEntitys(String entityType, Long mId,
			int startnum, int endnum) {
		List list = null;
		Class cls = BaseBizEntity.getClassByType(entityType);
		if (cls != String.class) {
			String key =BizContants.LOAD_PAGE_ENTITY+"_"+entityType+"_"+mId.toString();
			list = (List)wl2DataCache.get(key);
			if(list == null){
				list = bizService.findRefEntity(cls, mId);
				if(list != null && list.size()>=0){
					wl2DataCache.put(key, list,BizContants.EXPIRMINS_10);
				}
			}
			if (startnum < 0) {
				startnum = 0;
			}
			if (list != null) {
				if (endnum > list.size()) {
					endnum = list.size() ;
				}
				if(startnum<endnum){
					list = list.subList(startnum, endnum);
				}else{
					return new ArrayList();
				}
			}
		}
		return list;
	}

	@Override
	public String userGetCouponFromActivity(Long mId,String checkCode, Long userId) {
		if(mId==null||StringUtils.isBlank(checkCode)|| userId ==null){
			return "000" ;
		}
		
		Long activityId = null;
		String key = BizContants.COUPON_ACTIVITY+"_"+mId+"_"+checkCode;
		String activityIdKey = BizContants.COUPON_ACTIVITY+"_"+mId+"_"+checkCode+"_activityId";
		CouponVO vo = (CouponVO)wl2DataCache.get(key);
		activityId = (Long)wl2DataCache.get(activityIdKey);
		if(activityId==null){
			activityId = bizService.getCouponActivityId(mId,checkCode);
			if(activityId ==null){
				return "001" ;
			}else{
				wl2DataCache.put(activityIdKey, activityId,BizContants.EXPIRMINS_10);
			}
		}	
		if(vo == null){
			vo = managerService.queryCouponActiveInfoMapByActiveId(activityId);
			if(vo != null){
				wl2DataCache.put(key, vo,BizContants.EXPIRMINS_10);
			}else{
				return "002" ;
			}
		}
		
		
//		Date now = new Date() ;
//		if(now.after(vo.getCouponStartDate()) && now.before(vo.getCouponEndDate())){//活动有效
			List<Long> userIdList = new ArrayList<Long>();
			userIdList.add(userId);
			List<String> list =managerService.generateCouponToUsers(activityId, userIdList);
			if(list !=null && list.size()>0 ){
				return list.get(0) ;
			}
//		}		
		return "000";
	}

	
	
	@Override
	public String userGetCouponFromShop(Long shopId, String checkCode,
			Long userId) {
		if(shopId==null||StringUtils.isBlank(checkCode)|| userId ==null){
			return "000";
		}
		
		Long activityId = null;
		String key = BizContants.COUPON_ACTIVITY+"_SHOP_"+shopId+"_"+checkCode;
		String activityIdKey = BizContants.COUPON_ACTIVITY+"_SHOP_"+shopId+"_"+checkCode+"_activityId";
		CouponVO vo = (CouponVO)wl2DataCache.get(key);
		activityId = (Long)wl2DataCache.get(activityIdKey);
		if(activityId==null){
			activityId = bizService.getCouponActivityIdFromShop(shopId,checkCode);
			if(activityId ==null){
				return "001" ;
			}else{
				wl2DataCache.put(activityIdKey, activityId,BizContants.EXPIRMINS_10);
			}
		}	
		if(vo == null){
			vo = managerService.queryCouponActiveInfoMapByActiveId(activityId);
			if(vo != null){
				wl2DataCache.put(key, vo,BizContants.EXPIRMINS_10);
			}else{
				return "002" ;
			}
		}
		
		
//		Date now = new Date() ;
//		if(now.after(vo.getCouponStartDate()) && now.before(vo.getCouponEndDate())){//活动有效
			List<Long> userIdList = new ArrayList<Long>();
			userIdList.add(userId);
			List<String> list =managerService.generateCouponToUsers(activityId, userIdList);
			if(list !=null && list.size()>0){
				return list.get(0) ;
			}
//		}		
			return "000";
	}
	
	@Override
	public boolean clearCachedPage(Long pageId) {
		String key = BizContants.LOAD_PAGE+"_"+pageId.toString();
		wl2DataCache.remove(key);
		return true;
	}

	@Override
	public boolean clearCachedProduct(Long cmsMouldId,Long provinceId) {
		String key = BizContants.LOAD_PRODUCTS+"_"+cmsMouldId.toString()+"_"+provinceId.toString();
		wl2DataCache.remove(key);
		return true;
	}

	@Override
	public boolean clearCachedEntitys(String entityType, Long mId) {
		String key = BizContants.LOAD_PRODUCTS+"_"+entityType+"_"+mId.toString();
		wl2DataCache.remove(key);
		return true;
	}
	
	@Override
	public List<PageSearchEntity> searchPage(Long provinceId, Long categoryId,
			String keyword, int type) {
		if(SwitchUtil.getAppSwitchByType(SwitchCode.MAPSFRONT_SEARCHPAGE)==0)
	         return null;
		if(provinceId!=null&&((type==1&&categoryId!=null)||(type==2&&StringUtils.isNotBlank(keyword)))){
			try {
                return pageSearchService.searchPageFromDateTime(provinceId,categoryId,keyword,new Date());
            } catch (Exception e) {
                //logger.error("searchPage params: "+provinceId +"|"+ categoryId+"|"+keyword+"|" +type+" : "+e.getMessage());
            }
		}
		return null;
	}
	
	@Override
	public Result addNormal(CommInputVo inputoVo,Long endUserId, Long pmInfoId, int num) {
		Result result = new ResultModel();
		try{
			//通用参数
			ShoppingAddNormalInput shoppingAddNormalInput = (ShoppingAddNormalInput) setCommonPram(inputoVo,ShoppingAddNormalInput.class);
			//专用参数
			shoppingAddNormalInput.setPmId(pmInfoId);
			shoppingAddNormalInput.setNum(num);
			ShoppingCartBaseOutput output = FrontShoppingClient.getInstance().addNormalPmInfo(shoppingAddNormalInput);
			if(output != null && output.getRtnCode() != null){
				result.setSuccess(true);
				result.setResultDesc(output.getRtnCode());
				return result;
			}else{
				if(output != null){
					result.setSuccess(false);
					result.setResultDesc("1");
					return result;
				}else{
					result.setSuccess(false);
					result.setResultDesc("0");
					return result;
				}
			}
		}catch (Exception e) {
			result.setSuccess(false);
			result.setResultDesc("-1");
			return result;
		}
	}

	@Override
	public Result addPromotion(CommInputVo inputoVo, Long endUserId, int opType, Long promotionId,
			Long promotionLevelId, Long merchantId,
			Map<String, Integer> pmIdNums) {
		Result result = new ResultModel();
		try{
			//通用参数
			ShoppingAddPromotionInput input = (ShoppingAddPromotionInput) setCommonPram(inputoVo,ShoppingAddPromotionInput.class);
			
			//专用参数
			input.setOpType(opType) ;
			input.setPromotionId(promotionId) ;
			if(promotionLevelId != null){
				input.setPromotionLevelId(promotionLevelId) ;
			}
			input.setMerchantId(merchantId) ;
			Map<Long,Integer> map = new HashMap<Long, Integer>();
			for(Map.Entry<String, Integer> entry : pmIdNums.entrySet()) {
				Long pmid = Long.valueOf(entry.getKey());
				map.put(pmid, entry.getValue());
			}
			input.setPmIdNums(map) ;
			
			ShoppingCartBaseOutput  output = FrontShoppingClient.getInstance().addPromotion(input);		
			
			if(output != null && output.getRtnCode() != null){
				result.setSuccess(true);
				result.setResultDesc(output.getRtnCode());
				return result;
			}else{
				if(output != null){
					result.setSuccess(false);
					result.setResultDesc("1");
					return result;
				}else{
					result.setSuccess(false);
					result.setResultDesc("0");
					return result;
				}
			}
		}catch (Exception e) {
			result.setSuccess(false);
			result.setResultDesc("-1");
			return result;
		}
	}
	
	@SuppressWarnings("rawtypes")
	private CommInputVo setCommonPram(CommInputVo inputoVo,Class clazz) throws InstantiationException, IllegalAccessException{
		CommInputVo inputVo = (CommInputVo) clazz.newInstance();
		//通用参数
		inputVo.setClientSystem(inputoVo.getClientSystem());
		inputVo.setClientVersion(inputoVo.getClientVersion());
		inputVo.setClientAppVersion(inputoVo.getClientAppVersion());
		inputVo.setClientType(inputoVo.getClientType());
		inputVo.setInterfaceVersion(inputoVo.getInterfaceVersion());
		inputVo.setDeviceCode(inputoVo.getDeviceCode());
		inputVo.setTradeName(inputoVo.getTradeName());
		inputVo.setLongitude(inputoVo.getLongitude());
		inputVo.setLatitude(inputoVo.getLatitude());
		inputVo.setSessionId(inputoVo.getSessionId());
		inputVo.setUserId(inputoVo.getUserId());
		inputVo.setProvinceId(inputoVo.getProvinceId());
		inputVo.setShoppingBizType(inputoVo.getShoppingBizType());
		inputVo.setClientIp(inputoVo.getClientIp());
		return inputVo;		
	}
	
	@Override
	public GrouponBrandVO loadGrouponBrandVO(Long brandId) {
		return managerService.getBrandGrouponById(brandId);
	}
}
