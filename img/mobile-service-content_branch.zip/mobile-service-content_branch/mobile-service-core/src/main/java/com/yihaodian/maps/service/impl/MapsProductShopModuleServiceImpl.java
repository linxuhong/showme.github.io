package com.yihaodian.maps.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yihaodian.mobile.backend.maps.model.MapsProductShopModule;
import com.yihaodian.mobile.service.dal.backend.maps.dao.MapsProductShopModuleDAO;
import com.yihaodian.mobile.service.map.spi.MapsProductShopModuleService;

@Service
public class MapsProductShopModuleServiceImpl implements MapsProductShopModuleService {

	@Resource
	private MapsProductShopModuleDAO mapsProductShopModuleDAO;
	
	/**
	 * 批量新增
	 * @throws Exception 
	 */
	@Override
	public void batchInsert(List<MapsProductShopModule> list) throws Exception {
		if(list != null && list.size() > 0){
			mapsProductShopModuleDAO.batchInsert(list);
		}
	}

	/**
	 * 批量删除
	 * @throws Exception 
	 */
	@Override
	public void delEntitys(List<MapsProductShopModule> list) throws Exception {
		if(list != null && list.size() > 0){
			mapsProductShopModuleDAO.delEntitys(list);
		}
	}

	/**
	 * 批量更新
	 * @throws Exception 
	 */
	@Override
	public void batchUpdate(List<MapsProductShopModule> list) throws Exception {
		if(list != null && list.size() > 0){
			mapsProductShopModuleDAO.batchUpdate(list);
		}
	}

	/**
	 * 分页条件查询
	 * @throws Exception 
	 */
	@Override
	public List<MapsProductShopModule> queryEntitys(MapsProductShopModule mapsProductShopModule, Long pageStart,Long pageSize) throws Exception {
		List<MapsProductShopModule>	list = mapsProductShopModuleDAO.queryEntitys(mapsProductShopModule, pageStart, pageSize);
		return list;
	}

	/**
	 * 数据条数
	 * @throws Exception 
	 */
	@Override
	public Integer countEntitys(MapsProductShopModule mapsProductShopModule) throws Exception {
		Integer	count = mapsProductShopModuleDAO.countEntitys(mapsProductShopModule);
		return count;
	}

	/**
	 * 获取栏目数据
	 * @throws Exception 
	 */
	@Override
	public MapsProductShopModule queryMapsProductShopModule(MapsProductShopModule mapsProductShopModule) throws Exception {
		MapsProductShopModule result = mapsProductShopModuleDAO.queryMapsProductShopModule(mapsProductShopModule);
		return result;
	}

	/**
	 * 插入数据
	 * @throws Exception 
	 */
	@Override
	public Long insertMapsProductShopModule(MapsProductShopModule mapsProductShopModule) throws Exception {
		Long id = mapsProductShopModuleDAO.insertMapsProductShopModule(mapsProductShopModule);
		return id;
	}

}
