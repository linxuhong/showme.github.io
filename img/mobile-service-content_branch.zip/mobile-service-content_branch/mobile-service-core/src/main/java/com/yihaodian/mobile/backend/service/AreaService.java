package com.yihaodian.mobile.backend.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.backend.model.Area;
import com.yihaodian.mobile.framework.common.log.annotation.LogAnnotation;
import com.yihaodian.mobile.service.common.util.service.MemcachedProxy;
import com.yihaodian.mobile.service.dal.backend.AreaDao;
import com.yihaodian.mobile.vo.constant.CommonKey;


// TODO: Auto-generated Javadoc
/**
 * The Class AreaService.
 */
public class AreaService {
	
	/** The area dao. */
	private AreaDao areaDao;
	
	/**
	 * Creates the area.
	 *
	 * @param name the name
	 * @param id the id
	 */
	public void createArea(String name,Integer id){
		Area area=create(name,id);
		areaDao.saveArea(area);
	}
	
	/**
	 * Creates the.
	 *
	 * @param name the name
	 * @param id the id
	 * @return the area
	 */
	private Area create(String name, Integer id) {
		// TODO Auto-generated method stub
		Area area=new Area();
		if(id==null){
			area.setId(0);
		}
		else {
			area.setId(id);
		}
		area.setName(name);
		return area;
	}
	
	/**
	 * 一级区域.
	 *
	 * @param areaId the area id
	 * @return the first level area by area id
	 */
	@LogAnnotation
	public Area getFirstLevelAreaByAreaId(Integer areaId){
		for(Area area:getAllCachedAreas()){
			Area findOne=(area.checkSelfAndChildrenByAreaId(areaId,1));
			if(findOne!=null)
				return findOne;
    	}
		return null;
	}

	
	/**
	 * Gets the area by name.
	 *
	 * @param name the name
	 * @return the area by name
	 */
	@LogAnnotation
	public Area getAreaByName(String name){
		for(Area area:getAllCachedAreas()){
			if(area.getName().equals(name))
				return area;
		}
		return null;
	}
	
    /** The Constant KEY. */
    private static final String KEY="AD_ALL_AREAS";

	/**
	 * Gets the all cached areas.
	 *
	 * @return the all cached areas
	 */
    @LogAnnotation
	private List<Area> getAllCachedAreas(){
		MemcachedProxy proxy=MemcachedProxy.getInstance();
		List<Area> areas=(List<Area>)proxy.get(KEY);
		if(areas==null){
			areas=createAreaTree(areaDao.getAreas());
			if(areas!=null){
				proxy.put(KEY, areas,CommonKey.MEMCACHE_INVALID_TIME_ONE_WEEK);
			}
		}
		return areas;
	}
	
	/**
	 * Creates the area tree.
	 *
	 * @param dataFromDB the data from db
	 * @return the list
	 */
    @LogAnnotation
	private List<Area> createAreaTree(List<Area> dataFromDB){
		if(dataFromDB==null || dataFromDB.size()==0)
			return dataFromDB;
		Map<Integer,Area> map=new HashMap<Integer,Area>();
		List<Area> treeArea=new ArrayList<Area>();
		for(Area area:dataFromDB){
			if(area.getLevel()==1)
				treeArea.add(area);
			map.put(area.getId(), area);
		}
		for(Area area:dataFromDB){
			if(area.getParentId()!=null){
				Area parentArea=map.get(area.getParentId());
				if(parentArea!=null){
					area.setParentArea(parentArea);
					parentArea.addChild(area);
				}
			}
		}
		return treeArea;
	}
	
	/**
	 * Gets the area for bi visual.
	 *
	 * @return the area for bi visual
	 */
    @LogAnnotation
	public List<Area> getAreaForBIVisual(){
		List<Area> areaList = new ArrayList<Area>();
		for(Area area:getAllCachedAreas()){
			if(area.getLevel()==1 && area.getAreaId()<12){
				areaList.add(area);
			}
    	}
		return areaList;
	}
	
	/**
	 * Gets the area dao.
	 *
	 * @return the area dao
	 */
    @LogAnnotation
	public AreaDao getAreaDao() {
		return areaDao;
	}
	
	/**
	 * Sets the area dao.
	 *
	 * @param areaDao the new area dao
	 */
	public void setAreaDao(AreaDao areaDao) {
		this.areaDao = areaDao;
	}

}
