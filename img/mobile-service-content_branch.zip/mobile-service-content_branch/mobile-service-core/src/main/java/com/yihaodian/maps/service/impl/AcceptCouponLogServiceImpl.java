package com.yihaodian.maps.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yihaodian.mobile.backend.maps.model.AcceptCouponEntity;
import com.yihaodian.mobile.service.dal.backend.maps.dao.AcceptCouponDAO;
import com.yihaodian.mobile.service.map.spi.AcceptCouponLogService;


@Service("acceptCouponLogService")
public class AcceptCouponLogServiceImpl implements AcceptCouponLogService {
	
	@Resource
	private AcceptCouponDAO acceptCouponDAO ;
	
	@Override
	public Integer countAcceptCoupon(AcceptCouponEntity record) {
		Integer count = null ;
		if(record != null){
			count = acceptCouponDAO.countAcceptCoupon(record);
		}
		return count;
	}

	@Override
	public void deleteById(Long id) {
		if(id != null){
			acceptCouponDAO.deleteById(id);
		}
	}

	@Override
	public void saveAcceptCoupon(AcceptCouponEntity record) {
		if(record != null){
			acceptCouponDAO.saveAcceptCoupon(record);
		}
	}

	@Override
	public List<AcceptCouponEntity> selectAcceptCoupon(AcceptCouponEntity record) {
		List<AcceptCouponEntity> list = null ;
		if(record != null){
			list = acceptCouponDAO.selectAcceptCoupon(record);
		}
		return list;
	}

	@Override
	public void updateAcceptCoupon(AcceptCouponEntity record) {
		if(record != null){
			acceptCouponDAO.updateAcceptCoupon(record);
		}
	}
	

}
