/**
 * 
 */
package com.yihaodian.mobile.backend.service;

import java.util.List;

import com.yihaodian.mobile.backend.model.Area;
import com.yihaodian.mobile.backend.model.Platform;
import com.yihaodian.mobile.backend.model.Site;
import com.yihaodian.mobile.framework.common.log.annotation.LogAnnotation;


// TODO: Auto-generated Javadoc
/**
 *  
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->.
 *
 * @author luke
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class CommonDataService {
	
	/**
	 *  
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->.
	 *
	 * @return the sites
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	@LogAnnotation
	public List<Site> getSites() {
	     return  DataManager.getDataManager().getSites();
	}

	/**
	 *  
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->.
	 *
	 * @return the areas
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	@LogAnnotation
	public List<Area>  getAreas() {
		  return  DataManager.getDataManager().getAreaes();
	}

	/**
	 *  
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->.
	 *
	 * @return the platforms
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	@LogAnnotation
	public List<Platform> getPlatforms() {
		 return  DataManager.getDataManager().getPlatforms();

	}

	/**
	 * Creates the platform.
	 *
	 * @param name the name
	 * @return the platform
	 */
	@LogAnnotation
	public Platform createPlatform(String name) {
		Platform platform = new Platform();
		platform.setId(DataManager.generateId());
		platform.setName(name);
		DataManager.getDataManager().createPlatform(platform);
		return platform;
	}

	/**
	 * Creates the area.
	 *
	 * @param name the name
	 * @return the area
	 */
	@LogAnnotation
	public Area createArea(String name) {
		Area area = new Area();
		area.setId(DataManager.generateId());
		area.setName(name);
		DataManager.getDataManager().createArea(area);
		return area;
	}

	/**
	 * Creates the site.
	 *
	 * @param name the name
	 * @return the site
	 */
	@LogAnnotation
	public Site createSite(String name) {
		Site site = new Site();
		site.setId(DataManager.generateId());
		site.setName(name);
		DataManager.getDataManager().createSite(site);
		return site;
	}
	
	

	/**
	 * Gets the platform.
	 *
	 * @param name the name
	 * @return the platform
	 */
	@LogAnnotation
	public Platform getPlatform(String name) {
		return DataManager.getDataManager().getPlatform(name);
	}

	/**
	 * Gets the area.
	 *
	 * @param name the name
	 * @return the area
	 */
	@LogAnnotation
	public Area getArea(String name) {
		return DataManager.getDataManager().getArea(name);
	}

	/**
	 * Gets the site.
	 *
	 * @param name the name
	 * @return the site
	 */
	@LogAnnotation
	public Site getSite(String name) {
		return DataManager.getDataManager().getSite(name);
	}
	
	/**
	 * Gets the platform.
	 *
	 * @param id the id
	 * @return the platform
	 */
	@LogAnnotation
	public Platform getPlatform(int id) {
		return DataManager.getDataManager().getPlatform(id);
	}

	/**
	 * Gets the area.
	 *
	 * @param id the id
	 * @return the area
	 */
	@LogAnnotation
	public Area getArea(int id) {
		return DataManager.getDataManager().getArea(id);
	}

	/**
	 * Gets the site.
	 *
	 * @param id the id
	 * @return the site
	 */
	@LogAnnotation
	public Site getSite(int id) {
		return DataManager.getDataManager().getSite(id);
	}

	
}