package com.yihaodian.mobile.backend.service;

import java.util.List;

import com.google.gson.Gson;
import com.yihaodian.mobile.backend.model.BannerImageADLayout;
import com.yihaodian.mobile.backend.model.BigImageADLayout;
import com.yihaodian.mobile.backend.model.DailyXProductActivityLayout;
import com.yihaodian.mobile.backend.model.DataLayout;
import com.yihaodian.mobile.backend.model.FloorADLayout;
import com.yihaodian.mobile.backend.model.List2ColumnProductActivityLayout;
import com.yihaodian.mobile.backend.model.List2ColumnTitleADLayout;
import com.yihaodian.mobile.backend.model.ListProductActivityLayout;
import com.yihaodian.mobile.backend.model.MainEntryADLayout;
import com.yihaodian.mobile.backend.model.SmallImage2ColumnADLayout;
import com.yihaodian.mobile.backend.model.TitleOnlyADLayout;
import com.yihaodian.mobile.backend.model.WeeklyShowLayout;
import com.yihaodian.mobile.framework.common.log.annotation.LogAnnotation;
import com.yihaodian.mobile.service.dal.backend.DataLayoutDao;

// TODO: Auto-generated Javadoc
/**
 * The Class DataLayoutService.
 */
public class DataLayoutService {
    
	/** The data layout dao. */
	DataLayoutDao dataLayoutDao;
	
	/**
	 * Creates the data layout.
	 *
	 * @param dataLayoutName the data layout name
	 * @param type the type
	 * @param parameters the parameters
	 * @return the data layout
	 */
	@LogAnnotation
	public DataLayout createDataLayout(String dataLayoutName,Integer type,String parameters){
		DataLayout dataLayout=null;
		switch(type){
		case 1:
			dataLayout=new BannerImageADLayout(type);
			break;
		case 2:
			dataLayout=new MainEntryADLayout(type);;
			break;
		case 3:
			dataLayout=new TitleOnlyADLayout(type);
			break;
		case 4:
			dataLayout=new FloorADLayout(type);
			break;
		case 5:
			dataLayout=new SmallImage2ColumnADLayout(type);
			break;
		case 6:
			dataLayout=new WeeklyShowLayout(type);
			break;
		case 7:
			dataLayout=new DailyXProductActivityLayout(type);
			break;
		case 8:
			dataLayout=new List2ColumnTitleADLayout(type);
			break;
		case 9:
			dataLayout=new ListProductActivityLayout(type);
			break;
		case 10:
			dataLayout=new List2ColumnProductActivityLayout(type);
			break;
		case 11:
			dataLayout=new BigImageADLayout(type);
			break;
		case 12:
		default:
			dataLayout=new DataLayout(type);
			break;
		}
		dataLayout.setId(0);
		dataLayout.setName(dataLayoutName);
		dataLayout.setParameters(parameters);
		dataLayoutDao.saveDataLayout(dataLayout);
		dataLayout=dataLayoutDao.getLastDataLayout();
		return dataLayout;
	}
	
	/**
	 * Gets the all data layout.
	 *
	 * @return the all data layout
	 */
	@LogAnnotation
	public String getAllDataLayout(){
		List<DataLayout> dataLayouts=dataLayoutDao.getAllDataLayout();
		Gson gson=new Gson();
		return gson.toJson(dataLayouts);
	}
	
	/**
	 * Creates the data layout.
	 *
	 * @return the string
	 */
	@LogAnnotation
	public String createDataLayout(){
		System.out.println("=======dataLayout creating begin");
		/*DataLayout dataLayout=createDataLayout(1,"size:0");
		dataLayoutDao.saveDataLayout(dataLayout);
		dataLayout=createDataLayout(4,"isRightImage:false");
		dataLayoutDao.saveDataLayout(dataLayout);
		dataLayout=createDataLayout(4,"isRightImage:true");
		dataLayoutDao.saveDataLayout(dataLayout);
		dataLayout=createDataLayout(5,null);
		dataLayoutDao.saveDataLayout(dataLayout);*/
		DataLayout dataLayout=createDataLayout(7,"");
		dataLayoutDao.saveDataLayout(dataLayout);
		dataLayout=createDataLayout(8,"");
		dataLayoutDao.saveDataLayout(dataLayout);
		dataLayout=createDataLayout(6,"");
		dataLayoutDao.saveDataLayout(dataLayout);
		dataLayout=createDataLayout(10,"");
		dataLayoutDao.saveDataLayout(dataLayout);
		//dataLayout=createDataLayout(7,"");
		//dataLayoutDao.saveDataLayout(dataLayout);
		return null;
	}
    
    /**
     * Creates the data layout.
     *
     * @param type the type
     * @param parameters the parameters
     * @return the data layout
     */
	
	@LogAnnotation
    private DataLayout createDataLayout(Integer type,String parameters){
    	DataLayout dataLayout;
    	if(type==1){
    		dataLayout=new BannerImageADLayout(1);
    	}
    	else if(type==4){
    		dataLayout=new FloorADLayout(4);
    	}
    	else if(type==5){
    		dataLayout=new SmallImage2ColumnADLayout(5);
    	}
    	else if(type==9){
    		dataLayout=new ListProductActivityLayout(9);
    	}
    	else if(type==7){
    		dataLayout=new DailyXProductActivityLayout(7);
    	}  
    	else if(type==8){
    		dataLayout=new List2ColumnTitleADLayout(8);
    	}
    	else if(type==6){
    		dataLayout=new WeeklyShowLayout(6);
    	}
    	else if(type==10){
    		dataLayout=new List2ColumnProductActivityLayout(10);
    	}
    	else {
    		dataLayout=new DataLayout(type);
    		}
    	dataLayout.setParameters(parameters);
    	dataLayout.setId(0);
    	dataLayout.setName("");
    	return dataLayout;
    }
    
    /**
     * Gets the data layout by classname.
     *
     * @param classname the classname
     * @return the data layout by classname
     */
	@LogAnnotation
    public DataLayout getDataLayoutByClassname(String classname){
    	return dataLayoutDao.getDataLayoutByClassname(classname);
    }
	
	/**
	 * Gets the data layout dao.
	 *
	 * @return the data layout dao
	 */
	public DataLayoutDao getDataLayoutDao() {
		return dataLayoutDao;
	}

	/**
	 * Sets the data layout dao.
	 *
	 * @param dataLayoutDao the new data layout dao
	 */
	public void setDataLayoutDao(DataLayoutDao dataLayoutDao) {
		this.dataLayoutDao = dataLayoutDao;
	}
	
}
