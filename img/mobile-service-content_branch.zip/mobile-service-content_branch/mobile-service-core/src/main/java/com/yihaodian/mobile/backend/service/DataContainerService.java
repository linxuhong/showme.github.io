package com.yihaodian.mobile.backend.service;

import java.util.Date;
import java.util.List;

import com.yihaodian.mobile.backend.model.Coupon;
import com.yihaodian.mobile.backend.model.CouponListActivity;
import com.yihaodian.mobile.backend.model.Data;
import com.yihaodian.mobile.backend.model.DataLayout;
import com.yihaodian.mobile.backend.model.GrouponProductListActivity;
import com.yihaodian.mobile.backend.model.Image;
import com.yihaodian.mobile.backend.model.ListProductActivityLayout;
import com.yihaodian.mobile.backend.model.NoActionAdvertisement;
import com.yihaodian.mobile.backend.model.Product;
import com.yihaodian.mobile.backend.model.ProductListActivity;
import com.yihaodian.mobile.backend.model.View;
import com.yihaodian.mobile.backend.model.ViewData;
import com.yihaodian.mobile.backend.model.ViewDataContainer;
import com.yihaodian.mobile.framework.common.log.annotation.LogAnnotation;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.service.dal.backend.ContentDao;
import com.yihaodian.mobile.service.dal.backend.CouponDao;
import com.yihaodian.mobile.service.dal.backend.DataDao;
import com.yihaodian.mobile.service.dal.backend.DataLayoutDao;
import com.yihaodian.mobile.service.dal.backend.ImageDao;
import com.yihaodian.mobile.service.dal.backend.ProductDao;
import com.yihaodian.mobile.service.dal.backend.ViewDao;
import com.yihaodian.mobile.service.dal.backend.ViewDataContanierDao;
import com.yihaodian.mobile.service.dal.backend.ViewDataDao;


// TODO: Auto-generated Javadoc
/**
 * The Class DataContainerService.
 */
public class DataContainerService {
    
    /** The view data container dao. */
    private ViewDataContanierDao viewDataContainerDao;
    
    /** The view dao. */
    private ViewDao viewDao;
    
    /** The data layout dao. */
    private DataLayoutDao dataLayoutDao;
    
    /** The view data dao. */
    private ViewDataDao viewDataDao;
    
    /** The image dao. */
    private ImageDao imageDao;
    
    /** The backend product dao. */
    private ProductDao backendProductDao;
    
    /** The backend coupon dao. */
    private CouponDao backendCouponDao;
    
    /** The data dao. */
    private DataDao dataDao;
    
    /** The content dao. */
    private ContentDao contentDao;
    
    /**
     * Gets the view data containers.
     *
     * @param view the view
     * @return the view data containers
     */
    @LogAnnotation
    public List<ViewDataContainer> getViewDataContainers(View view){
    	//viewDataContainerDao.getViewDataContainerByView(view);//1
    	return viewDataContainerDao.getViewDataContainerWithDataLayout(view);//2
    }
    
    /**
     * Gets the view data container.
     *
     * @param containerId the container id
     * @return the view data container
     */
    @LogAnnotation
    public ViewDataContainer getViewDataContainer(Integer containerId){
    	ViewDataContainer viewDataContainer;
   	  /*  Date begin1=new Date();
    	viewDataContainer=viewDataContainerDao.getViewDataContainer(containerId);//1
    	if(viewDataContainer!=null){
    		List<ViewData> viewDatas;
    		viewDatas=viewDataDao.getViewData(viewDataContainer);
    		for(ViewData viewData:viewDatas){
				Data data=viewData.getData();
				String className=data.getClass().getSimpleName();
				List<Image> image;
				image=imageDao.getImages(data);
				data.setImages(image);
				if(className.equals("GrouponProductListActivity")){
					List<Product> products;
					products=backendProductDao.getProducts(data);
					((GrouponProductListActivity)data).setProducts(products);
				}
				else if(className.equals("ProductListActivity")){
					List<Product> products;
					products=backendProductDao.getProducts(data);
					((ProductListActivity)data).setProducts(products);
				}
				if(className.equals("CouponListActivity")){
					List<Coupon> coupons;
					coupons=backendCouponDao.getCoupons(data);
					((CouponListActivity)data).setCoupons(coupons);
				}
			}
    		viewDataContainer.setViewData(viewDatas);
    	}
    	else {
    	}
    	Date end1=new Date();
    	System.out.println("11old:getViewDataContainer>>>>>>>>end-begin:"+(end1.getTime()-begin1.getTime())+"<<<<<<<<");*/
    	Date begin2=new Date();
    	viewDataContainer=viewDataContainerDao.getViewDataContainerWithDataLayout(containerId);//2
    	if(viewDataContainer!=null){
    		List<ViewData> viewDatas;
    		viewDatas=viewDataDao.getViewDataWithData(viewDataContainer);
    		for(ViewData viewData:viewDatas){
				Data data=viewData.getData();
				List<Image> image;
				
				image=imageDao.getImages(data);
				data.setImages(image);
				
				
				if(data instanceof NoActionAdvertisement){
					String content=contentDao.getContent(data);
					if(!StringUtil.isEmpty(content)){
					    ((NoActionAdvertisement)data).setHtmlContent(content);
					}
					
				}else if(data instanceof GrouponProductListActivity){
					List<Product> products;
					products=backendProductDao.getProducts(data);
					((GrouponProductListActivity)data).setProducts(products);
				}
				else if(data instanceof ProductListActivity){
					List<Product> products;
					products=backendProductDao.getProducts(data);
					((ProductListActivity)data).setProducts(products);
				}
				if(data instanceof CouponListActivity){
					List<Coupon> coupons;
					coupons=backendCouponDao.getCoupons(data);
					((CouponListActivity)data).setCoupons(coupons);
				}
			}
    		viewDataContainer.setViewData(viewDatas);
    	}
    	Date end2=new Date();
    	System.out.println("22new:getViewDataContainer>>>>>>>>end-begin:"+(end2.getTime()-begin2.getTime())+"<<<<<<<<");
    	return viewDataContainer;
    }
    
    /**
     * Creates the container.
     *
     * @param view the view
     * @param dataLayout the data layout
     * @param name the name
     * @param order the order
     * @param trackcode the trackcode
     * @param tips the tips
     * @return the view data container
     */
    @LogAnnotation
    public ViewDataContainer createContainer(View view,DataLayout dataLayout,String name,Integer order,String trackcode,String tips){
    	ViewDataContainer viewDataContainer=createViewDataContainer(name,order,trackcode,tips);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	return viewDataContainerDao.getLastViewDataContainer();
    }
    
    /**
     * Creates the container.
     *
     * @return the string
     */
    
    @LogAnnotation
    public String createContainer(){
    	System.out.println("====viewdatacontainer creating begin");
    	/*View view=viewDao.getView("首页");
    	DataLayout dataLayout=dataLayoutDao.getDataLayoutByClassname(BannerImageADLayout.class.getSimpleName());
    	ViewDataContainer viewDataContainer=createViewDataContainer("轮播图",1,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	view=viewDao.getView("首页");
    	dataLayout=dataLayoutDao.getDataLayoutByClassname(FloorADLayout.class.getSimpleName());
    	viewDataContainer=createViewDataContainer("楼层1",2,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	view=viewDao.getView("首页");
    	dataLayout=dataLayoutDao.getDataLayoutByClassname(FloorADLayout.class.getSimpleName());
    	viewDataContainer=createViewDataContainer("楼层2",3,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	view=viewDao.getView("首页");
    	dataLayout=dataLayoutDao.getDataLayoutByClassname(FloorADLayout.class.getSimpleName());
    	viewDataContainer=createViewDataContainer("楼层3",4,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	view=viewDao.getView("首页");
    	dataLayout=dataLayoutDao.getDataLayoutByClassname(FloorADLayout.class.getSimpleName());
    	viewDataContainer=createViewDataContainer("楼层4",5,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	view=viewDao.getView("首页");
    	dataLayout=dataLayoutDao.getDataLayoutByClassname(SmallImage2ColumnADLayout.class.getSimpleName());
    	viewDataContainer=createViewDataContainer("促销推广",6,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);*/
    	View view=viewDao.getView("普通列表页");
    	DataLayout dataLayout=dataLayoutDao.getDataLayoutByClassname(ListProductActivityLayout.class.getSimpleName());
    	ViewDataContainer viewDataContainer=createViewDataContainer("产品列表",1,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	view=viewDao.getView("普通团购页");
    	dataLayout=dataLayoutDao.getDataLayoutByClassname(ListProductActivityLayout.class.getSimpleName());
    	viewDataContainer=createViewDataContainer("产品列表",1,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	view=viewDao.getView("普通抵购卷页");
    	dataLayout=dataLayoutDao.getDataLayoutByClassname(ListProductActivityLayout.class.getSimpleName());
    	viewDataContainer=createViewDataContainer("产品列表",1,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	view=viewDao.getView("普通促销列表页");
    	dataLayout=dataLayoutDao.getDataLayoutByClassname(ListProductActivityLayout.class.getSimpleName());
    	viewDataContainer=createViewDataContainer("产品列表",1,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	view=viewDao.getView("多栏目活动页面");
    	dataLayout=dataLayoutDao.getDataLayoutByClassname(ListProductActivityLayout.class.getSimpleName());
    	viewDataContainer=createViewDataContainer("活动列表1",1,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	viewDataContainer=createViewDataContainer("活动列表2",2,null,null);
    	viewDataContainerDao.saveViewDataContainer(view, dataLayout, viewDataContainer);
    	return null;
    }
    
    /**
     * Creates the view data container.
     *
     * @param name the name
     * @param order the order
     * @param trackcode the trackcode
     * @param tips the tips
     * @return the view data container
     */
    
    @LogAnnotation
    private ViewDataContainer createViewDataContainer(String name,Integer order,String trackcode,String tips){
    	ViewDataContainer viewDataContainer=new ViewDataContainer();
    	viewDataContainer.setId(0);
    	viewDataContainer.setName(name);
    	viewDataContainer.setOrder(order);
    	viewDataContainer.setState(ViewDataContainer.STATE.ENABLED.ordinal());
    	viewDataContainer.setTrakerId(trackcode);
    	viewDataContainer.setTips(tips);
    	return viewDataContainer;
    }
  
	/**
	 * Sets the view data container dao.
	 *
	 * @param viewDataContainerDao the new view data container dao
	 */
    @LogAnnotation
	public void setViewDataContainerDao(ViewDataContanierDao viewDataContainerDao) {
		this.viewDataContainerDao = viewDataContainerDao;
	}

	/**
	 * Gets the view data container dao.
	 *
	 * @return the view data container dao
	 */
    @LogAnnotation
	public ViewDataContanierDao getViewDataContainerDao() {
		return viewDataContainerDao;
	}
	
	/**
	 * Gets the view dao.
	 *
	 * @return the view dao
	 */
    @LogAnnotation
	public ViewDao getViewDao() {
		return viewDao;
	}
	
	/**
	 * Sets the view dao.
	 *
	 * @param viewDao the new view dao
	 */
	public void setViewDao(ViewDao viewDao) {
		this.viewDao = viewDao;
	}
	
	/**
	 * Gets the data layout dao.
	 *
	 * @return the data layout dao
	 */
	public DataLayoutDao getDataLayoutDao() {
		return dataLayoutDao;
	}
	
	/**
	 * Sets the data layout dao.
	 *
	 * @param dataLayoutDao the new data layout dao
	 */
	public void setDataLayoutDao(DataLayoutDao dataLayoutDao) {
		this.dataLayoutDao = dataLayoutDao;
	}
	
	/**
	 * Sets the view data dao.
	 *
	 * @param viewDataDao the new view data dao
	 */
	public void setViewDataDao(ViewDataDao viewDataDao) {
		this.viewDataDao = viewDataDao;
	}
	
	/**
	 * Gets the view data dao.
	 *
	 * @return the view data dao
	 */
	public ViewDataDao getViewDataDao() {
		return viewDataDao;
	}
	
	/**
	 * Gets the image dao.
	 *
	 * @return the image dao
	 */
	public ImageDao getImageDao() {
		return imageDao;
	}
	
	/**
	 * Sets the image dao.
	 *
	 * @param imageDao the new image dao
	 */
	public void setImageDao(ImageDao imageDao) {
		this.imageDao = imageDao;
	}

	/**
	 * Gets the data dao.
	 *
	 * @return the data dao
	 */
	public DataDao getDataDao() {
		return dataDao;
	}
	
	/**
	 * Sets the data dao.
	 *
	 * @param dataDao the new data dao
	 */
	public void setDataDao(DataDao dataDao) {
		this.dataDao = dataDao;
	}
	
	/**
	 * Gets the backend product dao.
	 *
	 * @return the backend product dao
	 */
	public ProductDao getBackendProductDao() {
		return backendProductDao;
	}
	
	/**
	 * Sets the backend product dao.
	 *
	 * @param backendProductDao the new backend product dao
	 */
	public void setBackendProductDao(ProductDao backendProductDao) {
		this.backendProductDao = backendProductDao;
	}
	
	/**
	 * Gets the backend coupon dao.
	 *
	 * @return the backend coupon dao
	 */
	public CouponDao getBackendCouponDao() {
		return backendCouponDao;
	}
	
	/**
	 * Sets the backend coupon dao.
	 *
	 * @param backendCouponDao the new backend coupon dao
	 */
	public void setBackendCouponDao(CouponDao backendCouponDao) {
		this.backendCouponDao = backendCouponDao;
	}
	
	/**
	 * Gets the content dao.
	 *
	 * @return the content dao
	 */
	public ContentDao getContentDao() {
		return contentDao;
	}
	
	/**
	 * Sets the content dao.
	 *
	 * @param contentDao the new content dao
	 */
	public void setContentDao(ContentDao contentDao) {
		this.contentDao = contentDao;
	}
    
	
}
