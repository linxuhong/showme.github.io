package com.yihaodian.mobile.app.domain.impl;

import java.sql.SQLException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yihaodian.mobile.app.domain.AppActivationStatService;
import com.yihaodian.mobile.backend.app.entity.AppActivationStat;
import com.yihaodian.mobile.service.dal.app.dao.AppActivationStatDAO;

@Service("appActivationStatService")
public class AppActivationStatServiceImpl implements AppActivationStatService {
	Logger logger = LoggerFactory.getLogger(AppActivationStatServiceImpl.class);

	@Autowired
	private AppActivationStatDAO appActivationStatDAO;
	
	@SuppressWarnings("deprecation")
	@Override
	public void saveOrUpdateStat(Date statDate, int receiveCount,
			int sendSuccessCount, int error4xxCount, int error5xxCount,
			int errorOtherCount, int receiveJdCount) {
		
		try {
			if (statDate==null) {
				statDate = new Date();
			}
			AppActivationStat stat = new AppActivationStat();
			stat.setStatDate(statDate);
			stat.setStatHour(statDate.getHours());
			stat.setError4xxCount(error4xxCount);
			stat.setError5xxCount(error5xxCount);
			stat.setErrorOtherCount(errorOtherCount);
			stat.setReceiveCount(receiveCount);
			stat.setReceiveJdCount(receiveJdCount);
			stat.setSendSuccessCount(sendSuccessCount);
			appActivationStatDAO.insertOrUpdateStat(stat);
		} catch (SQLException e) {
			logger.error("SQLException in saveOrUpdateStat", e);
		} catch (Exception e) {
			logger.error("Exception in saveOrUpdateStat", e);
		}

	}
	
}
