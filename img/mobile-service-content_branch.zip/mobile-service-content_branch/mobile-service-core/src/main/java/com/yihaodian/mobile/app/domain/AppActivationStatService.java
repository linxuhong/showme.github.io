package com.yihaodian.mobile.app.domain;

import java.util.Date;

public interface AppActivationStatService {

	/**
	 * jd激活反作弊数据统计
	 * @param statDate 统计日期
	 * @param receiveCount App上报数据的条数
	 * @param sendSuccessCount 往JD发送的数据条数
	 * @param error4xxCount 4XX错误数
	 * @param error5xxCount 5XX错误数
	 * @param errorOtherCount 其他错误数
	 * @param receiveJdCount jd回传的反作弊数据条数
	 */
	void saveOrUpdateStat(Date statDate, int receiveCount, int sendSuccessCount, 
			int error4xxCount, int error5xxCount, int errorOtherCount, int receiveJdCount);
}
