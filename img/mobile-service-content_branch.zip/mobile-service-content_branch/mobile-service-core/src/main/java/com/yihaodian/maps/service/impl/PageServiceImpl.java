package com.yihaodian.maps.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yihaodian.mobile.backend.maps.model.PageEntity;
import com.yihaodian.mobile.service.dal.backend.maps.dao.PageDao;
import com.yihaodian.mobile.service.map.spi.PageService;

/**
 * 活动页管理
 *
 */
@Service
public class PageServiceImpl implements PageService {
	@Resource
	private PageDao pageDao;
	
	@Override
	public List<PageEntity> findPage(PageEntity page, int pageNo, int pageSize) {
		 List<PageEntity> list=pageDao.getPageList(page, pageNo, pageSize);
		return list;
	}

	@Override
	public int count(PageEntity page) {
		int count = pageDao.count(page);
		return count;
	}

	@Override
	public Long saveEntity(PageEntity page) {
		return pageDao.savePage(page);
	}

	@Override
	public PageEntity getEntity(long id) {
		PageEntity pageEntity = pageDao.getPageDetail(id);
		return pageEntity;
	}

	@Override
	public void invalidPage(long id) {
		pageDao.updatePageInvalid(id);
	}

	@Override
	public PageEntity updateEntity(PageEntity page) {
		PageEntity pageEntity =null;
		if(page !=null){
			pageDao.updatePage(page);
			pageEntity = pageDao.getPageDetail(page.getId());
		}
		return pageEntity;
	}

}
