package com.yihaodian.maps.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.yihaodian.mobile.backend.maps.model.MHeaderEntity;
import com.yihaodian.mobile.backend.maps.model.ModuleEntity;
import com.yihaodian.mobile.backend.maps.model.PageSearchEntity;
import com.yihaodian.mobile.backend.maps.vo.ModuleContentVO;
import com.yihaodian.mobile.service.dal.backend.maps.dao.PageSearchDao;
import com.yihaodian.mobile.service.map.spi.PageSearchService;
@Service
public class PageSearchServiceImpl implements PageSearchService{
	@Resource
	private PageSearchDao pageSearchDao;


	@Override
	public void batchDelete(Long pageId) {
		pageSearchDao.deleteByPageId(pageId);
	}

	@Override
	public void batchSave(Long pageId, Date pageOnlineTime,
			Date pageOfflineTime, List<ModuleContentVO> mHlist,
			String categrayIds, String keywords, String title) {
		if(pageId!=null){
			if(mHlist.size()>0){
				List<PageSearchEntity> entitys = new ArrayList<PageSearchEntity>(); 
				if(StringUtils.isNotBlank(categrayIds)){
					//拼接类目
					List<PageSearchEntity> entityIds = batchEntityHandle(pageId,pageOnlineTime,pageOfflineTime,categrayIds,mHlist,1, title);
					if(entityIds.size()>0){
						entitys.addAll(entityIds);
					}
				}
				if(StringUtils.isNotBlank(keywords)){
					//拼接关键词
					List<PageSearchEntity> entityKeywords =batchEntityHandle(pageId,pageOnlineTime,pageOfflineTime,keywords,mHlist,2, title);
					if(entityKeywords.size()>0){
						entitys.addAll(entityKeywords);
					}
				}
				if(entitys.size()>0){
					pageSearchDao.batchSave(entitys);
				}
			}
			
		}
	}
	
	/**
	 * 依据活动页和头图都放时间，设置搜索有效时间；依据头图栏位投放地区设置搜索有效区域；
	 * -1表示全国
	 * @creator @wulibing
	 * @create @2015年5月19日 
	 * @param pageId
	 * @param pageOnlineTime
	 * @param pageOfflineTime
	 * @param targetStrs		类目id或关键词集合
	 * @param mHlist
	 * @param type   			1：类目，2：关键词
	 * @return
	 */
	private List<PageSearchEntity> batchEntityHandle(Long pageId, Date pageOnlineTime,
			Date pageOfflineTime,String targetStrs, List<ModuleContentVO> mHlist,int type,String title) {
		List<PageSearchEntity> entitys = new ArrayList<PageSearchEntity>();
		String[] targetWs = targetStrs.replace("，", ",").split(",");// 中英文间隔
		if (targetWs != null && targetWs.length > 0) {
			PageSearchEntity entity = null;
			ModuleEntity moduleCfg = null;
			MHeaderEntity mHeaderEntity = null ;
			Date mOnlineTime =null;
			Date mOfflineTime=null;
			String showAreas = null;
			String[] showAreaStrs = null;
			String url = null;
			Map<String,String> existIds = new HashMap<String,String>();
			for (String str : targetWs) {
				if (str != null && StringUtils.isNotBlank(str)) {
					for (ModuleContentVO vo : mHlist) {
						moduleCfg = vo.getModuleCfg();
						//无效栏位过滤
						if(moduleCfg==null||!moduleCfg.isValid()){
							continue;
						}
						mHeaderEntity = (MHeaderEntity) vo.getModule();
						//无效头图过滤
						if(mHeaderEntity==null||StringUtils.isBlank(mHeaderEntity.getImgUrl())||!mHeaderEntity.isValid()){
							continue;
						}
						url = mHeaderEntity.getImgUrl();
						//设置有效时间范围
						if(moduleCfg.getOnlineTime()==null||pageOnlineTime.before(moduleCfg.getOnlineTime())){
							mOnlineTime = moduleCfg.getOnlineTime();
						}else{
							mOnlineTime = pageOnlineTime;
						}
						if(moduleCfg.getOfflineTime()==null||pageOfflineTime.before(moduleCfg.getOfflineTime())){
							mOfflineTime = moduleCfg.getOfflineTime();
						}else{
							mOfflineTime = pageOfflineTime;
						}
						showAreas = moduleCfg.getShowArea();
						if(StringUtils.isBlank(showAreas)){
							showAreas="-1";
						}
						showAreaStrs = showAreas.split(",");
						if(type==1){
							//设置类目有效区域
							for (String s : showAreaStrs) {
								entity = new PageSearchEntity();
								entity.setId(pageId+"_"+s+"_"+str+"_n");
								//过滤重复数据
								if(existIds.containsKey(entity.getId())){
									continue;
								}else{
									existIds.put(entity.getId(),entity.getId());
								}
								entity.setPageId(pageId);
								entity.setCategoryId(Long.valueOf(str));
								entity.setImgUrl(url);
								entity.setProvinceId(Long.valueOf(s));
								entity.setOfflineTime(mOfflineTime);
								entity.setOnlineTime(mOnlineTime);
								entity.setTitle(title);
								entitys.add(entity);
							}
						}else{
							//设置关键词有效区域
							for (String s : showAreaStrs) {
								entity = new PageSearchEntity();
								//过滤重复数据
								entity.setId(pageId+"_"+s+"_n"+"_"+str.hashCode());
								if(existIds.containsKey(entity.getId())){
									continue;
								}else{
									existIds.put(entity.getId(),entity.getId());
								}
								entity.setPageId(pageId);
								entity.setKeyword(str);
								entity.setImgUrl(url);
								entity.setProvinceId(Long.valueOf(s));
								entity.setOfflineTime(mOfflineTime);
								entity.setOnlineTime(mOnlineTime);
								entity.setTitle(title);
								entitys.add(entity);
							}
						}
					}
				}
			}
		}
		return entitys;
	}

	@Override
	public List<PageSearchEntity> searchPageFromDateTime(Long provinceId,
			Long categoryId, String keyword, Date date) {
		return pageSearchDao.searchPageFromDateTime(provinceId,categoryId,keyword,date);
	}
}
