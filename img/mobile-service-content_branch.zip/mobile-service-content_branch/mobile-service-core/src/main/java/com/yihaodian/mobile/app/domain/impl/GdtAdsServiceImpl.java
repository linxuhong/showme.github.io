package com.yihaodian.mobile.app.domain.impl;

import gdt.dmp.DmpDataProto;
import gdt.dmp.DmpDataProto.DmpData;
import gdt.dmp.DmpDataProto.DmpData.VerticalType;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Charsets;
import com.google.common.collect.Maps;
import com.google.common.hash.Hashing;
import com.google.common.io.BaseEncoding;
import com.google.common.io.Files;
import com.google.protobuf.ByteString;
import com.yihaodian.mobile.app.domain.GdtAdsService;
import com.yihaodian.mobile.backend.app.enums.AudienceTypeEnum;
import com.yihaodian.mobile.backend.app.enums.DataTypeEnum;
import com.yihaodian.mobile.backend.app.enums.OperationTypeEnum;
import com.yihaodian.mobile.service.common.business.util.httpclient.HttpClientUtil;

@Service("gdtAdsService")
public class GdtAdsServiceImpl implements GdtAdsService {
	
	private static final Logger logger = LoggerFactory.getLogger(GdtAdsServiceImpl.class);
	
	private static final String TARGETING_AUDIENCE_CREATE_URL = "https://api.e.qq.com/ads/v3/targeting_audience/create";
	private static final String TARGETING_AUDIENCE_UPDATE_URL = "https://api.e.qq.com/ads/v3/targeting_audience/update";
	private static final String FILE_ADS_PATH = "file_ads.txt";
	private static final String ZIP_FILE_ADS_PATH = "file_ads.zip";
	private static final char CSV_VALUE_QUOTE = '"';
	
	protected Map<String, String> buildAdsHttpHeaders(Long advertiserId, String appKey) {
		Map<String, String> headers = Maps.newHashMap();
		headers.put("Content-Type", "multipart/form-data");
		headers.put("Authorization", "Bearer "+buildAuthorizationToken(advertiserId, appKey));
		
		return headers;
	}
	
	protected String buildAuthorizationToken(Long advertiserId, String appKey) {
		Long timestamp = new Date().getTime()/1000;
		String content = advertiserId.toString()+appKey+timestamp.toString();
		String sign = Hashing.sha1().hashString(content, Charsets.UTF_8).toString();
		String body = advertiserId.toString()+","+advertiserId.toString()+","+timestamp.toString()+","+sign;
		return BaseEncoding.base64().encode(body.getBytes(Charsets.UTF_8));
	}

	@Override
	public Long createTargetingAudience(Long advertiserId, String appKey, String audienceName, File payloadFile) {
		try {
			File file = buildZipFileFromPayload(payloadFile, false);
			
			Map<String, String> params = Maps.newHashMap();
			params.put("advertiser_id", advertiserId.toString());
			params.put("audience_name", audienceName);
			params.put("audience_type", AudienceTypeEnum.AUDIENCE_TYPE_PACKAGE.name());
			params.put("data_type", DataTypeEnum.DATA_TYPE_MD5_IMEI.name());
			params.put("file_name", file.getName());
			params.put("file_md5", Files.hash(file, Hashing.md5()).toString());
			params.put("description", audienceName);
			String responseBody = HttpClientUtil.doMultipartPost(TARGETING_AUDIENCE_CREATE_URL, params, buildAdsHttpHeaders(advertiserId, appKey), file);
			if (responseBody!=null) {
				JSONObject rtJson = JSON.parseObject(responseBody);
		    	Integer code = rtJson.getInteger("code");
		    	if (code!=null && code==0) {
		    		JSONObject rtData = rtJson.getJSONObject("data");
		    		return rtData.getLong("audience_id");
		    	} else {
		    		logger.error("Failed in calling createTargetingAudience API, response: "+responseBody);
		    	}
			}
		} catch (IOException e) {
			logger.error("IOException in createTargetingAudience", e);
		}
		
		return null;
	}
	
	@Override
	public void updateTargetingAudience(Long advertiserId, String appKey, Long audienceId, File payloadFile) {
		try {
			File file = buildZipFileFromPayload(payloadFile, false);
			
			Map<String, String> params = Maps.newHashMap();
			params.put("advertiser_id", advertiserId.toString());
			params.put("audience_id", audienceId.toString());
			params.put("operation_type", OperationTypeEnum.APPEND.name());
			params.put("data_type", DataTypeEnum.DATA_TYPE_MD5_IMEI.name());
			params.put("file_name", file.getName());
			params.put("file_md5", Files.hash(file, Hashing.md5()).toString());
			String responseBody = HttpClientUtil.doMultipartPost(TARGETING_AUDIENCE_UPDATE_URL, params, buildAdsHttpHeaders(advertiserId, appKey), file);
			if (responseBody!=null) {
				JSONObject rtJson = JSON.parseObject(responseBody);
		    	Integer code = rtJson.getInteger("code");
		    	if (code!=null) {
            		switch (code) {
            		case 0:
            			logger.info("Success in appendFileData for member "+advertiserId+" data source "+audienceId);
            			break;
            		case 1:
            			logger.warn("Partial success in appendFileData for member "+advertiserId+" data source "+audienceId+" response: "+responseBody);
            			break;
            		case 2:
            			logger.error("All Failed in appendFileData for member "+advertiserId+" data source "+audienceId);
            			break;
            		default:
            			logger.error("Failed in appendFileData for member "+advertiserId+" data source "+audienceId+" response: "+responseBody);
            			break;
            		}
            	}
			}
		} catch (IOException e) {
			logger.error("IOException in appendFileData", e);
		}
	}
	
	private File buildZipFileFromPayload(File payloadFile, boolean usePB) throws IOException {
		String adsFilePath = FILE_ADS_PATH;
		String zipFilePath = ZIP_FILE_ADS_PATH;
		final String parentPath = (payloadFile.getParent()==null)?"":payloadFile.getParent();
		if (StringUtils.isNotBlank(payloadFile.getParent())) {
			adsFilePath = parentPath+File.separator+FILE_ADS_PATH;
			zipFilePath = parentPath+File.separator+ZIP_FILE_ADS_PATH;
		}
		
		FileOutputStream adsOutput = new FileOutputStream(adsFilePath);
		Scanner scanner = new Scanner(payloadFile);
		System.out.println("First line: "+scanner.nextLine());
        while (scanner.hasNext()) {
            String line = scanner.nextLine();
            if (line.charAt(0)==CSV_VALUE_QUOTE && line.charAt(line.length()-1)==CSV_VALUE_QUOTE) {
            	line = line.substring(1, line.length()-1);
            }
            String hashed = Hashing.md5().hashString(StringUtils.lowerCase(line), Charsets.UTF_8).toString();
            if (usePB) {
            	DmpDataProto.IdLocator.Builder idLocator = DmpDataProto.IdLocator.newBuilder();
            	idLocator.setType(DmpDataProto.IdLocator.Type.HASH_IMEI);
            	idLocator.setId(ByteString.copyFromUtf8(hashed));
            	DmpData dmpData = DmpData.newBuilder().setIdLocator(idLocator)
            			.setVerticalType(VerticalType.VERTICAL_GENERAL_EC)
            			.build();
            	dmpData.writeDelimitedTo(adsOutput);
            } else {
            	adsOutput.write(hashed.getBytes(Charsets.UTF_8));
            	adsOutput.write("\n".getBytes(Charsets.UTF_8));
            }
        }
        scanner.close();
        adsOutput.close();
		
		FileOutputStream fos = new FileOutputStream(zipFilePath);
		ZipOutputStream zos = new ZipOutputStream(fos);
		FileInputStream fis = new FileInputStream(adsFilePath);
		ZipEntry ze= new ZipEntry(FILE_ADS_PATH);
		zos.putNextEntry(ze);
		int len;
		byte[] buffer = new byte[1024];
		while ((len = fis.read(buffer)) > 0) {
			zos.write(buffer, 0, len);
		}
		fis.close();
		zos.closeEntry();
		zos.close();
		
		return new File(zipFilePath);
	}
	
}
