package com.yihaodian.maps.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.yihaodian.mobile.backend.maps.beans.PageList;
import com.yihaodian.mobile.backend.maps.core.BizContants;
import com.yihaodian.mobile.backend.maps.model.PageConfigEntity;
import com.yihaodian.mobile.backend.maps.model.PageEntity;
import com.yihaodian.mobile.backend.maps.vo.ModuleContentVO;
import com.yihaodian.mobile.backend.maps.vo.PageWholeVO;
import com.yihaodian.mobile.service.map.spi.APIManagerService;
import com.yihaodian.mobile.service.map.spi.BizService;
import com.yihaodian.mobile.service.map.spi.ModuleService;
import com.yihaodian.mobile.service.map.spi.PageConfigService;
import com.yihaodian.mobile.service.map.spi.PageSearchService;
import com.yihaodian.mobile.service.map.spi.PageService;

@Service("aPIManagerService")
public class APIManagerServiceImpl implements APIManagerService {
	private static final Logger log = LoggerFactory.getLogger(APIManagerServiceImpl.class);
	@Resource
	private PageService pageService;
	
	@Resource
	private PageConfigService pageConfigService;
	
	@Resource
	private ModuleService moduleService;
	
	@Resource
	private BizService bizService;
	
	@Resource
	private PageSearchService pageSearchService;
	
	/**
	 * 依据查询查询活动页信息（分页）
	 */
	@Override
	public PageList<PageEntity> getPageList(PageEntity page,
			PageList<PageEntity> pagelist) {
		List<PageEntity> result = pageService.findPage(page,pagelist.getPageNo(),pagelist.getPageSize());
		int totalNum = pageService.count(page);
		pagelist.setResult(result);
		pagelist.setTotalNum(totalNum);
		return pagelist;
	}

	/**
	 * 新增活动页并返回新增实例:包括初始化全局
	 */
	@Override
	public PageEntity newPage(PageEntity page) {
		PageConfigEntity pageConfig =new PageConfigEntity();
		pageConfig = pageConfigService.saveOrUpdate(pageConfig);
		page.setConfigId(pageConfig.getId());
		
		Long id = pageService.saveEntity(page);
		PageEntity p=pageService.getEntity(id);
		return p;
	}

	/**
	 * 删除活动页:使活动页无效
	 */
	@Override
	public void invalidPage(long id) {
		pageService.invalidPage(id);
	}

	/**
	 * 查询活动页信息
	 */
	@Override
	public PageEntity getPageEntity(long id) {
		return pageService.getEntity(id);
	}

	/**
	 * 编辑保存活动页信息:如果有头图，则更新搜索信息
	 */
	@Override
	public PageEntity updatePageEntity(PageEntity page) {
		PageEntity pageEntity = pageService.updateEntity(page);
		try {
			List<ModuleContentVO> existsModuleVOList = moduleService.findModuleVOByPageId(page.getId());
			//如果有头图，则更新搜索信息
			//头图
			List<ModuleContentVO> mHlist = new ArrayList<ModuleContentVO>();
			for (ModuleContentVO moduleContentVO : existsModuleVOList) {
				if(moduleContentVO.getModule()!=null&&moduleContentVO.getModule().getType()==BizContants.MODULE_TYPE_HEADER){
					mHlist.add(moduleContentVO);
				}
			}
			pageSearchService.batchDelete(page.getId());
			if(mHlist.size()>0&&(StringUtils.isNotBlank(pageEntity.getCategrayId())||StringUtils.isNotBlank(pageEntity.getKeywords()))){
                if (pageEntity.getIsSearched())
                    pageSearchService.batchSave(pageEntity.getId(),pageEntity.getOnlineTime(),pageEntity.getOfflineTime(),mHlist,pageEntity.getCategrayId(),pageEntity.getKeywords(),pageEntity.getTitle());
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return pageEntity;
	}

	/**
	 * 查询活动页内容信息:整个活动页的全部信息
	 */
	@Override
	public PageWholeVO getPageContentById(long id) {
		PageWholeVO vo = new PageWholeVO();
		PageEntity page = pageService.getEntity(id);
		vo.setPage(page);
		if(page!=null){
			if(page.getConfigId()!=null){
				PageConfigEntity pageConfig = pageConfigService.getEntity(page.getConfigId());
				vo.setPageConfig(pageConfig);
			}
			List<ModuleContentVO> moduleList = moduleService.findModuleVOByPageId(id);
			vo.setModuleList(moduleList);
		}
		return vo;
	}

	/**
	 * 配置活动页内容:整个活动页的全部信息,如果有头图，则更新搜索信息
	 * 暂时不需要保存page
	 */
	@Override
	public boolean saveOrUpdatePageContent(PageWholeVO pvo) {
		boolean result = false;
		PageEntity page = pvo.getPage();
		if(page!=null&&page.getId()!=null){
			page = pageService.getEntity(page.getId());
			if(page==null){
				return result;
			}
			
			Long configId = page.getConfigId();
			PageConfigEntity pageConfig = pvo.getPageConfig();
			if(pageConfig!=null){
				if(configId!=null){
					pageConfig.setId(configId);
				}
				//新增或修改配置
				pageConfig = pageConfigService.saveOrUpdate(pageConfig);
				
				if(configId==null){
					//设置全局配置
					page.setConfigId(pageConfig.getId());
					page = pageService.updateEntity(page);
				}
			}
			
			//头图
			List<ModuleContentVO> mHlist = new ArrayList<ModuleContentVO>();
			
			List<ModuleContentVO> moduleList = pvo.getModuleList();
			Map<Long,Long> savedModuleIdMaps = new HashMap<Long,Long>();
			List<Long> moduleIdList = new ArrayList<Long>();
			if(moduleList!=null&&moduleList.size()>0){
				//保存或修改配置信息
				for (ModuleContentVO moduleContentVO : moduleList) {
					//新增或修改整个栏位的信息（包括配置）
					moduleContentVO = moduleService.saveOrUpdate(moduleContentVO);
					if(moduleContentVO!=null){
						moduleIdList.add(moduleContentVO.getModuleCfg().getId());
						savedModuleIdMaps.put(moduleContentVO.getModuleCfg().getId(), moduleContentVO.getModuleCfg().getId());
						
						if(moduleContentVO.getModule()!=null&&moduleContentVO.getModule().getType()==BizContants.MODULE_TYPE_HEADER){
							mHlist.add(moduleContentVO);
						}
					}
				}
			}
			
			//删除非保存module信息
			List<ModuleContentVO> existsModuleVOList = moduleService.findModuleVOByPageId(page.getId());
			for (ModuleContentVO moduleContentVO : existsModuleVOList) {
				if(!savedModuleIdMaps.containsKey(moduleContentVO.getModuleCfg().getId())){
					//物理删除整个栏位信息
					moduleService.deleteModuleCfg(moduleContentVO.getModuleCfg().getId());
					if(moduleContentVO.getModule()!=null&&moduleContentVO.getModule().getId()!=null){
						//物理删除栏位信息
						moduleService.deleteModule(moduleContentVO.getModule().getId(),moduleContentVO.getModule().getType());
					}
				}
			}
			
			//物理删除页面和栏位的对应关系
			moduleService.deleteModuleRefPMByPageId(page.getId());
			//设置级联关系
			int orderNum = 0;
			for (Long id : moduleIdList) {
				moduleService.insertRefPM(id,page.getId(),++orderNum);
			}

			//保存类目和关键词搜索信息
			pageSearchService.batchDelete(page.getId());
			if(mHlist.size()>0&&(StringUtils.isNotBlank(page.getCategrayId())||StringUtils.isNotBlank(page.getKeywords()))){
			    if (page.getIsSearched())
				pageSearchService.batchSave(page.getId(),page.getOnlineTime(),page.getOfflineTime(),mHlist,page.getCategrayId(),page.getKeywords(),page.getTitle());
			}
			result = true;
		}
		return result;
	}

	/**
	 * 新增一个模块(以配置为主，可以附带栏位信息)
	 */
	@Override
	public ModuleContentVO saveOrUpdateModuleContent(ModuleContentVO mvo) {
		ModuleContentVO moduleContentVO = moduleService.saveOrUpdate(mvo);
		return moduleContentVO;
	}

	/**
	 * 逻辑删除一个栏位
	 */
	@Override
	public boolean invalidModuleCfg(Long moduleCfgId) {
		return moduleService.invalidModuleCfg(moduleCfgId);
	}
}
