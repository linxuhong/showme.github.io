package com.yihaodian.mobile.backend.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.yihaodian.mobile.backend.model.ActivityRule;
import com.yihaodian.mobile.backend.model.Area;
import com.yihaodian.mobile.backend.model.CategoryBrand;
import com.yihaodian.mobile.backend.model.CategoryDescription;
import com.yihaodian.mobile.backend.model.Data;
import com.yihaodian.mobile.backend.model.ModelFilterOption;
import com.yihaodian.mobile.backend.model.Platform;
import com.yihaodian.mobile.backend.model.PromotionActivity;
import com.yihaodian.mobile.backend.model.Site;
import com.yihaodian.mobile.backend.model.View;
import com.yihaodian.mobile.backend.model.ViewData;
import com.yihaodian.mobile.backend.model.ViewDataContainer;
import com.yihaodian.mobile.backend.model.ViewTemplate;
import com.yihaodian.mobile.service.core.util.SwitchUtil;
import com.yihaodian.mobile.service.core.util.backend.PCBackendUtil;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.constant.CommonKey;
import com.yihaodian.mobile.vo.constant.Constants;
import com.yihaodian.mobile.vo.constant.SwitchCode;

// TODO: Auto-generated Javadoc
/**
 * View type:
 * 
 * 	首页                             1
 *  日历首页                          2
 *  每日惠（日历详情页）                3
 *  品牌旗舰页                        4
 *  无栏目产品列表页                   5 
 *  cms列表页（多栏目活动页面）         6
 *  cms聚合页                        7
 *  每日N款（N=1,2,..）               8
 *  抵购卷页面                        9
    手机充值页面                      10 
    进口馆页面                        11     
    品牌店铺                          12 
    N元N件                           13
    专题页                           14
    团购首页                         15
 团闪首页                             16
     爱分享规则                      17
 native内嵌               18
   类目广告                            19 
                             
                             
  
 * 
 * Container(layout)  type:
 * 首页  banner广告                 1
 * 首页  图片主题广告入口             2
 * 首页  文字广告快速入口             3 
 * 首页   楼层广告                   4
 * 首页   两列小图广告                5
 * 日历首页  周期性布局（广告和活动）    6
 * 日历详情页 每日n产品                7
 * 每日惠两列广告类似布局              8
 * 列表展示产品类似布局"                     9
 * 抵购卷显示列表                      10
 * 大图广告列表展示                     11
 * 品牌旗舰展示广告类似布局             12  
 * 每日最大牌类似布局                   13  
 * 进口馆首页顶部促销布局                14  
 * 进口馆首页楼层布局                   15
 *  
 * 
 * Data type（广告素材类型）:
 * cms广告                              1
 * 搜索词广告                            2
 * 类目广告                              3
 * 商城店铺广告                           4
 * 一号团购广告                           5
 * 品牌广告                              6 
 * 普通促销活动                           7
 * 产品列表活动（包括团购列表）              8
 * 抵购卷列表活动                         9 
 * 积分兑换活动                          10
 * 秒杀活动                             11
 * 满赠                                12
 * 满减                                13 
 * 满折                                14
 * 团购商品                             15
 * N元N件                              16
 * 无链接广告                            17
 * 链接广告                              18
 *  
 * @author luke
 *
 */
public class InterfaceService {
	
	/** The logger. */
	Logger logger=Logger.getLogger(InterfaceService.class);
    //private CommonDataService commonService=new CommonDataService();
    /** The view service. */
    private ViewService viewService;
    //private ViewDataService viewDataService =new ViewDataService();
    /** The site service. */
    private SiteService siteService;
    
    /** The platform service. */
    private PlatformService platformService=new PlatformService(); 
    
    /** The area service. */
    private AreaService areaService;
   
   /**
    * Gets the view service.
    *
    * @return the view service
    */
   public ViewService getViewService() {
		return viewService;
	}



	/**
	 * Sets the view service.
	 *
	 * @param viewService the new view service
	 */
	public void setViewService(ViewService viewService) {
		this.viewService = viewService;
	}



	/**
	 * Gets the site service.
	 *
	 * @return the site service
	 */
	public SiteService getSiteService() {
		return siteService;
	}



	/**
	 * Sets the site service.
	 *
	 * @param siteService the new site service
	 */
	public void setSiteService(SiteService siteService) {
		this.siteService = siteService;
	}



	/**
	 * Gets the platform service.
	 *
	 * @return the platform service
	 */
	public PlatformService getPlatformService() {
		return platformService;
	}



	/**
	 * Sets the platform service.
	 *
	 * @param platformService the new platform service
	 */
	public void setPlatformService(PlatformService platformService) {
		this.platformService = platformService;
	}



	/**
	 * Gets the area service.
	 *
	 * @return the area service
	 */
	public AreaService getAreaService() {
		return areaService;
	}



	/**
	 * Sets the area service.
	 *
	 * @param areaService the new area service
	 */
	public void setAreaService(AreaService areaService) {
		this.areaService = areaService;
	}


    /** The interface service. */
    private static InterfaceService interfaceService = new InterfaceService();
    
   
    
    
    
    
	/**
	 * Gets the interface service.
	 *
	 * @return the interface service
	 */
	public static InterfaceService getInterfaceService() {
		return interfaceService;
	}
	
	
	
	/**
	 * Instantiates a new interface service.
	 */
	public InterfaceService(){
		 //create test data, 以后清除
         //FakeDataManager.createFakeData();
    }
	
	/**
	 * Gets the site.
	 *
	 * @param siteType the site type
	 * @return the site
	 */
	private Site getSite(int siteType){
//		 if(siteType==1)
//		    return siteService.getSiteByName("mobile");
//		 else
//			return siteService.getSiteByName("mall");
		Site site = new Site();
		site.setId(1);
		site.setName("mobile");
		return site;
	}
	
	/**
	 * Gets the platform.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @return the platform
	 */
	private Platform getPlatform(String traderName,int siteType){
		//二合一版本中，tradername=androidSystem, iosSystem, sitetype==2
		// 此时将转换tradername分别为 android1MallSystem, ios1MallSystem
		if((CommonKey.TRADER_NAME_IPHONE.equals(traderName) && siteType==2)){
			 traderName=CommonKey.TRADER_NAME_IPHONE_MALL;
			
		}else if((CommonKey.TRADER_NAME_ANDROID.equals(traderName) && siteType==2)){
			 traderName=CommonKey.TRADER_NAME_ANDROID_MALL;
			
		}
	    return platformService.getPlatformByName(traderName);
	}
	
	/**
	 * Gets the area.
	 *
	 * @param mechantId the mechant id
	 * @return the area
	 */
	private Area getArea(int mechantId){
		return areaService.getFirstLevelAreaByAreaId(mechantId);
	}
	
	/**
	 * Gets the banner data.
	 *
	 * @param traderName : platform type
	 * @param siteType :    yihaodian/yihaomall
	 * @param mechantId  :   area
	 * @param type 1:  index ; type 2 : groupon index
	 * @param provinceId the province id
	 * @return the banner data
	 */
	public JsonObject getBannerData(String traderName,int siteType,int mechantId,int type,long provinceId){
		try{
			Site site=getSite(siteType);
			Area area=getArea(mechantId);
			Platform platform=getPlatform(traderName,siteType);
			View view=null;
			if(type==1)
				view=viewService.getViewByType(site, platform, area, Constants.VIEW_TYPE.INDEX.ordinal());
			else
				view=viewService.getViewByType(site, platform, area, Constants.VIEW_TYPE.GROUPON_INDEX.ordinal());
			if(view==null)
				return null;
			//View view= viewService.getViewObjectById(list.get(0).getId());
			//container 0
			List<ViewDataContainer>  containerList=view.getViewDataContainer(Constants.LAYOUT_TYPE.BANNER.ordinal());
			if(containerList!=null && containerList.size()>0){
				return containerList.get(0).generateData(false,getFilterOption(site,area,provinceId));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
		
	/**
	 * Gets the flash index.
	 *
	 * @param trader the trader
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param provinceId the province id
	 * @return the flash index
	 */
	public JsonObject getFlashIndex(Trader trader,int siteType,int mechantId,int provinceId){
		return getIndexObject(trader,siteType,mechantId,provinceId, Constants.VIEW_TYPE.GROUPON_FLASH_INDEX.ordinal(),null);
	}
	
	/**
	 * 检查viewtype是否正确.
	 *
	 * @param viewType the view type
	 * @return true, if successful
	 */
	private boolean checkViewType(int viewType){
		Constants.VIEW_TYPE[] types=Constants.VIEW_TYPE.values();
		if(viewType>0 && viewType<types.length)
			return true;
		
		return false;
	}

	/**
	 * 检查viewtype是否正确.
	 *
	 * @param cType the c type
	 * @return true, if successful
	 */
	private boolean checkContainerType(int cType){
		if(cType==-1)
			return false;
		Constants.LAYOUT_TYPE[] types=Constants.LAYOUT_TYPE.values();
		if(cType==51){
			return true;
		}
		if(cType>0 && cType<types.length)
			return true;
		
		return false;
	}
	
	/**
	 * 获取各种类型的首页数据.
	 *
	 * @param trader the trader
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param provinceId the province id
	 * @param viewType the view type
	 * @param userType the user type
	 * @return the index object
	 */
	public JsonObject getIndexObject(Trader trader,int siteType,int mechantId,int provinceId,int viewType,Long userType){
		return getIndexObject(trader,siteType,mechantId,provinceId,viewType,-1,userType);
	}
	
	/**
	 * Gets the index object.
	 *
	 * @param trader the trader
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param provinceId the province id
	 * @param viewType the view type
	 * @param containerType  -1 for all
	 * @param userType the user type
	 * @return the index object
	 */
	public JsonObject getIndexObject(Trader trader,int siteType,int mechantId,int provinceId,int viewType,int containerType,Long userType){
		
		if(!checkViewType(viewType))
		   return null;
		if(!checkContainerType(containerType))
			containerType=-1;
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		Platform platform=getPlatform(trader.getTraderName(),siteType);
		View view =viewService.getViewByType(site, platform, area,viewType,containerType);
		if(view==null)
			return null;
		if(viewType==Constants.VIEW_TYPE.CMS_ALL.ordinal() || viewType==Constants.VIEW_TYPE.CMS.ordinal() || viewType==Constants.VIEW_TYPE.CMS_MAX.ordinal()){
			//首页配置成cms，比如微便利商家，则按cms的方式获取数据
			 return filterCMSView(view, site, area, provinceId);
		}
		//View view= viewService.getViewObjectById(list.get(0).getId());
		if(viewType == Constants.VIEW_TYPE.INDEX.ordinal()){
			//根据渠道号过滤广告
			//filterADChannel(trader,view);  次数过滤无法加入缓存
			fetchADFromPCBackend(view,siteType,provinceId,trader.getTraderName(),userType);
		}
		return view.generateData(false,getFilterOption(site,area,provinceId));
	}
	
	/**
	 * Gets the filter option.
	 *
	 * @param site the site
	 * @param area the area
	 * @param provinceId the province id
	 * @return the filter option
	 */
	/**
	 * 无线2.0首页
	 * @param trader
	 * @param siteType
	 * @param provinceId
	 * @param userType
	 * @return
	 */
	public Map<String,JsonObject> getIndexObjectV2(Trader trader,String viewCode,int siteType,int mechantId,int provinceId,Long userType,String cityCode,Integer viewType,String cityId, boolean useCache){
		Map<String,JsonObject> map = new HashMap<String,JsonObject>();
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		//Platform platform=getPlatform(trader.getTraderName(),siteType);
		//Android和iPhone获取PC配置的广告 //新增ipad类型,其中tradername为ipadSystem
		if(CommonKey.TRADER_NAME_ANDROID.equals(trader.getTraderName()) || CommonKey.TRADER_NAME_IPHONE.equals(trader.getTraderName())
				|| CommonKey.TRADER_NAME_IPAD.equals(trader.getTraderName())||CommonKey.TRADER_NAME_WEBSITE.equals(trader.getTraderName())){		
			Map<String,List<ViewDataContainer>> viewMaps = PCBackendUtil.getIndexContainers(viewCode,provinceId,siteType,trader.getTraderName(),userType,cityCode,cityId, useCache);
		    //获取无线后台广告
		    //View wirelessView =viewService.getViewByType(site, platform, area,viewType,-1);
		    //组装PC后台和无线后台广告位
		    //fetchADFromWirelessBackend(view,wirelessView);
			for(Map.Entry<String,List<ViewDataContainer>> entry : viewMaps.entrySet()){
				List<ViewDataContainer> containers = entry.getValue();
				if(containers!=null){
					View view = getViewForTemplateIndex(viewType);
					view.setViewDataContainers(containers);
					JsonObject jo = view.generateData(false,getFilterOption(site,area,provinceId));
					map.put(entry.getKey(), jo);
				}
			}
		}
		return map; 
	}
	
	private View getViewForTemplateIndex(Integer viewType){
		View view = new View();
		view.setId(123);
		view.setViewDataContainers(new ArrayList<ViewDataContainer>());
		view.setHasRule(0);
		view.setIsSupportApp(0);
		view.setShareable(-1);
		view.setName(Constants.INDEX_NAME);
		ViewTemplate viewTemplate = new ViewTemplate();
		viewTemplate.setType(viewType);
		viewTemplate.setName(Constants.INDEX_NAME);
		view.setViewTemplate(viewTemplate);
		return view;
	}
	
	private ModelFilterOption getFilterOption(Site site,Area area,long provinceId){
		ModelFilterOption option=new ModelFilterOption();
		option.setSiteType(site);
		Area targetArea=area.checkSelfAndChildrenByAreaId((int)provinceId, 2);
		if(targetArea!=null){
			option.setArea(targetArea);
		}else{
			option.setArea(area);
		}
		return option;
	}
	
	/**
	 * 从PC获取广告
	 * 6个楼层+轮播图
	 * MobileIndex_FloorComp5_bigpicture_default  左上
	 * MobileIndex_FloorComp5_promotion_default  右上
	 * MobileIndex_FloorComp5_keyword_default  右下搜索词.
	 *
	 * @param view the view
	 * @param siteType the site type
	 * @param provinceId the province id
	 * @param traderName the trader name
	 * @param userType the user type
	 */
	private void fetchADFromPCBackend(View view,int siteType,long provinceId,String traderName,Long userType){
		if(!usePCBackend(traderName)){
			return;
		}
		if(view==null || view.getViewTemplate()==null || view.getViewTemplate().getType()!=Constants.VIEW_TYPE.INDEX.ordinal()){
			return;
		}
	    if(CommonKey.TRADER_NAME_ANDROID.equals(traderName) || CommonKey.TRADER_NAME_IPHONE.equals(traderName)){		
	    	removeContainer(view);
	    	if(view.getViewDataContainers() == null){
	    		view.setViewDataContainers(new ArrayList<ViewDataContainer>());
			}
	    	PCBackendUtil.exchangeIndexContainers(view.getViewDataContainers(),provinceId,siteType,traderName,userType);
		}
	}
	
	/**
	 * 获取分渠道广告位
	 * @param view
	 * @param wirelessView
	 */
//	private void fetchADFromWirelessBackend(View view ,View wirelessView){
//		if(view == null || wirelessView == null){
//			return;
//		}
//		if(view.getViewDataContainers() == null || wirelessView.getViewDataContainers() == null){
//			return;
//		}
//		if(wirelessView.getViewDataContainers().size()<=0 || view.getViewDataContainers().size()<=0){
//			return;
//		}
//		int flag = -1;
//		for(int j=0,length=view.getViewDataContainers().size();j<length;j++){
//			if(view.getViewDataContainers().get(j).getViewLayout() != null && view.getViewDataContainers().get(j).getViewLayout().getType() == Constants.LAYOUT_TYPE.FUNCTION.ordinal()){
//				flag = j+1;
//				break;
//			}
//		}
//		for(int i=0,length=wirelessView.getViewDataContainers().size();i<length;i++){
//			if(wirelessView.getViewDataContainers().get(i).getViewLayout() != null && wirelessView.getViewDataContainers().get(i).getViewLayout().getType() == Constants.LAYOUT_TYPE.CHANNEL_IMAGE.ordinal()){
//				//将渠道广告位放入首页广告位中
//				if(flag>0){
//					view.getViewDataContainers().add(flag,wirelessView.getViewDataContainers().get(i));
//				}
//			}
//		}
//	}
	
	//去掉相关的无线广告位 目前包括轮播图，楼层
	/**
	 * Removes the container.
	 *
	 * @param view the view
	 */
	private void removeContainer(View view){
		if(view != null && view.getViewDataContainers() != null ){
			List<ViewDataContainer> listFloor= view.getViewDataContainer(Constants.LAYOUT_TYPE.FLOOR.ordinal());
			List<ViewDataContainer> listBanner = view.getViewDataContainer(Constants.LAYOUT_TYPE.BANNER.ordinal());
			//List<ViewDataContainer> listImageRow = view.getViewDataContainer(Constants.LAYOUT_TYPE.IMAGE_ROW_LAYOUT.ordinal());
			view.getViewDataContainers().removeAll(listFloor);
			//view.getViewDataContainers().removeAll(listImageRow);
			view.getViewDataContainers().removeAll(listBanner);
		}
	}
	
	/**
	 * Gets the floor data.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param provinceId the province id
	 * @return the floor data
	 */
//	public String getIndexAsString(String traderName,int siteType,int mechantId){
//		Site site=getSite(siteType);
//		Area area=getArea(mechantId);
//		Platform platform=getPlatform(traderName);
//		ViewSuite vs=DataManager.getDataManager().getViewSuite(site, area, platform);
//		ViewTemplate vt=vs.getViewTemplate(1);
//		View index=vs.getView(vt);
//	    return index.generateJSONString(siteType);
//	}
	
	public List<JsonObject> getFloorData(String traderName, Integer siteType,int mechantId,int provinceId) {
		
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		Platform platform=getPlatform(traderName,siteType);
		List<JsonObject> resultList=new ArrayList<JsonObject>();
		View view =viewService.getViewByType(site, platform, area, 1);
		if(view==null)
			return null;
		//View view= viewService.getViewObjectById(list.get(0).getId());
		//container 0
		fetchADFromPCBackend(view,siteType,provinceId,traderName,null);
		List<ViewDataContainer>  containerList=view.getViewDataContainer(4);
		if(containerList!=null && containerList.size()>0){
			 for(ViewDataContainer container:containerList){
				
			     JsonObject obj=container.generateData(false,getFilterOption(site,area,provinceId));
			     if(obj!=null)
				     resultList.add(obj);
			 }
		}
		return resultList;
		
	
	}
	
	
  /**
   * 首页功能入口，一个广告位，可以返回多个广告.
   *
   * @param traderName the trader name
   * @param siteType the site type
   * @param mechantId the mechant id
   * @param provinceId the province id
   * @return the function data
   */
   public List<JsonObject> getFunctionData(String traderName, Integer siteType, int mechantId,long provinceId) {
		
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		Platform platform=getPlatform(traderName,siteType);
		List<JsonObject> resultList=new ArrayList<JsonObject>();
		View view =viewService.getViewByType(site, platform, area, 1);
		if(view==null)
			return null;
		//View view= viewService.getViewObjectById(list.get(0).getId());
		//container 0
		List<ViewDataContainer>  containerList=view.getViewDataContainer(2);
		if(containerList!=null && containerList.size()>0){
			 ViewDataContainer container=containerList.get(0);
			
		     JsonObject obj=container.generateData(false,getFilterOption(site,area,provinceId));
		     if(obj!=null)
			     resultList.add(obj);
			 
		  
		}
		
		return resultList;

	}
   
   /**
    * 获取进口馆入口广告.
    *
    * @param traderName the trader name
    * @param siteType the site type
    * @param mechantId the mechant id
    * @param provinceId the province id
    * @return the export goods entry data
    */
    public List<JsonObject> getExportGoodsEntryData(String traderName, Integer siteType, int mechantId,long provinceId) {
 		
 		Site site=getSite(siteType);
 		Area area=getArea(mechantId);
 		Platform platform=getPlatform(traderName,siteType);
 		List<JsonObject> resultList=new ArrayList<JsonObject>();
 		View view=viewService.getViewByType(site, platform, area, 1);
 		if(view==null)
 			return null;
 		//View view= viewService.getViewObjectById(list.get(0).getId());
 		//container 0
 		List<ViewDataContainer>  containerList=view.getViewDataContainer(2);
 		if(containerList!=null && containerList.size()>0){
 			 ViewDataContainer container=containerList.get(0);
 			
 		     
 			 
 		     //get four AD from view
 		     if(CommonKey.TRADER_NAME_IPAD.equals(traderName)){
 		    	 //ipad 进口馆
 		    	 if(null != container && container.getViewData() != null && container.getViewData().size()>0){
 		    		 View linkView=container.getViewData().get(0).getViewLink();
 		    		 if(linkView!=null && linkView.getViewTemplate()!=null && linkView.getViewTemplate().getType()!=null){
 		    			  if(linkView.getViewTemplate().getType().intValue()==11){
 		    				   //进口馆，取第一个楼层广告
 		    				   View importGoodsView=viewService.getViewObjectById(linkView.getId());
 		    				   if(importGoodsView.getViewDataContainers().size()>0){
 		    					   if(container!=null){
 		    						   int i=0;
 		    						   for(ViewData vd:importGoodsView.getViewDataContainers().get(0).getViewData()){
 		    							   if(i==4)
 		    								   break;
 		    							   if(vd!=null){
 		    								   container.getViewData().add(vd);
 		    							   }
 		    							   i++;
 		    						   }
 		    					   }
 		    					 
 		    				   }
 		    				  
 		    			  }
 		    		 }
 		    	 }
 		    	 
 		    	 
 		     }
 		     JsonObject obj = null;
 		     if(null != container) {
 		    	obj = container.generateData(false, getFilterOption(site,area,provinceId));
 		    	if(obj!=null) {
 			    	resultList.add(obj);
 		    	}
 		     }
 		}
 		return resultList;
 	}
    
   /**
    * 手机充值页面广告，一个广告位，可以放多个广告.
    *
    * @param traderName the trader name
    * @param siteType the site type
    * @param mechantId the mechant id
    * @param provinceId the province id
    * @return the mobile charge view data
    */
    public List<JsonObject> getMobileChargeViewData(String traderName, Integer siteType, int mechantId,long provinceId) {
		
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		Platform platform=getPlatform(traderName,siteType);
		List<JsonObject> resultList=new ArrayList<JsonObject>();
		View view =viewService.getViewByType(site, platform, area, Constants.VIEW_TYPE.MOBILE_CHARGE_INDEX.ordinal());
		if(view==null)
			return null;
		//View view= viewService.getViewObjectById(list.get(0).getId());
		//container 0
		List<ViewDataContainer>  containerList=view.getViewDataContainers();
		if(containerList!=null && containerList.size()>0){
			 ViewDataContainer container=containerList.get(0);
			 if (container.getViewData() != null && container.getViewData().size() > 1) { // 如果有多条手机充值配置返回，则倒序排，让app取第一条
				 Collections.sort(container.getViewData(), Collections.reverseOrder(new Comparator<ViewData>() {
						@Override
						public int compare(ViewData src, ViewData target) {
							return src.getId().compareTo(target.getId());
						}
				 }));
			 }
			 JsonObject obj=container.generateData(false,getFilterOption(site,area,provinceId));
		     if(obj!=null)
			     resultList.add(obj);
			 
		}
		return resultList;

	}
    
  
    /**
     * 手机充值页面广告，一个广告位，可以放多个广告.
     *
     * @param traderName the trader name
     * @param siteType the site type
     * @param mechantId the mechant id
     * @param linkId the link id
     * @param provinceId the province id
     * @return the mobile charge view data
     * @linkId  页面ID
     */
     public List<JsonObject> getMobileChargeViewData(String traderName, Integer siteType, int mechantId,Long linkId,long provinceId) {
    	List<JsonObject> resultList=new ArrayList<JsonObject>();
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
 		if(linkId==null || linkId.intValue()==0)
 			return null;
 		View view= viewService.getViewObjectById(linkId.intValue());
 		//container 0
 		List<ViewDataContainer>  containerList=view.getViewDataContainers();
 		if(containerList!=null && containerList.size()>0){
 			ViewDataContainer container=containerList.get(0);
 			JsonObject obj=container.generateData(false,getFilterOption(site,area,provinceId));
 		     if(obj!=null)
 			     resultList.add(obj);
 			 
 		}
 		return resultList;

 	}

    /**
     * 首页底部的促销广告	.
     *
     * @param traderName the trader name
     * @param siteType the site type
     * @param mechantId the mechant id
     * @param provinceId the province id
     * @return the index promotion data
     */
	public JsonObject getIndexPromotionData(String traderName,int siteType,int mechantId,long provinceId){
		try{
			Site site=getSite(siteType);
			Area area=getArea(mechantId);
			Platform platform=getPlatform(traderName,siteType);
			View view =viewService.getViewByType(site, platform, area, 1);
			if(view==null)
				return null;
			//View view= viewService.getViewObjectById(list.get(0).getId());
			//container 0
			List<ViewDataContainer>  containerList=view.getViewDataContainer(5);
			if(containerList!=null && containerList.size()>0){
				
				return containerList.get(0).generateData(false,getFilterOption(site,area,provinceId));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets the calander index.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param provinceId the province id
	 * @return the calander index
	 */
	public JsonObject getCalanderIndex(String traderName,int siteType,int mechantId,long provinceId){
		
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		Platform platform=getPlatform(traderName,siteType);
		View view =viewService.getViewByType(site, platform, area, 2);
		if(view==null)
			return null;
		//View view= viewService.getViewObjectById(list.get(0).getId());
		
		return view.generateData(false,getFilterOption(site,area,provinceId));

	}
	
	/**
	 * Gets the daily one view.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param provinceId the province id
	 * @return the daily one view
	 */
	public JsonObject getDailyOneView(String traderName,int siteType,int mechantId,long provinceId){
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		Platform platform=getPlatform(traderName,siteType);
		View view =viewService.getViewByType(site, platform, area, 8);
		if(view==null)
			return null;
		//View view= viewService.getViewObjectById(list.get(0).getId());
	
		return view.generateData(false,getFilterOption(site,area,provinceId));
	}
	
	
	/**
	 * Gets the calendar detail view.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param currentDate the current date
	 * @param provinceId the province id
	 * @return the calendar detail view
	 */
	public JsonObject getCalendarDetailView(String traderName,int siteType,int mechantId,Date currentDate,long provinceId){
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		Platform platform=getPlatform(traderName,siteType);
	
		View calanderDatailView =viewService.getViewByType(site, platform, area, 3);
		if(calanderDatailView==null)
			return null;
//		View calanderDatailView= viewService.getViewObjectById(list.get(0).getId());
//		
//		
//		if(calanderDatailView==null)
//			return null;
		//sunday :
		int index=Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
		if(index==1){
			index=7;
		}else{
			index--;
		}
		//类型13：从所链接的cms广告列表中周期性获取广告
		//container type 13;
		try{
			for(ViewDataContainer vdc:calanderDatailView.getViewDataContainers()){
				if(vdc!=null && vdc.getViewLayout()!=null){
					if(vdc.getViewLayout().getType().intValue()==13){
						//发现品牌店铺cms广告，通过链接来获取品牌店铺保护的广告
					
					   if(vdc.getViewData().size()>0){
						  ViewData findOne=null;
						  ViewData vd=vdc.getViewData().get(0);
					      if(vd!=null && vd.getViewLink()!=null && vd.getViewLink().getViewTemplate()!=null 
								    && vd.getViewLink().getViewTemplate().getType().intValue()==12){
							  View brandView = viewService.getViewObjectById(vd.getViewLink().getId());
							  if(brandView!=null){
								   if(brandView.getViewDataContainers().size()>0){
									   List<ViewData> listVD=brandView.getViewDataContainers().get(0).getViewData();
									   if(listVD.size()>=index){
										   findOne=listVD.get(index-1);
										  
									   }else if(listVD.size()>0){
										   findOne=listVD.get(0);
									   }
								   }
								 
							  }
						   }
					       if(findOne!=null){
							   vdc.getViewData().clear();
							   vdc.getViewData().add(findOne);
						   }
					   }
					   
					  
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			
		}
		

		return calanderDatailView.generateData(false,getFilterOption(site,area,provinceId));
	}
	
	/**
	 * Gets the view by id and filter ad.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param viewId the view id
	 * @param provinceId the province id
	 * @param viewType the view type
	 * @param filterADType the filter ad type
	 * @return the view by id and filter ad
	 */
	public JsonObject getViewByIdAndFilterAD(String traderName,int siteType,int mechantId,int viewId,long provinceId,
			Constants.VIEW_TYPE viewType,Constants.DATA_TYPE[] filterADType){
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		View view =viewService.getViewObjectById(viewId);
		if(view==null || view.getViewTemplate()==null)
			return null;
		filterADByClientVersion(view,viewType,filterADType);
		
		return filterCMSView(view, site, area, provinceId);
	}
	
	/**
	 * Filter ad by client version.
	 *
	 * @param view the view
	 * @param viewType the view type
	 * @param filterADType the filter ad type
	 */
	private void filterADByClientVersion(View view,Constants.VIEW_TYPE viewType,Constants.DATA_TYPE[] filterADType) {
		 if(view.getViewTemplate().getType()==viewType.ordinal()){
			 for(ViewDataContainer vdc:view.getViewDataContainers()){
				  for(ViewData vd:vdc.getViewData()){
					  for(Constants.DATA_TYPE dateType:filterADType){
						  if(vd.getData()!=null && vd.getData().getType()==dateType.ordinal()){
							  vd.getData().setState(-1);
						  }
					  }
					
				  }
			 }
		 }
	}
	
	/**
	 * Gets the view by id.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param merchantId the merchant id
	 * @param viewId the view id
	 * @param provinceId the province id
	 * @return the view by id
	 */
	public JsonObject getViewById(String traderName,int siteType,int merchantId,int viewId,long provinceId){
		Site site=getSite(siteType);
		Area area=getArea(merchantId);
		View view =viewService.getViewObjectById(viewId);
		if(view==null || view.getViewTemplate()==null)
			return null;
	    return filterCMSView(view, site, area, provinceId);
	}



	/**
	 * Filter cms view.
	 *
	 * @param view the view
	 * @param site the site
	 * @param area the area
	 * @param provinceId the province id
	 * @return the json object
	 */
	private JsonObject filterCMSView(View view, Site site, Area area, long provinceId) {
		return view.generateData(false,getFilterOption(site,area,provinceId));
	}
	
	/**
	 * Gets the export goods view by id.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param viewId the view id
	 * @param provinceId the province id
	 * @return the export goods view by id
	 */
	public JsonObject getExportGoodsViewById(String traderName,int siteType,int mechantId,int viewId,long provinceId){
		Site site=getSite(siteType);
		Area area=getArea(mechantId);
		Platform platform=getPlatform(traderName,siteType);
		View view =viewService.getViewByType(site, platform, area, 11);
		if(view==null)
			return null;
		
		view =viewService.getViewObjectById(view.getId());
		if(view==null || view.getViewTemplate()==null)
			return null;
 		return view.generateData(false,getFilterOption(site,area,provinceId));
	}
	
	/**
	 * Gets the export goods brands.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param categoryId the category id
	 * @param provinceId the province id
	 * @return the export goods brands
	 */
	public String getExportGoodsBrands(String traderName,int siteType,int mechantId,long categoryId,long provinceId){
		List<CategoryBrand> categoryDescList =viewService.getEnabledCategoryBrands(categoryId);
		if(categoryDescList!=null && categoryDescList.size()>0)
			return new Gson().toJson(categoryDescList);
		return null;
	}
	
	/**
	 * Gets the activity rule.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @return the activity rule
	 */
	public String getActivityRule(String traderName,int siteType,int mechantId){
		ActivityRule activityRule =viewService.getActivityRule();
		if(activityRule!=null)
			return new Gson().toJson(activityRule);
		return null;
	}
	
	/**
	 * Gets the export goods categories.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param provinceId the province id
	 * @return the export goods categories
	 */
	public String getExportGoodsCategories(String traderName,int siteType,int mechantId,long provinceId){
		List<CategoryDescription> categoryDescList =viewService.getEnabledCategoryDescriptions();
		if(categoryDescList!=null && categoryDescList.size()>0)
			return new Gson().toJson(categoryDescList);
		return null;
	}
//	public JsonObject getExportGoodsCategoryById(String traderName,int siteType,int mechantId,int viewId){
//		View view =viewService.getViewObjectById(viewId);
//		if(view==null || view.getViewTemplate()==null)
//			return null;
//		for(int i=view.getViewDataContainers().size()-1; i>=0;i--){
//			ViewDataContainer vdc=view.getViewDataContainers().get(i);
//			if(vdc!=null && vdc.getViewLayout()!=null &&vdc.getViewLayout().getType().intValue()==3){
//				//快速文字促销广告，过滤掉
//				view.getViewDataContainers().remove(i);
//			}
//		}
//		
//	    ModelFilterOption option=new ModelFilterOption();
//	    option.setSiteType(siteType);
//		return view.generateData(false,option);
//	}
	
	/**
 * Gets the promotion id by cms id.
 *
 * @param viewId the view id
 * @param provinceId the province id
 * @return the promotion id by cms id
 */
public String getPromotionIdByCmsId(int viewId,long provinceId){
		View view =viewService.getViewObjectById(viewId);
		if(view==null )
			return null;
	    for(ViewDataContainer vdc:view.getViewDataContainers()){
	    	for(ViewData vd:vdc.getViewData()){
	    		Data data=vd.getData();
	    		if(data!=null && data instanceof PromotionActivity){
	    		    PromotionActivity pa=(PromotionActivity)data;
	    		    if(pa.getPromotionId()!=null){
	    		    	return pa.getPromotionId();
	    		    }
	    		}
	    	}
	    }
		return null;
	}
	
	/**
	 * Gets the activity data by id.
	 *
	 * @param traderName the trader name
	 * @param siteType the site type
	 * @param mechantId the mechant id
	 * @param dataId the data id
	 * @param provinceId the province id
	 * @return the activity data by id
	 */
	public JsonObject getActivityDataById(String traderName,int siteType,int mechantId,int dataId,long provinceId){
		Area area=getArea(mechantId);
		Data data=viewService.getDataById(dataId,area);
		if(data==null)
			return null;
	    
		JsonObject js= parseToJsonObject(data.formatData());
		if(js!=null){
			js.remove("sites");
			if(js.get("type")==null)
		    	js.addProperty("type", data.getType());
		}
		return js;
	}
	
	/**
	 * Parses the to json object.
	 *
	 * @param parsedValue the parsed value
	 * @return the json object
	 */
	private JsonObject parseToJsonObject(String parsedValue){
		return new JsonParser().parse(parsedValue).getAsJsonObject();
	}
	
	/**
	 * Use pc backend.
	 *
	 * @param traderName the trader name
	 * @return true, if successful
	 */
	private boolean usePCBackend(String traderName) {
		// 是否使用PC广告后台
		if(traderName!=null && traderName.indexOf("adhoc")>=0){
			//广告预览类型
			return true;
		}
        //MobileCentralFlags centralFlags = CentralLogFlagsUtil.getLogFlags(CentralLogFlagsUtil.LOG_FLAGS_USEPCBACKEND);
    	int centaFlags = SwitchUtil.getAppSwitchByType(SwitchCode.USE_PC_BACKEND);
		if(centaFlags== 1){
    		return true;
    	}
    	else {
    		return false;
    	}
	}
	
//	private String exchangeTraderName(String traderName) {
//		// 是否使用PC广告后台
//		if(traderName!=null){
//			if(CommonKey.TRADER_NAME_ADHOC_ANDROID.equals(traderName)){
//				return CommonKey.TRADER_NAME_ANDROID;
//			}
//			if(CommonKey.TRADER_NAME_ADHOC_IPHONE.equals(traderName)){
//				return CommonKey.TRADER_NAME_IPHONE;
//			}
//			if(CommonKey.TRADER_NAME_ADHOC_IPAD.equals(traderName)){
//				return CommonKey.TRADER_NAME_IPAD;
//			}
//			if(CommonKey.TRADER_NAME_ADHOC_WEB.equals(traderName)){
//				return CommonKey.TRADER_NAME_WEBSITE;
//			}
//		}
//		return traderName;
//    }

	/**
	 * Should show container.
	 *
	 * @param containerType the container type
	 * @return true, if successful
	 */
	public boolean shouldShowContainer(int containerType){
		return ViewDataContainer.isShowContainer(containerType);
	}
	
	
	   /**
   	 * 类目广告查询详情.
   	 *
   	 * @param traderName the trader name
   	 * @param siteType the site type
   	 * @param mechantId the mechant id
   	 * @param provinceId the province id
   	 * @param viewType the view type
   	 * @param containerType  -1 for all
   	 * @param categoryId the category id
   	 * @return the category advertisement
   	 */
    public JsonObject getCategoryAdvertisement(String traderName,int siteType,int mechantId,int provinceId,int viewType,int containerType , Integer categoryId){
        
        if(!checkViewType(viewType))
           return null;
        if(!checkContainerType(containerType))
            containerType=-1;
        Site site=getSite(siteType);
        Area area=getArea(mechantId);
        Platform platform=getPlatform(traderName,siteType);
        View view =viewService.getViewByType(site, platform, area,viewType,containerType,null,categoryId);
        if(view==null)
            return null;
        return view.generateData(false,getFilterOption(site,area,provinceId));
    }
    
    
    public JsonObject getCurtainAdvertisement(String traderName,int siteType,int mechantId,int provinceId,int viewType,int containerType , Integer categoryId){
        
        if(!checkViewType(viewType))
           return null;
        //if(!checkContainerType(containerType))
//        containerType=-1;
        Site site=getSite(siteType);
        Area area=getArea(mechantId);
        Platform platform=getPlatform(traderName,siteType);
        View view =viewService.getViewByType(site, platform, area,viewType,containerType,null,categoryId);
        if(view==null)
            return null;
        return view.generateData(false,getFilterOption(site,area,provinceId));
    }
    
    public JsonObject getNewCategoryAd(String traderName,int siteType,int mechantId,int provinceId,int viewType,int containerType , String categoryId,String version){
        if(!checkViewType(viewType))
           return null;
        if(!checkContainerType(containerType))
            containerType=-1;
        Site site=getSite(siteType);
        Area area=getArea(mechantId);
        Platform platform=getPlatform(traderName,siteType);
        View view =viewService.getViewCateByType(site, platform, area,viewType,containerType,null,categoryId,version);
        if(view==null)
            return null;
        return view.generateData(false,getFilterOption(site,area,provinceId));
    }
    
}