package com.yihaodian.maps.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.yhd.pss.spi.baseinfo.service.QueryProductRemoteService;
import com.yhd.pss.spi.baseinfo.vo.ProductIdAndPicUrlVo;
import com.yhd.pss.spi.baseinfo.vo.ProductInfoFor201VO;
import com.yhd.pss.spi.baseinfo.vo.ProductVo;
import com.yhd.pss.spi.baseinfo.vo.input.ProductCodeRequest;
import com.yhd.pss.spi.baseinfo.vo.input.QueryProductInfoByPmIdsAndProvinceIdRequest;
import com.yhd.pss.spi.category.service.MasterQueryNavigationCategoryService;
import com.yhd.pss.spi.category.vo.NavigationCategory;
import com.yhd.pss.spi.category.vo.input.QueryByMultiConditionRequest;
import com.yhd.pss.spi.common.vo.Response;
import com.yhd.pss.spi.common.vo.input.QueryByIdsRequest;
import com.yhd.shareservice.exceptions.HedwigException;
import com.yihaodian.cms.hessian.handler.CmsServiceHandler;
import com.yihaodian.cms.hessian.query.output.CmsProdVoOut;
import com.yihaodian.cms.hessian.service.read.app.CmsPageDataService;
import com.yihaodian.front.busystock.client.BusyStockClientUtil;
import com.yihaodian.busy.common.BusystockClientConstants;
import com.yihaodian.front.busystock.vo.BSGrouponVo;
import com.yihaodian.front.busystock.vo.BSProductVo;
import com.yihaodian.front.busystock.vo.BSPromotionProductVo;
import com.yihaodian.groupon.data.client.framework.dict.GrouponReturnCodeDict;
import com.yihaodian.groupon.data.client.framework.model.GrouponReturn;
import com.yihaodian.groupon.data.client.mobile.modle.input.GrouponMobileIn;
import com.yihaodian.groupon.data.client.mobile.service.GrouponQueryForMobileService;
import com.yihaodian.groupon.data.client.query.model.input.GrouponCommonIn;
import com.yihaodian.groupon.data.client.query.model.output.GrouponBrandOut;
import com.yihaodian.groupon.data.client.query.model.output.GrouponOut;
import com.yihaodian.groupon.data.client.query.service.GrouponPublicQueryService;
import com.yihaodian.mobile.backend.maps.vo.CategroyVO;
import com.yihaodian.mobile.backend.maps.vo.ProductInfoVO;
import com.yihaodian.mobile.backend.maps.vo.ProductVO;
import com.yihaodian.promotion.basic.PromotionReturn;
import com.yihaodian.promotion.client.coupon.handler.CouponServiceHandler;
import com.yihaodian.promotion.coupon.inputVo.CouponActivityInputVo;
import com.yihaodian.promotion.coupon.outputVo.CouponActivityOutputVo;
import com.yihaodian.pss.client.PssClient;
import com.yihaodian.pss.client.PssClientConfiguration;
/**
 * 第三方接口调用集合
 * 
 * @author wulibing
 *
 */
public class ManagerUtils {
	private static Logger logger = Logger.getLogger(ManagerUtils.class);

	private static Long channelId = BusystockClientConstants.CHANNEL_1STORE_WIRELESS;
	private static Long channelId_LandingPage = BusystockClientConstants.CHANNEL_1STORE;//2015-6-4:wangxiaowu GBS 不区分渠道  
	private static PssClient pssClient;
	private static CmsPageDataService cmsHandler;

	static {
		pssClient = PssClient.getInstance(5000l,
				PssClientConfiguration.FRONT_SERVER_GROUP);
		cmsHandler = CmsServiceHandler.getCmsPageDataService();
	}

	public static PssClient getPssClient() {
		return pssClient;
	}

	public static CmsPageDataService getCmsHandler() {
		return cmsHandler;
	}

	// 过滤商品和获取商品的基本信息&默认图片
	public static List<ProductInfoFor201VO> loadBaseProductInfo(
			List<Long> pmIds, Long provinceId) {
		if(pmIds==null||pmIds.size()==0){
			return null;
		}
		
		List<ProductInfoFor201VO> list = null;
		QueryProductInfoByPmIdsAndProvinceIdRequest param = new QueryProductInfoByPmIdsAndProvinceIdRequest();
		param.setProvinceId(provinceId);
		Response<List<ProductInfoFor201VO>> subResult = null;
		try {
			//省份id不能为空且大于等于0,pminfoIdList不能为空，且长度不能超过100
			int s =pmIds.size();
			if(s>100){
				List<Long> pmc = new ArrayList<Long>();
				list = new ArrayList<ProductInfoFor201VO>();
				for (int i = 0; i < s; i++) {
					pmc.add(pmIds.get(i));
					if(((i+1)%100==0&&i>0)||i==(s-1)){
						param.setPminfoIdList(pmc);
						subResult = getPssClient().getQueryProductRemoteService()
								.queryProductDecodeTypeByPmIdsAndProvinceId(param);
						list.addAll(subResult.getResult());
						pmc.clear();
					}
				}
			}else{
				param.setPminfoIdList(pmIds);
				subResult = getPssClient().getQueryProductRemoteService()
						.queryProductDecodeTypeByPmIdsAndProvinceId(param);
				list = subResult.getResult();
			}
		} catch (HedwigException e) {
			logger.error(e.getMessage());
		}

		if (subResult == null) {
			return null;
		}
		if(list!=null&&list.size()>0){
			Map<Long,ProductInfoFor201VO> m = new HashMap<Long, ProductInfoFor201VO>();
			List<Long> ids = new ArrayList<Long>();
			for (ProductInfoFor201VO productInfoFor201VO : list) {
				m.put(productInfoFor201VO.getProductId(), productInfoFor201VO);
				if(StringUtils.isBlank(productInfoFor201VO.getDefaultPriceUrl())){
					ids.add(productInfoFor201VO.getProductId());
				}
			}
			if(ids.size()>0){
				Map<Long,String> urlMap = loadPicsByProductIds(ids);
				if(urlMap.size()>0){
					ProductInfoFor201VO vo = null;
					Set<Map.Entry<Long, String>> entrys = urlMap.entrySet();
					for (Entry<Long, String> entry : entrys) {
						Long id = (Long) entry.getKey();
						if (m.containsKey(id)) {
							vo = m.get(id);
							vo.setDefaultPriceUrl(entry.getValue());
							m.put(id, vo);
						}
					}
				}
			}
			list = new ArrayList<ProductInfoFor201VO>(m.values());
		}
		return list;
	}

	/**
	 * 
	 * @creator @wulibing
	 * @create @2015年6月23日 
	 * @param resVO
	 * @param provinceId
	 * @param promotionIds
	 * @param isPreView
	 * @param preViewTime
	 * @return
	 */
	public static List<ProductInfoVO> loadProductDetialByPromotionIdsFromCMS(Long provinceId, List<Long> promotionIds,
			boolean isPreView, Date preViewTime) {
		List<ProductInfoVO> l = new ArrayList<ProductInfoVO>();
		if(promotionIds==null||promotionIds.size()<=0){
			return l;
		}
		List<BSPromotionProductVo> pList = null;
		// landing暂不支持无线独享价
		//promotionIds查找产品信息
		if (isPreView) {
			pList = BusyStockClientUtil.getBusyPromotionFacadeService()
					.getLandingPagePriceStockList(channelId_LandingPage, provinceId,promotionIds, preViewTime);
		} else {
			pList = BusyStockClientUtil.getBusyPromotionFacadeService()
					.getLandingPagePriceStockList(channelId_LandingPage, provinceId,promotionIds);
		}
		if(pList==null||pList.size()==0){
			return l;
		}
		
		Map<Long,ProductVO> resVO = new HashMap<Long, ProductVO>();
		Map<Long,BSPromotionProductVo> bsMap = new HashMap<Long, BSPromotionProductVo>();
		ProductVO mapsvo = null;
		for (BSPromotionProductVo bsPromotionProductVo : pList) {
			mapsvo = new ProductVO();
			mapsvo.setDataType(ProductVO.PRODUCTTYPE_LP);//landing page 商品类型
			
			bsMap.put(bsPromotionProductVo.getPmId(), bsPromotionProductVo);
			mapsvo.setPromotionProductInfo(bsPromotionProductVo);
			resVO.put(bsPromotionProductVo.getPmId(), mapsvo);
		}
		
		// 过滤商品
		List<Long> subPmIds = new ArrayList<Long>(resVO.keySet());
		List<ProductInfoFor201VO> pmList = loadBaseProductInfo(subPmIds, provinceId);
		if (pmList == null) {
			return l;
		}
		
		//info 组装
		BSPromotionProductVo promotionProductInfo = null;
		ProductVO pvo = null;
		for (ProductInfoFor201VO productInfo : pmList) {
			pvo = resVO.get(productInfo.getPminfoId());
			if (pvo != null) {
				//loading page商品
				promotionProductInfo = pvo.getPromotionProductInfo();
				if(promotionProductInfo==null){
					continue;
				}
				
				ProductInfoVO productInfoVO = new ProductInfoVO();
				//product base info 
				productInfoVO.setPmInfoId(productInfo.getPminfoId());
				productInfoVO.setProductId(productInfo.getProductId());
				productInfoVO.setId(productInfo.getPminfoId());
				productInfoVO.setImg(productInfo.getDefaultPriceUrl());		
				if(productInfo.getIsYihaodian() ==1){
					productInfoVO.setSourceType(ProductInfoVO.SOURCETYPE_SELF);//productInfo.getIsYihaodian
				}else if(productInfo.getIsYihaodian() ==0){
					productInfoVO.setSourceType(ProductInfoVO.SOURCETYPE_SHOP);//productInfo.getIsYihaodian
				}
				productInfoVO.setTitle(productInfo.getProductCname());
				//landing page info
				if(promotionProductInfo.getCurrentPrice() != null){
					productInfoVO.setDiscountedPrice(promotionProductInfo.getCurrentPrice().doubleValue());
				}
				productInfoVO.setId(promotionProductInfo.getPmId());
				if(promotionProductInfo.getMarketPrice() != null){//市场价
					productInfoVO.setOriginalPrice(promotionProductInfo.getMarketPrice().doubleValue());
				}
				if(promotionProductInfo.getCurrentPoint() != null){
					productInfoVO.setPoints(promotionProductInfo.getCurrentPoint().doubleValue());
				}
				productInfoVO.setSales(promotionProductInfo.getSoldNum());					
				productInfoVO.setStatus(promotionProductInfo.getStatus());
				productInfoVO.setPromotionId(promotionProductInfo.getPromotionId());
				productInfoVO.setMerchantId(promotionProductInfo.getMerchantId());
				
				productInfoVO.setProductType(pvo.getDataType());
				productInfoVO.setType(ProductInfoVO.TYPE_LANDINGPAGE);
				l.add(productInfoVO);
			}
		}
		logger.info("loadProductDetialFromPromotionIds:"+l.size());
		return l;
	}

	public static List<ProductInfoVO> loadGrouponProductByGrouponIdsFromCMS(GrouponPublicQueryService grouponPublicQueryService,
			List<CmsProdVoOut> ds, Long provinceId,boolean isPreView, Date preViewTime) {
		List<ProductInfoVO> l = new ArrayList<ProductInfoVO>();
		
		ProductVO vo = null;
		Map<Long,ProductVO> pMaps = new HashMap<Long, ProductVO>();
		
		Map<Long,Long> grouponIdMaps = new HashMap<Long, Long>();
		for (CmsProdVoOut cmsProdVoOut : ds) {
			vo = new ProductVO();
			vo.setDataType(ProductVO.PRODUCTTYPE_GROUP);
			vo.setCmsProdInfo(cmsProdVoOut);
			grouponIdMaps.put(cmsProdVoOut.getGrouponId(),
					cmsProdVoOut.getGrouponId());
			pMaps.put(cmsProdVoOut.getProductId(), vo);
		}
		//团购商品
		if(grouponIdMaps.size()==0){
			return l;
		}
		
		List<Long> grouponIds = new ArrayList<Long>(grouponIdMaps.keySet());
		
		GrouponCommonIn grouponCommonIn = new GrouponCommonIn();
		grouponCommonIn.setProvinceId(provinceId);
		grouponCommonIn.setIdList(grouponIds);
		GrouponReturn<List<GrouponOut>> result = grouponPublicQueryService.findGrouponAndConfigByIds(grouponCommonIn);
		if(result.getCode() != GrouponReturnCodeDict.CODE_OK) {
			return l;
		}
		
		List<GrouponOut> pList = result.getOut();
		if(pList==null||pList.size()<=0){
			return l;
		}
		
		//信息组装
		ProductVO mapsvo = null;
		for (GrouponOut grouponOut : pList) {
			mapsvo = pMaps.get(grouponOut.getProductId());
			if (mapsvo != null) {
				ProductInfoVO productInfoVO = new ProductInfoVO();
				productInfoVO.setPmInfoId(grouponOut.getPmInfoId());
				productInfoVO.setProductId(grouponOut.getProductId());
				
				productInfoVO.setDiscountedPrice(grouponOut.getPrice());
				productInfoVO.setId(grouponOut.getPmInfoId());
				productInfoVO.setImg(grouponOut.getImageDetail());
				productInfoVO.setOriginalPrice(grouponOut.getOrigionalPrice());
				productInfoVO.setSales(grouponOut.getOrderNumber());//?
				productInfoVO.setSourceType(ProductInfoVO.SOURCETYPE_GROUP);
				// 0:初始化 50:预告 100:团购中101:团购中-成功 102:团购中-人数满 200:结束-失败 201:结束-成功202:可转DO
				Integer statue = grouponOut.getStatus();						 
				 if(statue == null || statue ==0 || statue==50 ){
					 productInfoVO.setStatus(ProductInfoVO.STATUS_NOTSTARTED);
				}else if(statue == 101){
					productInfoVO.setStatus(ProductInfoVO.STATUS_INPROGRESS);
				}else if(statue == 102 ){
					productInfoVO.setStatus(ProductInfoVO.STATUS_SOLDOUT);
				}else if(statue == 200 || statue ==201 || statue ==202){
					productInfoVO.setStatus(ProductInfoVO.STATUS_END);
				}				
				 
				if((grouponOut.getIsGrouponSerial()!=null&&grouponOut.getIsGrouponSerial().intValue()==1)||grouponOut.getIsIntoCart().intValue()==0) {
					//系统商品和指定不能加入购物车的都置为99：表示不能加入购物车
					productInfoVO.setProductType(ProductVO.PRODUCTTYPE_CANNOT_ADD_TO_CART);
				}
				
				productInfoVO.setProductType(mapsvo.getDataType());
				productInfoVO.setTitle(grouponOut.getName());
				productInfoVO.setType(ProductInfoVO.TYPE_GROUP);
				
				//PC
				//productInfoVO.setUrl(grouponOut.getDetailUrl());
				//h5
				productInfoVO.setUrl(grouponOut.getH5DetailUrl());
				productInfoVO.setGrouponId(grouponOut.getId());
				l.add(productInfoVO);
			}
		}
		
		logger.info("loadProductDetialFromGrouponIds:"+l.size());
		return l;
	}

	
	private static Map<Long,String> loadPicsByProductIds(List<Long> ids){
		Map<Long,String> m = new HashMap<Long, String>();
		QueryByIdsRequest request = new QueryByIdsRequest();
		request.setIds(ids);
		
		if(ids!=null&&ids.size()>0){
			try {
//				Response<List<McSiteProductPicVo>> res = getPssClient().getQueryProductPicRemoteService().queryDefaultPicByProductIds(request);
				Response<List<ProductIdAndPicUrlVo>> res = getPssClient().getQueryProductPicRemoteService().queryProductPictureByProductIds(request);
				if(res!=null){
					List<ProductIdAndPicUrlVo> pList = res.getResult();
					for (ProductIdAndPicUrlVo pp : pList) {
						m.put(pp.getProductId(), pp.getPicUrl());
					}
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
			
		}
		return m;
	}
	
	
	/**
	 * 获取商品的基本信息，并按传入pmid排序
	 * @creator @wulibing
	 * @create @2015年6月23日 
	 * @param provinceId
	 * @param pMaps
	 * @param pmIds
	 * @return
	 */
	public static List<ProductInfoVO> loadProductInfoOrderByPmIdsFromCMS(Long provinceId,List<CmsProdVoOut>  ds) {
		ProductVO vo = null;
		List<Long> pmIds = new ArrayList<Long>();
		Map<Long,ProductVO> pMaps = new HashMap<Long, ProductVO>();
		for (CmsProdVoOut cmsProdVoOut : ds) {
			vo = new ProductVO();
			vo.setDataType(ProductVO.PRODUCTTYPE_NORMAL);
			vo.setCmsProdInfo(cmsProdVoOut);
			pmIds.add(cmsProdVoOut.getPmInfoId());
			pMaps.put(cmsProdVoOut.getPmInfoId(), vo);
		}
		List<ProductInfoVO> l = new ArrayList<ProductInfoVO>();
		//普通商品
		if(pmIds!=null&&pmIds.size()>0){
			//过滤商品和获取商品的基本信息&默认图片
			List<ProductInfoFor201VO> pList = ManagerUtils.loadBaseProductInfo(pmIds, provinceId);
			ProductVO pvo = null;
			for (ProductInfoFor201VO productInfoFor201VO : pList) {
				pvo = pMaps.get(productInfoFor201VO.getPminfoId());
				if (pvo != null) {
					pvo.setProductInfo(productInfoFor201VO);
					pMaps.put(productInfoFor201VO.getPminfoId(), pvo);
				}
			}
			//排序&组装
			ProductVO productVO = null;
			ProductInfoFor201VO productInfo = null;
			ProductInfoVO productInfoVO = null;
			CmsProdVoOut cmsVO = null;
			for (Long pmId : pmIds) {
				productVO = pMaps.get(pmId);
				if(productVO!=null){
					productInfo = productVO.getProductInfo();	
					cmsVO = productVO.getCmsProdInfo();
					if(productInfo!=null){
						productInfoVO = new ProductInfoVO();
						productInfoVO.setPmInfoId(productInfo.getPminfoId());
						productInfoVO.setProductId(productInfo.getProductId());
						
						productInfoVO.setId(productInfo.getPminfoId());
						productInfoVO.setImg(productInfo.getDefaultPriceUrl());		
						
						if(productInfo.getIsYihaodian() ==1){
							productInfoVO.setSourceType(ProductInfoVO.SOURCETYPE_SELF);//productInfo.getIsYihaodian
						}else if(productInfo.getIsYihaodian() ==0){
							productInfoVO.setSourceType(ProductInfoVO.SOURCETYPE_SHOP);//productInfo.getIsYihaodian
						}
						productInfoVO.setTitle(productInfo.getProductCname());
						
						productInfoVO.setType(ProductInfoVO.TYPE_NORMAL);
						productInfoVO.setProductType(productVO.getDataType());
						
						if (cmsVO != null) {
							// 若有值,此数据代替商品名称做显示
							if (StringUtils.isNotBlank(cmsVO.getCustomName())) {
								productInfoVO.setTitle(cmsVO.getCustomName());
							}
							// 若有值,此数据代替商品详细页做跳转
							if (StringUtils.isNotBlank(cmsVO.getCustomLink())) {
								productInfoVO.setUrl(cmsVO.getCustomLink());
							}
							// 若有值,此数据代替商品显示图片
							if (StringUtils.isNotBlank(cmsVO.getCustomPic())) {
								productInfoVO.setImg(cmsVO.getCustomPic());
							}
						}
						l.add(productInfoVO);
					}
				}
			}
		}
		
		logger.info("loadProductInfoOrderByPmIds:"+l.size());
		return l;
	}
	
	
	/**
	 * 根据抵用卷活动id查询抵用券相关信息
	 * @param couponId  抵用卷活动id
	 * @return
	 */
	public static CouponActivityOutputVo queryCouponActiveInfoMapByActiveId(Long activityId){
		try {
			if(activityId!=null){
				List<CouponActivityInputVo> couponActivityInputVoList = new ArrayList<CouponActivityInputVo>();
				CouponActivityInputVo pVO = new CouponActivityInputVo(activityId);
				couponActivityInputVoList.add(pVO);
				PromotionReturn<Map<Long,CouponActivityOutputVo>> rVOMap = CouponServiceHandler.getCouponActivityClientService().queryCouponActiveInfoMapByActiveIdList(couponActivityInputVoList);
				if(rVOMap!=null){
					Map<Long,CouponActivityOutputVo> rMaps = rVOMap.getOut();
					if(rMaps!=null){
						return rMaps.get(activityId);
					}
				}
			}
		} catch (Exception e) {
			logger.error("findCouponActiveDefinitonById has exception ", e);
		}
		return null;
	}
	
	/**
	 * 抵用卷发放
	 * @creator @wulibing
	 * @create @2015年4月29日 
	 * @param activityId
	 * @param userIdList
	 * @return
	 */
	public static List<String> generateCouponToUsers(Long activityId,List<Long> userIdList){
		//CouponWirelessClientService
		List<String> retList = com.yihaodian.backend.market.client.handler.CouponServiceHandler.getCouponFacadeService().generateCouponToUsers(activityId, userIdList);
		return retList;
	}

	/**
	 * 品牌团详情查询接口
	 * @param service 品牌团 服务
	 * @param brandId 品牌团id
	 * @return
	 */
	public static GrouponBrandOut getBrandGrouponById(GrouponQueryForMobileService service,Long brandId){		
		GrouponMobileIn grouponMobileIn = new GrouponMobileIn();
		grouponMobileIn.setObjectId(brandId);
		GrouponReturn<GrouponBrandOut> result =service.findGrouponBrandOutById(grouponMobileIn);
		if(result !=null){
			return result.getOut();
		}
		return null;		
	}
	
	/**
	 * lp商品 查价格库存信息
	 * 
	 * @param provinceId 省份Id
	 * @param promotionIds Lpid
	 * @return
	 */
	public static Map<Long,BSPromotionProductVo> lPDetialFromPromotionIds(Long provinceId, List<Long> promotionIds, boolean isPreView,
			Date preViewTime) {
		if(provinceId ==null || promotionIds ==null ||promotionIds.size()<=0){
			return null;
		}
		
		List<BSPromotionProductVo> list = null;
		// landing暂不支持无线独享价
		if (isPreView) {
			list = BusyStockClientUtil.getBusyPromotionFacadeService()
					.getLandingPagePriceStockList(channelId_LandingPage, provinceId,promotionIds, preViewTime);
		} else {
			list = BusyStockClientUtil.getBusyPromotionFacadeService()
					.getLandingPagePriceStockList(channelId_LandingPage, provinceId,promotionIds);
		}
		
		if(list==null || list.size()==0){
			return null;
		}
		
		Map<Long,BSPromotionProductVo> map= new HashMap<Long,BSPromotionProductVo>();
		for(BSPromotionProductVo vo :list){
			map.put(vo.getPmId(), vo);
		}
		return map;
	}	
	
	   /**
     * 批量查询商品库存价格信息
     * 
     * @param provinceId
     *            省份
     * @param productIds
     *            产品Id列表
     * @return
     */
	public static Map<Long, BSProductVo> getProductPriceStockMap(
			Long provinceId, List<Long> pmIds, boolean isPreView,
			Date preViewTime) {
		Map<Long, BSProductVo> resultMap = new HashMap<Long, BSProductVo>();

		// 查询商品库存和价格
		// 普通商品，如果是虚品，则需要pss提供一个获取默认子品的接口
		List<BSProductVo> bsProdcutVoList = null;
		if (isPreView) {
			bsProdcutVoList = BusyStockClientUtil
					.getBusyPriceStockFacadeService()
					.getProductInfosWithMerchant(channelId, provinceId,
							pmIds, preViewTime);
		} else {
			bsProdcutVoList = BusyStockClientUtil
					.getBusyPriceStockFacadeService()
					.getProductInfosWithMerchant(channelId, provinceId,
							pmIds);
		}

		// List<BSProductVo> bsProdcutVoList =
		// BusyStockClientUtil.getBusyPriceStockFacadeService().getProductInfosWithoutMerchant(102L,provinceId,
		// productIds);
		if (bsProdcutVoList != null && bsProdcutVoList.size() > 0) {
			for (BSProductVo bSProductVo : bsProdcutVoList) {
				resultMap.put(bSProductVo.getPmId(), bSProductVo);
			}
		}
		return resultMap;
	}
    
    /**
	 * <del>查询某个团购活动在某个省份下的所有商品信息</del>
	 * @param provinceId
	 * @param promotionIds
	 * @return
	 * @see com.yihaodian.mobile.core.util.GrouponUtil#getBSGrouponVOList
	 */
	@Deprecated
	public static Map<Long , BSGrouponVo> getBSGrouponVOMap(Long provinceId , List<Long> grouponIds){
	    try {
	        //通过Bs得到商品列表
	    	List<BSGrouponVo> bSGrouponVoList = BusyStockClientUtil.getBusyGrouponFacadeService().getBSGrouponVoList(channelId, null, provinceId, grouponIds);
	        if(CollectionUtils.isNotEmpty(bSGrouponVoList)){
	        	Map<Long , BSGrouponVo> result = new HashMap<Long, BSGrouponVo>();
	            for(BSGrouponVo bSGrouponVo : bSGrouponVoList){
	                result.put(bSGrouponVo.getPmId(), bSGrouponVo);
	            }
	            return result;
	        }
        } catch (Exception e) {
            logger.error("getBSGrouponVOMap has error ", e);
        }
	    return new HashMap<Long, BSGrouponVo>();
	}
	/**
	 * 获得无线类目
	 * @param provinceId
	 */
	public static List<CategroyVO> getWirlessCategory (){
		List<CategroyVO> r = new ArrayList<CategroyVO>();
		Long parentId=0l;
		MasterQueryNavigationCategoryService service = pssClient.getMasterQueryNavigationCategoryService();
		QueryByMultiConditionRequest request = new QueryByMultiConditionRequest();
		request.setIsVisible(1);
		String evn = System.getProperty("env");
		Long navId =  100000021L;
		if(StringUtils.isNotBlank(evn)&&evn.equals("test")){//后台测试环境
			navId = 100000069L ;
		}
		request.setCategoryNavigationId(navId);
		
		request.setCategoryParentId(parentId);
		
		Response<List<NavigationCategory>> response = null;
		try {
			response = service.queryNavigationCategoryByMultiCodtion(request);
		} catch (HedwigException e) {
		}
		if(response==null){
			return null;
		}
		List<NavigationCategory> list1= response.getResult();
		
		List<CategroyVO> children = null;
		List<CategroyVO> children2 = null;
		CategroyVO c = null;
		CategroyVO c2 = null;
		CategroyVO c3 = null;
		for(NavigationCategory ca:list1){
			c = new CategroyVO();
			c.setId(ca.getId());
			c.setTitle(ca.getCategoryName());
			request.setCategoryParentId(ca.getId());
			try {
				response = service.queryNavigationCategoryByMultiCodtion(request);
			} catch (HedwigException e) {
			}
			if(response==null){
				continue;
			}
			List<NavigationCategory> list2 = response.getResult();
			if(list2!=null&&list2.size()>0){
				children = new ArrayList<CategroyVO>();
				//二级类目
				for(NavigationCategory ca1:list2){//二级类目
					c2 = new CategroyVO();
					c2.setId(ca1.getId());
					c2.setTitle(ca1.getCategoryName());
					request.setCategoryParentId(ca1.getId());
					try {
						response = service.queryNavigationCategoryByMultiCodtion(request);
					} catch (HedwigException e) {
					}
					if(response==null){
						continue;
					}
					List<NavigationCategory> list3 = response.getResult();
					if(list3!=null&&list3.size()>0){
						children2 = new ArrayList<CategroyVO>();
						for(NavigationCategory ca2:list3){//三级类目
							c3 = new CategroyVO();
							c3.setId(ca2.getId());
							c3.setTitle(ca2.getCategoryName());
							children2.add(c3);
						}
						c2.setChildren(children2);
					}
					children.add(c2);
				}
				c.setChildren(children);
			}
			r.add(c);
		}		
		return r;
	}	
	
	
	
	public static List<ProductInfoVO> updatePriceAndStock(Long provinceId,List<ProductInfoVO> list,boolean isPreView,Date preViewTime){
		List<ProductInfoVO> l = new ArrayList<ProductInfoVO>();
		if(provinceId ==null ||list ==null || list.size()<=0 ){
			return l;
		}
		String type = null;
		List<Long> listIds = new ArrayList<Long>();	//记录 lpid 或者 团购Id	
		Map<Long,Long> pIdMaps = new HashMap<Long, Long>();
		for (ProductInfoVO vo1 : list) {
			type = vo1.getType();
			//1  普通商品	 * 2 LandingPage商品	 * 4  团购商品
			if(ProductInfoVO.TYPE_NORMAL.equals(type)){
				listIds.add(vo1.getPmInfoId());
			}else if(ProductInfoVO.TYPE_LANDINGPAGE.equals(type)&&vo1.getPromotionId()!=null){
				if(!pIdMaps.containsKey(vo1.getPromotionId())){
					pIdMaps.put(vo1.getPromotionId(), vo1.getPromotionId());
					listIds.add(vo1.getPromotionId());
				}
			}else if(ProductInfoVO.TYPE_GROUP.equals(type)){
				listIds.add(vo1.getGrouponId());
			}
		}
		
		if(listIds.size()<=0){
			return l;
		}
		if(ProductInfoVO.TYPE_GROUP.equals(type)){			
			Map<Long,BSGrouponVo> map = getBSGrouponVOMap(provinceId, listIds);
			if(map == null){
				return l;
			}
			for(ProductInfoVO vo:list){
				Long pmId =vo.getId() ;
				if(map.get(pmId) != null){
					BSGrouponVo bsvo = map.get(pmId) ;
					if(bsvo.getCurrentPrice() != null){
						vo.setDiscountedPrice(bsvo.getCurrentPrice().doubleValue());
					}
					vo.setSales(bsvo.getSoldNum());//已买件数
					if(bsvo.getSiteType().intValue()==1){
						vo.setOriginalPrice(bsvo.getMarketPrice()
								.doubleValue());
					}else{
						vo.setOriginalPrice(bsvo.getYhdPrice()
								.doubleValue());
					}

					if(bsvo.getPeopleUpper()!=null&&bsvo.getSoldNum()!=null&&bsvo.getPeopleUpper()!=0){
						vo.setSnapData((100-(bsvo.getSoldNum()/bsvo.getPeopleUpper())*100)+"%");
					}
					
					l.add(vo);
				}
			}
		}else if(ProductInfoVO.TYPE_LANDINGPAGE.equals(type)){
			Map<Long,BSPromotionProductVo> map = lPDetialFromPromotionIds(provinceId, listIds,isPreView,preViewTime);
			if(map == null){
				return l;			
			}
			for (ProductInfoVO vo : list) {
				Long pmId = vo.getId();
				if (map.get(pmId) != null) {
					BSPromotionProductVo bsvo = map.get(pmId);
					if (bsvo.getPromNonMemberPrice()!=null){
						vo.setDiscountedPrice(bsvo.getPromNonMemberPrice()
								.doubleValue());
					}else{
						if (bsvo.getCurrentPrice() != null) {
							vo.setDiscountedPrice(bsvo.getCurrentPrice()
									.doubleValue());
						}
					}
					
					vo.setSales(bsvo.getSoldNum());// 已买件数
					if (bsvo.getCurrentStockNum() != null
							&& bsvo.getSoldNum() != null
							&& bsvo.getCurrentStockNum().intValue() != 0) {
						vo.setSnapData((100 - (bsvo.getSoldNum() / (bsvo
								.getSoldNum() + bsvo.getCurrentStockNum()
								.intValue())) * 100)
								+ "%");
					}
					if (bsvo.getMarketPrice() != null) {// 市场价
						vo.setOriginalPrice(bsvo.getMarketPrice().doubleValue());
					}
					if(bsvo.getCurrentPoint() != null){
						vo.setPoints(bsvo.getCurrentPoint().doubleValue());
					}
					
					vo.setStatus(bsvo.getStatus());
					vo.setPromotionId(bsvo.getPromotionId());
					vo.setMerchantId(bsvo.getMerchantId());
					l.add(vo);
				}
			}
		}else if(ProductInfoVO.TYPE_NORMAL.equals(type)){
			Map<Long,BSProductVo> map = getProductPriceStockMap(provinceId, listIds,isPreView,preViewTime);
			if(map == null){
				return l;			
			}
			for(ProductInfoVO vo:list){
				Long pmId =vo.getId() ;
				if(map.get(pmId) != null){
					BSProductVo bsvo = map.get(pmId) ;
					if(bsvo.getCurrentPrice() != null){
						vo.setDiscountedPrice(bsvo.getCurrentPrice().doubleValue());
					}
					vo.setOriginalPrice(bsvo.getMarketPrice());
					if(1==bsvo.getProductType()||2==bsvo.getProductType()){
						//主、子系列商品
						vo.setProductType(ProductVO.PRODUCTTYPE_CANNOT_ADD_TO_CART);
					}
					//20150611:普通商品不做特价时，页面控制不显示此数据
					vo.setSales(bsvo.getSpecialPriceSoldNum());//已买件数
					if(bsvo.getSpecialPriceLimitNumber()!=0){
						vo.setSnapData((100-(bsvo.getSpecialPriceSoldNum()/bsvo.getSpecialPriceLimitNumber())*100)+"%");
					}
					
					l.add(vo);
				}
			}
			
		}
		
		return l;
	}
	
    public static  ProductVo queryProductByCode(String productCode) {
        ProductVo vo = null ;
        try {
            PssClient pc = PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP);
            QueryProductRemoteService service = pc.getQueryProductRemoteService();
            ProductCodeRequest request = new ProductCodeRequest();
            request.setProductCode(productCode);        
            Response<ProductVo> response = service.queryProductByProductCode(request);
            if(response != null && response.getResult() != null){
                vo = response.getResult() ;
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return vo ;
    }

}
