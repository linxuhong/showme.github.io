package com.yihaodian.mobile.backend.service;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.yihaodian.mobile.backend.model.BrandAdvertisement;
import com.yihaodian.mobile.backend.model.CategoryAdvertisement;
import com.yihaodian.mobile.backend.model.Coupon;
import com.yihaodian.mobile.backend.model.CouponListActivity;
import com.yihaodian.mobile.backend.model.Data;
import com.yihaodian.mobile.backend.model.DecreaseUnderCondtionActivity;
import com.yihaodian.mobile.backend.model.DiscountUnderConditionActivity;
import com.yihaodian.mobile.backend.model.FunctionAdvertisement;
import com.yihaodian.mobile.backend.model.GiftUnderConditionPromotionActivity;
import com.yihaodian.mobile.backend.model.GrouponProductListActivity;
import com.yihaodian.mobile.backend.model.Image;
import com.yihaodian.mobile.backend.model.LinkAdvertisement;
import com.yihaodian.mobile.backend.model.MallStoreAdvertisement;
import com.yihaodian.mobile.backend.model.N2NPromotionAdvertisement;
import com.yihaodian.mobile.backend.model.Product;
import com.yihaodian.mobile.backend.model.ProductListActivity;
import com.yihaodian.mobile.backend.model.PromotionActivity;
import com.yihaodian.mobile.backend.model.RedeemActivity;
import com.yihaodian.mobile.backend.model.SearchAdvertisement;
import com.yihaodian.mobile.backend.model.SeckillActivity;
import com.yihaodian.mobile.backend.model.View;
import com.yihaodian.mobile.backend.model.ViewData;
import com.yihaodian.mobile.backend.model.ViewDataContainer;
import com.yihaodian.mobile.framework.common.log.annotation.LogAnnotation;
import com.yihaodian.mobile.service.dal.backend.CouponDao;
import com.yihaodian.mobile.service.dal.backend.DataDao;
import com.yihaodian.mobile.service.dal.backend.ImageDao;
import com.yihaodian.mobile.service.dal.backend.ProductDao;
import com.yihaodian.mobile.service.dal.backend.ViewDataContanierDao;
import com.yihaodian.mobile.service.dal.backend.ViewDataDao;

// TODO: Auto-generated Javadoc
/**
 * The Class DataService.
 */
public class DataService {
	
	/** The data dao. */
	private DataDao dataDao;
	
	/** The link advertisement dao. */
	private DataDao linkAdvertisementDao;
	
	/** The search advertisement dao. */
	private DataDao searchAdvertisementDao;
	
	/** The category advertisement dao. */
	private DataDao categoryAdvertisementDao;
	
	/** The mall store advertisement dao. */
	private DataDao mallStoreAdvertisementDao;
	
	/** The brand advertisement dao. */
	private DataDao brandAdvertisementDao;
	
	/** The default groupon advertisement dao. */
	private DataDao defaultGrouponAdvertisementDao;
	
	/** The gift under condition promotion activity dao. */
	private DataDao giftUnderConditionPromotionActivityDao;
	
	/** The decrease under condition activity dao. */
	private DataDao decreaseUnderConditionActivityDao;
	
	/** The discount under condition activity dao. */
	private DataDao discountUnderConditionActivityDao;
	
	/** The n2 n promotion advertisement dao. */
	private DataDao n2NPromotionAdvertisementDao;
	
	/** The promotion activity dao. */
	private DataDao promotionActivityDao;
	
	/** The product list activity dao. */
	private DataDao productListActivityDao;
	
	/** The goupon list activity dao. */
	private DataDao gouponListActivityDao;
	
	/** The redeem activity dao. */
	private DataDao redeemActivityDao;
	
	/** The seckill activity dao. */
	private DataDao seckillActivityDao;
	
	/** The groupon product list activity dao. */
	private DataDao grouponProductListActivityDao;
	
	/** The image dao. */
	private ImageDao imageDao;
	
	/** The view data dao. */
	private ViewDataDao viewDataDao;
	
	/** The view data container dao. */
	private ViewDataContanierDao viewDataContainerDao;
	
	/** The product dao. */
	private ProductDao productDao;
	
	/** The coupon dao. */
	private CouponDao couponDao;
	

	/**
	 * Creates the activity.
	 *
	 * @param type the type
	 */
	@LogAnnotation
	public void createActivity(Integer type){
		switch(type){
		case 7:
			break;
		case 8:
			break;
		case 9:
			break;
		case 10:
			break;
		case 11:
			break;
		case 15:
		    break;
	    default:
	    	break;
		
		}
	}
	 /*

     *2个参数(1链接-linkurl;2搜索词-id,keyword;3类目-id,keyword;4店铺-stroeid,stroename;

     * 5一号团;6品牌-brandid,brandname;7普通促销-id level;8产品列表-id逗号分隔;

     * 9抵购卷-id逗号分隔;10积分兑换-id,level;11秒杀-id,level;12满赠-id,level;

     * 13满减-id,level;14满折-id,level;15团购商品-id逗号分隔;16N元N件-id,level)

     */
      /*
       *    dataName        param1           pram2               type
       *    链接广告                pageId(int)         null                 1
       *   搜索词广告                     null         keyword(String)          2
       *    类目广告             categoryId(int)  categoryName(String)     3
       *  商城店铺广告         storeId(String)  storeName(String)        4
       *  一号团购广告                      null         linkUrl(String)         5
       *    品牌广告                  brandId(int)       null                  6
       *      满赠              promotionLevel(int) promotionId(String)     12
       *      满减              promotionLevel(int) promotionId(String)     13
       *      满折             promotionLevel(int)  promotionId(String)     14
       *      N2N      promotionLevel(int) promotionId(String)      16
       *  
       */		
	
	@LogAnnotation
	/**
 	 * Creates the new advertisement.
 	 *
 	 * @param images the images
 	 * @param titles the titles
 	 * @param startTime the start time
 	 * @param endTime the end time
 	 * @param type the type
 	 * @param containerId the container id
 	 * @param param1 the param1
 	 * @param param2 the param2
 	 * @param weight the weight
 	 * @return the string
 	 */
 	public String createNewAdvertisement(List<Image> images, String[] titles,
			Date startTime, Date endTime, Integer type,
			Integer containerId,String param1,String param2,Integer weight) {
		switch (type) {
		case 1:
			//LinkAdvertisement linkAdvertisement = new LinkAdvertisement();
			//linkAdvertisement.setId(TSMMConstants.INITIAL_KEY_VALUE.intValue());
			//linkAdvertisement.setTitles(Arrays.asList(titles));
			//linkAdvertisement.setStartTime(startTime);
			//linkAdvertisement.setEndTime(endTime);
			//linkAdvertisement.setDirectUrl(param2);
			//linkAdvertisementDao.saveData(linkAdvertisement);
			LinkAdvertisement linkAdvertisement=createLinkAdvertisement(titles, null,
					startTime,endTime,null);
		    //linkAdvertisement.setImages(images);
			linkAdvertisementDao.saveData(linkAdvertisement);
			break;
		case 2:
			SearchAdvertisement searchAdvertisement=createSearchAdvertisement(startTime, endTime,
					titles,param1,param2.split(","));
			//searchAdvertisement.setImages(images);
			searchAdvertisementDao.saveData(searchAdvertisement);
			//createSearchAdvertisement(startTime,endTime,titles,images,linkUrl,promotionId);
			break;
		case 3:
			CategoryAdvertisement categoryAdvertisement=createCategoryAdvertisement(startTime, endTime,
					titles,param2,Integer.parseInt(param1));
			//categoryAdvertisement.setImages(images);
			categoryAdvertisementDao.saveData(categoryAdvertisement);
			//createCategoryAdvertisement(startTime,endTime,titles,images,linkUrl,promotionId);
			break;
		case 4:
			MallStoreAdvertisement mallStoreAdvertisement=createMallStoreAdvertisement(startTime,endTime,
					titles,param1,param2);
			//mallStoreAdvertisement.setImages(images);
			mallStoreAdvertisementDao.saveData(mallStoreAdvertisement);
			//createCategoryAdvertisement(startTime,endTime,titles,images,linkUrl,promotionId);
			break;
		case 5:
			FunctionAdvertisement defaultGrouponAdvertisement=createDefaultGrouponAdvertisement(startTime,endTime,titles,null);
			//defaultGrouponAdvertisement.setImages(images);
			defaultGrouponAdvertisementDao.saveData(defaultGrouponAdvertisement);
			break;
		case 6:
			BrandAdvertisement brandAdvertisement=createBrandAdvertisement(startTime, endTime,
					titles,param2,Integer.parseInt(param1));
			//brandAdvertisement.setImages(images);
			brandAdvertisementDao.saveData(brandAdvertisement);
			//createBrandAdvertisement(startTime,endTime,titles,images,linkUrl,brandId);
			break;
		case 12:
			GiftUnderConditionPromotionActivity giftUnderConditionPromotionActivity=createPromotionGiftActivity(startTime, endTime,titles,
					param1,Integer.parseInt(param2));
			//giftUnderConditionPromotionActivity.setImages(images);
			giftUnderConditionPromotionActivityDao.saveData(giftUnderConditionPromotionActivity);
			break;
		case 13:
		    DecreaseUnderCondtionActivity decreaseUnderConditionActivity=createDecreaseActivity(startTime, endTime,titles,
					param1,Integer.parseInt(param2));
		    //decreaseUnderConditionActivity.setImages(images);
		    decreaseUnderConditionActivityDao.saveData(decreaseUnderConditionActivity);
			break;
		case 14:
		    DiscountUnderConditionActivity  discountUnderConditionActivity= createDiscountActivity(startTime, endTime,titles,
					param1,Integer.parseInt(param2));
		    //discountUnderConditionActivity.setImages(images);
		    discountUnderConditionActivityDao.saveData(discountUnderConditionActivity);
		    break;
		case 16:
			N2NPromotionAdvertisement n2NPromotionAdvertisement=createN2NPromotionAD(startTime, endTime,titles,
					param1,Integer.parseInt(param2));
			//n2NPromotionAdvertisement.setImages(images);
			n2NPromotionAdvertisementDao.saveData(n2NPromotionAdvertisement);
			break;
		case 7:
			PromotionActivity promotionActivity=createPromotionActivity(
					startTime, endTime, titles, 
					param1, Integer.parseInt(param2));
			//promotionActivity.setImages(images);
			promotionActivityDao.saveData(promotionActivity);
			break;
		case 8:
			ProductListActivity productListActivity=createProductListActivity(
					startTime, endTime, titles
			 );
			//productListActivity.setImages(images);
			productListActivityDao.saveData(productListActivity);
			break;
		case 9:
			CouponListActivity couponListActivity=createCouponActivity(
					startTime, endTime, titles) ;
			//couponListActivity.setImages(images);
			gouponListActivityDao.saveData(couponListActivity);
			break;
		case 10:
			RedeemActivity redeemActivity=createRedeemActivity(
					startTime, endTime, titles,
					param1, Integer.parseInt(param2));
			//redeemActivity.setImages(images);
			redeemActivityDao.saveData(redeemActivity);
			break;
		case 11:
			SeckillActivity seckillActivity=createSeckillActivity(
					startTime, endTime, titles,
					param1, Integer.parseInt(param2)) ;
			//seckillActivity.setImages(images);
			seckillActivityDao.saveData(seckillActivity);
			break;
		case 15:
			GrouponProductListActivity grouponProductListActivity=createGrouponProductListActivity(
					startTime,endTime,titles);
			//grouponProductListActivity.setImages(images);
			grouponProductListActivityDao.saveData(grouponProductListActivity);
		    break;
		default:
       }
		Data data=dataDao.getLastData();
		for (Image image : images) {
			imageDao.saveImage(image, data);
		}
		ViewDataContainer viewDataContainer=new ViewDataContainer();
		viewDataContainer.setId(containerId);
		if(type==1){
			System.out.println(">>>>>containerId:"+containerId+"<<<<<");
			View view=new View();
			view.setId(Integer.parseInt(param1));
			createViewData(viewDataContainer,data,view,weight);
		}
		else if(type==8||type==15){
			if(param1!=null){
		    	for(String productId:param1.split(",")){
		    		Product product=new Product();
		    		product.setId(0);
		    		product.setProductId(productId);
		    		productDao.saveProduct(data, product);	
		    	}
		    }
			createViewData(viewDataContainer,data,null,weight);
		}
		else if(type==9){
			if(param1!=null){
				for(String couponId:param1.split(",")){
		    		Coupon coupon=new Coupon();
		    	    coupon.setId(0);
		    		coupon.setCouponId(couponId);
		    		couponDao.saveCoupon(data, coupon);
		    	}
		    }
			createViewData(viewDataContainer,data,null,weight);
		}
		else {
			System.out.println(">>>>>containerId:"+containerId+"<<<<<");
			createViewData(viewDataContainer,data,null,weight);
		}
	return null;
	}
	
	@LogAnnotation
	/**
	 * Creates the discount activity.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param titles the titles
	 * @param promotionId the promotion id
	 * @param promotionLevel the promotion level
	 * @return the discount under condition activity
	 */
	public DiscountUnderConditionActivity createDiscountActivity(Date startTime, Date endTime, String[] titles,
			String promotionId, int promotionLevel) {
		DiscountUnderConditionActivity  pla=new DiscountUnderConditionActivity();
	    //pla.setId(DataManager.generateId());
		pla.setId(0);
		pla.setStartTime(startTime);
		pla.setEndTime(endTime);
		pla.setTitles(Arrays.asList(titles));
	    pla.setPromotionId(promotionId);
		pla.setPromotionLevel(promotionLevel);
		
		return pla;
	}
	
	/**
	 * Creates the n2 n promotion ad.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param titles the titles
	 * @param promotionId the promotion id
	 * @param promotionLevel the promotion level
	 * @return the n2 n promotion advertisement
	 */
	
	@LogAnnotation
	public N2NPromotionAdvertisement createN2NPromotionAD(Date startTime, Date endTime, String[] titles,
			String promotionId, int promotionLevel) {
		N2NPromotionAdvertisement  pla=new N2NPromotionAdvertisement();
	    //pla.setId(DataManager.generateId());
		pla.setId(0);
		pla.setStartTime(startTime);
		pla.setEndTime(endTime);
		pla.setTitles(Arrays.asList(titles));
	    pla.setPromotionId(promotionId);
		pla.setPromotionLevel(promotionLevel);
		
		return pla;
	}
	
	/**
	 * Creates the decrease activity.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param titles the titles
	 * @param promotionId the promotion id
	 * @param promotionLevel the promotion level
	 * @return the decrease under condtion activity
	 */
	@LogAnnotation
	public DecreaseUnderCondtionActivity createDecreaseActivity(Date startTime, Date endTime, String[] titles,
			String promotionId, int promotionLevel) {
		DecreaseUnderCondtionActivity  pla=new DecreaseUnderCondtionActivity();
	    //pla.setId(DataManager.generateId());
		pla.setId(0);
		pla.setStartTime(startTime);
		pla.setEndTime(endTime);
		pla.setTitles(Arrays.asList(titles));
	    pla.setPromotionId(promotionId);
		pla.setPromotionLevel(promotionLevel);
		
		return pla;
	}
	
	/**
	 * Creates the promotion gift activity.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param titles the titles
	 * @param promotionId the promotion id
	 * @param promotionLevel the promotion level
	 * @return the gift under condition promotion activity
	 */
	@LogAnnotation
	public GiftUnderConditionPromotionActivity createPromotionGiftActivity(Date startTime, Date endTime, String[] titles,
			String promotionId, int promotionLevel) {
		GiftUnderConditionPromotionActivity  pla=new GiftUnderConditionPromotionActivity();
	    //pla.setId(DataManager.generateId());
		pla.setId(0);
		pla.setStartTime(startTime);
		pla.setEndTime(endTime);
		pla.setTitles(Arrays.asList(titles));
	    pla.setPromotionId(promotionId);
		pla.setPromotionLevel(promotionLevel);
		
		return pla;
	}
	
	/**
	 * Creates the default groupon advertisement.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param titles the titles
	 * @param linkUrl the link url
	 * @return the function advertisement
	 */
	@LogAnnotation
	public FunctionAdvertisement createDefaultGrouponAdvertisement(Date startTime, Date endTime,
			String[] titles,String linkUrl) {
		FunctionAdvertisement ad=new FunctionAdvertisement();
		ad.setId(0);
		ad.setStartTime(startTime);
		ad.setEndTime(endTime);
		ad.setTitles(Arrays.asList(titles));
		ad.setDirectUrl(linkUrl);
		return ad;
	}
	
	/**
	 * Creates the mall store advertisement.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param titles the titles
	 * @param storeId the store id
	 * @param storeName the store name
	 * @return the mall store advertisement
	 */
	@LogAnnotation
	public MallStoreAdvertisement createMallStoreAdvertisement(Date startTime, Date endTime,
			String[] titles,String storeId,String storeName) {
		MallStoreAdvertisement ad=new MallStoreAdvertisement();
		ad.setId(0);
		ad.setStartTime(startTime);
		ad.setEndTime(endTime);
		ad.setTitles(Arrays.asList(titles));
		ad.setStoreId(storeId);
		ad.setStoreName(storeName);
		ad.setDirectUrl(null);
		return ad;
	}
	
	/**
	 * Creates the brand advertisement.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param titles the titles
	 * @param brandName the brand name
	 * @param brandId the brand id
	 * @return the brand advertisement
	 */
	@LogAnnotation
	public BrandAdvertisement createBrandAdvertisement(Date startTime, Date endTime,
			String[] titles,String brandName,Integer brandId) {
		BrandAdvertisement ad=new BrandAdvertisement();
		ad.setId(0);
		ad.setStartTime(startTime);
		ad.setEndTime(endTime);
		ad.setTitles(Arrays.asList(titles));
		ad.setBrandId(brandId);
		ad.setBrandName(brandName);
		ad.setDirectUrl(null);
		return ad;
	}
	
	/**
	 * Creates the category advertisement.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param titles the titles
	 * @param categoryName the category name
	 * @param categoryId the category id
	 * @return the category advertisement
	 */
	@LogAnnotation
	public CategoryAdvertisement createCategoryAdvertisement(Date startTime, Date endTime,
			String[] titles,String categoryName,Integer categoryId) {
		CategoryAdvertisement ad=new CategoryAdvertisement();
		ad.setId(0);
		ad.setStartTime(startTime);
		ad.setEndTime(endTime);
		ad.setTitles(Arrays.asList(titles));
		ad.setCategoryId(categoryId);
		ad.setCategoryName(categoryName);
		ad.setDirectUrl(null);
		return ad;
	}
	
	/**
	 * Creates the search advertisement.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param name the name
	 * @param linkUrl the link url
	 * @param keywords the keywords
	 * @return the search advertisement
	 */
	@LogAnnotation
	public SearchAdvertisement createSearchAdvertisement(Date startTime, Date endTime,
			String[] name,String linkUrl,String[] keywords) {
		SearchAdvertisement ad=new SearchAdvertisement();
		ad.setId(0);
		ad.setStartTime(startTime);
		ad.setEndTime(endTime);
		ad.setTitles(Arrays.asList(name));
		ad.setKeywords(Arrays.asList(keywords));
		ad.setDirectUrl(linkUrl);
		//ad.setViewLink(linkedToView);
		return ad;
	}

	/**
	 * Creates the data.
	 *
	 * @return the string
	 */
	@LogAnnotation
	public String createData() {
		Data data = createLinkAdvertisement(new String[] { "生活电器中心", "副标题" },
				"生活电器主中心", new Date(), new Date(), "http://特殊链接");
		linkAdvertisementDao.saveData(data);
		Image image = createImage(20, 120, 123L,
				"http://yihaodian.coms/sdsd/sdsd.cdsdc");
		data = linkAdvertisementDao.getLastData();
		imageDao.saveImage(image,data);
		
		return null;
	}
	
	@LogAnnotation
	/**
	 * Creates the link advertisement.
	 *
	 * @param name the name
	 * @param tips the tips
	 * @param starttime the starttime
	 * @param endtime the endtime
	 * @param directUrl the direct url
	 * @return the link advertisement
	 */
	public LinkAdvertisement createLinkAdvertisement(String[] name, String tips,
			Date starttime, Date endtime, String directUrl) {
		LinkAdvertisement linkAdvertisement = new LinkAdvertisement();
		linkAdvertisement.setId(0);
		linkAdvertisement.setTitles(Arrays.asList(name));
		linkAdvertisement.setTips(tips);
		linkAdvertisement.setStartTime(starttime);
		linkAdvertisement.setEndTime(endtime);
		linkAdvertisement.setDirectUrl(directUrl);
		return linkAdvertisement;
	}

	/**
	 * Creates the image.
	 *
	 * @param width the width
	 * @param height the height
	 * @param size the size
	 * @param srcUrl the src url
	 * @return the image
	 */
	@LogAnnotation
	private Image createImage(Integer width, Integer height, long size,
			String srcUrl) {
		Image image = new Image();
		image.setId(0);
		image.setWidth(width);
		image.setHeight(height);
		image.setSize(size);
		image.setSrcUrl(srcUrl);
		return image;
	}
   
	/**
	 * Creates the view data.
	 *
	 * @param viewDataContainer the view data container
	 * @param data the data
	 * @param linkView the link view
	 * @param weight the weight
	 * @return the string
	 */
	@LogAnnotation
	public String createViewData(ViewDataContainer viewDataContainer,
			Data data, View linkView,Integer weight) {
		ViewData viewData = new ViewData();
		viewData.setId(0);
		viewData.setStartTime(data.getStartTime());
		viewData.setEndTime(data.getEndTime());
		viewData.setViewLink(linkView);
		viewData.setData(data);
		Integer order;
		if(weight==null){
		order = viewDataDao
				.getNumberOfViewDataOfViewDataContainer(viewDataContainer);
		viewData.setOrder(order);
		viewData.setWeight(order);
		}else {
			viewData.setOrder(weight);
			viewData.setWeight(weight);
		}
		viewDataDao.saveViewData(viewDataContainer, viewData);
		return null;
	}
	
	/**
	 * Gets the link advertisement dao.
	 *
	 * @return the link advertisement dao
	 */
	public DataDao getLinkAdvertisementDao() {
		return linkAdvertisementDao;
	}

	/**
	 * Sets the link advertisement dao.
	 *
	 * @param linkAdvertisementDao the new link advertisement dao
	 */
	public void setLinkAdvertisementDao(DataDao linkAdvertisementDao) {
		this.linkAdvertisementDao = linkAdvertisementDao;
	}

	/**
	 * Gets the image dao.
	 *
	 * @return the image dao
	 */
	public ImageDao getImageDao() {
		return imageDao;
	}

	/**
	 * Sets the image dao.
	 *
	 * @param imageDao the new image dao
	 */
	public void setImageDao(ImageDao imageDao) {
		this.imageDao = imageDao;
	}

	/**
	 * Gets the view data dao.
	 *
	 * @return the view data dao
	 */
	public ViewDataDao getViewDataDao() {
		return viewDataDao;
	}

	/**
	 * Sets the view data dao.
	 *
	 * @param viewDataDao the new view data dao
	 */
	public void setViewDataDao(ViewDataDao viewDataDao) {
		this.viewDataDao = viewDataDao;
	}

	/**
	 * Sets the view data container dao.
	 *
	 * @param viewDataContainerDao the new view data container dao
	 */
	public void setViewDataContainerDao(
			ViewDataContanierDao viewDataContainerDao) {
		this.viewDataContainerDao = viewDataContainerDao;
	}

	/**
	 * Gets the view data container dao.
	 *
	 * @return the view data container dao
	 */
	public ViewDataContanierDao getViewDataContainerDao() {
		return viewDataContainerDao;
	}


	/**
	 * Sets the search advertisement dao.
	 *
	 * @param searchAdvertisementDao the new search advertisement dao
	 */
	public void setSearchAdvertisementDao(DataDao searchAdvertisementDao) {
		this.searchAdvertisementDao = searchAdvertisementDao;
	}


	/**
	 * Gets the search advertisement dao.
	 *
	 * @return the search advertisement dao
	 */
	public DataDao getSearchAdvertisementDao() {
		return searchAdvertisementDao;
	}


	/**
	 * Sets the category advertisement dao.
	 *
	 * @param categoryAdvertisementDao the new category advertisement dao
	 */
	public void setCategoryAdvertisementDao(DataDao categoryAdvertisementDao) {
		this.categoryAdvertisementDao = categoryAdvertisementDao;
	}


	/**
	 * Gets the category advertisement dao.
	 *
	 * @return the category advertisement dao
	 */
	public DataDao getCategoryAdvertisementDao() {
		return categoryAdvertisementDao;
	}


	/**
	 * Sets the mall store advertisement dao.
	 *
	 * @param mallStoreAdvertisementDao the new mall store advertisement dao
	 */
	public void setMallStoreAdvertisementDao(DataDao mallStoreAdvertisementDao) {
		this.mallStoreAdvertisementDao = mallStoreAdvertisementDao;
	}


	/**
	 * Gets the mall store advertisement dao.
	 *
	 * @return the mall store advertisement dao
	 */
	public DataDao getMallStoreAdvertisementDao() {
		return mallStoreAdvertisementDao;
	}


	/**
	 * Sets the brand advertisement dao.
	 *
	 * @param brandAdvertisementDao the new brand advertisement dao
	 */
	public void setBrandAdvertisementDao(DataDao brandAdvertisementDao) {
		this.brandAdvertisementDao = brandAdvertisementDao;
	}


	/**
	 * Gets the brand advertisement dao.
	 *
	 * @return the brand advertisement dao
	 */
	public DataDao getBrandAdvertisementDao() {
		return brandAdvertisementDao;
	}


	/**
	 * Sets the default groupon advertisement dao.
	 *
	 * @param defaultGrouponAdvertisementDao the new default groupon advertisement dao
	 */
	public void setDefaultGrouponAdvertisementDao(
			DataDao defaultGrouponAdvertisementDao) {
		this.defaultGrouponAdvertisementDao = defaultGrouponAdvertisementDao;
	}


	/**
	 * Gets the default groupon advertisement dao.
	 *
	 * @return the default groupon advertisement dao
	 */
	public DataDao getDefaultGrouponAdvertisementDao() {
		return defaultGrouponAdvertisementDao;
	}


	/**
	 * Gets the gift under condition promotion activity dao.
	 *
	 * @return the gift under condition promotion activity dao
	 */
	public DataDao getGiftUnderConditionPromotionActivityDao() {
		return giftUnderConditionPromotionActivityDao;
	}


	/**
	 * Sets the gift under condition promotion activity dao.
	 *
	 * @param giftUnderConditionPromotionActivityDao the new gift under condition promotion activity dao
	 */
	public void setGiftUnderConditionPromotionActivityDao(
			DataDao giftUnderConditionPromotionActivityDao) {
		this.giftUnderConditionPromotionActivityDao = giftUnderConditionPromotionActivityDao;
	}


	/**
	 * Sets the decrease under condition activity dao.
	 *
	 * @param decreaseUnderConditionActivityDao the new decrease under condition activity dao
	 */
	public void setDecreaseUnderConditionActivityDao(
			DataDao decreaseUnderConditionActivityDao) {
		this.decreaseUnderConditionActivityDao = decreaseUnderConditionActivityDao;
	}


	/**
	 * Gets the decrease under condition activity dao.
	 *
	 * @return the decrease under condition activity dao
	 */
	public DataDao getDecreaseUnderConditionActivityDao() {
		return decreaseUnderConditionActivityDao;
	}


	/**
	 * Gets the discount under condition activity dao.
	 *
	 * @return the discount under condition activity dao
	 */
	public DataDao getDiscountUnderConditionActivityDao() {
		return discountUnderConditionActivityDao;
	}


	/**
	 * Sets the discount under condition activity dao.
	 *
	 * @param discountUnderConditionActivityDao the new discount under condition activity dao
	 */
	public void setDiscountUnderConditionActivityDao(
			DataDao discountUnderConditionActivityDao) {
		this.discountUnderConditionActivityDao = discountUnderConditionActivityDao;
	}


	/**
	 * Sets the n2 n promotion advertisement dao.
	 *
	 * @param n2NPromotionAdvertisementDao the new n2 n promotion advertisement dao
	 */
	public void setN2NPromotionAdvertisementDao(
			DataDao n2NPromotionAdvertisementDao) {
		this.n2NPromotionAdvertisementDao = n2NPromotionAdvertisementDao;
	}


	/**
	 * Gets the n2 n promotion advertisement dao.
	 *
	 * @return the n2 n promotion advertisement dao
	 */
	public DataDao getN2NPromotionAdvertisementDao() {
		return n2NPromotionAdvertisementDao;
	}


	/**
	 * Gets the data dao.
	 *
	 * @return the data dao
	 */
	public DataDao getDataDao() {
		return dataDao;
	}


	/**
	 * Sets the data dao.
	 *
	 * @param dataDao the new data dao
	 */
	public void setDataDao(DataDao dataDao) {
		this.dataDao = dataDao;
	}
	
	/**
	 * Creates the product list activity.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param title the title
	 * @return the product list activity
	 */
	
	@LogAnnotation
	public ProductListActivity createProductListActivity(
			Date startTime, Date endTime, String[] title
			 ) {
		    ProductListActivity pla=new ProductListActivity();
		    pla.setId(0);
			pla.setStartTime(startTime);
			pla.setEndTime(endTime);
			StringBuffer name= new StringBuffer();
		    for(String t:title){
			   if(name.length()==0){
			       name.append(t);
			   }else {
			       name.append(",");
			       name.append(t);
			   }
			}
			pla.setName(name.toString());
			return pla;
	}
	
	/**
	 * Creates the coupon activity.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param title the title
	 * @return the coupon list activity
	 */
	
	@LogAnnotation
	public CouponListActivity createCouponActivity(
			Date startTime, Date endTime, String[] title) {
		    CouponListActivity pla=new CouponListActivity();
		    pla.setId(0);
			pla.setStartTime(startTime);
			pla.setEndTime(endTime);
            StringBuffer name= new StringBuffer();
            for(String t:title){
               if(name.length()==0){
                   name.append(t);
               }else {
                   name.append(",");
                   name.append(t);
               }
            }
            pla.setName(name.toString());
			return pla;
	}
	
	/**
	 * Creates the groupon product list activity.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param title the title
	 * @return the groupon product list activity
	 */
	
	@LogAnnotation
	public GrouponProductListActivity createGrouponProductListActivity(
			Date startTime, Date endTime, String[] title) {
		    GrouponProductListActivity pla=new GrouponProductListActivity();
		    pla.setId(0);
			pla.setStartTime(startTime);
			pla.setEndTime(endTime);
            StringBuffer name= new StringBuffer();
            for(String t:title){
               if(name.length()==0){
                   name.append(t);
               }else {
                   name.append(",");
                   name.append(t);
               }
            }
            pla.setName(name.toString());
			return pla;
	}
	
	/**
	 * Creates the promotion activity.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param title the title
	 * @param promotionId the promotion id
	 * @param promotionLevel the promotion level
	 * @return the promotion activity
	 */
	
	@LogAnnotation
	public PromotionActivity createPromotionActivity(
			Date startTime, Date endTime, String[] title, 
			String promotionId, int promotionLevel) {
		PromotionActivity pla=new PromotionActivity();
	    pla.setId(0);
		pla.setStartTime(startTime);
		pla.setEndTime(endTime);
        StringBuffer name= new StringBuffer();
        for(String t:title){
           if(name.length()==0){
               name.append(t);
           }else {
               name.append(",");
               name.append(t);
           }
        }
        pla.setName(name.toString());
	    pla.setPromotionId(promotionId);
		pla.setPromotionLevel(promotionLevel);
		return pla;
	}
	
	/**
	 * Creates the seckill activity.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param title the title
	 * @param promotionId the promotion id
	 * @param promotionLevel the promotion level
	 * @return the seckill activity
	 */
	
	@LogAnnotation
	public SeckillActivity createSeckillActivity(
			Date startTime, Date endTime, String[] title,
			String promotionId, int promotionLevel) {
		SeckillActivity pla=new SeckillActivity();
		pla.setId(0);
		pla.setStartTime(startTime);
		pla.setEndTime(endTime);
        StringBuffer name= new StringBuffer();
        for(String t:title){
           if(name.length()==0){
               name.append(t);
           }else {
               name.append(",");
               name.append(t);
           }
        }
        pla.setName(name.toString());
	    pla.setPromotionId(promotionId);
		pla.setPromotionLevel(promotionLevel);
		return pla;
	}
	
	/**
	 * Creates the redeem activity.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param title the title
	 * @param promotionId the promotion id
	 * @param promotionLevel the promotion level
	 * @return the redeem activity
	 */
	
	@LogAnnotation
	public RedeemActivity createRedeemActivity(
			Date startTime, Date endTime, String[] title,
			String promotionId, int promotionLevel) {
		RedeemActivity pla=new RedeemActivity();
		pla.setId(0);
		pla.setStartTime(startTime);
		pla.setEndTime(endTime);
        StringBuffer name= new StringBuffer();
        for(String t:title){
           if(name.length()==0){
               name.append(t);
           }else {
               name.append(",");
               name.append(t);
           }
        }
        pla.setName(name.toString());
	    pla.setPromotionId(promotionId);
		pla.setPromotionLevel(promotionLevel);
		return pla;
	}

	/**
	 * Gets the promotion activity dao.
	 *
	 * @return the promotion activity dao
	 */
	public DataDao getPromotionActivityDao() {
		return promotionActivityDao;
	}

	/**
	 * Sets the promotion activity dao.
	 *
	 * @param promotionActivityDao the new promotion activity dao
	 */
	public void setPromotionActivityDao(DataDao promotionActivityDao) {
		this.promotionActivityDao = promotionActivityDao;
	}

	/**
	 * Gets the product list activity dao.
	 *
	 * @return the product list activity dao
	 */
	public DataDao getProductListActivityDao() {
		return productListActivityDao;
	}

	/**
	 * Sets the product list activity dao.
	 *
	 * @param productListActivityDao the new product list activity dao
	 */
	public void setProductListActivityDao(DataDao productListActivityDao) {
		this.productListActivityDao = productListActivityDao;
	}

	/**
	 * Gets the goupon list activity dao.
	 *
	 * @return the goupon list activity dao
	 */
	public DataDao getGouponListActivityDao() {
		return gouponListActivityDao;
	}

	/**
	 * Sets the goupon list activity dao.
	 *
	 * @param gouponListActivityDao the new goupon list activity dao
	 */
	public void setGouponListActivityDao(DataDao gouponListActivityDao) {
		this.gouponListActivityDao = gouponListActivityDao;
	}

	/**
	 * Gets the redeem activity dao.
	 *
	 * @return the redeem activity dao
	 */
	public DataDao getRedeemActivityDao() {
		return redeemActivityDao;
	}

	/**
	 * Sets the redeem activity dao.
	 *
	 * @param redeemActivityDao the new redeem activity dao
	 */
	public void setRedeemActivityDao(DataDao redeemActivityDao) {
		this.redeemActivityDao = redeemActivityDao;
	}

	/**
	 * Gets the seckill activity dao.
	 *
	 * @return the seckill activity dao
	 */
	public DataDao getSeckillActivityDao() {
		return seckillActivityDao;
	}

	/**
	 * Sets the seckill activity dao.
	 *
	 * @param seckillActivityDao the new seckill activity dao
	 */
	public void setSeckillActivityDao(DataDao seckillActivityDao) {
		this.seckillActivityDao = seckillActivityDao;
	}

	/**
	 * Gets the groupon product list activity dao.
	 *
	 * @return the groupon product list activity dao
	 */
	public DataDao getGrouponProductListActivityDao() {
		return grouponProductListActivityDao;
	}

	/**
	 * Sets the groupon product list activity dao.
	 *
	 * @param grouponProductListActivityDao the new groupon product list activity dao
	 */
	public void setGrouponProductListActivityDao(
			DataDao grouponProductListActivityDao) {
		this.grouponProductListActivityDao = grouponProductListActivityDao;
	}

	/**
	 * Sets the beckend product dao.
	 *
	 * @param productDao the new beckend product dao
	 */
	public void setBeckendProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	/**
	 * Gets the beckend product dao.
	 *
	 * @return the beckend product dao
	 */
	public ProductDao getBeckendProductDao() {
		return productDao;
	}

	/**
	 * Sets the beckend coupon dao.
	 *
	 * @param couponDao the new beckend coupon dao
	 */
	public void setBeckendCouponDao(CouponDao couponDao) {
		this.couponDao = couponDao;
	}

	/**
	 * Gets the beckend coupon dao.
	 *
	 * @return the beckend coupon dao
	 */
	public CouponDao getBeckendCouponDao() {
		return couponDao;
	}
	
}