package com.yihaodian.mobile.service.client.redpacket.service;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.vo.ClientInfoVO;

/**
 * 周年庆红包客户端service
 * @author zhangwei5
 * @version $Id: AnniversaryRedPacketClientService.java, v 0.1 2014-6-23 下午6:21:53 zhangwei5 Exp $
 */
public interface AnniversaryRedPacketClientService {
    
    /**
     * 检查是否存在有效的周年庆红包活动
     * @param clientInfoVO
     * @return
     */
    Result checkActivityEffective(ClientInfoVO clientInfoVO);
    
    /**
     * 获取红包
     * @param clientInfoVO
     * @return
     */
    Result getRedPacketResult(ClientInfoVO clientInfoVO);
}
