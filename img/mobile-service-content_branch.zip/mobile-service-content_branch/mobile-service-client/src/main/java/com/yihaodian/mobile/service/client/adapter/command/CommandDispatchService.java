package com.yihaodian.mobile.service.client.adapter.command;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.command.ICommandService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 
 * @author chenliang
 *
 */
public class CommandDispatchService extends BaseDiapatchService{

	public RtnInfo getSpellGroupInfo(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceId"+result.getResultDesc());
    		} 
    	}
    	
    	String command = bizInfo.get("command");
		ICommandService service = CentralMobileServiceHandler.getCommandService();
    	Result result = service.getSpellGroupInfo(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Integer.valueOf(context.getRequestInfo().getProvinceId()),command);
        return  getRtnInfo(result);     	   
    }
	
}
