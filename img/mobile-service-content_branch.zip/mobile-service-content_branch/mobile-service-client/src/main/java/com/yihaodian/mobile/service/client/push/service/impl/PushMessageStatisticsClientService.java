package com.yihaodian.mobile.service.client.push.service.impl;

import java.util.List;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.domain.vo.business.push.OpenMessageParamVO;
import com.yihaodian.mobile.service.facade.business.push.IPushMessageStatisticsService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class PushMessageStatisticsClientService implements IPushMessageStatisticsService {

    private IPushMessageStatisticsService pushMessageStatisticsHessianCall; 
    
    
    
    public void setPushMessageStatisticsHessianCall(IPushMessageStatisticsService pushMessageStatisticsHessianCall) {
        this.pushMessageStatisticsHessianCall = pushMessageStatisticsHessianCall;
    }



    @Override
    public Result messageStatistics(ClientInfoVO clientInfoVo, Long openTime,
                                    List<OpenMessageParamVO> messageList, String deviceToken,
                                    Long userId, Integer type) {
        Result result = pushMessageStatisticsHessianCall.messageStatistics(clientInfoVo, openTime, messageList, deviceToken, userId, type);
        return result;
    }

}
