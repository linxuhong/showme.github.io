/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.List;
import java.util.Map;











import org.apache.log4j.Logger;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.push.spi.HomePageService;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.home.CalendarBuyDetail;
import com.yihaodian.mobile.vo.home.ViewVO;
import com.yihaodian.mobile.vo.community.CheckCommunityVO;
import com.yihaodian.mobile.vo.home.HomePromotionDetailVO;
import com.yihaodian.mobile.vo.product.ProductVO;
import com.yihaodian.mobile.vo.promotion.CmsColumnVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class HomePageDispatchService.
 * @author zuodeng
 */
public class HomePageDispatchService extends BaseDiapatchService{
    
    /** The logger. */
    private static Logger logger = Logger.getLogger(HomePageDispatchService.class);

	
	/**
	 * Gets the mobile view by id.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the mobile view by id
	 */
	public RtnInfo getMobileViewById(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		HomePageService homePageClientService = CentralMobileServiceHandler.getHomePageClientService();
		Trader trader = getTraderFromContext(context);
		if(trader==null||trader.getTraderName() == null){
			return RtnInfo.ParameterErrRtnInfo("traderName is null");
		}
		String provinceIdstr  = context.getRequestInfo().getProvinceId();	
		Result result =valiateGetParams(provinceIdstr);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("provinceId"+result.getResultDesc());
		}
		Long provinceId=Long.parseLong(provinceIdstr);
		
		String viewidStr  = bizInfo.get("viewid");	
		result =valiateGetParams(viewidStr);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("viewid"+result.getResultDesc());
		}
		Long viewId= Long.parseLong(viewidStr);
		ViewVO vo=homePageClientService.getMobileViewById(trader, provinceId,viewId);
		return RtnInfo.RightWlRtnInfo(vo);
	}
	
	/**
	 * Gets the brand shop promotion.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the brand shop promotion
	 */
	public RtnInfo getBrandShopPromotion(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		HomePageService homePageClientService = CentralMobileServiceHandler.getHomePageClientService();
		Trader trader =getTraderFromContext(context);
		if(trader.getTraderName()==null){
			return RtnInfo.ParameterErrRtnInfo("traderName is null");
		}
		String provinceIdstr  = context.getRequestInfo().getProvinceId();	
		Result result =valiateGetParams(provinceIdstr);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("provinceId"+result.getResultDesc());
		}
		Long provinceId=Long.parseLong(provinceIdstr);	
		List<HomePromotionDetailVO> list = homePageClientService.getBrandShopPromotion(trader, provinceId);
		return RtnInfo.RightWlRtnInfo(list);
	}
	
	
	/**
	 * Gets the mobile index view by type.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the mobile index view by type
	 */
	public RtnInfo getMobileIndexViewByType(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		HomePageService homePageClientService = CentralMobileServiceHandler.getHomePageClientService();
		Trader trader =getTraderFromContext(context);
		RtnInfo rtnInfo = vaildateTrader(trader);
		if(rtnInfo != null){
			return rtnInfo;
		}
		rtnInfo = validateProvinceId(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String viewType = bizInfo.get("viewtype");
		if(StringUtil.isBlank(viewType) || !viewType.matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("viewType  is null");
		}
		ViewVO result = homePageClientService.getMobileIndexViewByType(trader, Long.parseLong(context.getRequestInfo().getProvinceId()), Long.parseLong(viewType));
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the cms column detail.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the cms column detail
	 */
	public RtnInfo getCmsColumnDetail(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(StringUtil.isBlank(trader.getTraderName())){
			return RtnInfo.ParameterErrRtnInfo("traderName is null");
		}
		
		String provinceId = context.getRequestInfo().getProvinceId();
		if(StringUtil.isBlank(provinceId)){
			return RtnInfo.ParameterErrRtnInfo("province id is null");
		}
		
		String cmsColumnId = bizInfo.get("cmscolumnid");
		if(StringUtil.isBlank(cmsColumnId)){
			return RtnInfo.ParameterErrRtnInfo("cmsColumnId is null");
		}
		
		String sortType = bizInfo.get("sorttype");
		if(StringUtil.isBlank(sortType)){
			return RtnInfo.ParameterErrRtnInfo("sortType is null");
		}
		
		String currentPage = bizInfo.get("currentpage");
		if(StringUtil.isBlank(currentPage)){
			return RtnInfo.ParameterErrRtnInfo("currentPage is null");
		}
		
		String pageSize = bizInfo.get("pagesize");
		if(StringUtil.isBlank(pageSize)){
			return RtnInfo.ParameterErrRtnInfo("pageSize is null");
		}
		
		HomePageService service = CentralMobileServiceHandler.getHomePageClientService();
		CmsColumnVO result = service.getCmsColumnDetail(trader, Long.valueOf(provinceId), Long.valueOf(cmsColumnId), Integer.valueOf(sortType), Integer.valueOf(currentPage), Integer.valueOf(pageSize));
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the cms column detail.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the cms column detail
	 */
	public RtnInfo getCommunityProductList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(StringUtil.isBlank(trader.getTraderName())){
			return RtnInfo.ParameterErrRtnInfo("traderName is null");
		}
		
		String communityProvinceId = bizInfo.get("communityprovinceid");
		if(StringUtil.isBlank(communityProvinceId)){
			return RtnInfo.ParameterErrRtnInfo("communityProvinceId is null");
		}
		
		String cmsColumnId = bizInfo.get("cmscolumnid");
		if(StringUtil.isBlank(cmsColumnId)){
			return RtnInfo.ParameterErrRtnInfo("cmsColumnId is null");
		}
		
		String sortType = bizInfo.get("sorttype");
		if(StringUtil.isBlank(sortType)){
			return RtnInfo.ParameterErrRtnInfo("sortType is null");
		}
		
		String currentPage = bizInfo.get("currentpage");
		if(StringUtil.isBlank(currentPage)){
			return RtnInfo.ParameterErrRtnInfo("currentPage is null");
		}
		
		String pageSize = bizInfo.get("pagesize");
		if(StringUtil.isBlank(pageSize)){
			return RtnInfo.ParameterErrRtnInfo("pageSize is null");
		}
		
		HomePageService service = CentralMobileServiceHandler.getHomePageClientService();
		CmsColumnVO result = service.getCmsColumnDetail(trader, Long.valueOf(communityProvinceId), Long.valueOf(cmsColumnId), Integer.valueOf(sortType), Integer.valueOf(currentPage), Integer.valueOf(pageSize));
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the calendar buy detail.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the calendar buy detail
	 */
	public RtnInfo getCalendarBuyDetail(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(trader.getTraderName() == null || trader.getTraderName().isEmpty()){
			return RtnInfo.ParameterErrRtnInfo("traderName is null");
		}
		
		String provinceId = context.getRequestInfo().getProvinceId();
		if(provinceId == null){
			return RtnInfo.ParameterErrRtnInfo("province id is null");
		}
		
		String dateDay = bizInfo.get("dateday");
		if(dateDay == null || dateDay.isEmpty()){
			return RtnInfo.ParameterErrRtnInfo("dateDay is empty");
		}
		
		HomePageService service = CentralMobileServiceHandler.getHomePageClientService();
		CalendarBuyDetail result = service.getCalendarBuyDetail(trader, Long.valueOf(provinceId), dateDay);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	
	
	/**
	 * 返回每日N款商品列表.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the calendar buy product list
	 */
	public RtnInfo getCalendarBuyProductList(String urlPath, Boolean isLogined,
	                                         Map<String, String> bizInfo, AdapterContext context){
	    try {
	        Trader trader = getTraderFromContext(context);
	        RtnInfo rtnInfo = vaildateTrader(trader);
	        if(rtnInfo==null){
	            String provinceIdStr = context.getRequestInfo().getProvinceId();
	            rtnInfo = validateProvinceId(provinceIdStr);
	            if(rtnInfo==null){
	                String dateDay  = bizInfo.get("dateday");
	                HomePageService service = CentralMobileServiceHandler.getHomePageClientService();
	                List<ProductVO> result = service.getCalendarBuyProductList(trader, Long.valueOf(provinceIdStr), dateDay);
	                rtnInfo = RtnInfo.RightWlRtnInfo(result);
	            }
	        }
	        return rtnInfo;
        } catch (Exception e) {
            logger.error(" getCalendarBuyProductList has error ", e);
            return RtnInfo.ParameterErrRtnInfo("some pram null!");
        }
	}
	
    /**
     * 
     * @param urlPath
     * @param isLogined
     * @param bizInfo
     * @param context
     * @return
     */
	public RtnInfo getMobileIndexViewForBI(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		try {
			
			Trader trader = getTraderFromContext(context);
			if(trader ==null ||StringUtil.isEmpty(trader.getTraderName())){
				return RtnInfo.ParameterErrRtnInfo("trader or tradername is null");
			}
			String provinceIdStr = context.getRequestInfo().getProvinceId();
			RtnInfo rtn = validateProvinceId(provinceIdStr);
			if(rtn !=null){
				return rtn;
			}
			Long provinceId = Long.parseLong(provinceIdStr);
			HomePageService service = CentralMobileServiceHandler.getHomePageClientService();
			ViewVO re = service.getMobileIndexViewForBI(trader, provinceId);
			
			return RtnInfo.RightWlRtnInfo(re);
		} catch (Exception e) {
			logger.error("hompageDispatchService=>getMobileIndexViewForBI", e);
			return RtnInfo.ParameterErrRtnInfo("some pram null!");
		}
	}

	
	
	/**
	 * 获取雷购数据
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getCommunityView(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(trader ==null ||StringUtil.isEmpty(trader.getTraderName())){
			return RtnInfo.ParameterErrRtnInfo("trader or tradername is null");
		}
		String provinceName = bizInfo.get("provincename");
		if(StringUtil.isBlank(provinceName)){
			return RtnInfo.ParameterErrRtnInfo("provincenameis null");
		}
		String cityName = bizInfo.get("cityname");
		if(StringUtil.isBlank(cityName)){
			return RtnInfo.ParameterErrRtnInfo("cityname null");
		}
		String areaName = bizInfo.get("areaname");
		if(StringUtil.isBlank(areaName)){
			return RtnInfo.ParameterErrRtnInfo("areaname null");
		}
		String streetName = bizInfo.get("streetname");
		if(StringUtil.isBlank(streetName)){
			return RtnInfo.ParameterErrRtnInfo("streetname null");
		}
		HomePageService service = CentralMobileServiceHandler.getHomePageClientService();
		ViewVO re = service.getCommunityView(trader, provinceName, cityName, areaName, streetName);
		return RtnInfo.RightWlRtnInfo(re);
		
	}
	
	/**
	 * 获取雷购数据
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo checkCommunity(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		String communityProvinceId = bizInfo.get("communityprovinceid");
		RtnInfo rtn = validateProvinceId(communityProvinceId);
		if(rtn != null){
			return rtn;
		}
		String provinceName = bizInfo.get("provincename");
		if(StringUtil.isBlank(provinceName)){
			return RtnInfo.ParameterErrRtnInfo("provincenameis null");
		}
		String cityName = bizInfo.get("cityname");
		if(StringUtil.isBlank(cityName)){
			return RtnInfo.ParameterErrRtnInfo("cityname null");
		}
		String areaName = bizInfo.get("areaname");
		if(StringUtil.isBlank(areaName)){
			return RtnInfo.ParameterErrRtnInfo("areaname null");
		}
		String streetName = bizInfo.get("streetname");
		if(StringUtil.isBlank(streetName)){
			return RtnInfo.ParameterErrRtnInfo("streetname null");
		}
		HomePageService service = CentralMobileServiceHandler.getHomePageClientService();
		CheckCommunityVO re = service.checkCommunity(Long.parseLong(communityProvinceId), provinceName, cityName, areaName, streetName);
		return RtnInfo.RightWlRtnInfo(re);
		
	}
	
	
	
}
