package com.yihaodian.mobile.service.client.adapter.home;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.home.spi.ExtIndexService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class ExtIndexDispaterService extends BaseDiapatchService {
	public RtnInfo loadAppUIs(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		try {
			String cityid = bizInfo.get("cityid");
			if (cityid == null)
				cityid = context.getRequestInfo().getCityId();

			RtnInfo rtnInfo = validateNumber(cityid);
			if (rtnInfo != null) {
				return rtnInfo;
			}

			ExtIndexService service = CentralMobileServiceHandler.getExtIndexService();
			ClientInfoVO clientVO = convertClientInfoVO(context.getRequestInfo().getClientInfo(),
					context.getRequestInfo().getProvinceId(), cityid);

			String start = bizInfo.get("start");
			Integer startI = Integer.valueOf(0);
			if (StringUtils.isNotBlank(start)) {
				try {
					startI = Integer.valueOf(start);
				} catch (Exception e) {
				}
			}
			String limit = bizInfo.get("limit");
			Integer limitI = Integer.valueOf(-1);
			if (StringUtils.isNotBlank(limit)) {
				try {
					limitI = Integer.valueOf(limit);
				} catch (Exception e) {
				}
			}

			Result result = service.loadAppUIs(clientVO, startI, limitI);

			return getRtnInfo(result);
		} catch (Exception e) {
			return null;
		}
	}

	public RtnInfo secondHome(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if (rtnInfo != null) {
			return rtnInfo;
		}

		long uid = 0;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}

		String adcodesStr = bizInfo.get("adcodes");
		List<String> list = null;
		if (StringUtils.isNotEmpty(adcodesStr)) {
			list = java.util.Arrays.asList(adcodesStr.split(","));
		}
		String cityid = context.getRequestInfo().getCityId();
		ExtIndexService service = CentralMobileServiceHandler.getExtIndexService();
		Result result = service.secondHome(convertClientInfoVO(context.getRequestInfo().getClientInfo(),
				context.getRequestInfo().getProvinceId(), cityid), uid, list);
		return getRtnInfo(result);
	}
	
	public RtnInfo homePmsPromotions(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if (rtnInfo != null) {
			return rtnInfo;
		}

		long uid = 0;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}

		String cityid = context.getRequestInfo().getCityId();
		ExtIndexService service = CentralMobileServiceHandler.getExtIndexService();
		Result result = service.homePmsPromotions(convertClientInfoVO(context.getRequestInfo().getClientInfo(),
				context.getRequestInfo().getProvinceId(), cityid), uid);
		return getRtnInfo(result);
	}
	
	public RtnInfo getAppUI(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if (rtnInfo != null) {
			return rtnInfo;
		}

		String id = bizInfo.get("id");
		rtnInfo = validateNumber(id);
		if (rtnInfo != null) {
			return rtnInfo;
		}
		
		ExtIndexService service = CentralMobileServiceHandler.getExtIndexService();
		Result result = service.getAppUI(Long.valueOf(id));
		return getRtnInfo(result);
	}
	
	public RtnInfo secondHomeItems(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if (rtnInfo != null) {
			return rtnInfo;
		}

		String cityid = context.getRequestInfo().getCityId();
		ExtIndexService service = CentralMobileServiceHandler.getExtIndexService();
		Result result = service.secondHomeItems(convertClientInfoVO(context.getRequestInfo().getClientInfo(),
				context.getRequestInfo().getProvinceId(), cityid));
		return getRtnInfo(result);
	}

	public RtnInfo storeUserSkinConfig(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		if (isLogined == null || isLogined == Boolean.FALSE) {
			return RtnInfo.ParameterErrRtnInfo("userid is null");
		}
		Long userId = Long.parseLong(context.getCurrentUserId());
		String skinid = bizInfo.get("skinid");
		if (skinid == null || skinid.trim().isEmpty()) {
			return RtnInfo.ParameterErrRtnInfo("skinid is null");
		}
		if (!Pattern.matches(RegexEnum.PURE_DIGITAL.getRegex(), skinid)) {
			return RtnInfo.ParameterErrRtnInfo("skinid is not number");
		}
		Long skinId = Long.parseLong(bizInfo.get("skinid"));
		String floors = bizInfo.get("floors");
		String colmns = bizInfo.get("colmns");
		ExtIndexService service = CentralMobileServiceHandler.getExtIndexService();
		Result result = service.storeUserSkinConfig(userId, skinId, floors, colmns);
		return getRtnInfo(result);
	}

	public RtnInfo fetchUserSkinConfig(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		if (isLogined == null || isLogined == Boolean.FALSE) {
			return RtnInfo.ParameterErrRtnInfo("userid is null");
		}
		Long userId = Long.parseLong(context.getCurrentUserId());
		ExtIndexService service = CentralMobileServiceHandler.getExtIndexService();
		Result result = service.fetchUserSkinConfig(userId);
		return getRtnInfo(result);
	}
	
	public RtnInfo loadPmsFloors(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if (rtnInfo != null) {
			return rtnInfo;
		}
		Long userId = null;
		if (isLogined) {
			try {
				userId = Long.parseLong(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}
		ExtIndexService service = CentralMobileServiceHandler.getExtIndexService();
		String codes = bizInfo.get("codes");
		List<String> list = null;
		if (StringUtils.isNotEmpty(codes)) {
			list = java.util.Arrays.asList(codes.split(","));
		}
		Result result = service.loadPmsFloors(convertClientInfoVO(context.getRequestInfo().getClientInfo(),
				context.getRequestInfo().getProvinceId(), context.getRequestInfo().getCityId()),userId,list);
		return getRtnInfo(result);
	}
}
