package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.mobile.service.client.adapter.enums.ServiceEnum;
import com.yihaodian.mobile.service.client.adapter.service.DispatchAdapterServiceBasic;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnCodes;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 通过urlPath找到要调用的远程service方法
 * 调用前要将adapter的参数转换为远程service需要的参数
 * 调用后要将远程service返回的数据封装成adapter需要的RtnInfo对象
 * @author yeliang
 *
 */
public class DispatchAdapterService implements DispatchAdapterServiceBasic{
	private final static Logger logger = LoggerFactory
			.getLogger(DispatchAdapterService.class);
	
	private static Map<String, Object> SERVICE_MAP = new HashMap<String, Object>();
	
	public static final String ADAPTER_EXCEPTION = "201000000010";//我们固定异常的返回码，和venus区别

	@Override
	public RtnInfo execute(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		/**
		 * urlPath规定为/mobileservice/方法名
		 * 比如/mobileservice/isWeiDianHasDevice
		 * 通过方法名isWeiDianHasDevice找到相应的远程service类AppPushClientService
		 */
		String serviceMethodName = null;
		Class serviceClass = null;
		try{
			serviceMethodName = urlPath.split("/")[2];
			serviceClass = ServiceEnum.valueOf(serviceMethodName).getServiceClass();
		} catch (Exception e) {
			logger.error("DispatchAdapterService has error: "+serviceMethodName, e);
			return new RtnInfo(RtnCodes.INVALID_URL, "urlPath:"+urlPath+"找不到对应业务方法", e.getMessage());
		} 
		
		RtnInfo rtInfo = null;
		try {
			Object service = SERVICE_MAP.get(serviceClass.getName());
			Method method = serviceClass.getMethod(serviceMethodName, new Class[] {String.class, Boolean.class, Map.class, AdapterContext.class});  
			rtInfo = (RtnInfo)method.invoke(service, new Object[] {urlPath, isLogined, bizInfo, context});
		} catch (Exception e) {
			if(e instanceof InvocationTargetException){  
				logger.error("DispatchAdapterService has error: "+serviceMethodName, e);
				return new RtnInfo(ADAPTER_EXCEPTION, "系统异常", ((InvocationTargetException)e).getTargetException().getCause().getMessage());
            }else{  
            	logger.error("DispatchAdapterService has error: "+serviceMethodName, e);
            	return new RtnInfo(ADAPTER_EXCEPTION, "系统异常", e.getMessage());
            } 
		} 
		
		return rtInfo;
	}
	
	public void serviceInit(){
		for(ServiceEnum se : ServiceEnum.values()){
			try {
				Class serviceClass = se.getServiceClass();
				String serviceClassName = serviceClass.getName();
				Object service = SERVICE_MAP.get(serviceClassName);
			    if(service==null){
			    	service = serviceClass.newInstance();
			    	SERVICE_MAP.put(serviceClassName, service);
			    }
			} catch (InstantiationException e) {
				logger.error("mobile service init fail: ", e);
			} catch (IllegalAccessException e) {
				logger.error("mobile service init fail: ", e);
			}
		}
	}
	
}
