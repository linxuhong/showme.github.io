package com.yihaodian.mobile.hedwig.client.WeChat.service.impl;

import java.util.List;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.domain.business.dal.backend.WechatCoupon;
import com.yihaodian.mobile.service.domain.business.dal.backend.WechatCouponExample;
import com.yihaodian.mobile.service.facade.business.wechat.WechatCouponService;

public class WechatCouponClientServiceImpl implements WechatCouponService{
	
	private WechatCouponService weChatCouponHessianCall;

	public void setWeChatCouponHessianCall(
			WechatCouponService weChatCouponHessianCall) {
		this.weChatCouponHessianCall = weChatCouponHessianCall;
	}

	@Override
	public List<WechatCoupon> getCodesByCouponIds(List<Long> couponIds,
			Integer status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByCode(WechatCoupon wechatCoupon) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public WechatCoupon getWechatCouponByCode(String code) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<WechatCoupon> getByExample(WechatCouponExample example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result receiveCoupon(Long userId, String code) {
		return weChatCouponHessianCall.receiveCoupon(userId, code);
	}

	@Override
	public Result shareCoupon(Long srcUserId, Long destUserId, String code) {
		return weChatCouponHessianCall.shareCoupon(srcUserId, destUserId, code);
	}

	@Override
	public Result deleteCoupon(Long userId, String code) {
		return weChatCouponHessianCall.deleteCoupon(userId, code);
	}

	@Override
	public Result logErrorMsg(Long userId, String code, String errorMsg,
			Integer status) {
		return weChatCouponHessianCall.logErrorMsg(userId, code, errorMsg, status);
	}

	@Override
	public Result checkWechatByOrderId(Long orderId) {
		return weChatCouponHessianCall.checkWechatByOrderId(orderId);
	}

	@Override
	public Result checkWechatByCouponNum(List<String> couponNums) {
		return weChatCouponHessianCall.checkWechatByCouponNum(couponNums);
	}

}
