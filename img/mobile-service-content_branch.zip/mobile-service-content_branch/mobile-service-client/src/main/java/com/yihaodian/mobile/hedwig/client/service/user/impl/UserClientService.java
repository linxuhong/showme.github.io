package com.yihaodian.mobile.hedwig.client.service.user.impl;

import com.yihaodian.mobile.service.user.spi.UserFacadeService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.user.PushMappingResult;

public class UserClientService implements UserFacadeService{

	private UserFacadeService userHessianCall;
	
	@Override
	public Integer insertAppErrorLog(Trader trader, String log,
			String phoneNumber, String token) {
		return userHessianCall.insertAppErrorLog(trader, log, phoneNumber, token);
	}

	@Override
	public PushMappingResult enableDeviceForPushMsg(Trader trader,
			String deviceToken, Boolean isOpen, Integer startHour,
			Integer endHour) {
		return userHessianCall.enableDeviceForPushMsg(trader, deviceToken, isOpen, startHour, endHour);
	}

	public UserFacadeService getUserHessianCall() {
		return userHessianCall;
	}

	public void setUserHessianCall(UserFacadeService userHessianCall) {
		this.userHessianCall = userHessianCall;
	}

    @Override
    public Integer insertAppErrorLog(Trader trader, String log, String phoneNumber, Long userId) {
        return userHessianCall.insertAppErrorLog(trader, log, phoneNumber, userId);
    }

}
