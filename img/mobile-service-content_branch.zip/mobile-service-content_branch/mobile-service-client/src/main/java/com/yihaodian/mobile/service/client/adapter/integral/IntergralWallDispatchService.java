/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.integral;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.integral.IintergralWallService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class IntergralWallDispatchService.
 * @author zuodeng
 */
public class IntergralWallDispatchService extends BaseDiapatchService {

	/**
	 * Register intergral wall info.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo registerIntergralWallInfo(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String mac = bizInfo.get("mac");

		String appId = bizInfo.get("appid");
		if (StringUtil.isEmpty(appId)) {
			return RtnInfo.ParameterErrRtnInfo("appId is null");
		}
		String idFa = bizInfo.get("idfa");

		String oem = bizInfo.get("oem");
		
		IintergralWallService service = CentralMobileServiceHandler.getIntergralWallService();
		Result result = service.registerIntergralWallInfo(mac, appId, idFa, oem);
		return getRtnInfo(result);
	}

	/**
	 * Activating intergral wall info.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo activatingIntergralWallInfo(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		String mac = bizInfo.get("mac");

		String appId = bizInfo.get("appid");
		if (StringUtil.isEmpty(appId)) {
			return RtnInfo.ParameterErrRtnInfo("appId is null");
		}
		String idFa = bizInfo.get("idfa");
		
		if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        }
        Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        String userAgent = context.getRequestInfo().getUserAgent();
        
		String oem = bizInfo.get("oem");
		IintergralWallService service = CentralMobileServiceHandler.getIntergralWallService();
		Result result = service.activatingIntergralWallInfo(convertClientInfoVO(context.getRequestInfo().getClientInfo()), mac, appId, idFa, oem,
				provinceId, userAgent);
		return getRtnInfo(result);
	}

}
