package com.yihaodian.mobile.service.client.adapter.alipay;

//import java.io.ByteArrayInputStream;
//import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

//import org.dom4j.Document;
//import org.dom4j.DocumentException;
//import org.dom4j.Element;
//import org.dom4j.io.SAXReader;

//import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.AlipayService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 智能支付数据服务接口 Dispatch服务类
 * @author luoxiang
 *
 */
public class AlipayDataServiceDispatchService extends BaseDiapatchService  {

	 public RtnInfo requestAliPayDataService(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		if (!isLogined) {
			return RtnInfo.RightWlRtnInfo("false");
	    }
		 Trader trader = getTraderFromContext(context);
		 RtnInfo rtn = vaildateTrader(trader);
		 if(rtn!=null){
			 return rtn;
		 }
		 String phoneNo = bizInfo.get("phoneno");
		 rtn = validateNumber(phoneNo);
		 if(rtn!=null){
			 return rtn;
		 }
		 AlipayService alipayService = CentralMobileServiceHandler.getAlipayService();
		String flag =  alipayService.getAlipayDataServiceResult(phoneNo);
		Map<String,String> resultMap = new HashMap<String, String>();
		resultMap.put("flag", flag);
		 return RtnInfo.RightWlRtnInfo(resultMap); 
	 }
	
//	public static void main(String[] args) {
//		String xml = "<?xml version=\"1.0\" encoding=\"GBK\"?>" +
//				"<alipay>" +
//				"    <is_success>T</is_success>" +
//				"    <request>" +
//				"        <param name=\"sign\">082d4ae1792658a511a1b947b1ebaf46</param>" +
//				"        <param name=\"_input_charset\">UTF-8</param>" +
//				"        <param name=\"phone_no\">23456787651</param>" +
//				"        <param name=\"sign_type\">MD5</param>" +
//				"        <param name=\"service\">alipay.databiz.core.user.evaluation.get</param>" +
//				"        <param name=\"partner\">2088101114188654</param>" +
//				"    </request>" +
//				"    <response>" +
//				"        <databizcore>" +
//				"            <alipay_user_flag>1</alipay_user_flag>" +
//				"            <mob_client_user_flag>1</mob_client_user_flag>" +
//				"            <mob_pay_ability_level>D</mob_pay_ability_level>" +
//				"            <order_id>b3a12088123456789876#1414406218692eErAz2</order_id>" +
//				"            <trd_sy_user_flag>1</trd_sy_user_flag>" +
//				"            <user_consume_level>低</user_consume_level>" +
//				"            <user_pay_level>低</user_pay_level>" +
//				"        </databizcore>" +
//				"    </response>" +
//				"    <sign>7776d99d317869607725e82a1d0e4569</sign>" +
//				"    <sign_type>MD5</sign_type>" +
//				"</alipay>";
//		
//		SAXReader saxReader = new SAXReader(); 
//		String is_success = "";
//		String sign = "";
//		String mob_pay_ability_level = "";
//		String user_pay_level = "";
//		Document document = null;
//		try {
//			document = saxReader.read(new ByteArrayInputStream(xml.getBytes("GBK")));
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//		} catch (DocumentException e) {
//			e.printStackTrace();
//		}
//		if(document != null){
//			is_success = document.selectSingleNode("/alipay/is_success").getText();
//			mob_pay_ability_level = document.selectSingleNode("/alipay/response/databizcore/mob_pay_ability_level").getText();
//			user_pay_level = document.selectSingleNode("/alipay/response/databizcore/user_pay_level").getText();
//			sign = document.selectSingleNode("/alipay/sign").getText();
//			
//			System.out.println("is_success: "+is_success );
//			System.out.println("user_pay_level: "+user_pay_level);
//			System.out.println("mob_pay_ability_level:" +mob_pay_ability_level);
//			System.out.println("sign:" +sign);
//			System.out.println("is_success: ");
//		}
//	}
}
