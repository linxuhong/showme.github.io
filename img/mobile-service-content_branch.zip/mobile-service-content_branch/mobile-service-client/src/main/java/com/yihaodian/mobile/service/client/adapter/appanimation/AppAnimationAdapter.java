package com.yihaodian.mobile.service.client.adapter.appanimation;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.core.business.service.AppAnimationService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class AppAnimationAdapter extends BaseDiapatchService {
	public RtnInfo getAppAnimation(String urlPath,Boolean isLogined, Map<String, String> bizInfo,AdapterContext context) {
		AppAnimationService service = CentralMobileServiceHandler.getAppAnimationClientService();
		String provinceId = context.getRequestInfo().getProvinceId();
		RtnInfo rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}

		Result result = service.getAppAnimation(provinceId);

		return getRtnInfo(result);
	}
}
