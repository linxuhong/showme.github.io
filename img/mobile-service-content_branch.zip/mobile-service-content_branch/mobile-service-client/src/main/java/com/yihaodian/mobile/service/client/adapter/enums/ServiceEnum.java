package com.yihaodian.mobile.service.client.adapter.enums;

import com.yihaodian.mobile.service.client.adapter.abTest.AbTestDispater;
import com.yihaodian.mobile.service.client.adapter.advertisement.AdDispaterService;
import com.yihaodian.mobile.service.client.adapter.advertisement.CategoryAdDispaterService;
import com.yihaodian.mobile.service.client.adapter.advertisement.CurtainAdDispaterService;
import com.yihaodian.mobile.service.client.adapter.advertisement.EnglishAdDispaterService;
import com.yihaodian.mobile.service.client.adapter.advertisement.HomeDispatchService;
import com.yihaodian.mobile.service.client.adapter.advertisement.HomePageDispatchService;
import com.yihaodian.mobile.service.client.adapter.advertisement.MobileProfileDispaterService;
import com.yihaodian.mobile.service.client.adapter.advertisement.PrecisionHomePageAd;
import com.yihaodian.mobile.service.client.adapter.advertisement.ProductDispatchService;
import com.yihaodian.mobile.service.client.adapter.advertisement.SystemDispatchService;
import com.yihaodian.mobile.service.client.adapter.alipay.AlipayDataServiceDispatchService;
import com.yihaodian.mobile.service.client.adapter.alipay.AlipaySignDispatchService;
import com.yihaodian.mobile.service.client.adapter.apollo.ApolloDispatchService;
import com.yihaodian.mobile.service.client.adapter.app.AppActivationDispatchService;
import com.yihaodian.mobile.service.client.adapter.appanimation.AppAnimationAdapter;
import com.yihaodian.mobile.service.client.adapter.appconfig.AppConfigDispatchService;
import com.yihaodian.mobile.service.client.adapter.channal.GlobalImportProductDispatchService;
import com.yihaodian.mobile.service.client.adapter.channal.QualityKitchenDispatchService;
import com.yihaodian.mobile.service.client.adapter.channel.BigNameDispatchService;
import com.yihaodian.mobile.service.client.adapter.channel.NewFavoriteDispatchService;
import com.yihaodian.mobile.service.client.adapter.checklist.ChecklistDispatchService;
import com.yihaodian.mobile.service.client.adapter.cms.CmsNativeDispatchService;
import com.yihaodian.mobile.service.client.adapter.command.CommandDispatchService;
import com.yihaodian.mobile.service.client.adapter.cut.CutDispatchService;
import com.yihaodian.mobile.service.client.adapter.dailybuy.DailyBuyDispatchService;
import com.yihaodian.mobile.service.client.adapter.deeplink.DeeplinkDispatchService;
import com.yihaodian.mobile.service.client.adapter.downloadpage.DownloadPage;
import com.yihaodian.mobile.service.client.adapter.flashPurchase.FlashPurchaseDispatchService;
import com.yihaodian.mobile.service.client.adapter.game.PromotionGameDispatchService;
import com.yihaodian.mobile.service.client.adapter.home.AdIndexDispaterService;
import com.yihaodian.mobile.service.client.adapter.home.AppIndexDispatchService;
import com.yihaodian.mobile.service.client.adapter.home.CityIndexDispaterService;
import com.yihaodian.mobile.service.client.adapter.home.ExtConfigDispaterService;
import com.yihaodian.mobile.service.client.adapter.home.ExtIndexDispaterService;
import com.yihaodian.mobile.service.client.adapter.integral.IntergralWallDispatchService;
import com.yihaodian.mobile.service.client.adapter.jpegimg.JpegImageDispatchService;
import com.yihaodian.mobile.service.client.adapter.lottery.LotteryTickets;
import com.yihaodian.mobile.service.client.adapter.maps.MapsFrontDispatchService;
import com.yihaodian.mobile.service.client.adapter.message.MessageCenterDispatchService;
import com.yihaodian.mobile.service.client.adapter.mobilecart.AppCartDispatchService;
import com.yihaodian.mobile.service.client.adapter.mobilecoupon.MobileCouponDispatchService;
import com.yihaodian.mobile.service.client.adapter.navigationcategory.NavigationCategoryDispatchService;
import com.yihaodian.mobile.service.client.adapter.newuser.NewUserCouponDispatchService;
import com.yihaodian.mobile.service.client.adapter.pay.PayPreDispatchService;
import com.yihaodian.mobile.service.client.adapter.product.ProductSign;
import com.yihaodian.mobile.service.client.adapter.push.PushDispatchService;
import com.yihaodian.mobile.service.client.adapter.push.PushMessageStatisticsDispatchService;
import com.yihaodian.mobile.service.client.adapter.questionnaire.QuestionnaireDispatchService;
import com.yihaodian.mobile.service.client.adapter.red.OrderRedDispatchAdapter;
import com.yihaodian.mobile.service.client.adapter.reward.RewardService;
import com.yihaodian.mobile.service.client.adapter.rock.HomePageGameDispatchAdapter;
import com.yihaodian.mobile.service.client.adapter.seckill.SeckillDispatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.AlipayDispatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.CouponDispatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.FeedbackDispatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.MiracleDispatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.MonkeyDispatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.PassportDispatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.PromotionDispatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.ScratchDispatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.Wl2AdapterService;
import com.yihaodian.mobile.service.client.adapter.sharecoupon.ShareCouponService;
import com.yihaodian.mobile.service.client.adapter.survey.SurveyQuestionaireDispatchService;
import com.yihaodian.mobile.service.client.adapter.tag.AppTagDispatchService;
import com.yihaodian.mobile.service.client.adapter.thunder.ThunderBuyDispatchAdapter;
import com.yihaodian.mobile.service.client.adapter.update.UpdateAwardDispatch;
import com.yihaodian.mobile.service.client.adapter.user.UserDispatchService;
import com.yihaodian.mobile.service.client.adapter.voucher.VoucherDispatchService;
import com.yihaodian.mobile.service.client.venus.VenusHttpsCheckAdapter;


/**
 * 转发服务枚举类
 * 可以定义多个转发服务
 * @author yeliang
 *
 */
public enum ServiceEnum {

	getApolloPromotionInfoByClientLocation(ApolloDispatchService.class),
	getCommunityView(HomePageDispatchService.class),
	getCommunityProductList(HomePageDispatchService.class),
	getMobileViewById(HomePageDispatchService.class),
	getBrandShopPromotion(HomePageDispatchService.class),
	checkCommunity(HomePageDispatchService.class),
	getCalendarBuyProductList(HomePageDispatchService.class),
	getMobileIndexViewByType(HomePageDispatchService.class),
	getCmsColumnDetail(HomePageDispatchService.class),
	getCalendarBuyDetail(HomePageDispatchService.class),
	getMySecretKey(Wl2AdapterService.class),
	getAppLaunchData(Wl2AdapterService.class),
	getRebatesNotification(ScratchDispatchService.class),
	getScratchInfoListForOrderList(ScratchDispatchService.class),
	cancelScratchReuslt(ScratchDispatchService.class),
	getScratchConfig(ScratchDispatchService.class),
	switchToLocalUrl(PrecisionHomePageAd.class),
	getPrecisionHomePageADV3(PrecisionHomePageAd.class),
	getPrecisionHomePageProducts(PrecisionHomePageAd.class),
	getHomePageProduct(PrecisionHomePageAd.class),
	getHomePageColumnProducts(PrecisionHomePageAd.class),
	getHomePageGuessUlikeProducts(PrecisionHomePageAd.class),
	getPromoteSpecialTopic(PrecisionHomePageAd.class),
	doushouProduct(PrecisionHomePageAd.class),
	getsharemyOrderRule(AlipayDispatchService.class),
	alipayLogin(AlipayDispatchService.class),
	getshareMyOrderList(AlipayDispatchService.class),
	getAlipayGoodReceiver(AlipayDispatchService.class),
	sharetoMyOrder(AlipayDispatchService.class),
	getViewProfile(MobileProfileDispaterService.class),
	getIndexProfile(MobileProfileDispaterService.class),
	getExportGoodsView(MobileProfileDispaterService.class),	
	getExportGoodsCategory(MobileProfileDispaterService.class),
	getDailyOneProfile(MobileProfileDispaterService.class),
	getCalendarDetailProfile(MobileProfileDispaterService.class),
	getHomeHotPointList(ProductDispatchService.class),
	getUserInterestedProducts(ProductDispatchService.class),
	getAdvertisementList(ProductDispatchService.class),	
	getPackageProducts(ProductDispatchService.class),
	getUserInterestedProductsV2(ProductDispatchService.class),	
	getMoreInterestedProducts(ProductDispatchService.class),
	getHotRandomProducts(ProductDispatchService.class),
	getYhbByCategoryId(ProductDispatchService.class),
	getPromotionProductPage(ProductDispatchService.class),
	getHomeHotProductTop5List(ProductDispatchService.class),
	getHotProductPageByCategoryId(ProductDispatchService.class),
	getHotProductByActivityID(ProductDispatchService.class),
	insertAppErrorLog(UserDispatchService.class),
	getDownloadPageInfo(DownloadPage.class),
	getScratchAvailable(ScratchDispatchService.class),
	getScratchDetailByOrderId(ScratchDispatchService.class),
	getLotteryTicketUrlFor500(LotteryTickets.class),
	getInterestedProductsByUser(ProductSign.class),
	rewardPrize(RewardService.class),
	getReceiveCouponCount(ShareCouponService.class),
	getShareCouponDetail(ShareCouponService.class),
	getShareCouponPage(ShareCouponService.class),
	getShareCouponPageForWechat(ShareCouponService.class),
	shareCoupon(ShareCouponService.class),
	getShareCouponUrl(ShareCouponService.class),
	getQualityAppList(HomeDispatchService.class),
	getHomeSelection(HomeDispatchService.class),
	getHomeHotElement(HomeDispatchService.class),
	addCouponByActivityId(PromotionDispatchService.class),
	getCmsColumnList(PromotionDispatchService.class),
	getRockProductList(PromotionDispatchService.class),
	getCmsColumnListWithCMSType(PromotionDispatchService.class),
	getCmsPageList(PromotionDispatchService.class),
	addStorageBox(PromotionDispatchService.class),
	createRockGame(PromotionDispatchService.class),
	getRockGameProductVO(PromotionDispatchService.class),
	sendNewguestCoupon(CouponDispatchService.class),
	getMerchantH5Url(CouponDispatchService.class),
	flashSaleUrl(CouponDispatchService.class),
	getCmsColumnByColumnById(PromotionDispatchService.class),
	getRockResultV2(PromotionDispatchService.class),
	getRockResultV2WithToken(PromotionDispatchService.class),
	getPayPreInfo(PayPreDispatchService.class),
	autoSwitchGateWay(PayPreDispatchService.class),
	getPayGatePromotionInfo(PayPreDispatchService.class),
	getPayGatePromotionTip(PayPreDispatchService.class),
	checkNewCustomer(PayPreDispatchService.class),
	getNoReadCountWithUserId(MessageCenterDispatchService.class),
	getFMessTypeSubStatus(MessageCenterDispatchService.class),
	deleteSingleMesssage(MessageCenterDispatchService.class),
	updateMessageISReadWithMessT(MessageCenterDispatchService.class),
	getMessagesWithUserId(MessageCenterDispatchService.class),
	getPromotionByTopicID(PromotionDispatchService.class),
	getRockResultV3NotLogined(PromotionDispatchService.class),
	getRockResultV3WithToken(PromotionDispatchService.class),
	getMyStorageBoxList(PromotionDispatchService.class),
	getPresentsByToken(PromotionDispatchService.class),
	rockRock(PromotionDispatchService.class),
	checkResult(PromotionDispatchService.class),
	getAwardsResults(PromotionDispatchService.class),
	updateStroageBoxProductType(PromotionDispatchService.class),
	getFavoriteBrandLists(FlashPurchaseDispatchService.class),
	getBrandCollectState(FlashPurchaseDispatchService.class),
	getScratchReuslt(ScratchDispatchService.class),
	getUserScratchResultDetailList(ScratchDispatchService.class),
	getClientApplicationDownloadUrl(SystemDispatchService.class),
	checkCouppnVerfyCode(MobileCouponDispatchService.class),
	getCouponActivityVOByPromotionId(MobileCouponDispatchService.class),
	receiveCouponByActivityId(MobileCouponDispatchService.class),
	getCouponActivityDetailDescription(MobileCouponDispatchService.class),
	getHomeModuleList(HomeDispatchService.class),
	getHotPointNewVOById(PromotionDispatchService.class),
	getAdvertisingPromotionVOByType(PromotionDispatchService.class),
	checkIfSecKill(SeckillDispatchService.class),
	seckillProduct(SeckillDispatchService.class),
	addFeedback(FeedbackDispatchService.class),
	getFeedBackTypeInfoList(FeedbackDispatchService.class),
	getMessagesWithMSrc(MessageCenterDispatchService.class),
	updateMessageISRead(MessageCenterDispatchService.class),
	getNoReadMessageF(MessageCenterDispatchService.class),
	updateSubStatusWithFiType(MessageCenterDispatchService.class),
	updateUnSubStatusWithFiType(MessageCenterDispatchService.class),
	deleteMesssaageWithMType(MessageCenterDispatchService.class),
	deleteMultiMesssage(MessageCenterDispatchService.class),
	getMessageCatelogByParent(MessageCenterDispatchService.class),
	isUserSubscribeBatch(MessageCenterDispatchService.class),
	subscribeMessage(MessageCenterDispatchService.class),
	unsubscribeMessage(MessageCenterDispatchService.class),
	registerIntergralWallInfo(IntergralWallDispatchService.class),
	activatingIntergralWallInfo(IntergralWallDispatchService.class),
	getQuestionnaireSwitch(QuestionnaireDispatchService.class),
	skipQuestionnaire(QuestionnaireDispatchService.class),
	enableDeviceForPushMsg(UserDispatchService.class),
	getUserInterestedProductsCategorys(ProductDispatchService.class),
	getHotProductCountByCategoryId(ProductDispatchService.class),
	getShareContent(MobileProfileDispaterService.class),
	getExportGoodsBrand(MobileProfileDispaterService.class),
	monkeyGetExtratCouponResult(MonkeyDispatchService.class),
	monkeyCheckMobileNumber(MonkeyDispatchService.class),
	monkeyVerifyCouponCheckCode(MonkeyDispatchService.class),
	monkeyInsertAddress(MonkeyDispatchService.class),
	getPushInformation(PushDispatchService.class),
	storeUserInfo(PushDispatchService.class),
	messageOpen(PushDispatchService.class),
	getHomeHotPointListNew(PromotionDispatchService.class),
	processGameFlow(PromotionDispatchService.class),	
	getCmsAdvertisingPromotion(PromotionDispatchService.class),	
	addFeedbackV2(FeedbackDispatchService.class),
	getRockGameByToken(PromotionDispatchService.class),
	checkRockResult(PromotionDispatchService.class),
	addFavoriteForBrand(FlashPurchaseDispatchService.class),
	getAppFunctionSwitch(SystemDispatchService.class),
	getActivityRule(MobileProfileDispaterService.class),
	getCalendarProfile(MobileProfileDispaterService.class),
	checkSeckillCanBuy(SeckillDispatchService.class),
	preSeckillProduct(SeckillDispatchService.class),
	miracleAutoRegister(MiracleDispatchService.class),
	registerLaunchInfo(SystemDispatchService.class),
	getUserById(PassportDispatchService.class),
	updateUserById(PassportDispatchService.class),
	isCanInviteeUser(PromotionDispatchService.class),
	getAliPaySignature(AlipaySignDispatchService.class),
	requestAliPayDataService(AlipayDataServiceDispatchService.class),
	logReporting(PushDispatchService.class),
	messageStatistics(PushMessageStatisticsDispatchService.class),
	createMessageForUpdateAward(UpdateAwardDispatch.class),
	getThunderHomeBannerAndDes(ThunderBuyDispatchAdapter.class),
	getThunderProvinceInfo(ThunderBuyDispatchAdapter.class),
	arrivalReminding(ThunderBuyDispatchAdapter.class),
	getProductsByCategoryIds(ThunderBuyDispatchAdapter.class),
	getProductsByCategoryId(ThunderBuyDispatchAdapter.class),
	getProductsByProvinceId(ThunderBuyDispatchAdapter.class),
	getThunderCategory(ThunderBuyDispatchAdapter.class),
	getThunderBillChannel(ThunderBuyDispatchAdapter.class),
	getThunderBillNotice(ThunderBuyDispatchAdapter.class),
	getThunderBillNoticeById(ThunderBuyDispatchAdapter.class),
	getThunderUserDetailsById(ThunderBuyDispatchAdapter.class),
	getThunderBillInfoById(ThunderBuyDispatchAdapter.class),
	verifyThunderRedPacketQualification(ThunderBuyDispatchAdapter.class),
	getThunderRedPacket(ThunderBuyDispatchAdapter.class),
	checkStockNumByPminfoAndProvince(ThunderBuyDispatchAdapter.class),
	getNativeThunderMerchantInfo(ThunderBuyDispatchAdapter.class),
	getAddressListByKeyword(ThunderBuyDispatchAdapter.class),
	getNewUserCouponInfo(NewUserCouponDispatchService.class),
	getUserCoupon(NewUserCouponDispatchService.class),
	getAppTab(AppConfigDispatchService.class),
	getDefaultHit(AppConfigDispatchService.class),
	isPromotionAvailable(OrderRedDispatchAdapter.class),
	getPromotionDetail(OrderRedDispatchAdapter.class),
	getPromotionDescription(OrderRedDispatchAdapter.class),
	shareOrderRed(OrderRedDispatchAdapter.class),
	getTopicById(DailyBuyDispatchService.class),
	praiseTopic(DailyBuyDispatchService.class),
	getCategory(DailyBuyDispatchService.class),
	getTopicByCategoryId(DailyBuyDispatchService.class),
	getTopicByCategoryIds(DailyBuyDispatchService.class),
	getTopicByAllCategory(DailyBuyDispatchService.class),
	getTopicWithVideo(DailyBuyDispatchService.class),
	submitComment(DailyBuyDispatchService.class),
	deleteComment(DailyBuyDispatchService.class),
	getCommentPage(DailyBuyDispatchService.class),
	getCommentInfo(DailyBuyDispatchService.class),
	praiseComment(DailyBuyDispatchService.class),
	visitComment(DailyBuyDispatchService.class),
	getEndUserInfo(DailyBuyDispatchService.class),
	getPraisePage(DailyBuyDispatchService.class),
	getReplyPage(DailyBuyDispatchService.class),
	deleteReply(DailyBuyDispatchService.class),
	replyTopicOrComment(DailyBuyDispatchService.class),
	getTrialReports(DailyBuyDispatchService.class),
	getTrialReportInfo(DailyBuyDispatchService.class),
	getMoreTopics(DailyBuyDispatchService.class),
	getCommentCats(DailyBuyDispatchService.class),
	getCurtainAdvertisement(CurtainAdDispaterService.class),
	openCurtainAdvertisement(CurtainAdDispaterService.class),
	getHotRecommendCateList(CategoryAdDispaterService.class),
	validateThunderOrder(ThunderBuyDispatchAdapter.class),
	loadCachedPage(MapsFrontDispatchService.class),
	userGetCouponFromActivity(MapsFrontDispatchService.class),
	loadCachedProducts(MapsFrontDispatchService.class),
	loadCachedPageEntitys(MapsFrontDispatchService.class),
	searchPage(MapsFrontDispatchService.class),
	addToCart(MapsFrontDispatchService.class),
	loadGrouponBrandVO(MapsFrontDispatchService.class),
	userGetCouponFromShop(MapsFrontDispatchService.class),
	getHomeRecommendProducts(PrecisionHomePageAd.class),
	getDefaultHitForPad(AppConfigDispatchService.class),
	getSimilarProducts(CutDispatchService.class),
	getColumnAndActivity(CutDispatchService.class),
	getAllExclusivePriceColumns(CutDispatchService.class),
	getExclusiveProductsByColumnIds(CutDispatchService.class),
	getExclusiveAd(CutDispatchService.class),
	getCutPriceTab(CutDispatchService.class),
	getProductByActivityId(CutDispatchService.class),
	getCurrentProductList(CutDispatchService.class),
	getGroupProductListByLp(CutDispatchService.class),
	getYesterdayProductList(CutDispatchService.class),
	getProductReMindNum(CutDispatchService.class),
	updateProductReMindNum(CutDispatchService.class),
	getBrandActivityDetailById(CutDispatchService.class),
	getTodayDuoshouPic(CutDispatchService.class),
	findHeads(JpegImageDispatchService.class),
	findBodys16(JpegImageDispatchService.class),
	findBodysBase64(JpegImageDispatchService.class),
	getAbTest(AbTestDispater.class),
	getAnnouncements(PrecisionHomePageAd.class),
	getChoicenessCity(PrecisionHomePageAd.class),
	getHotWords(AdDispaterService.class),
	getHotWordsForCity(AdDispaterService.class),
	getPerCenterAd(AdDispaterService.class),
	getDeeplinkInfo(DeeplinkDispatchService.class),
	verifyThirdPart(DeeplinkDispatchService.class),
	getNavigationCategory(NavigationCategoryDispatchService.class),
	getActivityTime(PrecisionHomePageAd.class),
	getActivityTimeV2(PrecisionHomePageAd.class),
	getAppRefInfo(AppConfigDispatchService.class),
	getMobReCateList(CategoryAdDispaterService.class),
	getMobSubCategorysById(CategoryAdDispaterService.class),
	getAppTagConfigRule(AppTagDispatchService.class),
	grantCouponWithInfo(MobileCouponDispatchService.class),
	loadCmsPage(CmsNativeDispatchService.class),
	loadCmsColContent(CmsNativeDispatchService.class),
	getCmsVoucher(CmsNativeDispatchService.class),
	loadSubGroupProducts(CmsNativeDispatchService.class),
	checkNative(CmsNativeDispatchService.class),
	getNativeThunderProvinceInfo(ThunderBuyDispatchAdapter.class),
	getNativeThunderIndexInfo(ThunderBuyDispatchAdapter.class),
	getNativeThunderUserInfo(ThunderBuyDispatchAdapter.class),
	doShaking(HomePageGameDispatchAdapter.class),
	getAppAnimation(AppAnimationAdapter.class),
	getOpenQuestionairesForUser(SurveyQuestionaireDispatchService.class),
	redIsReady(HomePageGameDispatchAdapter.class),
	doShaking2(HomePageGameDispatchAdapter.class),
	doShaking3(HomePageGameDispatchAdapter.class),
	jdActivationDataReceive(AppActivationDispatchService.class),
	loadMobileAds(AppIndexDispatchService.class),
	loadPmsProducts(AppIndexDispatchService.class),
	getCheckoutProgressForPromotion(AppCartDispatchService.class),
	getCheckoutProgressForPromotionLevels(AppCartDispatchService.class),
	getVenusHttpsCheck(VenusHttpsCheckAdapter.class),
	getGamePromotionInfo(PromotionGameDispatchService.class),
	doShakingWithAwardPoolIds(PromotionGameDispatchService.class),
	acceptAward(PromotionGameDispatchService.class),
	getAchievementList(PromotionGameDispatchService.class),
	getUserAcceptAwardList(PromotionGameDispatchService.class),
	getSeckillTaskStatus(SeckillDispatchService.class),
	fetchSeckillTasks(SeckillDispatchService.class),
	sendSeckillTask(SeckillDispatchService.class),
	cancelSeckillTask(SeckillDispatchService.class),
	setSeckillTaskStatus(SeckillDispatchService.class),
	decrSeckillTaskCount(SeckillDispatchService.class),
	initSeckillRuleInfo(SeckillDispatchService.class),
	getSpellGroupInfo(CommandDispatchService.class),
	getVoucherByUser(VoucherDispatchService.class),
	getUserCommentNumber(VoucherDispatchService.class),
	loadNewFavoriteIndex(NewFavoriteDispatchService.class),
	getNewProductsForCategory(NewFavoriteDispatchService.class),
	loadBigNameIndex(BigNameDispatchService.class),
	getBigNameBrandsForCategory(BigNameDispatchService.class),
	getBigNameStoresForCategory(BigNameDispatchService.class),
	getPagedCategoryBrands(BigNameDispatchService.class),
	getPagedCategoryStores(BigNameDispatchService.class),
	
	/**
	 * 购物清单独立app接口
	 */
	getUserAllLists(ChecklistDispatchService.class),
	getUserListDetail(ChecklistDispatchService.class),
	createUserList(ChecklistDispatchService.class),
	updateUserList(ChecklistDispatchService.class),
	createListItem(ChecklistDispatchService.class),
	updateListItem(ChecklistDispatchService.class),
	reorderListItem(ChecklistDispatchService.class),
	cloneListItems(ChecklistDispatchService.class),
	copyListItems(ChecklistDispatchService.class),
	authorizeUsersListRequest(ChecklistDispatchService.class),
	authorizeUserListResponse(ChecklistDispatchService.class),
	getUserAuthorizeListPendingRequests(ChecklistDispatchService.class),
	deleteUserList(ChecklistDispatchService.class),
	deleteListItem(ChecklistDispatchService.class),
	batchSaveItemList(ChecklistDispatchService.class),
	parseExternalUrl(ChecklistDispatchService.class),
	addFeedbackForChecklist(ChecklistDispatchService.class),

	//英文app首页广告
	getEnAds(EnglishAdDispaterService.class),
	getEnSwitches(SystemDispatchService.class),
	//新版首页
	loadHomePageADs(AdIndexDispaterService.class),
	getBannerByCode(AdIndexDispaterService.class),
	getIconsByCode(AdIndexDispaterService.class),
	//第二首页
	loadAppUIs(ExtIndexDispaterService.class),
	secondHome(ExtIndexDispaterService.class),
	homePmsPromotions(ExtIndexDispaterService.class),
	getAppUI(ExtIndexDispaterService.class),
	secondHomeItems(ExtIndexDispaterService.class),
	loadPmsFloors(ExtIndexDispaterService.class),
	// 用户皮肤配置
	storeUserSkinConfig(ExtIndexDispaterService.class),
	fetchUserSkinConfig(ExtIndexDispaterService.class),
	//扩展配置
	checkAppType(ExtConfigDispaterService.class),
	
	//全球进口频道页
	getGlobalImportProduct(GlobalImportProductDispatchService.class),
	getNewProductsFromSearch(GlobalImportProductDispatchService.class),
	getCategoryByAreaCode(GlobalImportProductDispatchService.class),
	getProductsByCategory(GlobalImportProductDispatchService.class),
	getProductsByBrandId(GlobalImportProductDispatchService.class),
	getHotRecProductByCategory(GlobalImportProductDispatchService.class),
	getHotSalesSingleProducts(GlobalImportProductDispatchService.class),

	getQualityKitchenInfo(QualityKitchenDispatchService.class),
	//城市精选首页
	cityHome(CityIndexDispaterService.class),
	//城市精选首页-排行榜露出
	cityHomeRank(CityIndexDispaterService.class),
	//城市精选首页-排行榜露出-V2
	cityHomeRankV2(CityIndexDispaterService.class),
	//城市精选首页-猜你喜欢
	getCityHomePageGuessUlikeProducts(CityIndexDispaterService.class),
	//城市精选首页-猜你喜欢V2
	getCityHomePageGuessUlikeProductsV2(CityIndexDispaterService.class),
	getCityHomeChannelPage(CityIndexDispaterService.class),
	getCityGlobalImportProducts(CityIndexDispaterService.class),
	//获取场景购的总的场景
	getAllCityHomeChannel(CityIndexDispaterService.class),
	//城市精选-逛频道
	cityStrollChannel(CityIndexDispaterService.class),
	//城市精选-逛频道-南京好货
	cityStrollChannelGoods(CityIndexDispaterService.class),
	;
	
	/**
	 * 转发service类型
	 */
	private Class<?> serviceClass;
	
	/**
	 * 构造函数
	 * 
	 */
	private ServiceEnum(Class<?> serviceClass){
		this.serviceClass = serviceClass;
	}

	public Class<?> getServiceClass() {
		return serviceClass;
	}
	
	
}
