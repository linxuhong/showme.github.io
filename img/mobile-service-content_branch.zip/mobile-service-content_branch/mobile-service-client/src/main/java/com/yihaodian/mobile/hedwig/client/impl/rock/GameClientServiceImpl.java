package com.yihaodian.mobile.hedwig.client.impl.rock;

import java.sql.SQLException;
import java.util.List;

import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.push.spi.IGameService;
import com.yihaodian.mobile.service.domain.business.dal.backend.RockAward;
import com.yihaodian.mobile.service.domain.business.dal.backend.RockPromotion;

public class GameClientServiceImpl implements IGameService {
	
	private IGameService gameHessianCall;
	

	public IGameService getGameHessianCall() {
		return gameHessianCall;
	}

 

    public void setGameHessianCall(IGameService gameHessianCall) {
		this.gameHessianCall = gameHessianCall;
	}

	@Override
	public ResultModel getRockPromotionInfo(Long activityId, Long userId,
			Integer provinceId) {
 
		return gameHessianCall.getRockPromotionInfo(activityId, userId, provinceId);
	}

	@Override
	public ResultModel doShaking(Long activityId, Long userId,
			Integer isExplode, String traderName, String deviceToken,
			Integer provinceId, String ip) {

		return gameHessianCall.doShaking(activityId, userId, isExplode, traderName, deviceToken, provinceId, ip);
	}

	@Override
	public ResultModel acceptAward(Long activityId, Long userId, Long awardId,
			Integer isDiscard, Integer provinceId, String traderName,
			String deviceToken, String tokenSession, String phone,
			String address, String userName) {

		return gameHessianCall.acceptAward(activityId, userId, awardId, isDiscard, provinceId
				, traderName, deviceToken, tokenSession, phone, address, userName);
	}

	@Override
	public ResultModel getWinnersList(Long activityId) {

		return gameHessianCall.getWinnersList(activityId);
	}

	@Override
	public ResultModel yCacheRockPromotion(Long activityId) {
		 
		return gameHessianCall.yCacheRockPromotion(activityId);
	}

	@Override
	public ResultModel yCacheRockAwardList(Long activityId) {

		return gameHessianCall.yCacheRockAwardList(activityId);
	}

    @Override
    public ResultModel getAllAward(Long promotionId, String type, Integer provinceId) throws SQLException {
        return gameHessianCall.getAllAward(promotionId, type, provinceId);
    }

    @Override
    public ResultModel getUserAwardParts(Long promotionId, Long userId) {
        return gameHessianCall.getUserAwardParts(promotionId, userId);
    }

    @Override
    public ResultModel doShakingWithTag(Long activityId, Long userId, Integer isExplode, String traderName,
            String deviceToken, Integer provinceId, String ipAddr, String tag) {
        return gameHessianCall.doShakingWithTag(activityId, userId, isExplode, traderName, deviceToken, provinceId, ipAddr, tag);
    }



    @Override
    public ResultModel buildGiveAwardCode(Long userId, Long promotionId, Long sentAwardId) {
        return gameHessianCall.buildGiveAwardCode(userId, promotionId, sentAwardId);
    }



    @Override
    public ResultModel handleGiveAwardCode(Long toUserId, String key) {
        return gameHessianCall.handleGiveAwardCode(toUserId, key);
    }



    @Override
    public ResultModel getUserBigAward(Long userId, Long promotionId) {
        return gameHessianCall.getUserBigAward(userId, promotionId);
    }



    @Override
    public ResultModel getUserSplitAwardHistory(Long userId, Long promotionId) {
        return gameHessianCall.getUserSplitAwardHistory(userId, promotionId);
    }



    @Override
    public ResultModel getGiveInfo(Long touserId, String key) {
        return gameHessianCall.getGiveInfo(touserId, key);
    }



    @Override
    public ResultModel checkUserCanUseAwards(Long userId, Long promotionId, String awardids) {
        return gameHessianCall.checkUserCanUseAwards(userId, promotionId, awardids);
    }
	
    
}
