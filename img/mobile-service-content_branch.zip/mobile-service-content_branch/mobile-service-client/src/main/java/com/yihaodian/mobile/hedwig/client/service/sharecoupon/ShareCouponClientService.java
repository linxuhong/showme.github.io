package com.yihaodian.mobile.hedwig.client.service.sharecoupon;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.domain.vo.business.share.GenerateUrlVO;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponDetailInputVO;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponFindInputVO;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponInputVO;
import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;

public class ShareCouponClientService implements IShareCouponService {
	
	private IShareCouponService shareCouponHessianCall;

	@Override
	public Result getShareCouponUrl(GenerateUrlVO vo) {
		return shareCouponHessianCall.getShareCouponUrl(vo);
	}

	@Override
	public Result shareCoupon(ShareCouponInputVO vo) {
		return shareCouponHessianCall.shareCoupon(vo);
	}

	@Override
	public Result getShareCouponPage(
			ShareCouponFindInputVO shareCouponFindInputVO) {
		return shareCouponHessianCall.getShareCouponPage(shareCouponFindInputVO);
	}

	@Override
	public Result getShareCouponPageForWechat(
			ShareCouponFindInputVO shareCouponFindInputVO) {
		return shareCouponHessianCall.getShareCouponPageForWechat(shareCouponFindInputVO);
	}

	@Override
	public Result getShareCouponDetail(
			ShareCouponDetailInputVO shareCouponDetailInputVO) {
		return shareCouponHessianCall.getShareCouponDetail(shareCouponDetailInputVO);
	}

	@Override
	public Result getReceiveCouponCount(String userToken) {
		return shareCouponHessianCall.getReceiveCouponCount(userToken);
	}

	public IShareCouponService getShareCouponHessianCall() {
		return shareCouponHessianCall;
	}

	public void setShareCouponHessianCall(IShareCouponService shareCouponHessianCall) {
		this.shareCouponHessianCall = shareCouponHessianCall;
	}

	@Override
	public Result getShareCouponUrl_wl2(GenerateUrlVO vo) {
		return shareCouponHessianCall.getShareCouponUrl_wl2(vo);
	}

	@Override
	public Result shareCoupon_wl2(ShareCouponInputVO vo) {
		return shareCouponHessianCall.shareCoupon_wl2(vo);
	}

	@Override
	public Result getShareCouponPageForWl2(
			ShareCouponFindInputVO shareCouponFindInputVO,Long userId) {
		return shareCouponHessianCall.getShareCouponPageForWl2(shareCouponFindInputVO,userId);
	}

	@Override
	public Result getReceiveCouponCountWl2(Long userId) {
		return shareCouponHessianCall.getReceiveCouponCountWl2(userId);
	}

}
