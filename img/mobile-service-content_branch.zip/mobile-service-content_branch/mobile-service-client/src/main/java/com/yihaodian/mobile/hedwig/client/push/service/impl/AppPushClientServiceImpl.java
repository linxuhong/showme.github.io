package com.yihaodian.mobile.hedwig.client.push.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.hedwig.client.push.service.AppPushClientService;
import com.yihaodian.mobile.hedwig.push.spi.AppPushFacdeService;
import com.yihaodian.mobile.hedwig.push.vo.ClientAppPushInfo;
import com.yihaodian.mobile.vo.push.PushMapping;

public class AppPushClientServiceImpl implements AppPushClientService {
    private AppPushFacdeService<String> appPushHessianCall;

	public AppPushFacdeService<String> getAppPushHessianCall() {
		return appPushHessianCall;
	}


    public void setAppPushHessianCall(AppPushFacdeService<String> appPushHessianCall) {
		this.appPushHessianCall = appPushHessianCall;
	}
	@Override
	public boolean checkIfMobileUser(Long userId) {
		return appPushHessianCall.checkIfMobileUser(userId);
	}

	@Override
	public boolean insertAppPushInfo(ClientAppPushInfo clientAppPushInfo) {
		return appPushHessianCall.insertPushInfo(clientAppPushInfo);
	}

	@Override
	public List<Long> checkIfMobileUserForList(List<Long> userIdList) {
		return appPushHessianCall.checkIfMobileUserList(userIdList);
	}

	@Override
	public boolean insertAppPushInfoList(
			List<ClientAppPushInfo> clientAppPushInfoList) {
		return appPushHessianCall.insertPushInfoList(clientAppPushInfoList);
	}

	@Override
	public boolean insertPushInfoForVUser(String domainName, String content,
			List<Long> vUserIdList, String sourceCode, int msgSync, Date date) {
		return appPushHessianCall.insertPushInfoForVUser(domainName, content, vUserIdList, sourceCode, msgSync, date);
	}

	@Override
	public boolean isWeiDianHasDevice(Long vuserId) {
		return appPushHessianCall.isWeiDianHasDevice(vuserId);
	}

	@Override
	public Map<Long,Boolean> isWeiDianHasDeviceForBatch(List<Long> vUserIdList){
		return appPushHessianCall.isWeiDianHasDeviceForBatch(vUserIdList);
	}

	@Override
	public String getWeiDianDeviceToken(Long vuserId) {
		return appPushHessianCall.getWeiDianDeviceToken(vuserId);
	}
	
	@Override
	public Map<Long,String> getWeiDianDeviceTokenForBatch(List<Long> vUserIdList){
		return appPushHessianCall.getWeiDianDeviceTokenForBatch(vUserIdList);
	}

	@Override
	public List<PushMapping> getDeviceToken(Long userId) {
		return appPushHessianCall.getDeviceToken(userId);
	}

	@Override
	public Map<Long, List<String>> getDeviceToken(List<Long> userIdList) {
		return appPushHessianCall.getDeviceToken(userIdList);
	}

	@Override
	public Boolean isYHDDevice(String deviceCode) {
		return appPushHessianCall.isYHDDevice(deviceCode);
	}
    @Override
    public boolean checkIfSiteMobileUser(Long userId, int siteType) {
       return appPushHessianCall.checkIfSiteMobileUser(userId, siteType);
    }

    @Override
    public List<Long> checkIfSiteMobileUserList(List<Long> userIdList, int siteType) {
        return appPushHessianCall.checkIfSiteMobileUserList(userIdList, siteType);
    }

    @Override
    public List<PushMapping> getSiteDeviceToken(Long userId, int siteType) {
        return appPushHessianCall.getSiteDeviceToken(userId, siteType);
    }

    @Override
    public Map<Long, List<String>> getSiteDeviceToken(List<Long> userIdList, int siteType) {
        return appPushHessianCall.getSiteDeviceToken(userIdList, siteType);
    }

}
