package com.yihaodian.mobile.hedwig.client.impl.foodieBill;

import java.util.List;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.domain.business.dal.backend.FoodieOrderBill;
import com.yihaodian.mobile.service.facade.business.foodieBill.IFoodieBillService;


/**
 * @author liuhua
 *foodie_order_bill 表操作
 */
public class FoodieBillClientServiceImpl implements IFoodieBillService {
	
	private IFoodieBillService foodieBillHessianCall;

	@Override
	public Result insertOrUpdateOneFobill(FoodieOrderBill one) {
		return foodieBillHessianCall.insertOrUpdateOneFobill(one);
	}

	@Override
	public Result selectFobillsByUserIds(List<Long> userIds) {
		return foodieBillHessianCall.selectFobillsByUserIds(userIds);
	}

	@Override
	public Result selectFobillByUserId(Long userId) {
		return foodieBillHessianCall.selectFobillByUserId(userId);
	}

	@Override
	public Result updateFobillByObj(FoodieOrderBill one) {
		return foodieBillHessianCall.updateFobillByObj(one);
	}

	@Override
	public Result deleteFobillByUserId(Long userId) {
		return foodieBillHessianCall.deleteFobillByUserId(userId);
	}

	@Override
	public Result deleteFobillByUserIds(List<Long> userIds) {
		return foodieBillHessianCall.deleteFobillByUserIds(userIds);
	}

	@Override
	public Result sumFobillByObj(FoodieOrderBill one) {
		return foodieBillHessianCall.sumFobillByObj(one);
	}

	public IFoodieBillService getFoodieBillHessianCall() {
		return foodieBillHessianCall;
	}

	public void setFoodieBillHessianCall(IFoodieBillService foodieBillHessianCall) {
		this.foodieBillHessianCall = foodieBillHessianCall;
	}
	
	
//	
//	
//	@Override
//	public void insertOrUpdateOneFobill(FoodieOrderBill one) {
//		foodieBillHessianCall.insertOrUpdateOneFobill(one);
//	}
//
//	@Override
//	public List<FoodieOrderBill> selectFobillsByUserIds(List<Long> userIds) {
//		return foodieBillHessianCall.selectFobillsByUserIds(userIds);
//	}
//
//	@Override
//	public FoodieOrderBill selectFobillByUserId(Long userId) {
//		return foodieBillHessianCall.selectFobillByUserId(userId);
//	}
//
//	@Override
//	public int updateFobillByObj(FoodieOrderBill one) {
//		return foodieBillHessianCall.updateFobillByObj(one);
//	}
//
//	@Override
//	public int deleteFobillByUserId(Long userId) {
//		return foodieBillHessianCall.deleteFobillByUserId(userId);
//	}
//
//	@Override
//	public int deleteFobillByUserIds(List<Long> userIds) {
//		return foodieBillHessianCall.deleteFobillByUserIds(userIds);
//	}
//	
//	@Override
//	public FoodieOrderBill sumFobillByObj(FoodieOrderBill one) {
//		return foodieBillHessianCall.sumFobillByObj(one);
//	}
//
//	public IFoodieBillService getFoodieBillHessianCall() {
//		return foodieBillHessianCall;
//	}
//
//	public void setFoodieBillHessianCall(IFoodieBillService foodieBillHessianCall) {
//		this.foodieBillHessianCall = foodieBillHessianCall;
//	}
//


	
    
}