package com.yihaodian.mobile.hedwig.client.service.newuser;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.newuser.NewUserCouponService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class NewUserCouponClientService implements NewUserCouponService{

	private NewUserCouponService newUserCouponHessianCall;
	
	@Override
	public Result getNewUserCouponInfo(ClientInfoVO clientInfoVO, Long userId) {
		return newUserCouponHessianCall.getNewUserCouponInfo(clientInfoVO, userId);
	}

	@Override
	public Result getUserCoupon(ClientInfoVO clientInfoVO, Long userId,Long activityId) {
		return newUserCouponHessianCall.getUserCoupon(clientInfoVO, userId,activityId);
	}

	public NewUserCouponService getNewUserCouponHessianCall() {
		return newUserCouponHessianCall;
	}

	public void setNewUserCouponHessianCall(
			NewUserCouponService newUserCouponHessianCall) {
		this.newUserCouponHessianCall = newUserCouponHessianCall;
	}
	
}
