package com.yihaodian.mobile.hedwig.client.service.impl;

import com.yihaodian.mobile.service.hedwig.core.service.spi.ICouponService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class CouponClientServiceImpl implements ICouponService {
	
	private ICouponService couponMobileHessianCall;

	@Override
	public Long sendNewguestCoupon(String token) {
		return couponMobileHessianCall.sendNewguestCoupon(token);
	}

	@Override
	public Long opensendCouponflag(Trader trader, String flag) {
		return couponMobileHessianCall.opensendCouponflag(trader, flag);
	}

	@Override
	public String flashSaleUrl(String token) {
		return couponMobileHessianCall.flashSaleUrl(token);
	}

	@Override
	public String getMerchantH5Url(Trader trader, Long brandId, Long merchantId, Long provinceId) {
		return couponMobileHessianCall.getMerchantH5Url(trader, brandId, merchantId, provinceId);
	}
	
	@Override
	public String getMerchantH5UrlWl2(Trader trader, Long brandId,Long provinceId) {
		return couponMobileHessianCall.getMerchantH5UrlWl2(trader, brandId, provinceId);
	}

	public ICouponService getCouponHessianCall() {
		return couponMobileHessianCall;
	}

	public void setCouponHessianCall(ICouponService couponHessianCall) {
		this.couponMobileHessianCall = couponHessianCall;
	}

	@Override
	public Long sendNewguestCoupon(Long userId) {
		
		return couponMobileHessianCall.sendNewguestCoupon(userId);
	}

	@Override
	public String flashSaleUrl(Long userId) {
		
		return couponMobileHessianCall.flashSaleUrl(userId);
	}

	public ICouponService getCouponMobileHessianCall() {
		return couponMobileHessianCall;
	}

	public void setCouponMobileHessianCall(ICouponService couponMobileHessianCall) {
		this.couponMobileHessianCall = couponMobileHessianCall;
	}

	@Override
	public String getMerchantH5Url(Trader trader, Long brandId, Long provinceId) {
		return couponMobileHessianCall.getMerchantH5Url(trader, brandId, provinceId);
	}

}
