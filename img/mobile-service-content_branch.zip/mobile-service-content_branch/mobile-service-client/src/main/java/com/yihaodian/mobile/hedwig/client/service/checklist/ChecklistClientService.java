package com.yihaodian.mobile.hedwig.client.service.checklist;

import java.util.Date;
import java.util.List;

import com.yihaodian.mobile.backend.checklist.vo.BatchSaveListVO;
import com.yihaodian.mobile.backend.checklist.vo.LinkedItemVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.checklist.spi.ChecklistService;

public class ChecklistClientService implements ChecklistService {
	
	private ChecklistService checklistServiceHessianCall;

	public void setChecklistServiceHessianCall(
			ChecklistService checklistServiceHessianCall) {
		this.checklistServiceHessianCall = checklistServiceHessianCall;
	}

	@Override
	public Result getUserAllLists(Long userId, boolean includeItems, boolean includeAuthUsers, boolean isDoneOnly) {
		return checklistServiceHessianCall.getUserAllLists(userId, includeItems, includeAuthUsers, isDoneOnly);
	}

	@Override
	public Result getUserListDetail(Long userId, Long listId) {
		return checklistServiceHessianCall.getUserListDetail(userId, listId);
	}
	
	@Override
	public Result getUserAuthorizeListPendingRequests(Long authUserId) {
		return checklistServiceHessianCall.getUserAuthorizeListPendingRequests(authUserId);
	}

	@Override
	public Result createUserList(Long userId, String title, Date remindTime) {
		return checklistServiceHessianCall.createUserList(userId, title, remindTime);
	}
	
	@Override
	public Result updateUserList(Long userId, Long listId, String title, Date remindTime, Boolean oneClickDone, Long version) {
		return checklistServiceHessianCall.updateUserList(userId, listId, title, remindTime, oneClickDone, version);
	}

	@Override
	public Result createListItem(Long userId, Long listId, String memo, List<String> picUrls, String externalUrl) {
		return checklistServiceHessianCall.createListItem(userId, listId, memo, picUrls, externalUrl);
	}
	
	@Override
	public Result updateListItem(Long userId, Long listId, Long itemId, String memo, String externalUrl, List<String> picUrls, List<Long> picIds2Del, Boolean isDone, Boolean replaceMode, Long version) {
		return checklistServiceHessianCall.updateListItem(userId, listId, itemId, memo, externalUrl, picUrls, picIds2Del, isDone, replaceMode, version);
	}
	
	@Override
	public Result reorderListItem(Long userId, Long listId, Long itemId,
			Integer move) {
		return checklistServiceHessianCall.reorderListItem(userId, listId, itemId, move);
	}

	@Override
	public Result cloneListItems(Long userId, List<LinkedItemVO> items2Clone) {
		return checklistServiceHessianCall.cloneListItems(userId, items2Clone);
	}

	@Override
	public Result copyListItems(Long userId, List<Long> itemIds, Long listId) {
		return checklistServiceHessianCall.copyListItems(userId, itemIds, listId);
	}

	@Override
	public Result authorizeUsersListRequest(Long userId, Long listId,
			List<Long> authUsers) {
		return checklistServiceHessianCall.authorizeUsersListRequest(userId, listId, authUsers);
	}

	@Override
	public Result authorizeUserListResponse(Long authUserId, Long userId,
			Long listId, Boolean accept) {
		return checklistServiceHessianCall.authorizeUserListResponse(authUserId, userId, listId, accept);
	}

	@Override
	public Result deleteUserList(Long userId, Long listId, Long version) {
		return checklistServiceHessianCall.deleteUserList(userId, listId, version);
	}

	@Override
	public Result deleteListItem(Long userId, Long listId, Long itemId,
			Long version) {
		return checklistServiceHessianCall.deleteListItem(userId, listId, itemId, version);
	}

	@Override
	public Result batchSaveItemList(Long userId, BatchSaveListVO offlineList, Boolean replaceMode) {
		return checklistServiceHessianCall.batchSaveItemList(userId, offlineList, replaceMode);
	}

	@Override
	public Result parseExternalUrl(String externalUrl, Long provinceId) {
		return checklistServiceHessianCall.parseExternalUrl(externalUrl, provinceId);
	}

}
