package com.yihaodian.mobile.service.client.adapter.home;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.home.spi.AdIndexService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class AdIndexDispaterService extends BaseDiapatchService{
	public RtnInfo loadHomePageADs(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		long uid = 0;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}
		
		String cityid = context.getRequestInfo().getCityId();//手选   
		AdIndexService service = CentralMobileServiceHandler.getAdIndexService();
		Result result = service.loadHomePageADs(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),uid);
		return getRtnInfo(result);
	}
	
	public RtnInfo getBannerByCode(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		String code = bizInfo.get("code");
		if(code==null){
			return RtnInfo.ParameterErrRtnInfo("code is null");
		}
		
		String cityid = context.getRequestInfo().getCityId();
		AdIndexService service = CentralMobileServiceHandler.getAdIndexService();
		Result result = service.getBannerByCode(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),code);
		return getRtnInfo(result);
	}
	public RtnInfo getIconsByCode(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		String code = bizInfo.get("code");
		if(code==null){
			return RtnInfo.ParameterErrRtnInfo("code is null");
		}
		
		String cityid = context.getRequestInfo().getCityId();
		AdIndexService service = CentralMobileServiceHandler.getAdIndexService();
		Result result = service.getIconsByCode(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),code);
		return getRtnInfo(result);
	}
}
