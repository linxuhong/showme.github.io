package com.yihaodian.mobile.hedwig.client.shop.impl;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.shop.ShopBrandClientService;
import com.yihaodian.mobile.hedwig.push.spi.ShopBrandFacdeService;

public class ShopBrandClientServiceImpl implements ShopBrandClientService{

	private ShopBrandFacdeService shopBrandHessianCall;
	
	public void setShopBrandHessianCall(ShopBrandFacdeService shopBrandHessianCall) {
		this.shopBrandHessianCall = shopBrandHessianCall;
	}

	@Override
	public Result getShopInfos(String brandName, int pageSize, int currentPage) {
		return shopBrandHessianCall.getShopInfos(brandName, pageSize, currentPage);
	}

	@Override
	public Result getBrandNameByChar(String input) {
		return shopBrandHessianCall.getBrandNameByChar(input);
	}

}
