package com.yihaodian.mobile.hedwig.client.homegame;

import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.service.domain.vo.business.rock.RedPacketRainGameResult;
import com.yihaodian.mobile.service.facade.business.homegame.HomePageGameService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class HomePageGameClientService implements HomePageGameService {
	private HomePageGameService homePageGameHessianCall;


	public HomePageGameService getHomePageGameHessianCall() {
		return homePageGameHessianCall;
	}

	public void setHomePageGameHessianCall(
			HomePageGameService homePageGameHessianCall) {
		this.homePageGameHessianCall = homePageGameHessianCall;
	}

	@Override
	public RedPacketRainGameResult getGamePromotionInfo(Long userId) {
		return homePageGameHessianCall.getGamePromotionInfo(userId);
	}

	@Override
	public ResultModel doShaking(Trader trader, Long gameId, Long userId, Long batchId,
			Integer redPacketNum,String traderName,String deviceToken) {
		return homePageGameHessianCall.doShaking(trader, gameId, userId, batchId, redPacketNum, traderName, deviceToken);
	}

	@Override
	public ResultModel redIsReady(Long gameId, Long batchId, Long userId) {
		return homePageGameHessianCall.redIsReady(gameId, batchId, userId);
	}

	@Override
	public ResultModel doShaking2(Trader trader, Long gameId, Long userId, Long batchId, Integer redPacketNum,
			String traderName, String deviceToken, Long timestamp,String hcitoken,String userIp) {
		return homePageGameHessianCall.doShaking2(trader, gameId, userId, batchId, redPacketNum, traderName, deviceToken,timestamp,hcitoken,userIp);
	}
	
	@Override
	public ResultModel doShaking3(Trader trader, Long gameId, Long userId, Long batchId, Integer redPacketNum,
			String traderName, String deviceToken, Long timestamp,Long tstamp,String hcitoken,String userIp) {
		return homePageGameHessianCall.doShaking3(trader, gameId, userId, batchId, redPacketNum, traderName, deviceToken,timestamp,tstamp,hcitoken,userIp);
	}

}
