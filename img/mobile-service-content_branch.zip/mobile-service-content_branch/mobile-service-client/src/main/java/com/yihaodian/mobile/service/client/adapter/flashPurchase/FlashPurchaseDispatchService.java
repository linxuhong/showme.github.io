/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.flashPurchase;

import java.util.Map;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.content.spi.FlashPurchaseService;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class FlashPurchaseDispatchService.
 * @author zuodeng
 */
public class FlashPurchaseDispatchService extends BaseDiapatchService{
	
	/**
	 * Gets the brand collect state.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return RtnInfo
	 */
	public RtnInfo getBrandCollectState(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		FlashPurchaseService flashPurchaseService = CentralMobileServiceHandler
				.getFlashPurchaseService();
		String brandIdStr = bizInfo.get("brandid");
		if (brandIdStr == null || brandIdStr.equals("")) {
			return RtnInfo.ParameterErrRtnInfo("brandId is null");
		}
		if (!brandIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())) {
			return RtnInfo.ParameterErrRtnInfo("brandId formate error");
		}
		Long brandId = Long.parseLong(brandIdStr);
		Boolean re = flashPurchaseService.getBrandCollectState(context
				.getRequestInfo().getUserToken(), brandId);
		return RtnInfo.RightWlRtnInfo(re);
	}

	/**
	 * 	 * .
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the favorite brand lists
	 */	 
	public RtnInfo getFavoriteBrandLists(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String token = context.getRequestInfo().getUserToken();
		String currentPage = bizInfo.get("currentpage");
		String pageSize = bizInfo.get("pagesize");
		RtnInfo rtn = validatePageInfo(currentPage, pageSize);
		if (rtn != null) {
			return rtn;
		}

		FlashPurchaseService flashPurchaseService = CentralMobileServiceHandler
				.getFlashPurchaseService();
		Page<Long> page = flashPurchaseService.getFavoriteBrandLists(token,
				Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		return RtnInfo.RightWlRtnInfo(page);
	}

    /**
     * Adds the favorite for brand.
     *
     * @param urlPath the url path
     * @param isLogined the is logined
     * @param bizInfo the biz info
     * @param context the context
     * @return the rtn info
     */
    public RtnInfo addFavoriteForBrand(String urlPath, Boolean isLogined,
                                       Map<String, String> bizInfo, AdapterContext context) {

        RtnInfo rtnInfo = null;
        if (!isLogined) {
            rtnInfo = RtnInfo.TokenErrWlRtnInfo();
        }else{
            String brandId = bizInfo.get("brandid");
            FlashPurchaseService flashPurchaseService = CentralMobileServiceHandler
                    .getFlashPurchaseService();  
            boolean result = flashPurchaseService.addFavoriteForBrand(context.getRequestInfo().getUserToken(), Long.valueOf(brandId));
            rtnInfo = RtnInfo.RightWlRtnInfo(result);
        }
        return rtnInfo;
    }
	
}
