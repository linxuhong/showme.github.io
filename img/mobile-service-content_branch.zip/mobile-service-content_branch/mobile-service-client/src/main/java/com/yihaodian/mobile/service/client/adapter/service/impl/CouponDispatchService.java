/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.Map;

import com.fasterxml.jackson.core.util.VersionUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.hedwig.core.service.spi.ICouponService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class CouponDispatchService.
 */
public class CouponDispatchService extends BaseDiapatchService {
	
	/**
	 * Send newguest coupon.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo sendNewguestCoupon(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String userId =context.getCurrentUserId();
		Result re = valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}
		ICouponService couponService = CentralMobileServiceHandler.getCouponClientService();
		Long l = couponService.sendNewguestCoupon(Long.parseLong(userId));
		return RtnInfo.RightWlRtnInfo(l);
	}
	
	/**
	 * Gets the merchant h5 url.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the merchant h5 url
	 */
	public RtnInfo getMerchantH5Url(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
//		if(!isLogined){
//			return RtnInfo.TokenErrWlRtnInfo();
//		}
		Trader trader = this.getTraderFromContext(context);
		if(trader.getTraderName()==null){
			return RtnInfo.ParameterErrRtnInfo("traderName is null ");
		}
		// 这里不做修改,直接使用就的，当是品牌商时不走这个接口
//		// ********************
//		// 根据版本号区分处理过程
//		// ********************
//		String version = context.getRequestInfo().getClientInfo().getClientAppVersion();
//		if (compareVersion("4.2.9", version) >= 0) {
//			Long provinceId = null;
//			if (valiateGetParams(context.getRequestInfo().getProvinceId()).isSuccess()) {
//				provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
//			}
//
//			Long merchantId = null;// 这是商家ID
//			if (valiateGetParams(bizInfo.get("brandid")).isSuccess()) {
//				merchantId = Long.valueOf(bizInfo.get("brandid"));
//			}
//
//			Long brandId = null;// 这是品牌商ID
//			if (valiateGetParams(bizInfo.get("realbrandid")).isSuccess()) {
//				brandId = Long.valueOf(bizInfo.get("realbrandid"));
//			}
//
//			// 不能同时为空
//			if (merchantId == null && brandId == null) {
//				return RtnInfo.ParameterErrRtnInfo("brandid and realbrandid is null ");
//			} else if (merchantId != null && provinceId == null) {
//				return RtnInfo.ParameterErrRtnInfo("brandid and provinceId is null ");
//			}
//
//			ICouponService couponService = CentralMobileServiceHandler.getCouponClientService();
//			String str = couponService.getMerchantH5Url(trader, brandId, merchantId, provinceId);
//			return RtnInfo.RightWlRtnInfo(str);
//		}

		// ********************
		// <del>版本低于4.2.9的处理方式</del>
		// ********************
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		if(provinceIdStr==null ||provinceIdStr.equals("")){
			return RtnInfo.ParameterErrRtnInfo("provinceId is null ");		
		}
		if(!provinceIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("provinceId formate error ");		
		}		
		String brandIdStr = bizInfo.get("brandid");
		if(brandIdStr==null ||brandIdStr.equals("")){
			return RtnInfo.ParameterErrRtnInfo("brandId is null ");		
		}
		if(!brandIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("brandId formate error ");		
		}		
		Long provinceId = Long.parseLong(provinceIdStr);
		Long brandId = Long.parseLong(brandIdStr);
		ICouponService couponService = CentralMobileServiceHandler.getCouponClientService();
		String str = couponService.getMerchantH5UrlWl2(trader, brandId, provinceId);
		return RtnInfo.RightWlRtnInfo(str);
	}
	
	/**
	 * Flash sale url.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo flashSaleUrl(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();
		Result re = valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}		
		ICouponService couponService = CentralMobileServiceHandler.getCouponClientService();
		String str = couponService.flashSaleUrl(Long.parseLong(userId));
		return RtnInfo.RightWlRtnInfo(str);
	}
}
