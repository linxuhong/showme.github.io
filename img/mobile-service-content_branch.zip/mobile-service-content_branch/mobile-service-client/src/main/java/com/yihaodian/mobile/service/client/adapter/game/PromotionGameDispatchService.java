package com.yihaodian.mobile.service.client.adapter.game;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.push.spi.IPromotionGameService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class PromotionGameDispatchService extends BaseDiapatchService {
	
	public RtnInfo getGamePromotionInfo(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String gameId = bizInfo.get("gameid");
		RtnInfo rtn = validateNumber(gameId);
		if (rtn != null) {
			return rtn;
		}
		
		String provinceId = context.getRequestInfo().getProvinceId();
		rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		
		IPromotionGameService service = CentralMobileServiceHandler.getPromotionGameService();
		Result result = service.getGamePromotionInfo(Long.valueOf(gameId), Long.valueOf(uid), Integer.valueOf(provinceId));
		return getRtnInfo(result);
	}
	
	public RtnInfo doShakingWithAwardPoolIds(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String gameId = bizInfo.get("gameid");
		RtnInfo rtn = validateNumber(gameId);
		if (rtn != null) {
			return rtn;
		}
		
		String provinceId = context.getRequestInfo().getProvinceId();
		rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		
		String awardPoolIds = bizInfo.get("awardpoolids");
		String traderName = context.getRequestInfo().getClientInfo().getTraderName();
		String deviceToken = context.getRequestInfo().getClientInfo().getDeviceCode();
		String ip = context.getRequestIp();
		if (StringUtils.isBlank(traderName) || StringUtils.isBlank(deviceToken)) {
			return RtnInfo.ParameterErrRtnInfo("参数不能为空");
		}
		
		IPromotionGameService service = CentralMobileServiceHandler.getPromotionGameService();
		Result result = service.doShakingWithAwardPoolIds(Long.valueOf(gameId), Long.valueOf(uid), awardPoolIds, traderName, deviceToken, ip, Integer.valueOf(provinceId));
		return getRtnInfo(result);
	}
	
	public RtnInfo acceptAward(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String gameId = bizInfo.get("gameid");
		RtnInfo rtn = validateNumber(gameId);
		if (rtn != null) {
			return rtn;
		}
		
		String awardId = bizInfo.get("awardid");
		rtn = validateNumber(awardId);
		if (rtn != null) {
			return rtn;
		}
		
		String isDiscardStr = bizInfo.get("isdiscard");
		Integer isDiscard = null;
		if (StringUtils.isNumeric(isDiscardStr)) {
			isDiscard = Integer.valueOf(isDiscardStr);
		}
		
		String provinceId = context.getRequestInfo().getProvinceId();
		rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		
		String traderName = context.getRequestInfo().getClientInfo().getTraderName();
		String deviceToken = context.getRequestInfo().getClientInfo().getDeviceCode();
		String ip = context.getRequestIp();
		String tokenSession = bizInfo.get("tokensession");
		String sessionId = bizInfo.get("sessionid");
		String userName = bizInfo.get("username");
		String address = bizInfo.get("address");
		String phone = bizInfo.get("phone");
		
		if (StringUtils.isBlank(traderName) || StringUtils.isBlank(deviceToken) || StringUtils.isBlank(tokenSession)
				|| StringUtils.isBlank(sessionId)) {
			return RtnInfo.ParameterErrRtnInfo("参数不能为空");
		}
		
		IPromotionGameService service = CentralMobileServiceHandler.getPromotionGameService();
		Result result = service.acceptAward(Long.valueOf(gameId), Long.valueOf(uid), Long.valueOf(awardId), isDiscard, Integer.valueOf(provinceId), 
				traderName, deviceToken, tokenSession, phone, address, userName, sessionId, ip);
		return getRtnInfo(result);
	}
	
	public RtnInfo getAchievementList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String gameId = bizInfo.get("gameid");
		RtnInfo rtn = validateNumber(gameId);
		if (rtn != null) {
			return rtn;
		}
		
		String provinceId = context.getRequestInfo().getProvinceId();
		rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		
		IPromotionGameService service = CentralMobileServiceHandler.getPromotionGameService();
		Result result = service.getAchievementList(Long.valueOf(gameId), Long.valueOf(uid), Integer.valueOf(provinceId));
		return getRtnInfo(result);
	}
	
	public RtnInfo getUserAcceptAwardList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String gameId = bizInfo.get("gameid");
		RtnInfo rtn = validateNumber(gameId);
		if (rtn != null) {
			return rtn;
		}
		
		IPromotionGameService service = CentralMobileServiceHandler.getPromotionGameService();
		Result result = service.getUserAcceptAwardList(Long.valueOf(gameId), Long.valueOf(uid));
		return getRtnInfo(result);
	}
}
