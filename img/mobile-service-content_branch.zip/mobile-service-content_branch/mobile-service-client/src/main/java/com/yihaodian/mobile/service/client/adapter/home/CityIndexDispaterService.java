package com.yihaodian.mobile.service.client.adapter.home;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.channel.spi.CityChannelPageService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.home.spi.CityIndexService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class CityIndexDispaterService extends BaseDiapatchService{
	public RtnInfo cityHome(String urlPath, Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context){
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		long uid = 0;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}
		String cityid = context.getRequestInfo().getCityId();
		rtnInfo = validateNumber(cityid);
		if(rtnInfo != null){
			return rtnInfo;
		}
		CityIndexService service = CentralMobileServiceHandler.getCityIndexService();
		Result result = service.cityHome(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),uid);
		return getRtnInfo(result);
	}
	
	public RtnInfo getCityHomeChannelPage(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
    		} 
    	}
    	Long userId = null;
		if (isLogined) {
			try {
				userId = Long.parseLong(context.getCurrentUserId());
			} catch (Exception e) {
				
			}
		}    	
		String cityid = context.getRequestInfo().getCityId();
		CityChannelPageService service = CentralMobileServiceHandler.getCityChannelPageService();
    	Result result = service.getCityHomeChannelPage(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid), userId, bizInfo);
        return  getRtnInfo(result);    
    }

	public RtnInfo cityHomeRank(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		long uid = 0;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}
		
		String cityid = context.getRequestInfo().getCityId();
		CityIndexService service = CentralMobileServiceHandler.getCityIndexService();
		Result result = service.cityHomeRank(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),uid);
		return getRtnInfo(result);
	}

	public RtnInfo cityHomeRankV2(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null) {
			return rtnInfo;
		}

		long uid = 0;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {}
		}
		CityIndexService service = CentralMobileServiceHandler.getCityIndexService();
		Result result = service.cityHomeRankV2(convertClientInfoVO(context.getRequestInfo().getClientInfo(), context.getRequestInfo().getProvinceId(), context.getRequestInfo().getCityId()), uid);
		return getRtnInfo(result);
	}
	
	public RtnInfo getCityHomePageGuessUlikeProducts(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String excluds = bizInfo.get("excludeproducts");
		String cityid = context.getRequestInfo().getCityId();
		CityIndexService service = CentralMobileServiceHandler.getCityIndexService();
		
		Long uid = null;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}
		Result result = service.getCityHomePageGuessUlikeProducts(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),uid,excluds);
		return getRtnInfo(result);
	}
	
	public RtnInfo getCityHomePageGuessUlikeProductsV2(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String excluds = bizInfo.get("excludeproducts");
		String cityid = context.getRequestInfo().getCityId();
		CityIndexService service = CentralMobileServiceHandler.getCityIndexService();
		
		Long uid = null;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}
		Result result = service.getCityHomePageGuessUlikeProductsV2(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),uid,excluds);
		return getRtnInfo(result);
	}
	
	public RtnInfo getCityGlobalImportProducts(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
    		} 
    	}
		String cityid = context.getRequestInfo().getCityId();
		CityChannelPageService service = CentralMobileServiceHandler.getCityChannelPageService();
    	Result result = service.getCityGlobalImportProducts(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid));
        return  getRtnInfo(result);    
    }
	
	public RtnInfo getAllCityHomeChannel(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		long uid = 0;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}
		
		String cityid = context.getRequestInfo().getCityId();
		rtnInfo = validateNumber(cityid);
		if(rtnInfo != null){
			return rtnInfo;
		}
		CityIndexService service = CentralMobileServiceHandler.getCityIndexService();
		Result result = service.getAllCityHomeChannel(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),uid);
		return getRtnInfo(result);
	}
	
	public RtnInfo cityStrollChannel(String urlPath, Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context){
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		long uid = 0;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}
		String cityid = context.getRequestInfo().getCityId();
		rtnInfo = validateNumber(cityid);
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		String viewedproductids = bizInfo.get("viewedproductids");
		CityIndexService service = CentralMobileServiceHandler.getCityIndexService();
		Result result = service.cityStrollChannel(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),uid,viewedproductids);
		return getRtnInfo(result);
	}
	
	public RtnInfo cityStrollChannelGoods(String urlPath, Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context){
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}

		Long uid = null;
		if (isLogined) {
			try {
				uid = Long.valueOf(context.getCurrentUserId());
			} catch (Exception e) {
			}
		}
		
		String cityid = context.getRequestInfo().getCityId();
		rtnInfo = validateNumber(cityid);
		if(rtnInfo != null){
			return rtnInfo;
		}
		CityIndexService service = CentralMobileServiceHandler.getCityIndexService();
		Result result = service.cityStrollChannelGoods(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),uid);
		return getRtnInfo(result);
	}
}
