package com.yihaodian.mobile.hedwig.client.impl.product;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.product.spi.IProductSignService;

public class ProductSignClientService implements IProductSignService {
	
	private IProductSignService productSignHessianCall;

	@Override
	public Result getInterestedProductsByUser(String userToken,
			String traderName,  String clientAppVersion, Long productId, Long pmId, Long provinceId,
			Long merchantId, Integer productNum) {
		return productSignHessianCall.getInterestedProductsByUser(userToken, traderName, clientAppVersion , productId, pmId, provinceId, merchantId, productNum);
	}

	public IProductSignService getProductSignHessianCall() {
		return productSignHessianCall;
	}

	public void setProductSignHessianCall(IProductSignService productSignHessianCall) {
		this.productSignHessianCall = productSignHessianCall;
	}

    @Override
    public Result getInterestedProductsByUser(Long userId, String traderName,
                                              String clientAppVersion, Long productId, Long pmId,
                                              Long provinceId, Long merchantId, Integer productNum) {
        return productSignHessianCall.getInterestedProductsByUser(userId, traderName, clientAppVersion, productId, pmId, provinceId, merchantId, productNum);
    }

    @Override
    public Result getInterestedProductsByUser(Long userId, String traderName, String clientAppVersion, Long productId,
            Long pmId, Long provinceId, Long merchantId, Integer productNum, String cityid) {
        return productSignHessianCall.getInterestedProductsByUser(userId, traderName, clientAppVersion, productId, pmId, provinceId, merchantId, productNum, cityid);
    }
    
    
    

}
