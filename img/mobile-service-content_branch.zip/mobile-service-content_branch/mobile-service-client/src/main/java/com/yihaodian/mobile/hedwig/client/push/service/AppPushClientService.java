package com.yihaodian.mobile.hedwig.client.push.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.hedwig.push.vo.ClientAppPushInfo;
import com.yihaodian.mobile.vo.push.PushMapping;

public interface AppPushClientService {
	/**
	 * 检查用户是否为掌上用户
	 * @param userId 用户id
	 * @return
	 */
	public boolean checkIfMobileUser(Long userId);
	
	/**
	 * 检查用户是否为掌上用户
	 * @param userIdList 用户Id列表
	 * @return
	 */
	public List<Long> checkIfMobileUserForList(List<Long> userIdList);	
	
	/**
	 * 插入推送的信息
	 * @param appPushInfo
	 * @return
	 */
	public boolean insertAppPushInfo(ClientAppPushInfo clientAppPushInfo);
	
	/**
	 * 插入推送的信息
	 * @param appPushInfo
	 * @return
	 */
	public boolean insertAppPushInfoList(List<ClientAppPushInfo> clientAppPushInfoList);
	
	/**
	 * 插入微店推送信息
	 * @return
	 */
	public boolean insertPushInfoForVUser(String domainName, String content, List<Long> vUserIdList, String sourceCode, int msgSync, Date date);
	
	/**
	 * Android 查询有效设备号
	 * @return 判断该微店用户是绑定手机
	 */
	public boolean isWeiDianHasDevice(Long vuserId);
	
	/**
	 * Android 批量查询有效设备号
	 * @return 判断该微店用户是绑定手机
	 */
	public Map<Long,Boolean> isWeiDianHasDeviceForBatch(List<Long> vUserIdList);
	
	/**
	 * ios推送 ycm通过用户id查 device token
	 * @return 返回该微店用户的device token，如有多个device返回最后记录的device
	 */
	public String getWeiDianDeviceToken(Long vuserId);
	
	/**
	 * ios推送 ycm批量通过用户id查 device token
	 * @return 返回该微店用户的device token，如有多个device返回最后记录的device
	 */
	public Map<Long,String> getWeiDianDeviceTokenForBatch(List<Long> vUserIdList);
	
	/**
     * 根据userId获得IOS device token
     * @param userId
     * @return
     */
    public List<PushMapping> getDeviceToken(Long userId);
    
    /**
     * 根据userId获得IOS device token
     * @param userIdList
     * @return
     */
    public Map<Long,List<String>> getDeviceToken(List<Long> userIdList);
    
    /**
     * 判断该设备号一号店是否登陆过
     * @param deviceCode
     * @return
     */
    public Boolean isYHDDevice(String deviceCode);
    
    
    
    /**
     * 检查是否为掌上sam用户
     * @param userId
     * @return
     */
    public boolean checkIfSiteMobileUser(Long userId, int siteType);
    /**
     * 检查是否为sam掌上用户
     * @param userId
     * @return
     */
    public List<Long> checkIfSiteMobileUserList(List<Long> userIdList, int siteType) ;
 

   /**
     * 根据userId获得IOS device token
     * @param userIdList
     * @return
     */
    public List<PushMapping> getSiteDeviceToken(Long userId, int siteType);
    /**
     * 根据userId获得IOS device token
     * @param userIdList
     * @return
     */
    public Map<Long, List<String>> getSiteDeviceToken(List<Long> userIdList, int siteType);
    
	
}
