/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.questionnaire;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.questionnaire.QuestionnaireService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class QuestionnaireDispatchService.
 */
public class QuestionnaireDispatchService extends BaseDiapatchService {

	/**
	 * Gets the questionnaire switch.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the questionnaire switch
	 */
	public RtnInfo getQuestionnaireSwitch(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String userid = context.getCurrentUserId();
		Result result1 = null;
		Long userId = null;
		if(userid!=null){
			result1=this.valiateGetParams(userid);
			if(!result1.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result1.getResultDesc());
			}
			userId = Long.parseLong(userid);	
		}
			
		String provinceId = context.getRequestInfo().getProvinceId();
		result1 =this.valiateGetParams(provinceId);
		if(!result1.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("provinceId"+result1.getResultDesc());
		}
		QuestionnaireService service = CentralMobileServiceHandler.getQuestionnaireService();
		Result result = service.getQuestionnaireSwitch(convertClientInfoVO(context.getRequestInfo().getClientInfo()), userId, Integer.parseInt(provinceId));
		return getRtnInfo(result);
	}

	/**
	 * Skip questionnaire.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo skipQuestionnaire(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userid = context.getCurrentUserId();
		Result re = this.valiateGetParams(userid);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}	
		QuestionnaireService service = CentralMobileServiceHandler.getQuestionnaireService();
		Result result = service.skipQuestionnaire(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Long.parseLong(userid));
		return getRtnInfo(result);
	}

}
