package com.yihaodian.mobile.service.client.adapter.update;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.push.spi.UpdateAwardService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class UpdateAwardDispatch extends BaseDiapatchService{
	
	public RtnInfo createMessageForUpdateAward(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		UpdateAwardService service = CentralMobileServiceHandler
				.getUpdateAwardClientService();
		Result re = service.createMessageForUpdateAward(convertClientInfoVO(context.getRequestInfo().getClientInfo()),Long.valueOf(context.getCurrentUserId()));

		return getRtnInfo(re);
	}

}
