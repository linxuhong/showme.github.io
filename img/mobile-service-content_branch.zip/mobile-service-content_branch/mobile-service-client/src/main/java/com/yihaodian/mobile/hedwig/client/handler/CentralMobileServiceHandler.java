package com.yihaodian.mobile.hedwig.client.handler;

import com.yihaodian.architecture.hedwig.client.HedwigClientFactoryBean;
import com.yihaodian.mobile.hedwig.client.WeChat.service.WeChatClientService;
import com.yihaodian.mobile.hedwig.client.bivisual.BIVisualClientService;
import com.yihaodian.mobile.hedwig.client.mobileUser.service.MobileUserClientService;
import com.yihaodian.mobile.hedwig.client.push.service.AppPushClientService;
import com.yihaodian.mobile.hedwig.client.redshare.RedShareClientService;
import com.yihaodian.mobile.hedwig.client.service.rock.RockClientService;
import com.yihaodian.mobile.hedwig.client.service.seckill.SeckillQueueClientService;
import com.yihaodian.mobile.hedwig.client.shop.ShopBrandClientService;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.push.spi.HomePageService;
import com.yihaodian.mobile.hedwig.push.spi.IDailyBuyService;
import com.yihaodian.mobile.hedwig.push.spi.IGameService;
import com.yihaodian.mobile.hedwig.push.spi.IOrderRedService;
import com.yihaodian.mobile.hedwig.push.spi.IPromotionGameService;
import com.yihaodian.mobile.hedwig.push.spi.IRedShareService;
import com.yihaodian.mobile.hedwig.push.spi.IScanService;
import com.yihaodian.mobile.hedwig.push.spi.ITreeService;
import com.yihaodian.mobile.hedwig.push.spi.UpdateAwardService;
import com.yihaodian.mobile.service.alipay.spi.IAlipaySignService;
import com.yihaodian.mobile.service.app.spi.AppActivationService;
import com.yihaodian.mobile.service.channel.spi.BigNameService;
import com.yihaodian.mobile.service.channel.spi.CityChannelPageService;
import com.yihaodian.mobile.service.channel.spi.GlobalImportProductService;
import com.yihaodian.mobile.service.channel.spi.NewFavoriteService;
import com.yihaodian.mobile.service.channel.spi.QualityKitchenService;
import com.yihaodian.mobile.service.checklist.spi.ChecklistService;
import com.yihaodian.mobile.service.client.advertisement.service.AdvertisementShareClientService;
import com.yihaodian.mobile.service.client.advertisement.service.impl.AdClientService;
import com.yihaodian.mobile.service.client.advertisement.service.impl.CategoryAdClientService;
import com.yihaodian.mobile.service.client.advertisement.service.impl.EngAdClientService;
import com.yihaodian.mobile.service.client.redpacket.service.AnniversaryRedPacketClientService;
import com.yihaodian.mobile.service.cms.spi.CmsNativeService;
import com.yihaodian.mobile.service.core.business.service.AppAnimationService;
import com.yihaodian.mobile.service.facade.SeckillProductService;
import com.yihaodian.mobile.service.facade.business.advertisement.CurtainAdvertisementService;
import com.yihaodian.mobile.service.facade.business.advertisement.IPrecisionHomePageService;
import com.yihaodian.mobile.service.facade.business.apollo.IApolloPromotionService;
import com.yihaodian.mobile.service.facade.business.appconfig.AppConfigService;
import com.yihaodian.mobile.service.facade.business.command.ICommandService;
import com.yihaodian.mobile.service.facade.business.cut.ICutService;
import com.yihaodian.mobile.service.facade.business.devicecodeAB.DevicecodeABService;
import com.yihaodian.mobile.service.facade.business.foodieBill.IFoodieBillService;
import com.yihaodian.mobile.service.facade.business.homegame.HomePageGameService;
import com.yihaodian.mobile.service.facade.business.integral.IintergralWallService;
import com.yihaodian.mobile.service.facade.business.message.MessageCenterService;
import com.yihaodian.mobile.service.facade.business.navigationcategory.INavigationCategoryService;
import com.yihaodian.mobile.service.facade.business.newuser.NewUserCouponService;
import com.yihaodian.mobile.service.facade.business.pay.IPayPreService;
import com.yihaodian.mobile.service.facade.business.pmsrank.PmsRankService;
import com.yihaodian.mobile.service.facade.business.push.IPushMessageStatisticsService;
import com.yihaodian.mobile.service.facade.business.push.PushService;
import com.yihaodian.mobile.service.facade.business.questionnaire.QuestionnaireService;
import com.yihaodian.mobile.service.facade.business.system.SystemService;
import com.yihaodian.mobile.service.facade.business.tag.IAppTagService;
import com.yihaodian.mobile.service.facade.business.thunder.ThunderBuyService;
import com.yihaodian.mobile.service.facade.business.voucher.IVoucherService;
import com.yihaodian.mobile.service.facade.business.wechat.WechatCouponService;
import com.yihaodian.mobile.service.facade.content.spi.FlashPurchaseService;
import com.yihaodian.mobile.service.facade.content.spi.ScratchService;
import com.yihaodian.mobile.service.facade.coupon.IMobileCouponFacadeService;
import com.yihaodian.mobile.service.facade.deeplink.IDeeplinkService;
import com.yihaodian.mobile.service.facade.downloadpage.spi.IDownloadPageService;
import com.yihaodian.mobile.service.facade.lottery.spi.ILotteryTicketService;
import com.yihaodian.mobile.service.facade.product.spi.IProductSignService;
import com.yihaodian.mobile.service.facade.reward.spi.IRewardService;
import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;
import com.yihaodian.mobile.service.facade.venus.VenusHttpsCheckService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.AlipayService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.FeedbackService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.HomeService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.ICouponService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MiracleService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MobileProfileService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MonkeyService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.ProductService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.PromotionService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.UserPassport;
import com.yihaodian.mobile.service.home.spi.AdIndexService;
import com.yihaodian.mobile.service.home.spi.AppIndexService;
import com.yihaodian.mobile.service.home.spi.CityIndexService;
import com.yihaodian.mobile.service.home.spi.ExtConfigService;
import com.yihaodian.mobile.service.home.spi.ExtIndexService;
import com.yihaodian.mobile.service.map.spi.MapsFrontService;
import com.yihaodian.mobile.service.mobilecart.spi.AppCartService;
import com.yihaodian.mobile.service.survey.spi.SurveyQuestionaireService;
import com.yihaodian.mobile.service.user.spi.UserFacadeService;
import com.yihaodian.mobile.service.wl2.spi.IWl2Service;

/**
 * The Class CentralMobileServiceHandler.
 */
public class CentralMobileServiceHandler {
	
	/** The app push client service. */
	private static AppPushClientService appPushClientService;
	
	/** The mobile user client service. */
	private static MobileUserClientService mobileUserClientService;
	
	/** The we chat client service. */
	private static WeChatClientService weChatClientService;
	
	/** The shop brand client service. */
	private static ShopBrandClientService shopBrandClientService;
	
	/** The rock client service. */
	private static RockClientService rockClientService;
	
	/** The advertisement share client service. */
	private static AdvertisementShareClientService advertisementShareClientService ;

	
	/** The anniversary red packet client service. */
	private static AnniversaryRedPacketClientService anniversaryRedPacketClientService;
	
	/** The bi visual client service. */
	private static BIVisualClientService biVisualClientService;
	
	/** The update award client service. */
	private static UpdateAwardService updateAwardClientService;
	
	/** The red share client service. */
	private static IRedShareService redShareClientService;
	
	/** The home page client service. */
	private static HomePageService homePageClientService;
	
	/** The scratch service. */
	private static ScratchService scratchService;
	
	/** The wl2 client service. */
	private static IWl2Service wl2ClientService; 
	
	/** The precision home page ad client service. */
	private static IPrecisionHomePageService precisionHomePageADClientService; //app精准化首页广告
    
    /** The mobile profile service. */
    private static MobileProfileService mobileProfileService;
	
	/** The alipay service. */
	private static AlipayService alipayService;
    
    /** The product service. */
    private static ProductService productService;
    
    /** The user client service. */
    private static UserFacadeService userClientService;
    
    /** The download page client service. */
    private static IDownloadPageService downloadPageClientService;
    
    /** The lottery tickets client service. */
    private static ILotteryTicketService lotteryTicketsClientService;
    
    /** The product sign client service. */
    private static IProductSignService productSignClientService;
    
    /** The reward client service. */
    private static IRewardService rewardClientService;
    
    /** The share coupon client service. */
    private static IShareCouponService shareCouponClientService;
    
    /** The system service. */
    private static SystemService systemService ;
    
    /** The home service. */
    private static HomeService homeService;
    
    /** The promotion service. */
    private static PromotionService promotionService;
    
    /** The coupon client service. */
    private static ICouponService couponClientService;
    
    /** The pay pre service. */
    private static IPayPreService payPreService;
    
    /** The flash purchase service. */
    private static FlashPurchaseService flashPurchaseService;
    
    /** The message center service. */
    private static MessageCenterService messageCenterService;
    
    /** The push message statistics service. */
    private static IPushMessageStatisticsService pushMessageStatisticsService;
    
    /** The mobile coupon client service. */
    private static IMobileCouponFacadeService mobileCouponClientService;
    
    /** The feedback service. */
    private static FeedbackService feedbackService;
    
    /** The seckill client service. */
    private static SeckillProductService seckillClientService;
    
    /** The push service. */
    private static PushService pushService;  
    
    /** The apollo promotion service. */
    private static IApolloPromotionService apolloPromotionService;
    
    /** The intergral wall service. */
    private static IintergralWallService intergralWallService;
    
    /** The questionnaire service. */
    private static QuestionnaireService questionnaireService;
    
    /** The monkey service. */
    private static MonkeyService monkeyService;
    
    /** The miracle service. */
    private static MiracleService miracleService;
    
    /** The user passport. */
    private static UserPassport userPassport;
    
    /** The alipay sign service. */
    private static IAlipaySignService alipaySignService;
    
    private static WechatCouponService wechatCouponService;
    
    private static ThunderBuyService thunderBuyClientService;
    
    private static NewUserCouponService newUserCouponClientService;
    
    private static AppConfigService appConfigClientService;
    
    private static IOrderRedService orderRedService;
    
    private static IDailyBuyService dailyBuyService;
    
    private static CurtainAdvertisementService curtainADClientService;
    
    /** * 吃货账单 */
    private static IFoodieBillService foodieBillHedwService;
    
    private static CategoryAdClientService categoryAdClientService;
    /**     *      */
    private static MapsFrontService mapsFrontClientService;
    
    private static HomePageGameService homePageGameClientService;
    
    private static ICutService cutClientService;
    
//    private static IJpegImageService jpegImageClientService;
    /**摇一摇游戏接口*/
    private static IGameService gameService;
    
    private static DevicecodeABService devicecodeABClientService;
    /**生命树游戏接口*/
    private static ITreeService treeService;
    /**促销游戏接口*/
    private static IPromotionGameService promotionGameService;
    
    private static AdClientService adClientService;
    /**deeplink 第三方app启动1号店app*/
    private static IDeeplinkService deeplinkClientService;
    /**首页类目接口*/
    private static INavigationCategoryService navigationCategoryService;
    //微信扫码接口
    private static IScanService scanService;
    /**App标签动态下发接口*/
    private static IAppTagService appTagClientService;
    
    /**
     * 主会场
     */
    private static CmsNativeService cmsNativeService;
    
    /**
     * APP动画
     */
    private static AppAnimationService appAnimationClientService;
    
    /**
     * 调查问卷
     */
    private static SurveyQuestionaireService surveyQuestionaireService;
    
    /**
     * 设备激活 反作弊数据采集
     */
    private static AppActivationService appActivationService;
    
    private static AppIndexService appIndexService;
    
    /**
     * app端购物车促销进度显示
     */
    private static AppCartService appCartService;
    
    /**
     * venus测试https请求
     */
    private static VenusHttpsCheckService venusHttpsCheckService;
    
    /**
     * app购物清单
     */
    private static ChecklistService checklistService;
    
    
    //英文app
    private static EngAdClientService engAdClientService;
    
    // 描杀队列
    private static SeckillQueueClientService seckillQueueClientService;
    
    //口令接口
    private static ICommandService commandService;
    
    //领券中心
    private static IVoucherService voucherService;
    
    
    private static AdIndexService adIndexService;

    //爱上新频道页
    private static NewFavoriteService newFavoriteService;
    
    //耍大牌频道页
    private static BigNameService bigNameService;
    
    //全球进口频道
    private static GlobalImportProductService globalImportProductService;
    
    //品质厨房频道
    private static QualityKitchenService qualityKitchenService;
    
    //第二首页
    private static ExtIndexService extIndexService;
    //第二首页扩展配置
    private static ExtConfigService extConfigService;
    //城市精选首页
    private static CityIndexService cityIndexService;
    // 城市精选首页排行榜
    private static PmsRankService pmsRankService;    
    // 城市精选频道落地页
    private static CityChannelPageService cityChannelPageService;
    
    static{
    	try {
    		mobileCouponClientService = (IMobileCouponFacadeService)CentralMobileClientSpringBeanProxy.getBean("mobileCouponClientService");
    		shareCouponClientService = (IShareCouponService)CentralMobileClientSpringBeanProxy.getBean("shareCouponClientService");
    		rewardClientService = (IRewardService)CentralMobileClientSpringBeanProxy.getBean("rewardClientService");
    		productSignClientService = (IProductSignService)CentralMobileClientSpringBeanProxy.getBean("productSignClientService");
    		lotteryTicketsClientService = (ILotteryTicketService)CentralMobileClientSpringBeanProxy.getBean("lotteryTicketsClientService");
    		appPushClientService = (AppPushClientService)CentralMobileClientSpringBeanProxy.getBean("appPushClientService");
    		mobileUserClientService = (MobileUserClientService) CentralMobileClientSpringBeanProxy.getBean("mobileUserClientService");
    		weChatClientService = (WeChatClientService) CentralMobileClientSpringBeanProxy.getBean("weChatClientService");
    		shopBrandClientService = (ShopBrandClientService)CentralMobileClientSpringBeanProxy.getBean("shopBrandClientService");
    		rockClientService = (RockClientService)CentralMobileClientSpringBeanProxy.getBean("rockClientService");
    		advertisementShareClientService = (AdvertisementShareClientService) CentralMobileClientSpringBeanProxy.getBean("advertisementShareClientService");
    		anniversaryRedPacketClientService = (AnniversaryRedPacketClientService) CentralMobileClientSpringBeanProxy.getBean("anniversaryRedPacketClientService");
    		biVisualClientService = (BIVisualClientService)CentralMobileClientSpringBeanProxy.getBean("biVisualClientService");
    		homePageClientService = (HomePageService)CentralMobileClientSpringBeanProxy.getBean("homePageClientService");
    		updateAwardClientService = (UpdateAwardService)CentralMobileClientSpringBeanProxy.getBean("updateAwardClientService");
    		wl2ClientService = (IWl2Service) CentralMobileClientSpringBeanProxy.getBean("wl2ClientService");
    		precisionHomePageADClientService = (IPrecisionHomePageService) CentralMobileClientSpringBeanProxy.getBean("precisionHomePageADClientService");
    		mobileProfileService = (MobileProfileService) CentralMobileClientSpringBeanProxy.getBean("mobileProfileService");
    		alipayService = (AlipayService)CentralMobileClientSpringBeanProxy.getBean("alipayService");
    		downloadPageClientService= (IDownloadPageService) CentralMobileClientSpringBeanProxy.getBean("downloadPageClientService");
			userClientService = (UserFacadeService) CentralMobileClientSpringBeanProxy.getBean("userClientService");
			productService = (ProductService) CentralMobileClientSpringBeanProxy.getBean("productClientService");
			systemService = (SystemService) CentralMobileClientSpringBeanProxy.getBean("systemFacadeService");
			payPreService = (IPayPreService) CentralMobileClientSpringBeanProxy.getBean("payPreClientService");
			homeService = (HomeService) CentralMobileClientSpringBeanProxy.getBean("homeclientService");
			promotionService = (PromotionService)CentralMobileClientSpringBeanProxy.getBean("promotionService");
			couponClientService = (ICouponService)CentralMobileClientSpringBeanProxy.getBean("couponMobileClientService");
			flashPurchaseService = (FlashPurchaseService)CentralMobileClientSpringBeanProxy.getBean("flashPurchaseClientService");
			messageCenterService = (MessageCenterService) CentralMobileClientSpringBeanProxy.getBean("messageCenterClientService");
			pushMessageStatisticsService = (IPushMessageStatisticsService) CentralMobileClientSpringBeanProxy.getBean("pushMessageStatisticsClientService");
		    feedbackService = (FeedbackService) CentralMobileClientSpringBeanProxy.getBean("feedbackService");
		    seckillClientService = (SeckillProductService) CentralMobileClientSpringBeanProxy.getBean("seckillClientService");
		    scratchService = (ScratchService) CentralMobileClientSpringBeanProxy.getBean("scratchService");
		    pushService = (PushService) CentralMobileClientSpringBeanProxy.getBean("pushClientService");
		    apolloPromotionService = (IApolloPromotionService) CentralMobileClientSpringBeanProxy.getBean("apolloPromotionClientService");
			intergralWallService = (IintergralWallService) CentralMobileClientSpringBeanProxy.getBean("intergralWallClientService");
			questionnaireService = (QuestionnaireService) CentralMobileClientSpringBeanProxy.getBean("questionnaireClientService");
			monkeyService = (MonkeyService) CentralMobileClientSpringBeanProxy.getBean("monkeyClientService");
			miracleService = (MiracleService) CentralMobileClientSpringBeanProxy.getBean("miracleService");
			userPassport = (UserPassport) CentralMobileClientSpringBeanProxy.getBean("userPassport");
			alipaySignService = (IAlipaySignService)CentralMobileClientSpringBeanProxy.getBean("alipaySignService");
			redShareClientService = (RedShareClientService)CentralMobileClientSpringBeanProxy.getBean("redShareClientService");
			wechatCouponService = (WechatCouponService)CentralMobileClientSpringBeanProxy.getBean("weChatCouponClientService");
			thunderBuyClientService = (ThunderBuyService)CentralMobileClientSpringBeanProxy.getBean("thunderBuyClientService");
			newUserCouponClientService = (NewUserCouponService)CentralMobileClientSpringBeanProxy.getBean("newUserCouponClientService");
			appConfigClientService = (AppConfigService)CentralMobileClientSpringBeanProxy.getBean("appConfigClientService");
			orderRedService = (IOrderRedService)CentralMobileClientSpringBeanProxy.getBean("orderRedClientService");
			dailyBuyService = (IDailyBuyService)CentralMobileClientSpringBeanProxy.getBean("dailyBuyClientService");
			curtainADClientService = (CurtainAdvertisementService)CentralMobileClientSpringBeanProxy.getBean("curtainADClientService");
			foodieBillHedwService = (IFoodieBillService)CentralMobileClientSpringBeanProxy.getBean("foodieBillHedwService");
			categoryAdClientService = (CategoryAdClientService)CentralMobileClientSpringBeanProxy.getBean("categoryAdClientService");
			mapsFrontClientService = (MapsFrontService)CentralMobileClientSpringBeanProxy.getBean("mapsFrontClientService");
			homePageGameClientService = (HomePageGameService)CentralMobileClientSpringBeanProxy.getBean("homePageGameClientService");
			cutClientService  = (ICutService)CentralMobileClientSpringBeanProxy.getBean("cutClientService");
//			jpegImageClientService  = (IJpegImageService)CentralMobileClientSpringBeanProxy.getBean("jpegImageClientService");
			gameService = (IGameService)CentralMobileClientSpringBeanProxy.getBean("gameClientService");
			devicecodeABClientService = (DevicecodeABService)CentralMobileClientSpringBeanProxy.getBean("devicecodeABClientService");
			treeService = (ITreeService)CentralMobileClientSpringBeanProxy.getBean("treeClientService");
			adClientService = (AdClientService)CentralMobileClientSpringBeanProxy.getBean("adClientService");
			promotionGameService = (IPromotionGameService)CentralMobileClientSpringBeanProxy.getBean("promotionGameClientService");
			deeplinkClientService = (IDeeplinkService)CentralMobileClientSpringBeanProxy.getBean("deeplinkClientService");
			navigationCategoryService = (INavigationCategoryService)CentralMobileClientSpringBeanProxy.getBean("navigationCategoryClientService");
			scanService = (IScanService)CentralMobileClientSpringBeanProxy.getBean("scanClientService");
			appTagClientService = (IAppTagService)CentralMobileClientSpringBeanProxy.getBean("appTagClientService");
			cmsNativeService = (CmsNativeService)CentralMobileClientSpringBeanProxy.getBean("cmsNativeClientService");
			appAnimationClientService = (AppAnimationService)CentralMobileClientSpringBeanProxy.getBean("appAnimationClientService");
			surveyQuestionaireService = (SurveyQuestionaireService)CentralMobileClientSpringBeanProxy.getBean("surveyQuestionaireClientService");
			appActivationService = (AppActivationService)CentralMobileClientSpringBeanProxy.getBean("appActivationClientService");
			appIndexService = (AppIndexService)CentralMobileClientSpringBeanProxy.getBean("appIndexClientService");
			appCartService = (AppCartService)CentralMobileClientSpringBeanProxy.getBean("appCartClientService");
			venusHttpsCheckService = (VenusHttpsCheckService)CentralMobileClientSpringBeanProxy.getBean("venusHttpsCheckServiceHessianCall");
			checklistService = (ChecklistService)CentralMobileClientSpringBeanProxy.getBean("checklistClientService");
			engAdClientService = (EngAdClientService)CentralMobileClientSpringBeanProxy.getBean("engAdClientService");
			seckillQueueClientService = (SeckillQueueClientService)CentralMobileClientSpringBeanProxy.getBean("seckillQueueClientService");
			commandService = (ICommandService)CentralMobileClientSpringBeanProxy.getBean("commandClientService");
			voucherService = (IVoucherService)CentralMobileClientSpringBeanProxy.getBean("voucherClientService");
			adIndexService = (AdIndexService)CentralMobileClientSpringBeanProxy.getBean("adIndexClientService");
			newFavoriteService = (NewFavoriteService)CentralMobileClientSpringBeanProxy.getBean("newFavoriteClientService");
			bigNameService = (BigNameService)CentralMobileClientSpringBeanProxy.getBean("bigNameClientService");
			globalImportProductService = (GlobalImportProductService)CentralMobileClientSpringBeanProxy.getBean("globalImportProductClientService");
			qualityKitchenService = (QualityKitchenService)CentralMobileClientSpringBeanProxy.getBean("qualityKitchenClientService");
			extIndexService = (ExtIndexService)CentralMobileClientSpringBeanProxy.getBean("extIndexClientService");
			extConfigService = (ExtConfigService)CentralMobileClientSpringBeanProxy.getBean("extConfigClientService");
			cityIndexService = (CityIndexService)CentralMobileClientSpringBeanProxy.getBean("cityIndexClientService");
			pmsRankService = (PmsRankService) CentralMobileClientSpringBeanProxy.getBean("pmsRankClientService");
			cityChannelPageService = (CityChannelPageService)CentralMobileClientSpringBeanProxy.getBean("cityChannelPageClientService");
    	} catch (Exception e) {
			e.printStackTrace();
		}
    }
    
	public static CityIndexService getCityIndexService() {
		return cityIndexService;
	}

	/**
     * Gets the mobile coupon client service.
     *
     * @return the mobile coupon client service
     */
    public static IMobileCouponFacadeService getMobileCouponClientService() {
		return mobileCouponClientService;
	}

	/**
	 * Gets the share coupon client service.
	 *
	 * @return the share coupon client service
	 */
	public static IShareCouponService getShareCouponClientService() {
		return shareCouponClientService;
	}
    
    /**
     * Gets the reward client service.
     *
     * @return the reward client service
     */
    public static IRewardService getRewardClientService() {
		return rewardClientService;
	}

	/**
	 * Gets the product sign client service.
	 *
	 * @return the product sign client service
	 */
	public static IProductSignService getProductSignClientService() {
		return productSignClientService;
	}

	/**
	 * Gets the lottery tickets client service.
	 *
	 * @return the lottery tickets client service
	 */
	public static ILotteryTicketService getLotteryTicketsClientService() {
		return lotteryTicketsClientService;
	}

	/**
	 * Gets the app push client service.
	 *
	 * @return the app push client service
	 */
	public static AppPushClientService getAppPushClientService() {
		return appPushClientService;
	}

	/**
	 * Gets the mobile user client service.
	 *
	 * @return the mobile user client service
	 */
	public static MobileUserClientService getMobileUserClientService() {
		return mobileUserClientService;
	}

	/**
	 * Gets the we chat client service.
	 *
	 * @return the we chat client service
	 */
	public static WeChatClientService getWeChatClientService() {
		return weChatClientService;
	}

	/**
	 * Gets the shop brand client service.
	 *
	 * @return the shop brand client service
	 */
	public static ShopBrandClientService getShopBrandClientService() {
		return shopBrandClientService;
	}

	/**
	 * Gets the rock client service.
	 *
	 * @return the rock client service
	 */
	public static RockClientService getRockClientService() {
		return rockClientService;
	}

    /**
     * Gets the advertisement share client service.
     *
     * @return the advertisement share client service
     */
    public static AdvertisementShareClientService getAdvertisementShareClientService() {
        return advertisementShareClientService;
    }

    /**
     * Gets the anniversary red packet client service.
     *
     * @return the anniversary red packet client service
     */
    public static AnniversaryRedPacketClientService getAnniversaryRedPacketClientService() {
        return anniversaryRedPacketClientService;
    }
    
	/**
	 * Gets the bi visual client service.
	 *
	 * @return the bi visual client service
	 */
	public static BIVisualClientService getBiVisualClientService() {
		return biVisualClientService;
	}
	
	/**
	 * Gets the home page client service.
	 *
	 * @return the home page client service
	 */
	public static HomePageService getHomePageClientService() {
		return homePageClientService;
	}

	/**
	 * Gets the update award client service.
	 *
	 * @return the update award client service
	 */
	public static UpdateAwardService getUpdateAwardClientService() {
		return updateAwardClientService;
	}

	/**
	 * Gets the red share client service.
	 *
	 * @return the red share client service
	 */
	public static IRedShareService getRedShareClientService() {
		return redShareClientService;
	}

	/**
	 * Gets the wl2 client service.
	 *
	 * @return the wl2 client service
	 */
	public static IWl2Service getWl2ClientService() {
		return wl2ClientService;
	}

	/**
	 * Gets the precision home page ad client service.
	 *
	 * @return the precision home page ad client service
	 */
	public static IPrecisionHomePageService getPrecisionHomePageADClientService() {
		return precisionHomePageADClientService;
	}

	/**
	 * Gets the mobile profile service.
	 *
	 * @return the mobile profile service
	 */
	public static MobileProfileService getMobileProfileService() {
		return mobileProfileService;
	}

	/**
	 * Gets the alipay service.
	 *
	 * @return the alipay service
	 */
	public static AlipayService getAlipayService() {
		return alipayService;
	}

	/**
	 * Gets the download page client service.
	 *
	 * @return the download page client service
	 */
	public static IDownloadPageService getDownloadPageClientService() {
		return downloadPageClientService;
	}
	
	/**
	 * Gets the user client service.
	 *
	 * @return the user client service
	 */
	public static UserFacadeService getUserClientService() {
		return userClientService;
	}
	

	/**
	 * Gets the product service.
	 *
	 * @return the product service
	 */
	public static ProductService getProductService() {
		return productService;
	}	
	
	/**
	 * Gets the system service.
	 *
	 * @return the system service
	 */
	public static SystemService getSystemService() {
		return systemService;
	}
	

	/**
	 * Gets the pay pre service.
	 *
	 * @return the pay pre service
	 */
	public static IPayPreService getPayPreService(){
		return payPreService;
	}
   
	/**
	 * Gets the home service.
	 *
	 * @return the home service
	 */
	public static HomeService getHomeService() {
		return homeService;
	}


	/**
	 * Gets the promotion service.
	 *
	 * @return the promotion service
	 */
	public static PromotionService getPromotionService() {
		return promotionService;
	}

	/**
	 * Gets the coupon client service.
	 *
	 * @return the coupon client service
	 */
	public static ICouponService getCouponClientService() {
		return couponClientService;
	}
	
	/**
	 * Gets the flash purchase service.
	 *
	 * @return the flash purchase service
	 */
	public static FlashPurchaseService getFlashPurchaseService() {
		return flashPurchaseService;
	}
	
	/**
	 * Gets the message center service.
	 *
	 * @return the message center service
	 */
	public static MessageCenterService getMessageCenterService(){
	    return messageCenterService;
	}
	
	/**
	 * Gets the push message statistics service.
	 *
	 * @return the push message statistics service
	 */
	public static IPushMessageStatisticsService getPushMessageStatisticsService(){
	    return pushMessageStatisticsService;
	}

	/**
	 * Gets the feedback service.
	 *
	 * @return the feedback service
	 */
	public static FeedbackService getFeedbackService() {
		return feedbackService;
	}
	
	/**
	 * Gets the seckill client service.
	 *
	 * @return the seckill client service
	 */
	public static SeckillProductService getSeckillClientService() {
	    return seckillClientService;
	}

	/**
	 * Gets the scratch service.
	 *
	 * @return the scratch service
	 */
	public static ScratchService getScratchService() {
		return scratchService;
	}

	/**
	 * Gets the push service.
	 *
	 * @return the push service
	 */
	public static PushService getPushService(){
	    return pushService;
	}
	
	/**
	 * Gets the apollo promotion service.
	 *
	 * @return the apollo promotion service
	 */
	public static IApolloPromotionService getApolloPromotionService() {
		return apolloPromotionService;
	}

	/**
	 * Gets the intergral wall service.
	 *
	 * @return the intergral wall service
	 */
	public static IintergralWallService getIntergralWallService() {
		return intergralWallService;
	}

	/**
	 * Gets the questionnaire service.
	 *
	 * @return the questionnaire service
	 */
	public static QuestionnaireService getQuestionnaireService() {
		return questionnaireService;
	}

	/**
	 * Gets the monkey service.
	 *
	 * @return the monkey service
	 */
	public static MonkeyService getMonkeyService() {
		return monkeyService;
	}

	/**
	 * Gets the miracle service.
	 *
	 * @return the miracle service
	 */
	public static MiracleService getMiracleService() {
		return miracleService;
	}
	
	/**
	 * Gets the user passport service.
	 *
	 * @return the user passport service
	 */
	public static UserPassport getUserPassportService() {
		return userPassport;
	}

	/**
	 * Gets the alipay sign service.
	 *
	 * @return the alipay sign service
	 */
	public static IAlipaySignService getAlipaySignService() {
		return alipaySignService;
	}

	public static WechatCouponService getWechatCouponService() {
		return wechatCouponService;
	}

	public static ThunderBuyService getThunderBuyClientService() {
		return thunderBuyClientService;
	}

	public static NewUserCouponService getNewUserCouponClientService() {
		return newUserCouponClientService;
	}
	
	public static AppConfigService getAppConfigClientService() {
		return appConfigClientService;
	}

	public static IOrderRedService getOrderRedService() {
		return orderRedService;
	}

	public static IDailyBuyService getDailyBuyService() {
		return dailyBuyService;
	}
	
	public static IDailyBuyService getDailyBuyService(Long timeout) {
		HedwigClientFactoryBean hf = (HedwigClientFactoryBean)CentralMobileClientSpringBeanProxy.getBean("&dailyBuyHessianCall");
		hf.setTimeout(timeout);
		return dailyBuyService;
	}

	public static CurtainAdvertisementService getCurtainADClientService() {
		return curtainADClientService;
	}

	public static IFoodieBillService getFoodieBillHedwService() {
		return foodieBillHedwService;
	}

	public static CategoryAdClientService getCategoryAdClientService() {
		return categoryAdClientService;
	}

	public static MapsFrontService getMapsFrontClientService() {
		return mapsFrontClientService;
	}

	public static HomePageGameService getHomePageGameClientService() {
		return homePageGameClientService;
	}

    public static ICutService getCutClientService() {
        return cutClientService;
    }

        /**
         * Getter method for property <tt>jpegImageService</tt>.
         * 
         * @return property value of jpegImageService
         */
//    public static IJpegImageService getJpegImageClientService() {
//        return jpegImageClientService;
//    }

	public static IGameService getGameService() {
		return gameService;
	}

	public static DevicecodeABService getDevicecodeABClientService() {
		return devicecodeABClientService;
	}

	public static ITreeService getTreeService() {
		return treeService;
	}

	public static AdClientService getAdClientService() {
		return adClientService;
	}

	public static IPromotionGameService getPromotionGameService() {
		return promotionGameService;
	}

	public static IDeeplinkService getDeeplinkClientService() {
		return deeplinkClientService;
	}

	public static INavigationCategoryService getNavigationCategoryService() {
		return navigationCategoryService;
	}

    public static IScanService getScanService() {
        return scanService;
    }

	public static IAppTagService getAppTagClientService() {
		return appTagClientService;
	}

	public static CmsNativeService getCmsNativeService() {
		return cmsNativeService;
	}

	public static AppAnimationService getAppAnimationClientService() {
		return appAnimationClientService;
	}
	
	public static SurveyQuestionaireService getSurveyQuestionaireClientService() {
		return surveyQuestionaireService;
	}
	
	public static AppActivationService getAppActivationClientService() {
		return appActivationService;
	}

	public static AppIndexService getAppIndexService() {
		return appIndexService;
	}

	public static AppCartService getAppCartService() {
		return appCartService;
	}
	
	public static VenusHttpsCheckService getVenusHttpsCheckService() {
		return venusHttpsCheckService;
	}

	public static ChecklistService getChecklistService() {
		return checklistService;
	}
	
	public static EngAdClientService getEngAdClientService() {
		return engAdClientService;
	}
	
	public static SeckillQueueClientService getSeckillQueueClientService() {
		return seckillQueueClientService;
	}
	
	public static ICommandService getCommandService(){
		return commandService;
	}

	public static IVoucherService getVoucherService(){
		return voucherService;
	}
	
	public static AdIndexService getAdIndexService() {
		return adIndexService;
	}
	
	public static NewFavoriteService getNewFavoriteService() {
		return newFavoriteService;
	}

	public static BigNameService getBigNameService() {
		return bigNameService;
	}
	
	public static GlobalImportProductService getGlobalImportProductService() {
		return globalImportProductService;
	}
	
	public static QualityKitchenService getQualityKitchenService() {
		return qualityKitchenService;
	}

	public static ExtIndexService getExtIndexService() {
		return extIndexService;
	}

	public static ExtConfigService getExtConfigService() {
		return extConfigService;
	}
	
	public static PmsRankService getPmsRankService() {
		return pmsRankService;
	}
	
	public static CityChannelPageService getCityChannelPageService() {
		return cityChannelPageService;
	}
	
}
