/**
 * www.yhd.com-402 Inc.
 * Copyright (c) 2008-2015 All Rights Reserved.
 */
package com.yihaodian.mobile.hedwig.client.service.jpegimg;

import java.util.List;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.image.IJpegImageService;

/**
 * 
 * @author huangqihui
 * @version $Id: JpegImageClientServiceImpl.java, v 0.1 2015年9月10日 上午10:58:36 huangqihui Exp $
 */
public class JpegImageClientService implements IJpegImageService {
    
    private IJpegImageService jpegImageHessianCall ;
    
    /** 
     * @see com.yihaodian.mobile.service.facade.image.IJpegImageService#findHeads(java.lang.String)
     */
    @Override
    public Result findHeads(String jsonArr) {
        return getJpegImageHessianCall().findHeads(jsonArr);
    }

    /** 
     * @see com.yihaodian.mobile.service.facade.image.IJpegImageService#findBodys16(java.util.List)
     */
    @Override
    public Result findBodys16(List<String> url) {
        return getJpegImageHessianCall().findBodys16(url);
    }

    /** 
     * @see com.yihaodian.mobile.service.facade.image.IJpegImageService#findBodysBase64(java.util.List)
     */
    @Override
    public Result findBodysBase64(List<String> url) {
        return getJpegImageHessianCall().findBodysBase64(url);
    }

        /**
         * Getter method for property <tt>jpegImageHessianCall</tt>.
         * 
         * @return property value of jpegImageHessianCall
         */
    public IJpegImageService getJpegImageHessianCall() {
        return jpegImageHessianCall;
    }

        /**
         * Setter method for property <tt>jpegImageHessianCall</tt>.
         * 
         * @param jpegImageHessianCall value to be assigned to property jpegImageHessianCall
         */
    public void setJpegImageHessianCall(IJpegImageService jpegImageHessianCall) {
        this.jpegImageHessianCall = jpegImageHessianCall;
    }

}
