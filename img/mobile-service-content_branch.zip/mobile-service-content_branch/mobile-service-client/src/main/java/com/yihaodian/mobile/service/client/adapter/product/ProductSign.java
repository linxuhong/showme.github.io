/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.product;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.product.spi.IProductSignService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class ProductSign.
 */
public class ProductSign extends BaseDiapatchService {
	
	/**
	 * Gets the interested products by user.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the interested products by user
	 */
	public RtnInfo getInterestedProductsByUser(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		try {
		    
            if (!isLogined) {
                return RtnInfo.TokenErrWlRtnInfo();
            }
		    
			IProductSignService service = CentralMobileServiceHandler.getProductSignClientService();
			Long productId =bizInfo.get("productid")==null ? 0l : Long.valueOf(bizInfo.get("productid"));
			Long pmId = bizInfo.get("pmid")==null ? 0l : Long.valueOf(bizInfo.get("pmid"));
			Long provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
			Long merchantId = bizInfo.get("merchantid")==null ? 0l : Long.valueOf(bizInfo.get("merchantid"));
			Integer productNum = bizInfo.get("productnum")==null ? 0 : Integer.valueOf(bizInfo.get("productnum"));
			
			String cityid = context.getRequestInfo().getCityId();
			
			Result re = service.getInterestedProductsByUser(Long.valueOf(context.getCurrentUserId()), context.getRequestInfo().getClientInfo().getTraderName() , context.getRequestInfo().getClientInfo().getClientAppVersion(), productId, pmId, provinceId, merchantId, productNum, cityid);
			
			return getRtnInfo(re);
		} catch (Exception e) {
			return null;
		}
	}
}
