/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.rock;

import java.io.ObjectInputStream.GetField;
import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.service.rock.RockClientService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class RockService.
 */
public class RockService extends BaseDiapatchService {
	
	/**
	 * Gets the rock promotion info.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rock promotion info
	 */
	public RtnInfo getRockPromotionInfo(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		RockClientService service = CentralMobileServiceHandler
				.getRockClientService();
		String activityId = bizInfo.get("activityid");
		RtnInfo rtn = validateNumber(activityId);
		if(rtn!= null){
			return rtn;
		}
		 String userIdStr = context.getCurrentUserId();
		 rtn = validateNumber(userIdStr);
		if(rtn!=null){
			 return rtn;
		 }
		 Long userId  = Long.parseLong(userIdStr);
		 String provinceIdStr = context.getRequestInfo().getProvinceId();
		 rtn = validateProvinceId(provinceIdStr);
		 if(rtn!=null){
			 return rtn;
		 }
		 Integer provinceId = Integer.parseInt(provinceIdStr);
		 
		 ResultModel list = service.getRockPromotionInfo(activityId,userId,provinceId);

		return RtnInfo.RightWlRtnInfo(list);
	}
	
	/**
	 * Gets the winners list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the winners list
	 */
	public RtnInfo getWinnersList(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		RockClientService service = CentralMobileServiceHandler
				.getRockClientService();
		String activityId = bizInfo.get("activityid");
		if (StringUtil.isEmpty(activityId)) {
			return RtnInfo.ParameterErrRtnInfo("activityId is null");
		}
		Result re = service.getWinnersList(activityId);

		return getRtnInfo(re);
	}
	
	/**
	 * Do shaking.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo doShaking(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		RockClientService service = CentralMobileServiceHandler.getRockClientService();
		String deviceToken = bizInfo.get("devicetoken");
		if (StringUtil.isEmpty(deviceToken)) {
			return RtnInfo.ParameterErrRtnInfo("deviceToken is null");
		}
		String activityId = bizInfo.get("activityid");
		if (StringUtil.isEmpty(activityId)) {
			return RtnInfo.ParameterErrRtnInfo("activityId is null");
		}
		String explodeSecIndex = bizInfo.get("explodesecindex");
		RtnInfo rtn = validateNumber(explodeSecIndex);
		if (rtn != null) {
			return rtn;
		}
		 String userIdStr = context.getCurrentUserId();
		 rtn = validateNumber(userIdStr);
		if(rtn!=null){
			 return rtn;
		 }
		 Long userId  = Long.parseLong(userIdStr);
		Result re = service.doShaking(userId,
				activityId, Integer.valueOf(explodeSecIndex), context
						.getRequestInfo().getClientInfo().getTraderName(),
				deviceToken,
				Integer.valueOf(context.getRequestInfo().getProvinceId()));
		return getRtnInfo(re);
	}
	
	/**
	 * Accept award.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo acceptAward(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		RockClientService service = CentralMobileServiceHandler
				.getRockClientService();
		String deviceToken = bizInfo.get("devicetoken");
		if (StringUtil.isEmpty(deviceToken)) {
			return RtnInfo.ParameterErrRtnInfo("deviceToken is null");
		}
		String activityId = bizInfo.get("activityid");
		if (StringUtil.isEmpty(activityId)) {
			return RtnInfo.ParameterErrRtnInfo("activityId is null");
		}
		String awardId = bizInfo.get("awardid");
		if (StringUtil.isEmpty(awardId)) {
			return RtnInfo.ParameterErrRtnInfo("awardId is null");
		}
		String isDiscard = bizInfo.get("isdiscard");
		RtnInfo rtn = validateNumber(isDiscard);
		if (rtn != null) {
			return rtn;
		}
		String explodeSecIndex = bizInfo.get("explodesecindex");
		rtn = validateNumber(explodeSecIndex);
		if (rtn != null) {
			return rtn;
		}
		 String userIdStr = context.getCurrentUserId();
		 rtn = validateNumber(userIdStr);
		if(rtn!=null){
			 return rtn;
		 }
		Long userId = Long.parseLong(userIdStr);
		Result re = service.acceptAward(
				userId, activityId, awardId,
				Integer.valueOf(explodeSecIndex), Integer.valueOf(isDiscard),
				Integer.valueOf(context.getRequestInfo().getProvinceId()),
				context.getRequestInfo().getClientInfo().getTraderName(),
				deviceToken);

		return getRtnInfo(re);
	}
	
	/**
	 * Gets the users for push.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the users for push
	 */
	public RtnInfo getUsersForPush(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		RockClientService service = CentralMobileServiceHandler
				.getRockClientService();
		String start = bizInfo.get("startminutetime");
		if (StringUtil.isEmpty(start)) {
			return RtnInfo.ParameterErrRtnInfo("startminutetime is null");
		}
		String step = bizInfo.get("step");
		if (StringUtil.isEmpty(step)) {
			return RtnInfo.ParameterErrRtnInfo("step is null");
		}
		Result re = service.getUsersForPush(start, step);

		return getRtnInfo(re);
	}
	
	/**
	 * Gets the new time start.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the new time start
	 */
	public RtnInfo getNewTimeStart(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		RockClientService service = CentralMobileServiceHandler
				.getRockClientService();
		String index = bizInfo.get("newsecindex");
		if (StringUtil.isEmpty(index)) {
			return RtnInfo.ParameterErrRtnInfo("newsecindex is null");
		}
		String tc = bizInfo.get("trrigercount");
		if (StringUtil.isEmpty(tc)) {
			return RtnInfo.ParameterErrRtnInfo("trrigercount is null");
		}
		Result re = service.getNewTimeStart(index, tc);

		return getRtnInfo(re);
	}
}
