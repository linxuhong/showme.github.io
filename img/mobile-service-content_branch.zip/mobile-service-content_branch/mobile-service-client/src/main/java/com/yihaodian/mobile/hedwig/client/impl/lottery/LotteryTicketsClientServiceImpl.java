package com.yihaodian.mobile.hedwig.client.impl.lottery;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.lottery.spi.ILotteryTicketService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class LotteryTicketsClientServiceImpl implements ILotteryTicketService {

	private ILotteryTicketService lotteryTicketsHessianCall;
	
	@Override
	public Result getLotteryTicketUrlFor500(String userToken,
			String traderName, Integer type) {
		return lotteryTicketsHessianCall.getLotteryTicketUrlFor500(userToken, traderName, type);
	}


    @Override
    public Result getLotteryTicketUrlFor500(Long userId, String traderName, Integer type ,Trader trader) {
        return lotteryTicketsHessianCall.getLotteryTicketUrlFor500(userId, traderName, type , trader);
    }

    public ILotteryTicketService getLotteryTicketsHessianCall() {
        return lotteryTicketsHessianCall;
    }
    
    public void setLotteryTicketsHessianCall(
                                             ILotteryTicketService lotteryTicketsHessianCall) {
        this.lotteryTicketsHessianCall = lotteryTicketsHessianCall;
    }
}
