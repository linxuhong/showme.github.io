/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.gson.reflect.TypeToken;
import com.yihaodian.mobile.backend.model.CategoryBrand;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MobileProfileService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.home.ShareContentVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnCodes;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class MobileProfileDispaterService.
 * @author zuodeng
 */
public class MobileProfileDispaterService extends BaseDiapatchService{
	
	/** The logger. */
	private Logger logger = Logger.getLogger(MobileProfileDispaterService.class);
	
	/**
	 * Gets the view profile.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the view profile
	 */
	public RtnInfo getViewProfile(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String str = null;
		try{
			MobileProfileService mobileProfileService = CentralMobileServiceHandler.getMobileProfileService();
			Trader trader = getTraderFromContext(context);
			String linkIdStr = bizInfo.get("linkid");
			String provinceIdStr = context.getRequestInfo().getProvinceId();
			RtnInfo rtnInfo = validateProvinceId(provinceIdStr);
			if(rtnInfo != null){
				return rtnInfo;
			}
			
			Long provinceId = Long.parseLong(provinceIdStr);
			rtnInfo = validateNumber(linkIdStr);
			if(rtnInfo != null){
				return rtnInfo;
			}
			Long linkId =  Long.parseLong(linkIdStr);
			rtnInfo = vaildateTrader(trader);
			if(rtnInfo == null){
				str = mobileProfileService.getViewProfile(trader,linkId, provinceId);
				rtnInfo = RtnInfo.RightWlRtnInfo(str);
			}
			 return rtnInfo;
		}catch(Exception e){
			logger.error("MobileProfileDispaterService=>getViewProfile error",e);
			return new RtnInfo(RtnCodes.ADAPTER_EXCEPTION,"MobileProfileDispaterService=>getViewProfile error",null);
		}		
	}
	
	/**
	 * Gets the index profile.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the index profile
	 */
	public RtnInfo getIndexProfile(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
//		if(!isLogined){
//			return RtnInfo.TokenErrWlRtnInfo();
//		}
		MobileProfileService mobileProfileService = CentralMobileServiceHandler.getMobileProfileService();
		Trader trader = getTraderFromContext(context);	
		if(trader.getTraderName()==null){
			return RtnInfo.ParameterErrRtnInfo("TraderName is null");
		}
		
		String provinceIdStr = context.getRequestInfo().getProvinceId();		
		if(provinceIdStr==null || provinceIdStr.equals("")){
			return RtnInfo.ParameterErrRtnInfo("provinceId is null");
		}
		if(!provinceIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("provinceId formate error");
		}		
		Long provinceId = Long.parseLong(provinceIdStr);
		String str = mobileProfileService.getIndexProfile(trader, provinceId);
		return RtnInfo.RightWlRtnInfo(str);
	}
	
	/**
	 * Gets the export goods brand.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the export goods brand
	 */
	public RtnInfo getExportGoodsBrand(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		MobileProfileService mobileProfileService = CentralMobileServiceHandler.getMobileProfileService();
		Trader trader = getTraderFromContext(context);
		if(trader.getTraderName()==null){
			return RtnInfo.ParameterErrRtnInfo("TraderName is null");
		}
		String categoryIdStr = bizInfo.get("categoryid");		
		if(categoryIdStr==null || categoryIdStr.equals("")){
			return RtnInfo.ParameterErrRtnInfo("categoryId is null");
		}
		if(!categoryIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("categoryId formate error");
		}						
		Long categoryId = Long.parseLong(categoryIdStr);
		
		String provinceIdStr = context.getRequestInfo().getProvinceId();		
		if(provinceIdStr==null || provinceIdStr.equals("")){
			return RtnInfo.ParameterErrRtnInfo("provinceId is null");
		}
		if(!provinceIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("provinceId formate error");
		}		
		Long provinceId = Long.parseLong(provinceIdStr);
		String str = mobileProfileService.getExportGoodsBrand(trader, categoryId, provinceId);
		return RtnInfo.RightWlRtnInfo(str);
	}
	
	/**
	 * Gets the export goods view.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the export goods view
	 */
	public RtnInfo getExportGoodsView(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String linkId = bizInfo.get("linkid");
		RtnInfo rtn = validateNumber(linkId);
		if (rtn != null) {
			return rtn;
		}
		Trader trader = getTraderFromContext(context);
		Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
		
		MobileProfileService mobileProfileService = CentralMobileServiceHandler.getMobileProfileService();
		String str = mobileProfileService.getExportGoodsView(trader,Long.parseLong(linkId), provinceId);
		List<CategoryBrand> list = (List<CategoryBrand>)GsonUtil.paseToObject(str, new TypeToken<List<CategoryBrand>>(){}.getType());
		return RtnInfo.RightWlRtnInfo(list);
	}
	
	/**
	 * Gets the export goods category.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the export goods category
	 */
	public RtnInfo getExportGoodsCategory(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		MobileProfileService mobileProfileService = CentralMobileServiceHandler.getMobileProfileService();
		Trader trader = getTraderFromContext(context);
		RtnInfo rtnInfo = vaildateTrader(trader);
		if(rtnInfo != null){
			return rtnInfo;
		}
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		rtnInfo = validateProvinceId(provinceIdStr);
		if(rtnInfo == null){
			Long provinceId = Long.parseLong(provinceIdStr);
			String str = mobileProfileService.getExportGoodsCategory(trader, provinceId);
			rtnInfo = RtnInfo.RightWlRtnInfo(str);
		}
		
		return rtnInfo;
	}
	
	/**
	 * Gets the daily one profile.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the daily one profile
	 */
	public RtnInfo getDailyOneProfile(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
		
		MobileProfileService mobileProfileService = CentralMobileServiceHandler.getMobileProfileService();
		String str = mobileProfileService.getDailyOneProfile(trader, provinceId);
		return RtnInfo.RightWlRtnInfo(str);
	}
	
	/**
	 * Gets the calendar detail profile.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the calendar detail profile
	 */
	public RtnInfo getCalendarDetailProfile(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			Trader trader = getTraderFromContext(context);
			Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
			String date = bizInfo.get("date");
			if(StringUtil.isBlank(date)){
				return RtnInfo.ParameterErrRtnInfo("date is null");
			}
			MobileProfileService mobileProfileService = CentralMobileServiceHandler.getMobileProfileService();
			String str = mobileProfileService.getCalendarDetailProfile(trader, provinceId, date);
			return RtnInfo.RightWlRtnInfo(str);
		} catch (Exception e) {
			return RtnInfo.ParameterErrRtnInfo("some pram null!");
		}
	}
	
	/**
	 * Gets the share content.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the share content
	 */
	public RtnInfo getShareContent(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			Trader trader = getTraderFromContext(context);
			if(trader.getTraderName() == null || trader.getTraderName().isEmpty()){
				return RtnInfo.ParameterErrRtnInfo("trader name is empty");
			}
			MobileProfileService service = CentralMobileServiceHandler.getMobileProfileService();
			Long viewId = Long.valueOf(bizInfo.get("viewid"));
			ShareContentVO result = service.getShareContent(trader, viewId);
			return RtnInfo.RightWlRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error :: viewId");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some pram null!");
		}
	}
	/**
	 * 获取晒单活动规则
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getActivityRule(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {			
			String provinceIdStr = context.getRequestInfo().getProvinceId();
			RtnInfo rtn = validateProvinceId(provinceIdStr);
			if(rtn != null){
				return rtn ;
			}
			Long provinceId = Long.parseLong(provinceIdStr);
			Trader trader = getTraderFromContext(context);
			rtn = vaildateTrader(trader);
			if(rtn != null){
				return rtn;
			}
			MobileProfileService service = CentralMobileServiceHandler.getMobileProfileService();
			String result = service.getActivityRule(trader, provinceId);
			return RtnInfo.RightWlRtnInfo(result);
		} catch (NumberFormatException e) {
			logger.error("mobileprifileDispachService = > getActivityRule",e);
			return RtnInfo.ParameterErrRtnInfo("number param format error :: viewId");
		} catch (Exception e2) {
			logger.error("mobileprifileDispachService = > getActivityRule",e2);
			return RtnInfo.ParameterErrRtnInfo("some pram null!");
		}
	}
	public RtnInfo getCalendarProfile(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			Trader trader = getTraderFromContext(context);
			RtnInfo rtn = vaildateTrader(trader);
			if(rtn != null){
				return rtn;
			}
			String provinceIdStr = context.getRequestInfo().getProvinceId();
			 rtn = validateProvinceId(provinceIdStr);
			if(rtn != null){
				return rtn ;
			}
			Long provinceId = Long.parseLong(provinceIdStr);
			MobileProfileService service = CentralMobileServiceHandler.getMobileProfileService();
			String result = service.getCalendarProfile(trader, provinceId);
			return RtnInfo.RightWlRtnInfo(result);
		} catch (NumberFormatException e) {
			logger.error("mobileprifileDispachService = > getCalendarProfile",e);
			return RtnInfo.ParameterErrRtnInfo("number param format error :: viewId");
		} catch (Exception e2) {
			logger.error("mobileprifileDispachService = > getCalendarProfile",e2);
			return RtnInfo.ParameterErrRtnInfo("some pram null!");
		}
	}
	
}
