package com.yihaodian.mobile.hedwig.client.service.voucher;

import java.util.Date;
import java.util.Set;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.voucher.IVoucherService;

public class VoucherClientService implements IVoucherService {
	
	private IVoucherService voucherServiceHessianCall ;
	
	
	public IVoucherService getVoucherServiceHessianCall() {
		return voucherServiceHessianCall;
	}

	public void setVoucherServiceHessianCall(
			IVoucherService voucherServiceHessianCall) {
		this.voucherServiceHessianCall = voucherServiceHessianCall;
	}

	
	
	@Override
	public Result getCategoryList(Long cityId) {
		return voucherServiceHessianCall.getCategoryList(cityId);
	}

	@Override
	public Result getVoucherAds() {
		return voucherServiceHessianCall.getVoucherAds();
	}

	@Override
	public Result getCategoryVouchers(Long userId, Long categoryId,
			boolean isAnonymous) {
		return voucherServiceHessianCall.getCategoryVouchers(userId, categoryId, isAnonymous);
	}

	@Override
	public Result getVoucherByUser(Long userId, Long voucherId, String ip,String validateUserBehaviorRes) {
		return voucherServiceHessianCall.getVoucherByUser(userId, voucherId, ip, validateUserBehaviorRes);
	}

	@Override
	public Result getUserPoint(Long userId) {
		return voucherServiceHessianCall.getUserPoint(userId);
	}

	@Override
	public Result getTreaurePictures(Long userId, Long voucherId, String taskStatus) {
		return voucherServiceHessianCall.getTreaurePictures(userId, voucherId, taskStatus);
	}

	@Override
	public Result updateTaskStatus(Long userId, Long voucherId,	Byte taskStatus, Integer voucherStatus) {
		return voucherServiceHessianCall.updateTaskStatus(userId, voucherId, taskStatus, voucherStatus);
	}

	@Override
	public Result getUserSignInDate(Long userId, Long voucherId) {
		return voucherServiceHessianCall.getUserSignInDate(userId, voucherId);
	}

	@Override
	public Result getVoucherById(Long userId, Long voucherId) {
		return voucherServiceHessianCall.getVoucherById(userId, voucherId);
	}

	@Override
	public Result startTask(Long userId, Long voucherId, Byte taskType) {
		return voucherServiceHessianCall.startTask(userId, voucherId, taskType);
	}

	@Override
	public Result getUserCommentNumber(Long userId, Long voucherId) {
		return voucherServiceHessianCall.getUserCommentNumber(userId, voucherId);
	}

    @Override
    public Set<String> getUserSignDate(Long userId, Date startDate, Date endDate) {
        return voucherServiceHessianCall.getUserSignDate(userId, startDate, endDate);
    }
	

}
