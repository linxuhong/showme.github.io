package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.advertisement.AdService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class AdDispaterService extends BaseDiapatchService{
	 public RtnInfo getHotWords(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		 	RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		 	String userId = null;
		 	if (isLogined) {
				userId = context.getCurrentUserId();
		 	}
		 		Trader trader = getTraderFromContext(context);
			if(rtnInfo != null){
				return rtnInfo;
			}
			String provinceId = context.getRequestInfo().getProvinceId();
			rtnInfo = validateNumber(provinceId);
			if(rtnInfo != null){
				return rtnInfo;
			}
			String pageType = bizInfo.get("pagetype");
			if(StringUtil.isEmpty(pageType)){
				RtnInfo.ParameterErrRtnInfo("pagetype is null");
			}
			String seatType = bizInfo.get("seattype");
			if(StringUtil.isEmpty(seatType)){
				RtnInfo.ParameterErrRtnInfo("seatType is null");
			}
			AdService adService = CentralMobileServiceHandler.getAdClientService();
		 return RtnInfo.RightWlRtnInfo(adService.getHotWords(Integer.valueOf(pageType), Integer.valueOf(seatType), provinceId,trader,userId));
	 }
	 public RtnInfo getHotWordsForCity(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		 	RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		 	String userId = null;
		 	if (isLogined) {
				userId = context.getCurrentUserId();
		 	}
		 		Trader trader = getTraderFromContext(context);
			if(rtnInfo != null){
				return rtnInfo;
			}
			String provinceId = context.getRequestInfo().getProvinceId();
			rtnInfo = validateNumber(provinceId);
			if(rtnInfo != null){
				return rtnInfo;
			}
			String pageType = bizInfo.get("pagetype");
			if(StringUtil.isEmpty(pageType)){
				RtnInfo.ParameterErrRtnInfo("pagetype is null");
			}
			String seatType = bizInfo.get("seattype");
			if(StringUtil.isEmpty(seatType)){
				RtnInfo.ParameterErrRtnInfo("seatType is null");
			}
			AdService adService = CentralMobileServiceHandler.getAdClientService();
		 return RtnInfo.RightWlRtnInfo(adService.getHotWordsForCity(Integer.valueOf(pageType), Integer.valueOf(seatType), provinceId,trader,userId, context.getRequestInfo().getCityId()));
	 }
	 public RtnInfo getPerCenterAd(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		 RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		 	String clientSystem = context.getRequestInfo().getClientInfo().getTraderName();
	 		if(StringUtil.isEmpty(clientSystem)){
	 			RtnInfo.ParameterErrRtnInfo("traderName is null");
	 		}
			if(rtnInfo != null){
				return rtnInfo;
			}
			String provinceId = context.getRequestInfo().getProvinceId();
			rtnInfo = validateNumber(provinceId);
			if(rtnInfo != null){
				return rtnInfo;
			}
			String pageType = bizInfo.get("pagetype");
			if(StringUtil.isEmpty(pageType)){
				RtnInfo.ParameterErrRtnInfo("pagetype is null");
			}
			String seatType = bizInfo.get("seattype");
			if(StringUtil.isEmpty(seatType)){
				RtnInfo.ParameterErrRtnInfo("seatType is null");
			}
			AdService adService = CentralMobileServiceHandler.getAdClientService();
			 return RtnInfo.RightWlRtnInfo(adService.getActPushMessages(Integer.valueOf(pageType), Integer.valueOf(seatType), provinceId, clientSystem));
	 }
	 
}
