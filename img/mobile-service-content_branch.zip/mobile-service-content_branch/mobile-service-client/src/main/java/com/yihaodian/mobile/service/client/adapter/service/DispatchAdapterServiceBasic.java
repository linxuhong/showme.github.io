package com.yihaodian.mobile.service.client.adapter.service;

import java.util.Map;

import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * @author yeliang
 * 
 */
public interface DispatchAdapterServiceBasic {

	public RtnInfo execute(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context);

}
