package com.yihaodian.mobile.service.client.adapter.home;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.home.spi.ExtConfigService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class ExtConfigDispaterService extends BaseDiapatchService{

	public RtnInfo checkAppType(String urlPath, Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		try {
			String cityid = bizInfo.get("cityid");
			if(cityid==null)
			    cityid=context.getRequestInfo().getCityId();
			
			ExtConfigService service = CentralMobileServiceHandler.getExtConfigService();
			ClientInfoVO clientVO = convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid);
			Result result = service.checkAppType(clientVO);
			return getRtnInfo(result);
		} catch (Exception e) {
			return null;
		}
	}
}
