package com.yihaodian.mobile.service.client.push.service.impl;

import java.util.List;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.push.PushService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.push.PushInformationVO;
import com.yihaodian.mobile.vo.wl2.ClientInfo;

/**
 * 推送hedwig客户端service
 * @author zhangwei5
 * @version $Id: PushClientService.java, v 0.1 2014年8月14日 下午1:30:00 zhangwei5 Exp $
 */
public class PushClientService implements PushService {

    private PushService pushServiceHessianCall;
    
    
    
    public void setPushServiceHessianCall(PushService pushServiceHessianCall) {
        this.pushServiceHessianCall = pushServiceHessianCall;
    }

    @Override
    public void messageOpen(Trader trader, Long openTime, Long pageId, Long promotionId,
                            Integer promotionType) {
        pushServiceHessianCall.messageOpen(trader, openTime, pageId, promotionId, promotionType );
    }

    @Override
    public String createAppPushInfo(Trader trader, Long userId) {
        return pushServiceHessianCall.createAppPushInfo(trader, userId);
    }

    @Override
    public void storeUserInfo(Long userId, Trader trader) {
        pushServiceHessianCall.storeUserInfo(userId, trader);
    }

    @Override
    public void messageOpen(Trader trader, Long openTime, Long pageId, Long promotionId,
                            Integer promotionType, Long userId) {
        pushServiceHessianCall.messageOpen(trader, openTime, pageId, promotionId, promotionType, userId);
    }

    @Override
    public void logReporting(Trader trader, Long sendTime, Long userId) {
        pushServiceHessianCall.logReporting(trader, sendTime, userId);
    }

    @Override
    public List<PushInformationVO> getPushInformation(Trader trader, Long userId) {
        return pushServiceHessianCall.getPushInformation(trader, userId);
    }

    @Override
    public Result storeUserPushMapping(Long userId, ClientInfo clientInfo, String deviceToken) {
        return pushServiceHessianCall.storeUserPushMapping(userId, clientInfo, deviceToken);
    }

}
