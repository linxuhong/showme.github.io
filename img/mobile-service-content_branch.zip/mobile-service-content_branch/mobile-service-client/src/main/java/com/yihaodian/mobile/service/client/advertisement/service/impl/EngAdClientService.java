package com.yihaodian.mobile.service.client.advertisement.service.impl;

import java.util.List;

import com.yihaodian.mobile.service.facade.business.advertisement.EngAdService;
import com.yihaodian.mobile.vo.ad.MobEngAds;
import com.yihaodian.mobile.vo.ad.MobEngSource;

public class EngAdClientService implements EngAdService{
	
	private EngAdService engAdServiceHessianCall;

	public EngAdService getEngAdServiceHessianCall() {
		return engAdServiceHessianCall;
	}

	public void setEngAdServiceHessianCall(EngAdService engAdServiceHessianCall) {
		this.engAdServiceHessianCall = engAdServiceHessianCall;
	}

	@Override
	public List<MobEngAds<MobEngSource>> getEnAds(Long provinceId) {
		return engAdServiceHessianCall.getEnAds(provinceId);
	}

	@Override
	public List<MobEngAds<MobEngSource>> getEnAds(Long provinceId,String traderName) {
		return engAdServiceHessianCall.getEnAds(provinceId,traderName);
	}
	
}
