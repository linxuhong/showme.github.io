package com.yihaodian.mobile.service.client.adapter.dailybuy;

import java.util.Map;


import com.alibaba.fastjson.JSON;
import com.yihaodian.mobile.backend.dailybuy.entity.DailyBuyComment;
import com.yihaodian.mobile.backend.dailybuy.vo.DailyBuyCommentInfo;
import com.yihaodian.mobile.backend.dailybuy.vo.DailyBuyCommentVO;
import com.yihaodian.mobile.backend.dailybuy.vo.DailyBuyReplyVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.push.spi.IDailyBuyService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class DailyBuyDispatchService extends BaseDiapatchService {
	

	/**
	 * 主题详情页
	 * @param provinceId
	 * @param topicId
	 * @return
	 */
	public RtnInfo getTopicById(String urlPath, Boolean isLogined,	Map<String, String> bizInfo, AdapterContext context){
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		Long provinceId = null;
		Long topicId = null ;		
		if(context.getRequestInfo() != null){
			Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
			if(!result.isSuccess()){
				return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
			} 
		}
		provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
				
		Result result = valiateGetParams(bizInfo.get("topicid"));
		if(!result.isSuccess()){
			return  RtnInfo.ParameterErrRtnInfo("topicid"+result.getResultDesc());
		} 
		topicId = Long.parseLong(bizInfo.get("topicid"));		
		
		Long userId = null; 
		result = valiateGetParams(context.getCurrentUserId());
		if(result.isSuccess()){
			userId = Long.parseLong(context.getCurrentUserId());
		}
		
		String version= urlPath.substring(urlPath.lastIndexOf("/")+1);
		//取版本号区分 一品堂 一期/二期/三期
		
        if ("v2".equalsIgnoreCase(version))
            result = service.getTopicById_v2(provinceId, topicId, userId);
        else if ("v3".equalsIgnoreCase(version))
            result = service.getTopicById_v3(provinceId, topicId, userId);
        else
            result = service.getTopicById(provinceId, topicId, userId);
		
		return this.getRtnInfo(result);
	}
	/**
	 * 
	 * @param userId
	 * @param praise 0：
	 * @param topicId
	 * @return
	 */
	public RtnInfo praiseTopic(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		Long userId = Long.parseLong(context.getCurrentUserId());
//		Result result = valiateGetParams(bizInfo.get("praise"));
//		if(!result.isSuccess()){
//			return  RtnInfo.ParameterErrRtnInfo("praise"+result.getResultDesc());
//		} 
		Result result = valiateGetParams(bizInfo.get("topicid"));
		if(!result.isSuccess()){
			return  RtnInfo.ParameterErrRtnInfo("topicId"+result.getResultDesc());
		} 
		
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.praiseTopic(userId, bizInfo.get("praise"), bizInfo.get("topicid")) ;
		return this.getRtnInfo(result);
	}
	/**
	 * 获取分类列表	 *
	 * 按照 权重排序 
	 * @return
	 */
	public RtnInfo getCategory(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		Result result = service.getCategory() ;
		return this.getRtnInfo(result);
	}
	/**
	 * 获取分类下的主题
	 * 根据 userid 判断 是否登录
	 * 已登录，获取通用户的点赞信息
	 * @param userId
	 * @param CategoryId
	 * @return
	 */
	public RtnInfo getTopicByCategoryId(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
		if(bizInfo.get("categoryid")==null || "".equals(bizInfo.get("categoryid"))){
			return  RtnInfo.ParameterErrRtnInfo("categoryid is null");
		}
		Long categoryId = Long.parseLong(bizInfo.get("categoryid"));
		Result result = valiateGetParams(bizInfo.get("startpage"));
		if(!result.isSuccess()){
			return  RtnInfo.ParameterErrRtnInfo("startpage"+result.getResultDesc());
		}
		int startPage = Integer.parseInt(bizInfo.get("startpage"));
		int pageSize = 10;
		result = valiateGetParams(bizInfo.get("pagesize"));
		if (result.isSuccess()) {
			pageSize = Integer.parseInt(bizInfo.get("pagesize"));
		}
		int template = 0;
		result = valiateGetParams(bizInfo.get("template"));
		if (result.isSuccess()) {
			template = Integer.parseInt(bizInfo.get("template"));
		}
		if(isLogined ==false && categoryId ==-1L){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		Long userId = null; 
		result = valiateGetParams(context.getCurrentUserId());
		if(result.isSuccess()) {
			userId = Long.parseLong(context.getCurrentUserId());
		}		
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getTopicByCategoryId(userId, categoryId, startPage, pageSize, template);
		return this.getRtnInfo(result);
	}
	
	   /**
     * 获取分类下的主题
     * 根据 userid 判断 是否登录
     * 已登录，获取通用户的点赞信息
     * @param userId
     * @param CategoryIds   3,4,5
     * @return
     */
    public RtnInfo getTopicByCategoryIds(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
        if(bizInfo.get("categoryids")==null || "".equals(bizInfo.get("categoryids").trim())){
            return  RtnInfo.ParameterErrRtnInfo("categoryids is null");
        }
        String categoryIds =  bizInfo.get("categoryids").trim();
        Result result = valiateGetParams(bizInfo.get("startpage"));
        if(!result.isSuccess()){
            return  RtnInfo.ParameterErrRtnInfo("startpage"+result.getResultDesc());
        }
        int startPage = Integer.parseInt(bizInfo.get("startpage"));
        int pageSize = 10;
		result = valiateGetParams(bizInfo.get("pagesize"));
		if (result.isSuccess()) {
			pageSize = Integer.parseInt(bizInfo.get("pagesize"));
		}
		int template = 0;
		result = valiateGetParams(bizInfo.get("template"));
		if (result.isSuccess()) {
			template = Integer.parseInt(bizInfo.get("template"));
		}
        if(isLogined ==false &&"-1".equals(categoryIds)){
            return RtnInfo.TokenErrWlRtnInfo();
        }
        Long userId = null; 
        result = valiateGetParams(context.getCurrentUserId());
        if(result.isSuccess()) {
            userId = Long.parseLong(context.getCurrentUserId());
        }
        IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
        result = service.getTopicByCategoryIds(userId, categoryIds, startPage, pageSize, template);
        return this.getRtnInfo(result);
    }

	/**
	 * 获取所有分类下的主题
	 * 根据 userid 判断 是否登录
	 * 已登录，获取通用户的点赞信息
	 * @param userId
	 * @param CategoryId
	 * @return
	 */
	public RtnInfo getTopicByAllCategory(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
		Long userId = null; 
		Result result = valiateGetParams(context.getCurrentUserId());
		if(result.isSuccess()){
			userId = Long.parseLong(context.getCurrentUserId());
		}		
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getTopicByAllCategory(userId);
		return this.getRtnInfo(result);
	}
	

	/**
	 * 获取视频的主题 根据 userid 判断 是否登录 已登录，获取通用户的点赞信息
	 * 
	 * @param userId
	 * @param praised
	 * @return
	 */
	public RtnInfo getTopicWithVideo(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		Integer praised = 0;
		if (bizInfo.get("praised") != null && !"".equals(bizInfo.get("praised").trim())) {
			praised = Integer.valueOf(bizInfo.get("praised").trim());
		}
		Result result = valiateGetParams(bizInfo.get("startpage"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("startpage" + result.getResultDesc());
		}
		int startPage = Integer.parseInt(bizInfo.get("startpage"));
		int pageSize = 10;
		result = valiateGetParams(bizInfo.get("pagesize"));
		if (result.isSuccess()) {
			pageSize = Integer.parseInt(bizInfo.get("pagesize"));
		}
		if (isLogined == false && praised == 1) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		Long userId = null;
		result = valiateGetParams(context.getCurrentUserId());
		if (result.isSuccess()) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getTopicWithVideo(userId, praised, startPage, pageSize);
		return this.getRtnInfo(result);
	}

	// 获取晒单
	public RtnInfo getCommentPage(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		Integer type = 0;// (0:无限制,1:用户发表过的,2:用户点赞过的)
		if (bizInfo.get("type") != null && !"".equals(bizInfo.get("type").trim())) {
			type = Integer.valueOf(bizInfo.get("type").trim());
		}
		// 取得晒单用户
		Result result = valiateGetParams(bizInfo.get("userid"));
		// 未指定晒单用户，则无法查询点赞过或发表过的晒单
		if ((!isLogined && !result.isSuccess()) && (type == 1 || type == 2)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}

		Long userId = null, loginUserId = null;
		if (isLogined) {
			// 已经登录
			loginUserId = Long.parseLong(context.getCurrentUserId());
		}

		if (result.isSuccess()) {
			userId = Long.valueOf(bizInfo.get("userid").trim());
		} else {
			// 如果没有指定晒单用户ID，则查询自己的情况
			userId = loginUserId;
		}

		// 校验分页参数
		result = valiateGetParams(bizInfo.get("startpage"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("startpage" + result.getResultDesc());
		}
		result = valiateGetParams(bizInfo.get("pagesize"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("pagesize" + result.getResultDesc());
		}

		// 校验省份（查询商品价格需要省份）
		Long provinceId = null;
		if (context.getRequestInfo() != null) {
			result = valiateGetParams(context.getRequestInfo().getProvinceId());
			if (result.isSuccess()) {
				provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
			}
		}
		if (provinceId == null) {
			return RtnInfo.ParameterErrRtnInfo("ProvinceId" + result.getResultDesc());
		}

		// 获取分页参数
		int startPage = Integer.parseInt(bizInfo.get("startpage"));
		int pageSize = Integer.parseInt(bizInfo.get("pagesize"));

		// 虚拟类目
		Long vcate = null;
		if (valiateGetParams(bizInfo.get("vcate")).isSuccess()) {
			vcate = Long.valueOf(bizInfo.get("vcate"));
		}

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();

		String version = urlPath.substring(urlPath.lastIndexOf("/") + 1);
		//取版本号区分 一品堂晒单 一期/二期

		if ("v2".equalsIgnoreCase(version)) {
			result = service.getCommentPageByVCate(loginUserId, userId, type, startPage, pageSize, provinceId, vcate);
		} else {
			result = service.getCommentPage(loginUserId, userId, type, startPage, pageSize, provinceId);
		}

		// 过滤掉内容
		if (result.isSuccess()) {
			Page<DailyBuyCommentInfo> page = (Page<DailyBuyCommentInfo>) result.getDefaultModel();
			if (page != null && page.getObjList() != null) {
				for (DailyBuyCommentInfo info : page.getObjList()) {
					info.setContent("");
					info.setProductName("");
				}
			}
		}
		return this.getRtnInfo(result);
	}

	// 点赞晒单或取消点赞
	public RtnInfo praiseComment(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		Long userId = Long.parseLong(context.getCurrentUserId());
		// 校验点赞标志（0:点赞,1:取消）
		Result result = valiateGetParams(bizInfo.get("cancel"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("cancel" + result.getResultDesc());
		}
		Integer cancel = Integer.valueOf(bizInfo.get("cancel"));
		// 校验晒单ID
		result = valiateGetParams(bizInfo.get("commentid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("commentid" + result.getResultDesc());
		}
		Long commentId = Long.valueOf(bizInfo.get("commentid"));

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.praiseComment(userId, commentId, cancel);
		return this.getRtnInfo(result);
	}

	// 取消晒单
	public RtnInfo deleteComment(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		Long userId = Long.parseLong(context.getCurrentUserId());
		// 校验晒单ID
		Result result = valiateGetParams(bizInfo.get("commentid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("commentid" + result.getResultDesc());
		}
		Long commentId = Long.valueOf(bizInfo.get("commentid"));

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.deleteComment(userId, commentId);
		return this.getRtnInfo(result);
	}

	// 访问晒单
	public RtnInfo visitComment(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
		// 校验晒单ID
		Result result = valiateGetParams(bizInfo.get("commentid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("commentid" + result.getResultDesc());
		}
		Long commentId = Long.valueOf(bizInfo.get("commentid"));

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.visitComment(commentId);
		return this.getRtnInfo(result);
	}

	// 提交晒单
	public RtnInfo submitComment(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		Long userId = Long.parseLong(context.getCurrentUserId());

		// 评论内容
		String comment = bizInfo.get("comment");
		if (comment == null || comment.trim().isEmpty()) {
			return RtnInfo.ParameterErrRtnInfo("comment is null");
		}
		DailyBuyCommentVO commentInfo = JSON.parseObject(comment, DailyBuyCommentVO.class);
		if (commentInfo == null) {
			return RtnInfo.ParameterErrRtnInfo("comment param error");
		}

		DailyBuyComment entity = new DailyBuyComment();
		entity.setContent(commentInfo.getContent());
		entity.setEndUserId(userId);
		entity.setPhoto(commentInfo.getPhoto());
		entity.setPminfoId(commentInfo.getPminfoId());
		entity.setProductCode(commentInfo.getProductCode());
		entity.setProductId(commentInfo.getProductId());
		entity.setSource(commentInfo.getSource());
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		Result result = service.submitComment(entity);
		return this.getRtnInfo(result);
	}

	// 获取晒单
	public RtnInfo getCommentInfo(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		// 校验晒单ID
		Result result = valiateGetParams(bizInfo.get("commentid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("commentid" + result.getResultDesc());
		}
		Long commentId = Long.valueOf(bizInfo.get("commentid"));

		// 登录用户
		Long loginUserId = null;
		if (isLogined) {
			// 已经登录
			loginUserId = Long.parseLong(context.getCurrentUserId());
		}

		// 校验省份（查询商品价格需要省份）
		Long provinceId = null;
		if (context.getRequestInfo() != null) {
			result = valiateGetParams(context.getRequestInfo().getProvinceId());
			if (result.isSuccess()) {
				provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
			}
		}
		if (provinceId == null) {
			return RtnInfo.ParameterErrRtnInfo("ProvinceId" + result.getResultDesc());
		}

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getCommentInfo(loginUserId, commentId, provinceId);
		// 过滤掉内容
		if (result.isSuccess()) {
			DailyBuyCommentInfo info = (DailyBuyCommentInfo) result.getDefaultModel();
			if (info != null) {
				info.setContent("");
				info.setProductName("");
			}
		}
		return this.getRtnInfo(result);
	}

	// 获取点赞列表
	public RtnInfo getPraisePage(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		// 登录用户
		Long loginUserId = null;
		if (isLogined) {
			// 已经登录
			loginUserId = Long.parseLong(context.getCurrentUserId());
		}
		// 验证ID
		Result result = valiateGetParams(bizInfo.get("threadid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("threadid" + result.getResultDesc());
		}
		Long threadId = Long.valueOf(bizInfo.get("threadid"));
		// 验证type
		result = valiateGetParams(bizInfo.get("type"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("type" + result.getResultDesc());
		}
		Integer type = Integer.valueOf(bizInfo.get("type"));

		// 校验分页参数
		result = valiateGetParams(bizInfo.get("pagenumber"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("pagenumber" + result.getResultDesc());
		}
		Integer pageNumber = Integer.valueOf(bizInfo.get("pagenumber"));
		result = valiateGetParams(bizInfo.get("pagesize"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("pagesize" + result.getResultDesc());
		}
		Integer pageSize = Integer.valueOf(bizInfo.get("pagesize"));

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getPraisePage(loginUserId, threadId, type, pageNumber, pageSize);
		return this.getRtnInfo(result);
	}

	// 获取回复列表
	public RtnInfo getReplyPage(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		Long loginUserId = null;
		if (isLogined) {
			loginUserId = Long.parseLong(context.getCurrentUserId());
		}
		// 验证ID
		Result result = valiateGetParams(bizInfo.get("threadid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("threadid" + result.getResultDesc());
		}
		Long threadId = Long.valueOf(bizInfo.get("threadid"));
		// 验证type
		result = valiateGetParams(bizInfo.get("type"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("type" + result.getResultDesc());
		}
		Integer type = Integer.valueOf(bizInfo.get("type"));

		// 校验分页参数
		result = valiateGetParams(bizInfo.get("pagenumber"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("pagenumber" + result.getResultDesc());
		}
		Integer pageNumber = Integer.valueOf(bizInfo.get("pagenumber"));
		result = valiateGetParams(bizInfo.get("pagesize"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("pagesize" + result.getResultDesc());
		}
		Integer pageSize = Integer.valueOf(bizInfo.get("pagesize"));

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getReplyPage(loginUserId, threadId, type, pageNumber, pageSize);
		// 过滤掉内容
		if (result.isSuccess()) {
			Page<DailyBuyReplyVO> page = (Page<DailyBuyReplyVO>) result.getDefaultModel();
			if (page != null && page.getObjList() != null) {
				for (DailyBuyReplyVO info : page.getObjList()) {
					info.setContent("");
				}
			}
		}
		return this.getRtnInfo(result);
	}

	// 删除回复
	public RtnInfo deleteReply(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		Long loginUserId = null;
		if (isLogined) {
			loginUserId = Long.parseLong(context.getCurrentUserId());
		} else {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		// 验证ID
		Result result = valiateGetParams(bizInfo.get("replyid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("replyid" + result.getResultDesc());
		}
		Long replyId = Long.valueOf(bizInfo.get("replyid"));

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.deleteReply(loginUserId, replyId);
		return this.getRtnInfo(result);
	}

	// 回复
	public RtnInfo replyTopicOrComment(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		Long loginUserId = null;
		Long userId = null;
		if (isLogined) {
			loginUserId = Long.parseLong(context.getCurrentUserId());
		} else {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		if ("-1".equals(bizInfo.get("userid")) || valiateGetParams(bizInfo.get("userid")).isSuccess()) {
			userId = Long.valueOf(bizInfo.get("userid"));
		}
		// 验证ID
		Result result = valiateGetParams(bizInfo.get("threadid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("threadid" + result.getResultDesc());
		}
		Long threadId = Long.valueOf(bizInfo.get("threadid"));
		// 验证TYPE
		result = valiateGetParams(bizInfo.get("type"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("type" + result.getResultDesc());
		}
		Integer type = Integer.valueOf(bizInfo.get("type"));
		// 验证CONTENT
		String content = bizInfo.get("content");
		if (content == null || content.isEmpty()) {
			return RtnInfo.ParameterErrRtnInfo("content is null");
		}
		

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.replyTopicOrComment(loginUserId, userId, threadId, content, type);
		return this.getRtnInfo(result);
	}

	// 获取用户信息
	public RtnInfo getEndUserInfo(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		// 验证ID
		Long userId = null;
		Result result = valiateGetParams(bizInfo.get("userid"));
		if (!result.isSuccess()) {
			if (isLogined) {
				userId = Long.parseLong(context.getCurrentUserId());
			} else {
				return RtnInfo.ParameterErrRtnInfo("userid" + result.getResultDesc());
			}
		} else {
			userId = Long.valueOf(bizInfo.get("userid"));
		}

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getEndUserInfo(userId);
		return this.getRtnInfo(result);
	}
	
	/**
	 * 获取用户品牌接口
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 *//*
	public RtnInfo getUserAttentionBrand(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		Result result = null;
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getUserAttentionBrand();
		return this.getRtnInfo(result);
	}*/

	// 获取新品试用报告
	public RtnInfo getTrialReports(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		Long vcate = null;
		Result result = valiateGetParams(bizInfo.get("vcate"));
		if (result.isSuccess()) {
			vcate = Long.valueOf(bizInfo.get("vcate"));
		}
		Long lastReportId = null;
		result = valiateGetParams(bizInfo.get("lastreportid"));
		if (result.isSuccess()) {
			lastReportId = Long.valueOf(bizInfo.get("lastreportid"));
		}
		// 校验省份（查询商品价格需要省份）
		Long provinceId = null;
		if (context.getRequestInfo() != null) {
			result = valiateGetParams(context.getRequestInfo().getProvinceId());
			if (result.isSuccess()) {
				provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
			}
		}
		if (provinceId == null) {
			return RtnInfo.ParameterErrRtnInfo("ProvinceId" + result.getResultDesc());
		}

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getTrialReports(vcate, lastReportId, provinceId);
		return this.getRtnInfo(result);
	}

	/**
	 * 获取新品试用报告详情
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getTrialReportInfo(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		Long reportId = null;
		Result result = valiateGetParams(bizInfo.get("reportid"));
		if (result.isSuccess()) {
			reportId = Long.valueOf(bizInfo.get("reportid"));
		}
		// 校验省份（查询商品价格需要省份）
		Long provinceId = null;
		if (context.getRequestInfo() != null) {
			result = valiateGetParams(context.getRequestInfo().getProvinceId());
			if (result.isSuccess()) {
				provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
			}
		}
		if (provinceId == null) {
			return RtnInfo.ParameterErrRtnInfo("ProvinceId" + result.getResultDesc());
		}

		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getTrialReportInfo(reportId, provinceId);
		return this.getRtnInfo(result);
	}

	// 获取更多关联的文章
	public RtnInfo getMoreTopics(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		Result result = valiateGetParams(bizInfo.get("categoryid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("categoryid " + result.getResultDesc());
		}
		Long categoryId = Long.parseLong(bizInfo.get("categoryid"));
		result = valiateGetParams(bizInfo.get("topicid"));
		if (!result.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("topicid " + result.getResultDesc());
		}
		Long topicId = Long.parseLong(bizInfo.get("topicid"));
		Long userId = null;
		result = valiateGetParams(context.getCurrentUserId());
		if (result.isSuccess()) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		result = service.getMoreTopics(topicId, userId, categoryId);
		return this.getRtnInfo(result);
	}

	// 获取晒单类目列表
	public RtnInfo getCommentCats(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		IDailyBuyService service = CentralMobileServiceHandler.getDailyBuyService();
		Result result = service.getCommentCats();
		return this.getRtnInfo(result);
	}
}
