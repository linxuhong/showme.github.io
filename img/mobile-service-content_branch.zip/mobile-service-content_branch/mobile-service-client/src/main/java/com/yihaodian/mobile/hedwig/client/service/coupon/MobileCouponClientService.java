package com.yihaodian.mobile.hedwig.client.service.coupon;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.coupon.IMobileCouponFacadeService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.coupon.CouponActivityVO;
import com.yihaodian.mobile.vo.coupon.ReceiveResult;

public class MobileCouponClientService implements IMobileCouponFacadeService {

	private IMobileCouponFacadeService mobileCouponHessianCall;

	@Override
	public ReceiveResult receiveCouponByActivityId(String token,
			Long couponActivityId, String entryActiveId) {
		return mobileCouponHessianCall.receiveCouponByActivityId(token, couponActivityId, entryActiveId);
	}
	
    @Override
    public ReceiveResult receiveCouponByActivityId(Long userId, Long couponActivityId,
                                                   String entryActiveId, Trader trader) {
        return mobileCouponHessianCall.receiveCouponByActivityId(userId, couponActivityId, entryActiveId, trader);
    }

	@Override
	public Page<CouponActivityVO> getCouponActivityVOByPromotionId(
			Trader trader, Long promotionId, Integer type, Integer currentPage,
			Integer pageSize) {
		return mobileCouponHessianCall.getCouponActivityVOByPromotionId(trader, promotionId, type, currentPage, pageSize);
	}

	@Override
	public ReceiveResult checkCouppnVerfyCode(Trader trader, String code,
			String sessionId) {
		return mobileCouponHessianCall.checkCouppnVerfyCode(trader, code, sessionId);
	}

	public IMobileCouponFacadeService getMobileCouponHessianCall() {
		return mobileCouponHessianCall;
	}

	public void setMobileCouponHessianCall(
			IMobileCouponFacadeService mobileCouponHessianCall) {
		this.mobileCouponHessianCall = mobileCouponHessianCall;
	}

	@Override
	public String grantCouponByActivityId(Long userId,
			String activityCode, Long orderId) {
		return mobileCouponHessianCall.grantCouponByActivityId(userId, activityCode, orderId);
	}

	@Override
	public Double getCouponAmountByActivityId(String activityCode) {
		return mobileCouponHessianCall.getCouponAmountByActivityId(activityCode);
	}

	@Override
	public Result grantCouponWithInfo(Long userId, String activityCode) {
		return mobileCouponHessianCall.grantCouponWithInfo(userId, activityCode);
	}

}
