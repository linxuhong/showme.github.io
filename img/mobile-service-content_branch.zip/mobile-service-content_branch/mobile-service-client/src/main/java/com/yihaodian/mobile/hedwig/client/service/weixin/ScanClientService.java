package com.yihaodian.mobile.hedwig.client.service.weixin;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;
import com.yhd.shareservice.exceptions.HedwigException;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.push.spi.IScanService;

public class ScanClientService implements IScanService {
    private IScanService scanHessianCall;

 

    public void setScanHessianCall(IScanService scanHessianCall) {
        this.scanHessianCall = scanHessianCall;
    }



    @Override
    public Result delBarcodeFromWeixin(List<String> barcodeList) {
        return scanHessianCall.delBarcodeFromWeixin(barcodeList);
    }



    @Override
    public Result importProductToWeixin(JSONArray jsonArray) {
        return scanHessianCall.importProductToWeixin(jsonArray);
    }



    @Override
    public Result importOneProductToWeixin(Long pminfoId, Long productId)    {
        return scanHessianCall.importOneProductToWeixin(pminfoId, productId);
    }



 
 

 
}
