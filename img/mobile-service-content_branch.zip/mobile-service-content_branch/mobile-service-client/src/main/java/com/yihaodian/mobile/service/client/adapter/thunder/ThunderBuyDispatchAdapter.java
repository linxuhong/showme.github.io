package com.yihaodian.mobile.service.client.adapter.thunder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.google.gson.reflect.TypeToken;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.thunder.ThunderBuyService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.thunder.MobileProductVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class ThunderBuyDispatchAdapter extends BaseDiapatchService {

	public RtnInfo getThunderHomeBannerAndDes(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {

		ThunderBuyService service = CentralMobileServiceHandler
				.getThunderBuyClientService();
		String provinceId = bizInfo.get("provinceid");
		RtnInfo rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}

		Result result = service.getThunderHomeBannerAndDes(Long
				.parseLong(provinceId));

		return getRtnInfo(result);
	}

	public RtnInfo getThunderProvinceInfo(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {

		ThunderBuyService service = CentralMobileServiceHandler
				.getThunderBuyClientService();

		String provinceName = bizInfo.get("provincename");
		String cityName = bizInfo.get("cityname");
		String areaName = bizInfo.get("areaname");
		String streetName = bizInfo.get("streetname");
		
		Result result = service.getThunderProvinceInfo(provinceName, cityName,
				areaName, streetName);

		return getRtnInfo(result);
	}
	
	
	public RtnInfo getProductsByCategoryIds(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {

		ThunderBuyService service = CentralMobileServiceHandler
				.getThunderBuyClientService();

		List<Long> categoryIds = getCategoryIds(bizInfo);
		if(categoryIds == null || categoryIds.size() == 0){
			return RtnInfo.ParameterErrRtnInfo("categoryIds is null");
		}
		String provinceId = bizInfo.get("provinceid");
		RtnInfo rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		String size = bizInfo.get("size");
		rtn = validateNumber(size);
		if (rtn != null) {
			return rtn;
		}
		Long userId = null;
		if(context.getCurrentUserId()!=null){
			userId = Long.parseLong(context.getCurrentUserId());
		}
		Result result = service.getProductsByCategoryIds(categoryIds, Long.parseLong(provinceId), Integer.parseInt(size), userId);

		return getRtnInfo(result);
	}
	
	@SuppressWarnings("unchecked")
	private List<Long> getCategoryIds(Map<String, String> bizInfo){
		List<Long> categoryIds = null;
		String str = bizInfo.get("categoryids");
		if (StringUtil.isNotBlank(str)) {
			try {
				categoryIds = (List<Long>) GsonUtil.paseToObject(
						str, new TypeToken<List<Long>>() {
						}.getType());
			} catch (Exception e) {
				categoryIds = new ArrayList<Long>();
			}
			return categoryIds;
		}
		return categoryIds;
	}
	
	public RtnInfo getProductsByCategoryId(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		ThunderBuyService service = CentralMobileServiceHandler
				.getThunderBuyClientService();
		String categoryId = bizInfo.get("categoryid");
		RtnInfo rtn = validateNumber(categoryId);
		if (rtn != null) {
			return rtn;
		}
		String provinceId = bizInfo.get("provinceid");
		rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		Long userId = null;
		if(context.getCurrentUserId()!=null){
			userId = Long.parseLong(context.getCurrentUserId());
		}
		Result result = service.getProductsByCategoryId(Long.parseLong(categoryId), Long.parseLong(provinceId), userId);
		return getRtnInfo(result);
	}
	
	public RtnInfo getProductsByProvinceId(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		ThunderBuyService service = CentralMobileServiceHandler
				.getThunderBuyClientService();
		String provinceId = bizInfo.get("provinceid");
		RtnInfo rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		Long userId = null;
		if(context.getCurrentUserId()!=null){
			userId = Long.parseLong(context.getCurrentUserId());
		}
		Result result = service.getProductsByProvinceId(Long.parseLong(provinceId), userId);
		return getRtnInfo(result);
	}

	public RtnInfo arrivalReminding(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {

		ThunderBuyService service = CentralMobileServiceHandler
				.getThunderBuyClientService();
		String provinceId = bizInfo.get("provinceid");
		RtnInfo rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		String pmid = bizInfo.get("pmid");
		rtn = validateNumber(pmid);
		if (rtn != null) {
			return rtn;
		}
		String userIdStr = context.getCurrentUserId();
		rtn = validateNumber(userIdStr);
		if (rtn != null) {
			return rtn;
		}
		Long userId = Long.parseLong(userIdStr);
		String isRemindingStr = bizInfo.get("isreminding");
		boolean isReminding = false;
		if (isRemindingStr != null && isRemindingStr.equals("1")) {
			isReminding = true;
		}

		Result result = service.arrivalReminding(Long.parseLong(provinceId), Long.parseLong(pmid), userId, isReminding);

		return getRtnInfo(result);
	}
	
	public RtnInfo getThunderCategory(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		ThunderBuyService service = CentralMobileServiceHandler.getThunderBuyClientService();
		String provinceId = bizInfo.get("provinceid");
		RtnInfo rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}

		Result result = service.getThunderCategory(Long.parseLong(provinceId));

		return getRtnInfo(result);
	}
	
	public RtnInfo getNativeThunderMerchantInfo(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		Double lng = Double.valueOf(bizInfo.get("lng"));
		Double lat = Double.valueOf(bizInfo.get("lat"));
		String cellId = bizInfo.get("cellid");
		String page = bizInfo.get("currentpage");
		Long currentPage = null;
		RtnInfo rtn  = validateNumber(page);
		if (rtn == null) {
			currentPage = Long.parseLong(page);
		}
		ThunderBuyService service = CentralMobileServiceHandler.getThunderBuyClientService();
		Result result = service.getNativeThunderMerchantInfo(lng, lat, cellId, currentPage);
		
		return getRtnInfo(result);
	}
 
	public RtnInfo validateThunderOrder(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		ThunderBuyService service = CentralMobileServiceHandler.getThunderBuyClientService();
		
		List<MobileProductVO> productIds = getProductIds(bizInfo);
		if(productIds == null || productIds.size() == 0){
			return RtnInfo.ParameterErrRtnInfo("productIds is null");
		}
		Long userId = null;
		if(context.getCurrentUserId()!=null){
			userId = Long.parseLong(context.getCurrentUserId());
		}
		Long rayBuyActiveId = Long.valueOf(bizInfo.get("rayBuyActiveId"));
		Double amount = Double.valueOf(bizInfo.get("amount"));

		Result result = service.validateThunderOrder(userId,rayBuyActiveId,amount,productIds);

		return getRtnInfo(result);
	}
	
	@SuppressWarnings("unchecked")
	private List<MobileProductVO> getProductIds(Map<String, String> bizInfo){
		List<MobileProductVO> productIds = null;
		String str = bizInfo.get("productIds");
		if (StringUtil.isNotBlank(str)) {
			try {
				productIds = (List<MobileProductVO>) GsonUtil.paseToObject(
						str, new TypeToken<List<MobileProductVO>>() {
						}.getType());
			} catch (Exception e) {
				productIds = new ArrayList<MobileProductVO>();
			}
			return productIds;
		}
		return productIds;
	}
	
	public RtnInfo checkStockNumByPminfoAndProvince(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {

		String provinceId = bizInfo.get("provinceid");
		RtnInfo rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		String jsonString = bizInfo.get("selectproductlist");		
		if(StringUtil.isEmpty(jsonString)){
			return RtnInfo.ParameterErrRtnInfo("pram :selectproductlist is null ") ;
		}
		@SuppressWarnings("unchecked")
		List<Map<String,Long>> list = (List<Map<String,Long>>)GsonUtil.paseToObject(jsonString, new TypeToken<List<Map<String,Long>>>(){}.getType());
		if(CollectionUtils.isEmpty(list)){
			return RtnInfo.ParameterErrRtnInfo("pram :selectproductlist formate error") ;
		}
		Map<Long,Long> map = new HashMap<Long, Long>() ;
		for(int i = 0;i<list.size();i++){
			if(list.get(i).get("pmid") !=null && list.get(i).get("num") !=null){
				map.put(list.get(i).get("pmid"), list.get(i).get("num"));
			}
		}
		ThunderBuyService service = CentralMobileServiceHandler.getThunderBuyClientService();
		Result result = service.checkStockNumByPminfoAndProvince(map,Long.parseLong(provinceId));
		return getRtnInfo(result);
	}
		
	/**
	 * 小雷O2O地址定位
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getNativeThunderProvinceInfo(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		
		ThunderBuyService service = CentralMobileServiceHandler.getThunderBuyClientService();

		String provinceName = bizInfo.get("provincename");
		String cityName = bizInfo.get("cityname");
		String areaName = bizInfo.get("areaname");
		String streetName = bizInfo.get("streetname");
		
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			rtnInfo.setRtn_msg("provinceId must be number.");
			return rtnInfo;
		}
		Long provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
		Result result = service.getNativeThunderProvinceInfo(provinceName, cityName, areaName, streetName,provinceId);
		return getRtnInfo(result);
	}
	
	/**
	 * 小雷O2O首页信息
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getNativeThunderIndexInfo(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		
		ThunderBuyService service = CentralMobileServiceHandler.getThunderBuyClientService();
 
		//虚拟省份
		String strProvinceId = bizInfo.get("provinceid");
		RtnInfo rtn = validateNumber(strProvinceId);
		if (rtn != null) {
			return rtn;
		}
		Long vProvinceId = Long.valueOf(strProvinceId);
 	
 
		//区域ID
		String strBlockId = bizInfo.get("blockid");
		rtn = validateNumber(strBlockId);
		if (rtn != null) {
			return rtn;
		}
		Long blockId = Long.valueOf(strBlockId);
		
		//用户ID
		Long userId = null;
		if(null != context.getCurrentUserId()){
			userId = Long.valueOf(context.getCurrentUserId());
		}
		
		//用户终端类型
		String traderName = null;
		ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
		if(null != clientInfoVO){
			traderName = clientInfoVO.getTraderName();
		}
		
		Result result = service.getNativeThunderIndexInfo(traderName, userId, blockId, vProvinceId);
		return getRtnInfo(result);
	}
	
	/**
	 * 小雷O2O用户信息
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getNativeThunderUserInfo(String urlPath, Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		String currUserId = context.getCurrentUserId();
		if (StringUtils.isBlank(currUserId)) {
			return RtnInfo.ParameterErrRtnInfo("user must login");
		}
		ThunderBuyService service = CentralMobileServiceHandler.getThunderBuyClientService();
		Long userId = Long.valueOf(currUserId);
		Result result = service.getNativeThunderUserInfo(userId);
		return getRtnInfo(result);
	}
 
	/**
	 * 小雷O2O,根据关键字返回地址列表
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getAddressListByKeyword(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		String keywords = bizInfo.get("keywords");
		String location = bizInfo.get("location");
		String city = bizInfo.get("city");
		
		if(null == keywords){
			return RtnInfo.ParameterErrRtnInfo("keywords is null");
		}
		
		ThunderBuyService service = CentralMobileServiceHandler.getThunderBuyClientService();
		Result result = service.getAddressListByKeyword(keywords, location, city);
		
		return getRtnInfo(result);
	}
	
}
