package com.yihaodian.mobile.service.client.pay.service.impl;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.pay.IPayPreService;
import com.yihaodian.mobile.vo.ClientInfoVO;

/**
 * 支付前置服务
 * @author zhangwei5
 * @version $Id: PayPreClientServiceImpl.java, v 0.1 2014年8月8日 下午3:53:19 zhangwei5 Exp $
 */
public class PayPreClientServiceImpl implements IPayPreService{

    private IPayPreService payPreHessianCall;  
    
    

    public void setPayPreHessianCall(IPayPreService payPreHessianCall) {
        this.payPreHessianCall = payPreHessianCall;
    }

    @Override
    public Result getPayPreInfo(String userToken, Long orderId) {
        Result result = payPreHessianCall.getPayPreInfo(userToken, orderId);
        return result;
    }

    @Override
    public Result autoSwitchGateWay(String userToken, Long orderId, ClientInfoVO clientInfoVO,
                                    Integer provinceId) {
        Result result = payPreHessianCall.autoSwitchGateWay(userToken, orderId, clientInfoVO, provinceId);
        return result;
    }
    
    @Override
    public Result autoSwitchGateWay(Long userId, Long orderId, ClientInfoVO clientInfoVO,
                                    Integer provinceId) {
        return payPreHessianCall.autoSwitchGateWay(userId, orderId, clientInfoVO, provinceId);
    }

    @Override
    public Result getPayPreInfo(Long userId, Long orderId) {
        Result result = payPreHessianCall.getPayPreInfo(userId, orderId);
        return result;
    }

	@Override
	public Result getPayGatePromotionInfo() {
		Result result = payPreHessianCall.getPayGatePromotionInfo();
		return result;
	}

	@Override
	public Result getPayGatePromotionTip() {
		Result result = payPreHessianCall.getPayGatePromotionTip();
		return result;
	}
	
	@Override
	public Result getPayGatePromotionTip_V2() {
		Result result = payPreHessianCall.getPayGatePromotionTip_V2();
		return result;
	}
	
	@Override
	public Result checkNewCustomer(String userId) {
		Result result = payPreHessianCall.checkNewCustomer(userId);
		return result;
	}

	@Override
	public Result getPayGatePromotionInfo_V2(String payType, String payGateWay, String abTest, String userId, String deviceCode, ClientInfoVO clientInfoVO) {
		Result result = payPreHessianCall.getPayGatePromotionInfo_V2(payType,payGateWay,abTest,userId,deviceCode,clientInfoVO);
		return result;
	}

	@Override
	public Result getPayGatePromotionTip_V3(String payType, String payGateWay, String abTest, String userId, String deviceCode, ClientInfoVO clientInfoVO) {
		Result result = payPreHessianCall.getPayGatePromotionTip_V3(payType,payGateWay,abTest,userId,deviceCode,clientInfoVO);
		return result;
	}
}
