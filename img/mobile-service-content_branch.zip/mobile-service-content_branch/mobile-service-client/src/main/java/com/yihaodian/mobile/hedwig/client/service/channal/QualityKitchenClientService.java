package com.yihaodian.mobile.hedwig.client.service.channal;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.channel.spi.QualityKitchenService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class QualityKitchenClientService implements QualityKitchenService {

	private QualityKitchenService qualityKitchenServiceHessianCall;
	
	public QualityKitchenService getQualityKitchenServiceHessianCall() {
		return qualityKitchenServiceHessianCall;
	}

	public void setQualityKitchenServiceHessianCall(
			QualityKitchenService qualityKitchenServiceHessianCall) {
		this.qualityKitchenServiceHessianCall = qualityKitchenServiceHessianCall;
	}



	@Override
	public Result getQualityKitchenInfo(ClientInfoVO clientInfoVO, Long provinceId, Long userId, String cityid,String pageId, String tpa) {
		return qualityKitchenServiceHessianCall.getQualityKitchenInfo(clientInfoVO, provinceId, userId, cityid,pageId,tpa);
	}

}
