package com.yihaodian.mobile.hedwig.client.service.content.impl;

import com.yihaodian.mobile.service.facade.content.spi.FlashPurchaseService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.user.RegisterResult;

public class FlashPurchaseClientServiceImpl implements FlashPurchaseService{

	private FlashPurchaseService flashPurchaseHessianCall ;
	@Override
	public RegisterResult inviteesRegister(Trader trader, String email,
			String userName, String password, String verifyCode,
			String tempToken, Integer type, String inviterName) {
		return flashPurchaseHessianCall.inviteesRegister(trader, email, userName, password, verifyCode, tempToken, type, inviterName);
	}

	@Override
	public boolean getBrandCollectState(String token, Long brandId) {
		return flashPurchaseHessianCall.getBrandCollectState(token, brandId);
	}

	@Override
	public boolean addFavoriteForBrand(String token, Long brandId) {
		return flashPurchaseHessianCall.addFavoriteForBrand(token, brandId);
	}

	@Override
	public Page<Long> getFavoriteBrandLists(String token, int currentPage,
			int pageSize) {
		return flashPurchaseHessianCall.getFavoriteBrandLists(token, currentPage, pageSize);
	}

	@Override
	public boolean removeFavoriteBrand(String token, Long brandId) {
		return flashPurchaseHessianCall.removeFavoriteBrand(token, brandId);
	}

	public FlashPurchaseService getFlashPurchaseHessianCall() {
		return flashPurchaseHessianCall;
	}

	public void setFlashPurchaseHessianCall(
			FlashPurchaseService flashPurchaseHessianCall) {
		this.flashPurchaseHessianCall = flashPurchaseHessianCall;
	}

}
