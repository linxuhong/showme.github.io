package com.yihaodian.mobile.hedwig.client.bivisual.impl;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.bivisual.BIVisualClientService;
import com.yihaodian.mobile.hedwig.push.spi.BIVisualFacdeService;

public class BIVisualClientServiceImpl implements BIVisualClientService{

	private BIVisualFacdeService biVisualHessianCall;
	
	public void setBiVisualHessianCall(BIVisualFacdeService biVisualHessianCall) {
		this.biVisualHessianCall = biVisualHessianCall;
	}

	@Override
	public Result getBIVisualInfos() {
		return biVisualHessianCall.getBIVisualInfos();
	}

}
