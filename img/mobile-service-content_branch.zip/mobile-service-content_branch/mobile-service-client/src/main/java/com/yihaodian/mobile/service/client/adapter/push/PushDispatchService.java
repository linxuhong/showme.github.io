/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.push;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.client.adapter.service.impl.DispatchAdapterService;
import com.yihaodian.mobile.service.domain.business.emuns.CommonResultCode;
import com.yihaodian.mobile.service.facade.business.push.PushService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.push.PushInformationVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 推送拦截器.
 *
 * @author zhangwei5
 * @version $Id: PushDispatchService.java, v 0.1 2014年8月14日 下午1:38:26 zhangwei5 Exp $
 */
public class PushDispatchService extends BaseDiapatchService{

    /** The logger. */
    private Logger logger = Logger.getLogger(PushDispatchService.class);
    
    /**
     * 消息上报.
     *
     * @param urlPath the url path
     * @param isLogined the is logined
     * @param bizInfo the biz info
     * @param context the context
     * @return the rtn info
     */
    public RtnInfo logReporting(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
                                AdapterContext context){
        try {
            Trader trader = getTraderFromContext(context);
            RtnInfo rtnInfo = vaildateTrader(trader);
            if (rtnInfo == null) {
                String sendTimeStr = bizInfo.get("sendtime");
                if(StringUtil.isNotBlank(sendTimeStr)&&sendTimeStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
                    rtnInfo = RtnInfo.RightWlRtnInfo(null); 
                }else{
                    logger.error(" 发送时间参数有误  ");
                    rtnInfo = RtnInfo.ParameterErrRtnInfo("param sendtime has error ");
                }
            }
            return rtnInfo;
        } catch (Exception e) {
            logger.error("logReporting has error ",e);
            return new RtnInfo(DispatchAdapterService.ADAPTER_EXCEPTION, e.getMessage(), "");
        }
    }
    
    /**
     * 消息打开.
     *
     * @param urlPath the url path
     * @param isLogined the is logined
     * @param bizInfo the biz info
     * @param context the context
     * @return the rtn info
     */
    public RtnInfo messageOpen(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
                                AdapterContext context){
        try {
            Trader trader = getTraderFromContext(context);
            RtnInfo rtnInfo = vaildateTrader(trader);
            if (rtnInfo == null) {
                String opentimeStr = bizInfo.get("opentime");
                String pageIdStr  = bizInfo.get("pageid");
                String promotionIdStr  = bizInfo.get("promotionid");
                String promotionTypeStr = bizInfo.get("promotiontype");
                Result result = validateMessageOpenParam(opentimeStr, pageIdStr, promotionIdStr,
                    promotionTypeStr);
                if(result.isSuccess()){
                    PushService pushService = CentralMobileServiceHandler.getPushService();
                    if(isLogined){
                        pushService.messageOpen(trader, Long.valueOf(opentimeStr), Long.valueOf(pageIdStr), Long.valueOf(promotionIdStr), Integer.valueOf(promotionTypeStr),Long.valueOf(context.getCurrentUserId()));    
                    }else{
                        pushService.messageOpen(trader, Long.valueOf(opentimeStr), Long.valueOf(pageIdStr), Long.valueOf(promotionIdStr), Integer.valueOf(promotionTypeStr));    
                    } 
                    return RtnInfo.RightWlRtnInfo(null); 
                }else{
                    return getRtnInfo(result);
                }
            }
            return rtnInfo;
        } catch (Exception e) {
            logger.error("messageOpen has error ",e);
            return new RtnInfo(DispatchAdapterService.ADAPTER_EXCEPTION, e.getMessage(), "");
        }
    }

    /**
     * 消息上报.
     *
     * @param urlPath the url path
     * @param isLogined the is logined
     * @param bizInfo the biz info
     * @param context the context
     * @return the rtn info
     */
    public RtnInfo storeUserInfo(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
                                AdapterContext context){
        try {
            Trader trader = getTraderFromContext(context);
            RtnInfo rtnInfo = vaildateTrader(trader);
            if (rtnInfo == null) {
                if(isLogined){
                    PushService pushService = CentralMobileServiceHandler.getPushService();
                    pushService.storeUserInfo(Long.valueOf(context.getCurrentUserId()), trader);
                    return RtnInfo.RightWlRtnInfo(null); 
                }else{
                    return RtnInfo.TokenErrWlRtnInfo();
                }
            }
            return rtnInfo;
        } catch (Exception e) {
            logger.error("storeUserInfo has error ",e);
            return new RtnInfo(DispatchAdapterService.ADAPTER_EXCEPTION, e.getMessage(), "");
        }
    }
    
    /**
     * 获取消息
     *
     * @param urlPath the url path
     * @param isLogined the is logined
     * @param bizInfo the biz info
     * @param context the context
     * @return the rtn info
     */
    public RtnInfo getPushInformation(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
                                AdapterContext context){
        try {
            Trader trader = getTraderFromContext(context);
            RtnInfo rtnInfo = vaildateTrader(trader);
            if(rtnInfo!=null){
            	return rtnInfo;
            }
            Long userId = null;
            String userIdStr = context.getCurrentUserId();
            if(userIdStr!=null&&!userIdStr.equals("")){
                userId = Long.parseLong(userIdStr);
            }
            PushService pushService = CentralMobileServiceHandler.getPushService();
            List<PushInformationVO> result = pushService.getPushInformation(trader, userId);
            return RtnInfo.RightWlRtnInfo(result); 

        } catch (Exception e) {
            logger.error("getPushInformation has error ",e);
            return new RtnInfo(DispatchAdapterService.ADAPTER_EXCEPTION, e.getMessage(), "");
        }
    }
    
    /**
     * Validate message open param.
     *
     * @param opentimeStr the opentime str
     * @param pageIdStr the page id str
     * @param promotionIdStr the promotion id str
     * @param promotionTypeStr the promotion type str
     * @return the result
     */
    private  Result  validateMessageOpenParam(String opentimeStr, String pageIdStr,
                                          String promotionIdStr, String promotionTypeStr) {
        Result result = new ResultModel();
        result.setSuccess(true);
        try {
            if(StringUtil.isBlank(opentimeStr)||!opentimeStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
                result.setSuccess(false);
                result.setBaseResultCode(CommonResultCode.PARAMS_NULL_EXCEPTION);
            }
            
            if(StringUtil.isBlank(pageIdStr)||!pageIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
                result.setSuccess(false);
                result.setBaseResultCode(CommonResultCode.PARAMS_NULL_EXCEPTION);                
            }
            
            if(pageIdStr.equals("2")&&(StringUtil.isBlank(promotionIdStr)||StringUtil.isBlank(promotionTypeStr)||!promotionTypeStr.matches(RegexEnum.PURE_DIGITAL.getRegex())||!promotionIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex()))){
                result.setSuccess(false);
                result.setBaseResultCode(CommonResultCode.PARAMS_NULL_EXCEPTION); 
            }
            
            return result;
        } catch (Exception e) {
            logger.error("validateMessageOpenParam has error ", e);
            return getSystemErrorResult(); 
        }
        
    }
}
