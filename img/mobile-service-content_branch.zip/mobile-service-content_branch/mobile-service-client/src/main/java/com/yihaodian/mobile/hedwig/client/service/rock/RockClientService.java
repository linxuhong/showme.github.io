package com.yihaodian.mobile.hedwig.client.service.rock;

import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.service.domain.business.dal.backend.RockAwardAccept;

public interface RockClientService {
	
	public ResultModel getRockPromotionInfo(String activityId, Long userId, int provinceId);
	public ResultModel getRockPromotionInfo(String activityId, String userToken, int provinceId);
	
	public ResultModel getWinnersList(String activityId);
	
	public ResultModel doShaking(Long userId, String activityId, int isExplode, String traderName, String deviceToken,int provinceId);
	public ResultModel doShaking(String userToken, String activityId, int isExplode, String traderName, String deviceToken,int provinceId);
	
	public ResultModel acceptAward(Long userId, String activityId, String awardId, int explodeSecIndex, int isDiscard, int provinceId, String traderName, String deviceToken);
	public ResultModel acceptAward(String userToken, String activityId, String awardId, int explodeSecIndex, int isDiscard, int provinceId, String traderName, String deviceToken);
	
	public ResultModel getUsersForPush(String startMin, String step);
	
	public ResultModel getNewTimeStart(String newSecIndex, String trrigerCount);
	
	/**
	 * 查询得到某个活动下所有奖品
	 * @param promotionType 活动类型 1-摇一摇 2-支付宝摇一摇 3-品牌专场摇一摇
	 * @param activityId    活动id
	 * @param userId
	 * @param provinceId
	 * @return
	 */
	public ResultModel getRockPromotionInfo(String promotionType, String activityId, Long userId, int provinceId);
	
	/**
	 * 摇奖接口
	 * @param promotionType 活动类型 1-摇一摇 2-支付宝摇一摇 3-品牌专场摇一摇
	 * @param userId
	 * @param activityId
	 * @param isExplode
	 * @param traderName
	 * @param deviceToken
	 * @param provinceId
	 * @return
	 */
	public ResultModel doShaking(String promotionType, Long userId, String userName, String activityId, int explodedSec, String traderName, String deviceToken,int provinceId);
	
	/**
	 * 领奖接口
	 * @param promotionType
	 * @param userId
	 * @param activityId
	 * @param awardId
	 * @param explodeSecIndex
	 * @param isDiscard
	 * @param provinceId
	 * @param traderName
	 * @param deviceToken
	 * @return
	 */
	public ResultModel acceptAward(String promotionType, Long userId, String activityId, String awardId, int explodeSecIndex, int isDiscard, int provinceId, String traderName, String deviceToken,String ciphertext, RockAwardAccept rockAwardAccept);
	
	/**
	 * 用户礼品箱
	 * @param activityId    活动id
	 * @param userId
	 * @return
	 */
	public ResultModel getUserGiftBox(String activityId, Long userId, int provinceId);
	
	/**
	 * 分享，记录用户ID，下次必中，24小时有效
	 * @param activityId    活动id
	 * @param userId
	 * @return
	 */
	public ResultModel sharePromotion(String activityId, Long userId);
	
	/**
	 * 是否填写大奖收货地址
	 * @param activityId    活动id
	 * @param awardId
	 * @param userId
	 * @return
	 */
	public ResultModel returnAddress(String activityId, String awardId, Long userId);
	
	/**
	 * 获取用户的剩余的摇奖次数
	 * @param activityId   活动id
	 * @param userId       用户id
	 * @return
	 */
	public ResultModel getResidueRockTime(String activityId, Long userId);
}
