/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.user;

import java.util.Map;

import org.apache.log4j.Logger;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.user.spi.UserFacadeService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.user.PushMappingResult;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class UserDispatchService.
 */
public class UserDispatchService extends BaseDiapatchService{
	
	/** The logger. */
	private Logger logger = Logger.getLogger(UserDispatchService.class);
	
	/**
	 * Insert app error log.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo insertAppErrorLog(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if(!isLogined){
				return RtnInfo.TokenErrWlRtnInfo();
			}
			UserFacadeService userFacadeService = CentralMobileServiceHandler.getUserClientService();
			Trader trader = getTraderFromContext(context);
			RtnInfo rtnInfo = vaildateTrader(trader);
			if(rtnInfo == null){
				String log = bizInfo.get("log")!=null?bizInfo.get("log"):"";
				String phoneNumber = bizInfo.get("phonenumber")!=null?bizInfo.get("phonenumber"):"";
				Long userId = context.getCurrentUserId()!=null ? Long.valueOf(context.getCurrentUserId()) : null;
				Integer result = userFacadeService.insertAppErrorLog(trader, log, phoneNumber, userId);
				rtnInfo = RtnInfo.RightWlRtnInfo(result);
			}
			return rtnInfo;
		} catch (Exception e) {
			logger.error("UserDispatchService=>insertAppErrorLog error",e);
			return RtnInfo.ParameterErrRtnInfo("some pram is null");
		}
	}

	/**
	 * Enable device for push msg.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo enableDeviceForPushMsg(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			UserFacadeService service = CentralMobileServiceHandler.getUserClientService();
			Trader trader = getTraderFromContext(context);
			//省份
			String provinceId = context.getRequestInfo().getProvinceId();
			trader.setProvinceId(provinceId);
			String deviceToken = bizInfo.get("devicetoken");
			String isopen=bizInfo.get("isopen");
			Boolean isOpen =false;
			if("1".endsWith(isopen)){
				isOpen=true ;
			}
			int startHour = Integer.valueOf(bizInfo.get("starthour"));
			int endHour = Integer.valueOf(bizInfo.get("endhour"));
			
			PushMappingResult result = service.enableDeviceForPushMsg(trader, deviceToken, isOpen, startHour, endHour);
			return RtnInfo.RightWlRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2){
			return null;
		}
	}
}
