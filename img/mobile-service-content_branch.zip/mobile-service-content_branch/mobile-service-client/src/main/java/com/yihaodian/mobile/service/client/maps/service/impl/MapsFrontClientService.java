package com.yihaodian.mobile.service.client.maps.service.impl;

import java.util.List;
import java.util.Map;

import com.yihaodian.front.shopping.interfaces.vo.CommInputVo;
import com.yihaodian.mobile.backend.maps.model.PageSearchEntity;
import com.yihaodian.mobile.backend.maps.vo.BizVO;
import com.yihaodian.mobile.backend.maps.vo.GrouponBrandVO;
import com.yihaodian.mobile.backend.maps.vo.PageWholeVO;
import com.yihaodian.mobile.backend.maps.vo.ProductInfoVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.map.spi.MapsFrontService;

public class MapsFrontClientService implements MapsFrontService {

	private MapsFrontService mapsFrontServiceHessianCall ;
	@Override
	public PageWholeVO loadCachedPage(Long pageId, Long provinceId) {
		return mapsFrontServiceHessianCall.loadCachedPage(pageId, provinceId);
	}

	@Override
	public List<ProductInfoVO> loadCachedProducts(Long cmsMouldId,
			Long provinceId, int startnum, int endnum) {
		return mapsFrontServiceHessianCall.loadCachedProducts(cmsMouldId, provinceId, startnum, endnum);
	}

	@Override
	public List<BizVO> loadCachedPageEntitys(String entityType, Long mId,
			int startnum, int endnum) {
		return mapsFrontServiceHessianCall.loadCachedPageEntitys(entityType, mId, startnum, endnum);
	}

	@Override
	public String userGetCouponFromActivity(Long mId,String checkCode, Long userId) {
		return mapsFrontServiceHessianCall.userGetCouponFromActivity(mId,checkCode, userId);
	}
	
	@Override
	public String userGetCouponFromShop(Long shopId, String checkCode, Long userId) {
		return mapsFrontServiceHessianCall.userGetCouponFromShop(shopId,checkCode, userId);
	}

	@Override
	public boolean clearCachedPage(Long pageId) {
		return mapsFrontServiceHessianCall.clearCachedPage(pageId);
	}

	@Override
	public boolean clearCachedProduct(Long cmsMouldId, Long provinceId) {
		return mapsFrontServiceHessianCall.clearCachedProduct(cmsMouldId, provinceId);
	}

	@Override
	public boolean clearCachedEntitys(String entityType, Long mId) {
		return mapsFrontServiceHessianCall.clearCachedEntitys(entityType, mId);
	}

	public MapsFrontService getMapsFrontServiceHessianCall() {
		return mapsFrontServiceHessianCall;
	}

	public void setMapsFrontServiceHessianCall(
			MapsFrontService mapsFrontServiceHessianCall) {
		this.mapsFrontServiceHessianCall = mapsFrontServiceHessianCall;
	}

	@Override
	public List<PageSearchEntity> searchPage(Long provinceId, Long categoryId,
			String keyword, int type) {
		return mapsFrontServiceHessianCall.searchPage(provinceId, categoryId, keyword, type);
	}

	@Override
	public Result addNormal(CommInputVo inputoVo,
			Long endUserId, Long pmInfoId, int num) {
		return mapsFrontServiceHessianCall.addNormal(inputoVo, endUserId, pmInfoId, num);
	}

	@Override
	public Result addPromotion(CommInputVo inputoVo, Long endUserId, int opType, Long promotionId,
			Long promotionLevelId, Long merchantId,
			Map<String, Integer> pmIdNums) {
		return mapsFrontServiceHessianCall.addPromotion(inputoVo, endUserId, opType, promotionId, promotionLevelId, merchantId, pmIdNums);
	}

	@Override
	public GrouponBrandVO loadGrouponBrandVO(Long brandId) {
		return mapsFrontServiceHessianCall.loadGrouponBrandVO(brandId);
	}

}
