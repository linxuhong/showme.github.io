package com.yihaodian.mobile.hedwig.client.service.cms;

import java.util.Date;
import java.util.List;

import com.yihaodian.mobile.backend.cms.vo.NativePageVO;
import com.yihaodian.mobile.backend.cms.vo.cl.AbsColumnVO;
import com.yihaodian.mobile.backend.cms.vo.p.CmsNativeProductVO;
import com.yihaodian.mobile.service.cms.spi.CmsNativeService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class CmsNativeClientService implements CmsNativeService{

	private CmsNativeService cmsNativeServiceHessianCall;
	public void setCmsNativeServiceHessianCall(CmsNativeService cmsNativeServiceHessianCall) {
		this.cmsNativeServiceHessianCall = cmsNativeServiceHessianCall;
	}
	@Override
	public NativePageVO loadCmsPage(ClientInfoVO clientInfo,long pageId, String uid) {
		return cmsNativeServiceHessianCall.loadCmsPage(clientInfo,pageId, uid);
	}
	@Override
	public AbsColumnVO loadCmsColContent(ClientInfoVO clientInfo,long colId, String uid) {
		return cmsNativeServiceHessianCall.loadCmsColContent(clientInfo,colId, uid);
	}
	@Override
	public String getCmsVoucher(Long userId, long subGroupId, long vourcherId) {
		return cmsNativeServiceHessianCall.getCmsVoucher(userId, subGroupId, vourcherId);
	}
	@Override
	public List<CmsNativeProductVO> loadSubGroupProducts(ClientInfoVO clientInfo,long colId,
			Long subGroupId, String uid) {
		return cmsNativeServiceHessianCall.loadSubGroupProducts(clientInfo,colId, subGroupId, uid);
	}
	@Override
	public NativePageVO loadCmsPage(long pageId, long provinceId,
			Date previewTime) {
		return cmsNativeServiceHessianCall.loadCmsPage(pageId, provinceId, previewTime);
	}
	@Override
	public Boolean checkNative(long pageId, long provinceId, String version) {
		return cmsNativeServiceHessianCall.checkNative(pageId, provinceId, version);
	}
	@Override
	public NativePageVO loadCmsPageH5(long pageId, long provinceId, String uid, String guid) {
		return cmsNativeServiceHessianCall.loadCmsPageH5(pageId, provinceId, uid, guid);
	}
	@Override
	public AbsColumnVO loadCmsColContentH5(long colId, long provinceId, String uid, String guid, Long cityId) {
		return cmsNativeServiceHessianCall.loadCmsColContentH5(colId, provinceId, uid, guid, cityId);
	}
	@Override
	public List<CmsNativeProductVO> loadSubGroupProductsH5(long colId, Long subgroupid, long provinceId, String uid, String guid, Long cityId) {
		return cmsNativeServiceHessianCall.loadSubGroupProductsH5(colId, subgroupid, provinceId, uid, guid, cityId);
	}
}
