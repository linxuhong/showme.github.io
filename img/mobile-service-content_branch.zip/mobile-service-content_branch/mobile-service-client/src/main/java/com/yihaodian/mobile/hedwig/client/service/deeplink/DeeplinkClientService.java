package com.yihaodian.mobile.hedwig.client.service.deeplink;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.deeplink.IDeeplinkService;

public class DeeplinkClientService implements IDeeplinkService{
	
	private IDeeplinkService deeplinkHessianCall;
	
	@Override
	public Result getThirdAppInfo(String key, String traderName) {
		return deeplinkHessianCall.getThirdAppInfo(key, traderName);
	}

	public IDeeplinkService getDeeplinkHessianCall() {
		return deeplinkHessianCall;
	}

	public void setDeeplinkHessianCall(IDeeplinkService deeplinkHessianCall) {
		this.deeplinkHessianCall = deeplinkHessianCall;
	}

	@Override
	public Result verifyThirdParty(String bundleId, String key, String trader) {
		return deeplinkHessianCall.verifyThirdParty(bundleId, key, trader);
	}
}
