package com.yihaodian.mobile.service.client.adapter.abTest;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.devicecodeAB.DevicecodeABService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo.ClientInfo;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class AbTestDispater extends BaseDiapatchService {
	 public RtnInfo getAbTest(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		 String clientid = bizInfo.get("clientid");
		 if(clientid == null){
			 clientid = "";
		 }
		 ClientInfo clientInfo =context.getRequestInfo().getClientInfo();
		 Trader trader = getTraderFromContext(context);
		 String deviceCode = trader.getDeviceCode();
		 RtnInfo rtn = vaildateTrader(trader);
		 if(rtn!=null){
			 return rtn;
		 }
		 if(StringUtil.isEmpty(deviceCode)){
			 return RtnInfo.ParameterErrRtnInfo("deviceCode is null");
		 }
	     DevicecodeABService service = CentralMobileServiceHandler.getDevicecodeABClientService();
		return RtnInfo.RightWlRtnInfo(service.getAbBydeviceCode(deviceCode,trader.getTraderName(),clientInfo.getImei(),clientid));
		 
	 }


}
