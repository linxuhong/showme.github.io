package com.yihaodian.mobile.service.client.adapter.maps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.yihaodian.front.shopping.interfaces.constants.ShoppingBizType;
import com.yihaodian.front.shopping.interfaces.vo.CommInputVo;
import com.yihaodian.mobile.backend.maps.core.BizContants;
import com.yihaodian.mobile.backend.maps.model.PageSearchEntity;
import com.yihaodian.mobile.backend.maps.vo.BizVO;
import com.yihaodian.mobile.backend.maps.vo.GrouponBrandVO;
import com.yihaodian.mobile.backend.maps.vo.PageWholeVO;
import com.yihaodian.mobile.backend.maps.vo.ProductInfoVO;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.map.spi.MapsFrontService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class MapsFrontDispatchService extends BaseDiapatchService{
	
	public RtnInfo loadCachedPage(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Result result = valiateGetParams(bizInfo.get("pageid"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("pageid " + result.getResultDesc());
		}
		result = valiateGetParams(context.getRequestInfo().getProvinceId());
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("provinceid " + result.getResultDesc());
		}
		Long pageId = Long.parseLong(bizInfo.get("pageid"));
		Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
		MapsFrontService service = CentralMobileServiceHandler.getMapsFrontClientService();
		PageWholeVO vo = service.loadCachedPage(pageId, provinceId);
		RtnInfo.RightWlRtnInfo(vo);
		return RtnInfo.RightWlRtnInfo(vo);
	}

	public RtnInfo loadCachedProducts(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		Result result = valiateGetParams(bizInfo.get("cmsmouldid"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("cmsmouldid " + result.getResultDesc());
		}
		
		result = valiateGetParams(context.getRequestInfo().getProvinceId());
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("provinceid " + result.getResultDesc());
		}
		
		result = valiateGetParams(bizInfo.get("startnum"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("startnum " + result.getResultDesc());
		}
		
		result = valiateGetParams(bizInfo.get("endnum"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("endnum " + result.getResultDesc());
		}
		Long cmsMouldId = Long.parseLong(bizInfo.get("cmsmouldid"));
		Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
		Integer startnum = Integer.parseInt(bizInfo.get("startnum"));
		Integer endnum = Integer.parseInt(bizInfo.get("endnum"));
		
		MapsFrontService service = CentralMobileServiceHandler.getMapsFrontClientService();
		List<ProductInfoVO>  list = service.loadCachedProducts(cmsMouldId, provinceId, startnum, endnum);
		return RtnInfo.RightWlRtnInfo(list) ;
	}

	public RtnInfo loadCachedPageEntitys(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		if(StringUtil.isBlank(bizInfo.get("entitytype"))){
			return RtnInfo.ParameterErrRtnInfo("entitytype is null");
		}
		
		Result result = valiateGetParams(bizInfo.get("mid"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("mid " + result.getResultDesc());
		}
		
		result = valiateGetParams(bizInfo.get("startnum"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("startnum " + result.getResultDesc());
		}
		
		result = valiateGetParams(bizInfo.get("endnum"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("endnum " + result.getResultDesc());
		}
		Long mId = Long.parseLong(bizInfo.get("mid"));
		Integer startnum = Integer.parseInt(bizInfo.get("startnum"));
		Integer endnum = Integer.parseInt(bizInfo.get("endnum"));
		
		MapsFrontService service = CentralMobileServiceHandler.getMapsFrontClientService();
		List<BizVO> list = service.loadCachedPageEntitys(bizInfo.get("entitytype"), mId, startnum, endnum);
		return RtnInfo.RightWlRtnInfo(list) ;
	}

	public RtnInfo userGetCouponFromActivity(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		if(!isLogined){
			//登录校验
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		Result result = valiateGetParams(bizInfo.get("mid"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("mid " + result.getResultDesc());
		}
		Long userId = Long.parseLong(context.getCurrentUserId());
		Long mid = Long.parseLong(bizInfo.get("mid"));
		MapsFrontService service = CentralMobileServiceHandler.getMapsFrontClientService();
		String re = service.userGetCouponFromActivity(mid, bizInfo.get("checkcode"),userId);
		return RtnInfo.RightWlRtnInfo(re) ;
	}
	
	public RtnInfo userGetCouponFromShop(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		if(!isLogined){
			//登录校验
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		Result result = valiateGetParams(bizInfo.get("shopid"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("shopid " + result.getResultDesc());
		}
		Long userId = Long.parseLong(context.getCurrentUserId());
		Long shopId = Long.parseLong(bizInfo.get("shopid"));
		MapsFrontService service = CentralMobileServiceHandler.getMapsFrontClientService();
		String re = service.userGetCouponFromShop(shopId, bizInfo.get("checkcode"),userId);
		return RtnInfo.RightWlRtnInfo(re) ;
	}
	
	
	
	public RtnInfo searchPage(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Result result = valiateGetParams(bizInfo.get("provinceid"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("provinceid " + result.getResultDesc());
		}
		result = valiateGetParams(bizInfo.get("type"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("type " + result.getResultDesc());
		}
		
		Long provinceId = Long.parseLong(bizInfo.get("provinceid"));
		Long categoryId = null;
		if(StringUtil.isNotBlank(bizInfo.get("categoryid"))){
			categoryId = Long.parseLong(bizInfo.get("categoryid"));
		}
		String keyword = bizInfo.get("keyword");
		int type = Integer.valueOf(bizInfo.get("type")).intValue();
		MapsFrontService service = CentralMobileServiceHandler.getMapsFrontClientService();
		List<PageSearchEntity> re = service.searchPage(provinceId, categoryId, keyword, type);
		return RtnInfo.RightWlRtnInfo(re) ;
	}
	
	public RtnInfo addToCart(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		Result re = new ResultModel();
		String productType = bizInfo.get("producttype");
		if(StringUtil.isBlank(productType)){
			return RtnInfo.ParameterErrRtnInfo("producttype is null");
		}
		String provinceId = bizInfo.get("provinceid");
		RtnInfo rtn = validateNumber(provinceId);
		if (rtn != null) {
			return rtn;
		}
		Long userId = null;
		if(context.getCurrentUserId() != null){
			userId = Long.parseLong(context.getCurrentUserId());
		}
		Long pmId = null;
		if(bizInfo.get("pmid") != null){
			pmId = Long.parseLong(bizInfo.get("pmid"));
		}
		String promotionId = null;
		if(bizInfo.get("promotionid") != null){
			promotionId = bizInfo.get("promotionid");
		}
		Long merchantId = null;
		if(bizInfo.get("merchantid") != null){
			merchantId = Long.parseLong(bizInfo.get("merchantid"));
		}
		int num = 0;
		if(bizInfo.get("num") != null){
			num = Integer.parseInt(bizInfo.get("num"));
		}
		CommInputVo inputVo = setCommonParam(bizInfo, context);
		MapsFrontService service = CentralMobileServiceHandler.getMapsFrontClientService();
		if(productType.equalsIgnoreCase(ProductInfoVO.TYPE_NORMAL) || productType.equalsIgnoreCase(ProductInfoVO.TYPE_GROUP)){
			re = service.addNormal(inputVo, userId, pmId, num);
		}else if(productType.equalsIgnoreCase(ProductInfoVO.TYPE_LANDINGPAGE)){
			Long promoId = Long.parseLong(promotionId.replace("_0_landingpage", ""));
			Map<String,Integer> pmIdNums = new HashMap<String,Integer>();
			pmIdNums.put(pmId.toString(), num);
			re = service.addPromotion(inputVo, userId, 3, promoId, null, merchantId, pmIdNums);
		}
		return RtnInfo.RightWlRtnInfo(re) ;
	}
	
	private CommInputVo setCommonParam(Map<String, String> bizInfo,AdapterContext context){
		CommInputVo inputVo = new CommInputVo();
		//通用参数
		inputVo.setClientSystem(context.getRequestInfo().getClientInfo().getClientSystem());
		inputVo.setClientVersion(context.getRequestInfo().getClientInfo().getClientVersion());
		inputVo.setClientAppVersion(context.getRequestInfo().getClientInfo().getClientAppVersion());
		inputVo.setClientType(BizContants.CLIENT_TYPE_1);
		inputVo.setInterfaceVersion(BizContants.INTERFACE_VERSION);
		inputVo.setDeviceCode(context.getRequestInfo().getClientInfo().getDeviceCode());
		inputVo.setTradeName(context.getRequestInfo().getClientInfo().getTraderName());
		inputVo.setLongitude(context.getRequestInfo().getClientInfo().getLongitude());
		inputVo.setLatitude(context.getRequestInfo().getClientInfo().getLatitude());
		if(bizInfo.get("sessionid") != null && !bizInfo.get("sessionid").equals("")){
			inputVo.setSessionId(bizInfo.get("sessionid"));
		}
		if(context.getCurrentUserId() != null){
			inputVo.setUserId(Long.valueOf(context.getCurrentUserId()));
		}
		if(bizInfo.get("provinceid") != null){
			inputVo.setProvinceId(Long.valueOf(bizInfo.get("provinceid")));
		}
		inputVo.setShoppingBizType(ShoppingBizType.COMM_MOBILE);
		inputVo.setClientIp(context.getRequestInfo().getClientInfo().getClientIp());
		return inputVo;
	}
	
	
	public RtnInfo loadGrouponBrandVO(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Long brandId = null;
		if(bizInfo.get("brandid") != null){
			brandId = Long.parseLong(bizInfo.get("brandid"));
		}
		
		MapsFrontService service = CentralMobileServiceHandler.getMapsFrontClientService();
		GrouponBrandVO re = service.loadGrouponBrandVO(brandId);
		return RtnInfo.RightWlRtnInfo(re) ;
	}
}
