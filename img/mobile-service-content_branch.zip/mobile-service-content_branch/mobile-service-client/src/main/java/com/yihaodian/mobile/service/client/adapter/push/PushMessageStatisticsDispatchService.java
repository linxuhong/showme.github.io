/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.push;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.gson.reflect.TypeToken;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.domain.business.emuns.CommonResultCode;
import com.yihaodian.mobile.service.domain.vo.business.push.OpenMessageAndVO;
import com.yihaodian.mobile.service.domain.vo.business.push.OpenMessageParamVO;
import com.yihaodian.mobile.service.facade.business.push.IPushMessageStatisticsService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 推送消息统计拦截器.
 *
 * @author zhangwei5
 * @version $Id: PushMessageStatisticsDispatchService.java, v 0.1 2014年8月12日 下午5:47:05 zhangwei5 Exp $
 */
public class PushMessageStatisticsDispatchService extends BaseDiapatchService{

    /** The logger. */
    private Logger logger  = Logger.getLogger(PushMessageStatisticsDispatchService.class);
    
    /**
     * 消息统计.
     *
     * @param urlPath the url path
     * @param isLogined the is logined
     * @param bizInfo the biz info
     * @param context the context
     * @return the rtn info
     */
    public RtnInfo messageStatistics(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
                                     AdapterContext context){
        try {
        	String openTime;
        	List<OpenMessageParamVO> messageList = null;
        	String type = bizInfo.get("type"); 
        	String deviceToken = bizInfo.get("devicetoken");
        	
        	//android 4.0.3之前用的是sendtime messageinfo对应VO不一样
        	openTime = bizInfo.get("time");
        	if(openTime==null||openTime.equals("")){
        		openTime = bizInfo.get("sendtime");
        	}
        	Result result = validateMessageStatistics(openTime);
        	
        	messageList= paseMessageList(bizInfo);
        	
            Long userId = null;
            String userIdStr = context.getCurrentUserId();
            if(userIdStr!=null&&!userIdStr.equals("")){
                userId = Long.parseLong(userIdStr);
            }
            if(result.isSuccess()){
               IPushMessageStatisticsService pushMessageStatisticsService = CentralMobileServiceHandler.getPushMessageStatisticsService();
               result = pushMessageStatisticsService.messageStatistics(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Long.valueOf(openTime), messageList, deviceToken,userId, Integer.valueOf(type));
            }
            return RtnInfo.RightWlRtnInfo(result);
        } catch (Exception e) {
            logger.error("messageStatistics has error ",e);
            return null;
        }
    }
    
    /**
     * Validate message statistics.
     *
     * @param openTime the open time
     * @param messageList the message list
     * @return the result
     */
	private Result validateMessageStatistics(String openTime) throws Exception {
		Result result = new ResultModel();
		result.setSuccess(true);
		if (openTime == null
				|| !openTime.matches(RegexEnum.PURE_DIGITAL.getRegex())) {
			result.setSuccess(false);
			result.setBaseResultCode(CommonResultCode.PARAMS_NULL_EXCEPTION);
		}
		return result;
	}
    
    /**
     * Pase message list.
     *
     * @param bizInfo the biz info
     * @return the list
     */
	private List<OpenMessageParamVO> paseMessageList(Map<String, String> bizInfo)
			throws Exception {
		List<OpenMessageParamVO> messageList = null;
		String messageInfoJson = bizInfo.get("messageinfo");
		if (StringUtil.isNotBlank(messageInfoJson)) {
			try {
				messageList = (List<OpenMessageParamVO>) GsonUtil.paseToObject(
						messageInfoJson, new TypeToken<List<OpenMessageParamVO>>() {
						}.getType());
			} catch (Exception e) {
				messageList = paseMessageAndroidList(bizInfo);
			}
			return messageList;
		}
		return messageList;
	}
	private List<OpenMessageParamVO> paseMessageAndroidList(Map<String, String> bizInfo)
			throws Exception {
		List<OpenMessageAndVO> messageList = null;
		String messageInfoJson = bizInfo.get("messageinfo");
		if (StringUtil.isNotBlank(messageInfoJson)) {
			messageList = (List<OpenMessageAndVO>) GsonUtil.paseToObject(
					messageInfoJson, new TypeToken<List<OpenMessageAndVO>>() {
					}.getType());
			return changeList(messageList);
		}
		return null;
	}
	
	private List<OpenMessageParamVO> changeList(List<OpenMessageAndVO> vo){
		List<OpenMessageParamVO> list1 = new ArrayList<OpenMessageParamVO>();
		if(vo!=null && vo.size()>0){
			for(OpenMessageAndVO v :vo){
				OpenMessageParamVO mes = new OpenMessageParamVO();
				mes.setPageId(v.getPageId());
				mes.setPromotionId(v.getPromotionId());
				mes.setPromotionType(v.getPromotionType());
				mes.setTaskId(v.getTaskId());
				list1.add(mes);
			}
			
		}
		return list1;
		
	}
}
