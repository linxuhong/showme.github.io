package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.HomeService;
import com.yihaodian.mobile.vo.bussiness.FacetValue;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.home.HomeModuleVO;
import com.yihaodian.mobile.vo.home.HomeSelectionVO;
import com.yihaodian.mobile.vo.home.QualityAppVO;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class HomeDispatchService.
 * @author zuodeng
 */
public class HomeDispatchService extends BaseDiapatchService{

	/**
	 * Gets the quality app list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the quality app list
	 */
	public RtnInfo getQualityAppList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		Trader trader = getTraderFromContext(context);
		if(trader.getTraderName()==null){
			return RtnInfo.ParameterErrRtnInfo("TraderName is null");
		}
		HomeService homeService = CentralMobileServiceHandler.getHomeService();	
		
		if(bizInfo.get("currentpage")==null||bizInfo.get("currentpage").equals("")){
			return RtnInfo.ParameterErrRtnInfo("currentpage is null");
		}
		if(!bizInfo.get("currentpage").matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("currentpage formate error");
		}
		
		if(bizInfo.get("pagesize")==null||bizInfo.get("pagesize").equals("")){
			return RtnInfo.ParameterErrRtnInfo("pagesize is null");
		}
		if(!bizInfo.get("pagesize").matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("pagesize formate error");
		}
		Integer currentPage =Integer.parseInt(bizInfo.get("currentpage"));
		Integer pageSize = Integer.parseInt(bizInfo.get("pagesize"));
		Page<QualityAppVO> page = homeService.getQualityAppList(trader, currentPage, pageSize);
		return RtnInfo.RightWlRtnInfo(page);
	}
	
	/**
	 * Gets the home selection.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the home selection
	 */
	public RtnInfo getHomeSelection(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		Long provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
		String currentPage = bizInfo.get("currentpage");
		if(StringUtil.isEmpty(currentPage)){
			return RtnInfo.ParameterErrRtnInfo("currentPage is null");
		}
		String pageSize = bizInfo.get("pagesize");
		if(StringUtil.isEmpty(pageSize)){
			return RtnInfo.ParameterErrRtnInfo("pageSize is null");
		}
		
		HomeService homeService = CentralMobileServiceHandler.getHomeService();
		Page<HomeSelectionVO> page = homeService.getHomeSelection(trader, provinceId, Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		return RtnInfo.RightWlRtnInfo(page);
	}
	
	/**
	 * Gets the home hot element.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the home hot element
	 */
	public RtnInfo getHomeHotElement(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			Trader trader = getTraderFromContext(context);
			RtnInfo rtnInfo = vaildateTrader(trader);
			if(rtnInfo != null){
				return rtnInfo;
			}
			String type = bizInfo.get("type");
			if(StringUtil.isEmpty(type) || !type.matches(RegexEnum.PURE_DIGITAL.getRegex())){
				return RtnInfo.ParameterErrRtnInfo("type is null");
			}
			HomeService homeService = CentralMobileServiceHandler.getHomeService();
			List<FacetValue> result = homeService.getHomeHotElement(trader, Integer.parseInt(type));
			return RtnInfo.RightWlRtnInfo(result);
		} catch (Exception e) {
			return RtnInfo.ParameterErrRtnInfo("some pram null!");
		}
		
	}
	

	
	/**
	 * Gets the home module list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the home module list
	 */
	public RtnInfo getHomeModuleList(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		try {
			HomeService service = CentralMobileServiceHandler.getHomeService();
			List<HomeModuleVO> re = service.getHomeModuleList(getTraderFromContext(context));
			
			return RtnInfo.RightWlRtnInfo(re);
		} catch (Exception e) {
			return RtnInfo.ParameterErrRtnInfo("some pram null!");
		}
	}
	
}
