package com.yihaodian.mobile.service.client.adapter.newuser;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.newuser.NewUserCouponService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class NewUserCouponDispatchService extends BaseDiapatchService{
	
	public RtnInfo getNewUserCouponInfo(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		NewUserCouponService service = CentralMobileServiceHandler
				.getNewUserCouponClientService();
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		Result result = service.getNewUserCouponInfo(convertClientInfoVO(context.getRequestInfo().getClientInfo()), userId);
		return getRtnInfo(result);
	}
	
	public RtnInfo getUserCoupon(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String userId = context.getCurrentUserId();
		Result result=valiateGetParams(userId);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId" + result.getResultDesc());
		}
		
		NewUserCouponService service = CentralMobileServiceHandler
				.getNewUserCouponClientService();
		
		String activityId = bizInfo.get("activityid");
		if(StringUtil.isBlank(activityId) || !activityId.matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("activityId is error");
		}
		Result result2 = service.getUserCoupon(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Long.parseLong(userId),Long.parseLong(activityId));
		return getRtnInfo(result2);
	}

}
