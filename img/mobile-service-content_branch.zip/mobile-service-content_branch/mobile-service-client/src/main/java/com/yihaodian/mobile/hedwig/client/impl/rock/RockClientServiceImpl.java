package com.yihaodian.mobile.hedwig.client.impl.rock;

import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.client.service.rock.RockClientService;
import com.yihaodian.mobile.hedwig.push.spi.IRockService;
import com.yihaodian.mobile.service.domain.business.dal.backend.RockAwardAccept;

public class RockClientServiceImpl implements RockClientService {
	
	private IRockService rockHessianCall;

	public ResultModel getRockPromotionInfo(String activityId, String userToken,
			int provinceId) {
		return rockHessianCall.getRockPromotionInfo(activityId, userToken, provinceId);
	}

	public ResultModel getWinnersList(String activityId) {
		return rockHessianCall.getWinnersList(activityId);
	}

	public ResultModel doShaking(String userToken, String activityId, int isExplode,
			String traderName, String deviceToken , int provinceId) {
		return rockHessianCall.doShaking(userToken, activityId, isExplode, traderName, deviceToken , provinceId);
	}

	public ResultModel acceptAward(String userToken, String activityId,
			String awardId, int explodeSecIndex, int isDiscard, int provinceId,
			String traderName, String deviceToken) {
		return rockHessianCall.acceptAward(userToken, activityId, awardId, explodeSecIndex, 
				isDiscard, provinceId, traderName, deviceToken);
	}

	public ResultModel getUsersForPush(String startMin, String step) {
		return rockHessianCall.getUsersForPush(startMin, step);
	}

	public ResultModel getNewTimeStart(String newSecIndex, String trrigerCount) {
		return rockHessianCall.getNewTimeStart(newSecIndex, trrigerCount);
	}

	public IRockService getRockHessianCall() {
		return rockHessianCall;
	}

	public void setRockHessianCall(IRockService rockHessianCall) {
		this.rockHessianCall = rockHessianCall;
	}

	/**
	 * 查询得到某个活动下所有奖品
	 * @param promotionType 活动类型 1-摇一摇 2-支付宝摇一摇 3-品牌专场摇一摇
	 * @param activityId    活动id
	 * @param userId
	 * @param provinceId
	 * @return
	 */
	@Override
	public ResultModel getRockPromotionInfo(String promotionType,
			String activityId, Long userId, int provinceId) {
		return rockHessianCall.getRockPromotionInfo(promotionType, activityId, userId, provinceId);
	}

	/**
	 * 摇奖接口
	 * @param promotionType 活动类型 1-摇一摇 2-支付宝摇一摇 3-品牌专场摇一摇
	 * @param userId
	 * @param activityId
	 * @param isExplode
	 * @param traderName
	 * @param deviceToken
	 * @param provinceId
	 * @return
	 */
	@Override
	public ResultModel doShaking(String promotionType, Long userId, String userName,
			String activityId, int explodedSec, String traderName,
			String deviceToken, int provinceId) {
		return rockHessianCall.doShaking(promotionType, userId, userName, activityId, explodedSec, traderName, deviceToken, provinceId);
	}

	@Override
	public ResultModel getRockPromotionInfo(String activityId, Long userId,
			int provinceId) {
		return rockHessianCall.getRockPromotionInfo(activityId, userId, provinceId);
	}

	@Override
	public ResultModel doShaking(Long userId, String activityId, int isExplode,
			String traderName, String deviceToken, int provinceId) {
		return rockHessianCall.doShaking(userId, activityId, isExplode, traderName, deviceToken, provinceId);
	}

	@Override
	public ResultModel acceptAward(Long userId, String activityId,
			String awardId, int explodeSecIndex, int isDiscard, int provinceId,
			String traderName, String deviceToken) {
		return rockHessianCall.acceptAward(userId, activityId, awardId, explodeSecIndex, isDiscard, provinceId, traderName, deviceToken);
	}
	
	/**
	 * 领奖接口
	 * @param promotionType
	 * @param userId
	 * @param activityId
	 * @param awardId
	 * @param explodeSecIndex
	 * @param isDiscard
	 * @param provinceId
	 * @param traderName
	 * @param deviceToken
	 * @return
	 */
	@Override
	public ResultModel acceptAward(String promotionType, Long userId,
			String activityId, String awardId, int explodeSecIndex,
			int isDiscard, int provinceId, String traderName,
			String deviceToken,String ciphertext, RockAwardAccept rockAwardAccept) {
		return rockHessianCall.acceptAward(promotionType, userId, activityId, awardId, explodeSecIndex, isDiscard, provinceId, traderName, deviceToken,ciphertext, rockAwardAccept);
	}

	/**
	 * 用户礼品箱
	 * @param activityId    活动id
	 * @param userId
	 * @return
	 */
	@Override
	public ResultModel getUserGiftBox(String activityId, Long userId, int provinceId) {
		return rockHessianCall.getUserGiftBox(activityId, userId, provinceId);
	}
	
	/**
	 * 分享，记录用户ID，下次必中，24小时有效
	 * @param activityId    活动id
	 * @param userId
	 * @return
	 */
	public ResultModel sharePromotion(String activityId, Long userId) {
		return rockHessianCall.sharePromotion(activityId, userId);
	}

	/**
	 * 是否填写大奖收货地址
	 * @param activityId    活动id
	 * @param awardId
	 * @param userId
	 * @return
	 */
	public ResultModel returnAddress(String activityId, String awardId, Long userId) {
		return rockHessianCall.returnAddress(activityId, awardId, userId);
	}

	@Override
	public ResultModel getResidueRockTime(String activityId, Long userId) {
		return rockHessianCall.getResidueRockTime(activityId, userId);
	}
	
}
