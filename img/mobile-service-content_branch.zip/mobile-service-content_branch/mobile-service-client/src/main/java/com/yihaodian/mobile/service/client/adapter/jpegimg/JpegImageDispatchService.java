/**
 * www.yhd.com-402 Inc.
 * Copyright (c) 2008-2015 All Rights Reserved.
 */
package com.yihaodian.mobile.service.client.adapter.jpegimg;

import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;

/**
 * 
 * @author huangqihui
 * @version $Id: JpegImageDispatchService.java, v 0.1 2015年9月10日 上午10:32:14 huangqihui Exp $
 */
public class JpegImageDispatchService extends BaseDiapatchService {
    
//    public RtnInfo findHeads(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
//        IJpegImageService service =  CentralMobileServiceHandler.getJpegImageClientService();
//        String jsonArr = bizInfo.get("jsonarr");
//        Result result = service.findHeads(jsonArr);
//        return getRtnInfo(result);
//    }
//    
//    public RtnInfo findBodys16(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
//        IJpegImageService service =  CentralMobileServiceHandler.getJpegImageClientService();
//        String url = bizInfo.get("url") ;
//        if(StringUtil.isEmpty(url)){
//            return RtnInfo.ParameterErrRtnInfo("pram : url is null");
//        }
//        List<String> urlList =(List<String>) GsonUtil.paseToObject(url, new TypeToken<List<String>>(){}.getType());
//        Result result = service.findBodys16(urlList);
//        return getRtnInfo(result);
//    }
//    
//   
//    
//    public RtnInfo findBodysBase64(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context){
//        IJpegImageService service =  CentralMobileServiceHandler.getJpegImageClientService();
//        String url = bizInfo.get("url") ;
//        if(StringUtil.isEmpty(url)){
//            return RtnInfo.ParameterErrRtnInfo("pram : url is null");
//        }
//        List<String> urlList =(List<String>) GsonUtil.paseToObject(url, new TypeToken<List<String>>(){}.getType());
//        Result result = service.findBodysBase64(urlList);
//        return getRtnInfo(result);
//    }
//    

}
