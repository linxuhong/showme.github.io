package com.yihaodian.mobile.hedwig.client.service.alipay;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.alipay.spi.IAlipaySignService;

public class AlipaySignClientService implements IAlipaySignService {

	private IAlipaySignService alipaySignHessianCall;

	public IAlipaySignService getAlipaySignHessianCall() {
		return alipaySignHessianCall;
	}

	public void setAlipaySignHessianCall(IAlipaySignService alipaySignHessianCall) {
		this.alipaySignHessianCall = alipaySignHessianCall;
	}

	@Override
	public Result getAliPaySignature(String userToken, Long orderId,
			String traderName, String appversion) {
		return alipaySignHessianCall.getAliPaySignature(userToken, orderId, traderName, appversion);
	}

	@Override
	public Result getAliPaySignatureV2(Long userId, Long orderId,
			String traderName) {
		return alipaySignHessianCall.getAliPaySignatureV2(userId, orderId, traderName);
	}
	
}
