package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.Map;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.client.advertisement.service.impl.EngAdClientService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class EnglishAdDispaterService extends BaseDiapatchService {

	 public RtnInfo getEnAds(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		String provinceId = context.getRequestInfo().getProvinceId();
		RtnInfo rtnInfo = validateNumber(provinceId);
			if(rtnInfo != null){
				return rtnInfo;
			}
		String traderName = context.getRequestInfo().getClientInfo().getTraderName();
		if(traderName==null){
				return RtnInfo.ParameterErrRtnInfo("traderName is null");
		}
		EngAdClientService engAdService = CentralMobileServiceHandler.getEngAdClientService();
		if(traderName.equals("iossystemen")){
			return RtnInfo.RightWlRtnInfo(engAdService.getEnAds(Long.parseLong(provinceId)));
		}
		return RtnInfo.RightWlRtnInfo(engAdService.getEnAds(Long.parseLong(provinceId),traderName));
	 }
}
