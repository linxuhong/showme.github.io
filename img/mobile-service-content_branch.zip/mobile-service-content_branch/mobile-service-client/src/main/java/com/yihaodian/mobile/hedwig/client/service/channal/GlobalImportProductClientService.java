package com.yihaodian.mobile.hedwig.client.service.channal;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.channel.spi.GlobalImportProductService;
import com.yihaodian.mobile.vo.ClientInfoVO;

import java.util.Map;

public class GlobalImportProductClientService implements GlobalImportProductService {
	
	private GlobalImportProductService globalImportProductHessianCall;	
	
	
	public GlobalImportProductService getGlobalImportProductHessianCall() {
		return globalImportProductHessianCall;
	}


	public void setGlobalImportProductHessianCall(
			GlobalImportProductService globalImportProductHessianCall) {
		this.globalImportProductHessianCall = globalImportProductHessianCall;
	}


	
	
	@Override
	public Result getGlobalImportProduct(ClientInfoVO clientInfoVO,	Long provinceId, Long userId, Map<String, String> bizInfo) {
		return globalImportProductHessianCall.getGlobalImportProduct(clientInfoVO, provinceId, userId, bizInfo);
	}


	@Override
	public Result getNewProductsFromSearch(Long provinceId,	Long cityId, Map<String, String> bizInfo) {
		return globalImportProductHessianCall.getNewProductsFromSearch(provinceId, cityId, bizInfo);
	}


	@Override
	public Result getCategoryByAreaCode(ClientInfoVO clientInfoVO, Long provinceId, Map<String, String> bizInfo) {
		return globalImportProductHessianCall.getCategoryByAreaCode(clientInfoVO,provinceId, bizInfo);
	}


	@Override
	public Result getProductsByCategory(ClientInfoVO clientInfoVO, Long provinceId, Long userId, Map<String, String> bizInfo) {
		return globalImportProductHessianCall.getProductsByCategory(clientInfoVO, provinceId, userId, bizInfo);
	}


	@Override
	public Result getProductsByBrandId(Long provinceId, String brandIds,String cityId) {
		return globalImportProductHessianCall.getProductsByBrandId(provinceId, brandIds,cityId);
	}


	@Override
	public Result getHotRecProductByCategory(ClientInfoVO clientInfoVO,	Long provinceId, Long userId, Map<String, String> bizInfo) {
		return globalImportProductHessianCall.getHotRecProductByCategory(clientInfoVO, provinceId, userId, bizInfo);
	}

	@Override
	public Result getHotSalesSingleProducts(ClientInfoVO clientInfoVO, Long provinceId, Long userId, Map<String, String> bizInfo) {
		return globalImportProductHessianCall.getHotSalesSingleProducts(clientInfoVO, provinceId, userId, bizInfo);
	}

}
