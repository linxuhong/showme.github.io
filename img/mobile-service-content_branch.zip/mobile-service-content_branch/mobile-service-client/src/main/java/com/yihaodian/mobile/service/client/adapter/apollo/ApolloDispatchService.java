/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.apollo;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.apollo.IApolloPromotionService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class ApolloDispatchService.
 * @author zuodeng
 */
public class ApolloDispatchService extends BaseDiapatchService{

    
    /**
     * Gets the apollo promotion info by client location.
     *
     * @param urlPath the url path
     * @param isLogined the is logined
     * @param bizInfo the biz info
     * @param context the context
     * @return the apollo promotion info by client location
     */
    public RtnInfo getApolloPromotionInfoByClientLocation(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
                                 AdapterContext context){
    	String cityName = bizInfo.get("cityname");    	
    	IApolloPromotionService service = CentralMobileServiceHandler.getApolloPromotionService();
    	Result result = service.getApolloPromotionInfoByClientLocation(cityName, convertClientInfoVO(context.getRequestInfo().getClientInfo()));
    	return getRtnInfo(result);
    }
    
}
