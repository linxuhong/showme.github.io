package com.yihaodian.mobile.hedwig.client.service.app;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.app.spi.AppActivationService;

public class AppActivationClientService implements AppActivationService {
	
	private AppActivationService appActivationServiceHessianCall;

	public void setAppActivationServiceHessianCall(
			AppActivationService appActivationServiceHessianCall) {
		this.appActivationServiceHessianCall = appActivationServiceHessianCall;
	}

	@Override
	public Result jdActivationDataReceive(String jdData, String deviceCode, String clientIp, String channelId, Integer provinceId, Long appCallTime) {
		return appActivationServiceHessianCall.jdActivationDataReceive(jdData, deviceCode, clientIp, channelId, provinceId, appCallTime);
	}

}
