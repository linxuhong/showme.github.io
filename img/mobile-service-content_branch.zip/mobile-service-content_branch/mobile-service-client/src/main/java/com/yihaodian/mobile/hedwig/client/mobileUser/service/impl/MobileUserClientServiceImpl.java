package com.yihaodian.mobile.hedwig.client.mobileUser.service.impl;

import com.yihaodian.mobile.hedwig.client.mobileUser.service.MobileUserClientService;
import com.yihaodian.mobile.hedwig.push.spi.MobileUserInfoFacdeService;
import com.yihaodian.mobile.hedwig.push.vo.MobileUserInfo;

public class MobileUserClientServiceImpl implements MobileUserClientService{

	private MobileUserInfoFacdeService<String> mobileUserHessianCall;
	
	public void setMobileUserHessianCall(
			MobileUserInfoFacdeService<String> mobileUserHessianCall) {
		this.mobileUserHessianCall = mobileUserHessianCall;
	}
	
	@Override
	public MobileUserInfo getMobileUserInfoByToken(String token) {
		return mobileUserHessianCall.getMobileUserInfoByToken(token);
	}


}
