package com.yihaodian.mobile.hedwig.client.mobileUser.service;

import com.yihaodian.mobile.service.facade.business.devicecodeAB.DevicecodeABService;

public class DevicecodeABClientService implements DevicecodeABService {
	private DevicecodeABService devicecodeABHessianCall;

	public DevicecodeABService getDevicecodeABHessianCall() {
		return devicecodeABHessianCall;
	}

	public void setDevicecodeABHessianCall(
			DevicecodeABService devicecodeABHessianCall) {
		this.devicecodeABHessianCall = devicecodeABHessianCall;
	}

	@Override
	public String getAbBydeviceCode(String deviceCode, String traderName) {
		return devicecodeABHessianCall.getAbBydeviceCode(deviceCode, traderName);
	}

	@Override
	public String getAbBydeviceCode(String deviceCode, String traderName,String imei, String clientid) {
		return devicecodeABHessianCall.getAbBydeviceCode(deviceCode, traderName,imei,clientid);
	}
}
