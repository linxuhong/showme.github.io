package com.yihaodian.mobile.service.client.venus;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.venus.VenusHttpsCheckService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnCodes;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class VenusHttpsCheckAdapter extends BaseDiapatchService {
	private static Logger logger = LoggerFactory.getLogger(VenusHttpsCheckAdapter.class);
	
	public RtnInfo getVenusHttpsCheck(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		
		VenusHttpsCheckService service = CentralMobileServiceHandler.getVenusHttpsCheckService();
		
		Integer cityId = NumberUtils.toInt(context.getRequestInfo().getCityId());
		Integer provinceId = NumberUtils.toInt(context.getRequestInfo().getProvinceId());
		String nettype = context.getRequestInfo().getClientInfo().getNetType();
		String ts = bizInfo.get("ts");
		
		try {
			String ret = service.request(provinceId, cityId, nettype, ts);
			return RtnInfo.RightWlRtnInfo(ret);
		} catch (Exception e) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cityId", cityId);
			params.put("provinceId", provinceId);
			params.put("nettype", nettype);
			params.put("ts", ts);
			
			logger.error(JSON.toJSONString(params), e);
			return new RtnInfo(RtnCodes.ADAPTER_EXCEPTION, "request soa error", "");
		}
	}
}
