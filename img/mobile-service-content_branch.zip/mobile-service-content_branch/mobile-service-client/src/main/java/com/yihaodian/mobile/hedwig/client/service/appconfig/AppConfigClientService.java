package com.yihaodian.mobile.hedwig.client.service.appconfig;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.appconfig.AppConfigService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class AppConfigClientService implements AppConfigService{

	private AppConfigService appConfigHessianCall;

	@Override
	public Result getDefaultHit(Trader trader) {		
		return appConfigHessianCall.getDefaultHit(trader);
	}

	@Override
	public Result getAppTab(Trader trader) {		
		return appConfigHessianCall.getAppTab(trader);
	}

	@Override
	public Result getAppTab() {
		return appConfigHessianCall.getAppTab();
	}
	
	@Override
	public Result getDefaultHit() {
		return appConfigHessianCall.getDefaultHit();
	}
	
	public AppConfigService getAppConfigHessianCall() {
		return appConfigHessianCall;
	}

	public void setAppConfigHessianCall(AppConfigService appConfigHessianCall) {
		this.appConfigHessianCall = appConfigHessianCall;
	}

	@Override
	public Result getAppRefInfo(Trader trader, Long userId) {
		return appConfigHessianCall.getAppRefInfo(trader, userId);
	}

	@Override
	public void getRedPacketGame(Long userId, String defaultClientAppVersion, Map<String, Object> map) {
		 appConfigHessianCall.getRedPacketGame(userId, defaultClientAppVersion,map);
	}

}
