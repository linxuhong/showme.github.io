package com.yihaodian.mobile.hedwig.client.bivisual;

import com.yihaodian.mobile.framework.model.Result;

public interface BIVisualClientService {
	
	/**
	 * 获取客户端首页可视化数据
	 * @return
	 */
	public Result getBIVisualInfos();

}
