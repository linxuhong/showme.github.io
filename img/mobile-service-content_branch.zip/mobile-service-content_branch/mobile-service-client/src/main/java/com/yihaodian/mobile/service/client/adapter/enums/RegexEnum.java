package com.yihaodian.mobile.service.client.adapter.enums;


/**
 * 正则表达式枚举类
 * @author zhangwei5
 * @version $Id: RegexEnum.java, v 0.1 2014年8月11日 下午3:22:22 zhangwei5 Exp $
 */
public enum RegexEnum {
    //验证是否为纯数字
    PURE_DIGITAL("[0-9]+", "是否为纯数字"),
    ALL_INTEGER("-?[0-9]+", "是否是整数"),
    ;

    private final String regex;
    private final String msg;
    
    RegexEnum(String regex, String msg) {
        this.regex = regex;
        this.msg = msg;
    }

    public String getRegex() {
        return regex;
    }

    public String getMsg() {
        return msg;
    }

}
