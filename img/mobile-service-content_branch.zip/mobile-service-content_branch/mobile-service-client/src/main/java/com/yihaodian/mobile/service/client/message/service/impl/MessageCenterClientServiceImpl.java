package com.yihaodian.mobile.service.client.message.service.impl;

import java.util.List;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.message.MessageCenterService;

public class MessageCenterClientServiceImpl implements MessageCenterService {
    
    
    private MessageCenterService  messageCenterHessianCall;

    public void setMessageCenterHessianCall(MessageCenterService messageCenterHessianCall) {
        this.messageCenterHessianCall = messageCenterHessianCall;
    }

    @Override
    public Result getNoReadCountWithUserId(String userToken, int isRead) {
        Result result = messageCenterHessianCall.getNoReadCountWithUserId(userToken, isRead);
        return result;
    }


    @Override
    public Result getMessagesWithUserId(String userToken, int startIndex, int size) {
        return messageCenterHessianCall.getMessagesWithUserId(userToken, startIndex, size);
    }

    @Override
    public Result getMessagesWithMSrc(String userToken, Long messageType, int startIndex, int size,
                                      int platform) {
        return messageCenterHessianCall.getMessagesWithMSrc(userToken, messageType, startIndex, size, platform);
    }

    @Override
    public Result updateMessageISRead(String userToken, Long messageId) {
        return messageCenterHessianCall.updateMessageISRead(userToken, messageId);
    }

    @Override
    public Result updateMessageISReadWithMessT(String userToken, Long messageType) {
        return messageCenterHessianCall.updateMessageISReadWithMessT(userToken, messageType);
    }

    @Override
    public Result getFMessTypeSubStatus(String userToken) {
        Result result = messageCenterHessianCall.getFMessTypeSubStatus(userToken);
        return result;
    }

    @Override
    public Result updateSubStatusWithFiType(String userToken, Long firstCateType) {
        return messageCenterHessianCall.updateSubStatusWithFiType(userToken, firstCateType);
    }

    @Override
    public Result updateUnSubStatusWithFiType(String userToken, Long firstCateType) {
        return messageCenterHessianCall.updateUnSubStatusWithFiType(userToken, firstCateType);
    }

    @Override
    public Result deleteMesssaageWithMType(String userToken, Long messageType) {
        return messageCenterHessianCall.deleteMesssaageWithMType(userToken, messageType);
    }

    @Override
    public Result deleteSingleMesssage(String userToken, Long messageId) {
        return messageCenterHessianCall.deleteSingleMesssage(userToken, messageId);
    }

    @Override
    public Result deleteMultiMesssage(String userToken, List<Long> messageIds) {
        return messageCenterHessianCall.deleteMultiMesssage(userToken, messageIds);
    }

    @Override
    public Result getNoReadMessageF(String userToken) {       
        return messageCenterHessianCall.getNoReadMessageF(userToken);
    }

    @Override
    public Result getMessageCatelogByParent() {       
        return messageCenterHessianCall.getMessageCatelogByParent();
    }

    @Override
    public Result isUserSubscribeBatch(String userToken, List<Long> cateIds) {        
        return messageCenterHessianCall.isUserSubscribeBatch(userToken, cateIds);
    }

    @Override
    public Result subscribeMessage(String userToken, Long cateId) {        
        return messageCenterHessianCall.subscribeMessage(userToken, cateId);
    }

    @Override
    public Result unsubscribeMessage(String userToken, Long cateId) {        
        return messageCenterHessianCall.unsubscribeMessage(userToken, cateId);
    }

	@Override
	public Result getNoReadCountWithUserId(Long userId, int isRead) {
		return messageCenterHessianCall.getNoReadCountWithUserId(userId, isRead);
	}

	@Override
	public Result getNoReadMessageF(Long userId) {
		return messageCenterHessianCall.getNoReadMessageF(userId);
	}

	@Override
	public Result getMessagesWithUserId(Long userId, int startIndex, int size) {
		return messageCenterHessianCall.getMessagesWithUserId(userId, startIndex, size);
	}

	@Override
	public Result getMessagesWithMSrc(Long userId, Long messageType,
			int startIndex, int size, int platform) {
		return messageCenterHessianCall.getMessagesWithMSrc(userId, messageType, startIndex, size, platform);
	}

	@Override
	public Result updateMessageISRead(Long userId, Long messageId) {
		return messageCenterHessianCall.updateMessageISRead(userId, messageId);
	}

	@Override
	public Result updateMessageISReadWithMessT(Long userId, Long messageType) {
		return messageCenterHessianCall.updateMessageISReadWithMessT(userId, messageType);
	}

	@Override
	public Result getFMessTypeSubStatus(Long userId) {
		return messageCenterHessianCall.getFMessTypeSubStatus(userId);
	}

	@Override
	public Result updateSubStatusWithFiType(Long userId, Long firstCateType) {
		return messageCenterHessianCall.updateSubStatusWithFiType(userId, firstCateType);
	}

	@Override
	public Result updateUnSubStatusWithFiType(Long userId, Long firstCateType) {
		return messageCenterHessianCall.updateUnSubStatusWithFiType(userId, firstCateType);
	}

	@Override
	public Result deleteMesssaageWithMType(Long userId, Long messageType) {
		return messageCenterHessianCall.deleteMesssaageWithMType(userId, messageType);
	}

	@Override
	public Result deleteSingleMesssage(Long userId, Long messageId) {
		return messageCenterHessianCall.deleteSingleMesssage(userId, messageId);
	}

	@Override
	public Result deleteMultiMesssage(Long userId, List<Long> messageIds) {
		return messageCenterHessianCall.deleteMultiMesssage(userId, messageIds);
	}

	@Override
	public Result isUserSubscribeBatch(Long userId, List<Long> cateIds) {
		return messageCenterHessianCall.isUserSubscribeBatch(userId, cateIds);
	}

	@Override
	public Result subscribeMessage(Long userId, Long cateId) {
		return messageCenterHessianCall.subscribeMessage(userId, cateId);
	}

	@Override
	public Result unsubscribeMessage(Long userId, Long cateId) {
		return messageCenterHessianCall.unsubscribeMessage(userId, cateId);
	}

}
