package com.yihaodian.mobile.hedwig.client.service.impl;

import java.util.List;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.hedwig.core.service.spi.ProductService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.core.PagePms;
import com.yihaodian.mobile.vo.product.AdvertisementVO;
import com.yihaodian.mobile.vo.product.HotPointVO;
import com.yihaodian.mobile.vo.product.ProductVO;
import com.yihaodian.mobile.vo.product.ProductYhbVO;

public class ProductClientServiceImpl implements ProductService {

	private ProductService productHessiancall;

	@Override
	public List<ProductVO> getHomeHotProductTop5List(Trader trader,
			Long provinceId) {

		return productHessiancall.getHomeHotProductTop5List(trader, provinceId);
	}

	@Override
	public Page<HotPointVO> getHomeHotPointList(Trader trader, Long provinceId,
			Integer currentPage, Integer pageSize) {
		return productHessiancall.getHomeHotPointList(trader, provinceId,
				currentPage, pageSize);
	}

	@Override
	public Page<ProductVO> getHotProductByActivityID(Trader trader,
			Long activityID, Long provinceId, Integer currentPage,
			Integer pageSize) {

		return productHessiancall.getHotProductByActivityID(trader, activityID,
				provinceId, currentPage, pageSize);
	}

	@Override
	public Page<ProductVO> getPromotionProductPage(Trader trader,
			Long provinceId, Long categoryId, Integer currentPage,
			Integer pageSize) {
		return productHessiancall.getPromotionProductPage(trader, provinceId,
				categoryId, currentPage, pageSize);
	}

	@Override
	public Page<ProductVO> getHotProductPageByCategoryId(Trader trader,
			Long provinceId, Long categoryId, Integer currentPage,
			Integer pageSize) {
		return productHessiancall.getHotProductPageByCategoryId(trader,
				provinceId, categoryId, currentPage, pageSize);
	}

	@Override
	public Long getHotProductCountByCategoryId(Trader trader, Long provinceId,
			Long categoryId) {

		return productHessiancall.getHotProductCountByCategoryId(trader,
				provinceId, categoryId);
	}

	@Override
	public List<ProductVO> getHotRandomProducts(Trader trader, Long provinceId) {
		return productHessiancall.getHotRandomProducts(trader, provinceId);
	}

	@Override
	public Page<ProductVO> getUserInterestedProductsV2(Trader trader,
			Long provinceId, Integer currentPage, Integer pageSize) {

		return productHessiancall.getUserInterestedProductsV2(trader,
				provinceId, currentPage, pageSize);
	}

	@Override
	public Page<ProductVO> getPackageProducts(Trader trader, Long productId,
			Integer currentPage, Integer pageSize, Long provinceId) {
		return productHessiancall.getPackageProducts(trader, productId,
				currentPage, pageSize, provinceId);
	}

	@Override
	public Page<ProductVO> getMoreInterestedProducts(Trader trader,
			Long productId, Integer currentPage, Integer pageSize) {
		return productHessiancall.getMoreInterestedProducts(trader, productId,
				currentPage, pageSize);
	}

	@Override
	public Page<ProductVO> getMoreInterestedProducts(Trader trader,
			Long productId, Long provinceId, Integer currentPage,
			Integer pageSize) {
		return productHessiancall.getMoreInterestedProducts(trader, productId,
				provinceId, currentPage, pageSize);
	}

	@Override
	public Page<ProductVO> getUserBehavior(String token, Integer currentPage,
			Integer pageSize) {

		return productHessiancall.getUserBehavior(token, currentPage, pageSize);
	}

	@Override
	public List<String> getUserInterestedProductsCategorys(Trader trader) {

		return productHessiancall.getUserInterestedProductsCategorys(trader);
	}

	@Override
	public Page<AdvertisementVO> getAdvertisementList(Trader trader,
			Long provinceId, Integer currentPage, Integer pageSize) {
		return productHessiancall.getAdvertisementList(trader, provinceId,
				currentPage, pageSize);
	}

	@Override
	public Page<ProductYhbVO> getYhbByCategoryId(Trader trader,
			Long categoryId, Long mcsiteid, Long siteType, Long provinceId,
			Integer currentPage, Integer pageSize) {
		return productHessiancall.getYhbByCategoryId(trader, categoryId,
				mcsiteid, siteType, provinceId, currentPage, pageSize);
	}

	@Override
	public PagePms<ProductYhbVO> getYhbPageByCategoryId(Trader trader,
			Long categoryId, Long mcsiteid, Long siteType, Long provinceId,
			Integer currentPage, Integer pageSize) {

		return productHessiancall.getYhbPageByCategoryId(trader, categoryId,
				mcsiteid, siteType, provinceId, currentPage, pageSize);
	}
	

	/**
	 * web 2.0 使用V2代替
	 * 
	 * @see com.yihaodian.mobile.service.hedwig.core.service.spi.ProductService#getUserInterestedProducts(java.lang.String,
	 *      java.lang.Integer, java.lang.Integer)
	 */
	@Override
	public Page<ProductVO> getUserInterestedProducts(String token,
			Integer currentPage, Integer pageSize) {
		return null;
	}

	public ProductService getProductHessiancall() {
		return productHessiancall;
	}

	public void setProductHessiancall(ProductService productHessiancall) {
		this.productHessiancall = productHessiancall;
	}
}
