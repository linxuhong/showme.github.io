package com.yihaodian.mobile.hedwig.client.mobileUser.service;

import com.yihaodian.mobile.hedwig.push.vo.MobileUserInfo;

public interface MobileUserClientService {

	public MobileUserInfo getMobileUserInfoByToken(String token);
}
