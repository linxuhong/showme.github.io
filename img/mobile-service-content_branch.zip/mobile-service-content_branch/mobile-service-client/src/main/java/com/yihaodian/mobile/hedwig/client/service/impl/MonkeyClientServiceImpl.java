package com.yihaodian.mobile.hedwig.client.service.impl;

import com.yihaodian.mobile.service.hedwig.core.service.spi.MonkeyService;
import com.yihaodian.mobile.vo.monkey.MonkeyExtratCouponResultVO;
import com.yihaodian.mobile.vo.order.CouponGetCheckCodeResult;
import com.yihaodian.mobile.vo.order.CouponVerifyCheckCodeResult;

public class MonkeyClientServiceImpl implements MonkeyService {

	private MonkeyService monkeyHessiancall;

	@Override
	public MonkeyExtratCouponResultVO monkeyGetExtratCouponResult(String token,
			Double lng, Double lat) {
		return monkeyHessiancall.monkeyGetExtratCouponResult(token, lng, lat);
	}

	@Override
	public CouponGetCheckCodeResult monkeyGetCouponCheckCode(String token,
			String mobile) {
		
		return monkeyHessiancall.monkeyGetCouponCheckCode(token, mobile);
	}

	@Override
	public CouponVerifyCheckCodeResult monkeyVerifyCouponCheckCode(
			String token, String mobile, String checkCode) {
		
		return monkeyHessiancall.monkeyVerifyCouponCheckCode(token, mobile, checkCode);
	}

	@Override
	public Integer monkeyCheckMobileNumber(String token, String mobile) {
		
		return monkeyHessiancall.monkeyCheckMobileNumber(token, mobile);
	}

	@Override
	public Integer monkeyInsertAddress(String token, String receiverName,
			String detailAddress, String mobile) {
		return monkeyHessiancall.monkeyInsertAddress(token, receiverName, detailAddress, mobile);
	}

	public MonkeyService getMonkeyHessiancall() {
		return monkeyHessiancall;
	}

	public void setMonkeyHessiancall(MonkeyService monkeyHessiancall) {
		this.monkeyHessiancall = monkeyHessiancall;
	}

	@Override
	public MonkeyExtratCouponResultVO monkeyGetExtratCouponResult(Long userId,
			Double lng, Double lat) {
		return monkeyHessiancall.monkeyGetExtratCouponResult(userId, lng, lat);
	}

	@Override
	public Integer monkeyInsertAddress(Long UserId, String receiverName,
			String detailAddress, String mobile) {		
		return monkeyHessiancall.monkeyInsertAddress(UserId, receiverName, detailAddress, mobile);
	}

	
}
