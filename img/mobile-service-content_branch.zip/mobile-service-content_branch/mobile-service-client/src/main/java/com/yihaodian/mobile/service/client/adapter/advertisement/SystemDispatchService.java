/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;

import org.apache.log4j.Logger;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.system.SystemService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.constant.CommonKey;
import com.yihaodian.mobile.vo.system.AppFunctionSwitchVO;
import com.yihaodian.mobile.vo.system.DownloadVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class SystemDispatchService.
 * @author zuodeng
 */
public class SystemDispatchService extends BaseDiapatchService {
    
    /** The logger. */
    private Logger logger = Logger.getLogger(SystemDispatchService.class);

	
	/**
	 * 检测APP是否有更新.
	 *
	 * @author zhangwei5
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the client application download url
	 */
	public RtnInfo getClientApplicationDownloadUrl(String urlPath, Boolean isLogined,
	                                               Map<String, String> bizInfo, AdapterContext context){
	    try {
	        Trader trader = getTraderFromContext(context);
	        RtnInfo rtnInfo = vaildateTrader(trader);
	        if(rtnInfo==null){
	        	trader.setProtocol("HTTPXML");
        		if("iosSystem".equals(trader.getTraderName())){
        			trader.setTraderPassword("4JanEnE@");
        		}else if("androidSystem".equals(trader.getTraderName())){
        			trader.setTraderPassword("sCarce!8");
        		}else if("ipadSystem".equals(trader.getTraderName())){
        			trader.setTraderPassword("1HaoP@d");
        		} else if (CommonKey.TRADER_NAME_ANDROID_EN.equals(trader.getTraderName())) {
        			trader.setTraderPassword("sCarce!4");
        		} else if (CommonKey.TRADER_NAME_IPHONE_EN.equals(trader.getTraderName())) {
        			trader.setTraderPassword("8JanEnE@");
        		}
 	        	if(StringUtil.isBlank(trader.getInterfaceVersion())){
	        		trader.setInterfaceVersion("1.3.8");
	        	}
                String cityid = bizInfo.get("cityid");
                if (cityid == null)
                    cityid = context.getRequestInfo().getCityId();

                ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
                clientInfoVO.setCityId(cityid);
 	            
	            SystemService systemService = CentralMobileServiceHandler.getSystemService();
	            DownloadVO result = systemService.getClientApplicationDownloadUrl(trader,clientInfoVO);
	            rtnInfo = RtnInfo.RightWlRtnInfo(result);
	        }
	        return rtnInfo;
        } catch (Exception e) {
            logger.error("getNoReadCountWithUserId has error ", e);
            return RtnInfo.ParameterErrRtnInfo("some prams null");
        }
	}
	
	
	public RtnInfo getAppFunctionSwitch(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(trader==null || trader.getTraderName()=="" ){
			return RtnInfo.ParameterErrRtnInfo("trader or trader name is null");
		}
		SystemService systemFacadeService = CentralMobileServiceHandler.getSystemService();
		List<AppFunctionSwitchVO> vo = systemFacadeService.getAppFunctionSwitch(trader);
		return RtnInfo.RightWlRtnInfo(vo);
	}
	
	public RtnInfo getEnSwitches(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(trader==null || trader.getTraderName()=="" ){
			return RtnInfo.ParameterErrRtnInfo("trader or trader name is null");
		}
		SystemService systemFacadeService = CentralMobileServiceHandler.getSystemService();
		List<AppFunctionSwitchVO> vo = systemFacadeService.getEnSwitches(trader);
		return RtnInfo.RightWlRtnInfo(vo);
	}
	
	public RtnInfo registerLaunchInfo(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(trader==null || trader.getTraderName()=="" ){
			return RtnInfo.ParameterErrRtnInfo("trader or trader name is null");
		}

		String iMei =trader.getDeviceCode();// bizInfo.get("imei");
		if(StringUtil.isEmpty(iMei)){
			return RtnInfo.ParameterErrRtnInfo("DeviceCodeis null");
		}
		String phoneNo = bizInfo.get("phoneno");
		RtnInfo result = validateNumber(phoneNo);
		if(result!=null){
			return result;
		}
		
		SystemService systemFacadeService = CentralMobileServiceHandler.getSystemService();
		String ip = context.getRequestInfo().getClientInfo().getClientIp();
		Integer vo = systemFacadeService.registerLaunchInfo(trader, iMei, phoneNo,ip );
		return RtnInfo.RightWlRtnInfo(vo);
	}                         
}
