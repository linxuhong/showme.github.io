package com.yihaodian.mobile.service.client.advertisement.service.impl;

import java.util.List;

import com.yihaodian.mobile.service.domain.business.dal.backend.AdPage;
import com.yihaodian.mobile.service.facade.business.advertisement.AdService;
import com.yihaodian.mobile.vo.ad.DataResource;
import com.yihaodian.mobile.vo.ad.MobAd;
import com.yihaodian.mobile.vo.ad.MobAdResource;
import com.yihaodian.mobile.vo.ad.RequestParams;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class AdClientService implements AdService{
	
	private AdService adServiceHessianCall;

	public AdService getAdServiceHessianCall() {
		return adServiceHessianCall;
	}

	public void setAdServiceHessianCall(AdService adServiceHessianCall) {
		this.adServiceHessianCall = adServiceHessianCall;
	}

	@Override
	public MobAd<MobAdResource<DataResource>> getAnnouncements(
			Integer pageType, Integer seatType, String provinceId,
			String clientAppVersion, String platForm,Long cityId) {
		return adServiceHessianCall.getAnnouncements(pageType, seatType, provinceId, clientAppVersion, platForm,cityId);
	}

	@Override
	public MobAdResource<DataResource> getHotWords(Integer pageType,
			Integer seatType, String provinceId, Trader trader, String userId) {
		return adServiceHessianCall.getHotWords(pageType, seatType, provinceId, trader, userId);
	}

	@Override
	public List<MobAdResource<DataResource>> getActPushMessages(Integer pageType,
			Integer seatType, String provinceId, String clientSystem) {
		return adServiceHessianCall.getActPushMessages(pageType, seatType, provinceId, clientSystem);
	}

	@Override
	public List<AdPage> getCurtainAdvertisement(RequestParams requestParams) {
		return null;
	}

	@Override
	public List<AdPage> getBackgroundImgs(String provinceId, String traderName) {
		return adServiceHessianCall.getBackgroundImgs(provinceId, traderName);
	}

	@Override
	public MobAdResource<DataResource> getHotWordsForCity(Integer pageType,
			Integer seatType, String provinceId, Trader trader, String userId,
			String cityId) {
		return adServiceHessianCall.getHotWordsForCity(pageType, seatType, provinceId, trader, userId, cityId);
	}
}
