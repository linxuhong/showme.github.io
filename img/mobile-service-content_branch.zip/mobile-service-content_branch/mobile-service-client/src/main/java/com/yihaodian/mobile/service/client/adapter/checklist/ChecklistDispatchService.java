package com.yihaodian.mobile.service.client.adapter.checklist;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.yhd.gps.utils.DateUtil;
import com.yihaodian.mobile.backend.checklist.vo.BatchSaveListVO;
import com.yihaodian.mobile.backend.checklist.vo.LinkedItemVO;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.checklist.spi.ChecklistService;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.FeedbackService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.result.ContentResult;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class ChecklistDispatchService extends BaseDiapatchService {
	
	private static final Logger logger = LoggerFactory.getLogger(ChecklistDispatchService.class);
	
	public RtnInfo getUserAllLists(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String includeItems = bizInfo.get("includeitems");
		String includeAuthUsers = bizInfo.get("includeauthusers");
		String isDoneOnly = bizInfo.get("isdoneonly");
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.getUserAllLists(Long.valueOf(uid), convertBoolean(includeItems), 
				convertBoolean(includeAuthUsers), convertBoolean(isDoneOnly));
		return getRtnInfo(result);
	}
	
	public RtnInfo getUserListDetail(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.getUserListDetail(Long.valueOf(uid), Long.valueOf(listId));
		return getRtnInfo(result);
	}
	
	public RtnInfo createUserList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String title = bizInfo.get("title");
		String remindTime = bizInfo.get("remindtime");
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.createUserList(Long.valueOf(uid), title, DateUtil.parseDate(remindTime));
		return getRtnInfo(result);
	}
	
	public RtnInfo updateUserList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		String version = bizInfo.get("version");
		rtn = validateNumber(version);
		if (rtn != null) {
			return rtn;
		}
		
		String title = bizInfo.get("title");
		String remindTime = bizInfo.get("remindtime");
		String oneClickDone = bizInfo.get("oneclickdone");
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.updateUserList(Long.valueOf(uid), Long.valueOf(listId), title,
				DateUtil.parseDate(remindTime), convertBoolean(oneClickDone), Long.valueOf(version));
		return getRtnInfo(result);
	}
	
	public RtnInfo createListItem(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		String memo = bizInfo.get("memo");
		String picUrls = bizInfo.get("picurls");
		String externalUrl = bizInfo.get("externalurl");
		
		List<String> picUrlLst = JSON.parseArray(picUrls, String.class);
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.createListItem(Long.valueOf(uid), Long.valueOf(listId), memo, picUrlLst, externalUrl);
		return getRtnInfo(result);
	}
	
	public RtnInfo updateListItem(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		String itemId = bizInfo.get("itemid");
		rtn = validateNumber(itemId);
		if (rtn != null) {
			return rtn;
		}
		String version = bizInfo.get("version");
		rtn = validateNumber(version);
		if (rtn != null) {
			return rtn;
		}
		String memo = bizInfo.get("memo");
		String picUrls = bizInfo.get("picurls");
		String externalUrl = bizInfo.get("externalurl");
		String isDone = bizInfo.get("isdone");
		String picIds2Del = bizInfo.get("picids2del");
		String replaceMode = bizInfo.get("replacemode");
		
		List<String> picUrlLst = JSON.parseArray(picUrls, String.class);
		List<Long> picIds = JSON.parseArray(picIds2Del, Long.class);
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.updateListItem(Long.valueOf(uid), Long.valueOf(listId), Long.valueOf(itemId), 
				memo, externalUrl, picUrlLst, picIds, convertBoolean(isDone), convertBoolean(replaceMode), Long.valueOf(version));
		return getRtnInfo(result);
	}
	
	public RtnInfo reorderListItem(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		String itemId = bizInfo.get("itemid");
		rtn = validateNumber(itemId);
		if (rtn != null) {
			return rtn;
		}
		String move = bizInfo.get("move");
		rtn = validateNumber(move);
		if (rtn != null) {
			return rtn;
		}
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.reorderListItem(Long.valueOf(uid), Long.valueOf(listId), Long.valueOf(itemId), Integer.valueOf(move));
		return getRtnInfo(result);
	}
	
	public RtnInfo cloneListItems(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String items2Clone = bizInfo.get("items2clone");
		List<LinkedItemVO> linkedItems = JSON.parseArray(items2Clone, LinkedItemVO.class);
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.cloneListItems(Long.valueOf(uid), linkedItems);
		return getRtnInfo(result);
	}
	
	public RtnInfo copyListItems(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		String itemIds = bizInfo.get("itemids");
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.copyListItems(Long.valueOf(uid), JSON.parseArray(itemIds, Long.class), Long.valueOf(listId));
		return getRtnInfo(result);
	}
	
	public RtnInfo authorizeUsersListRequest(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		String authUsers = bizInfo.get("authusers");
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.authorizeUsersListRequest(Long.valueOf(uid),
				Long.valueOf(listId), JSON.parseArray(authUsers, Long.class));
		return getRtnInfo(result);
	}

	public RtnInfo authorizeUserListResponse(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		String userId = bizInfo.get("userid");
		rtn = validateNumber(userId);
		if (rtn != null) {
			return rtn;
		}
		
		String accept = bizInfo.get("accept");
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.authorizeUserListResponse(Long.valueOf(uid), Long.valueOf(userId), 
				Long.valueOf(listId), convertBoolean(accept));
		
		return getRtnInfo(result);
	}
	
	public RtnInfo getUserAuthorizeListPendingRequests(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.getUserAuthorizeListPendingRequests(Long.valueOf(uid));
		
		return getRtnInfo(result);
	}
	
	public RtnInfo deleteUserList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		String version = bizInfo.get("version");
		rtn = validateNumber(version);
		if (rtn != null) {
			return rtn;
		}
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.deleteUserList(Long.valueOf(uid), Long.valueOf(listId), Long.valueOf(version));
		
		return getRtnInfo(result);
	}
	
	public RtnInfo deleteListItem(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String listId = bizInfo.get("listid");
		RtnInfo rtn = validateNumber(listId);
		if (rtn != null) {
			return rtn;
		}
		String itemId = bizInfo.get("itemid");
		rtn = validateNumber(itemId);
		if (rtn != null) {
			return rtn;
		}
		String version = bizInfo.get("version");
		rtn = validateNumber(version);
		if (rtn != null) {
			return rtn;
		}
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.deleteListItem(Long.valueOf(uid), Long.valueOf(listId), 
				Long.valueOf(itemId), Long.valueOf(version));
		
		return getRtnInfo(result);
	}
	
	public RtnInfo batchSaveItemList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String offlineList = bizInfo.get("offlinelist");
		String replaceMode = bizInfo.get("replacemode");
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.batchSaveItemList(Long.valueOf(uid), 
				JSON.parseObject(offlineList, BatchSaveListVO.class), convertBoolean(replaceMode));
		
		return getRtnInfo(result);
	}
	
	public RtnInfo parseExternalUrl(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String externalUrl = bizInfo.get("externalurl");
		if (StringUtils.isBlank(externalUrl)) {
			return RtnInfo.ParameterErrRtnInfo("externalUrl cannot be null.");
		}
		
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		Long provinceId = 1L; //default to ShangHai
		if (StringUtils.isNumeric(provinceIdStr)) {
			provinceId = Long.valueOf(provinceIdStr);
		}
		
		ChecklistService service = CentralMobileServiceHandler.getChecklistService();
		Result result = service.parseExternalUrl(externalUrl, provinceId);
		
		return getRtnInfo(result);
	}
	
	/**
	 * Adds the feedback.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo addFeedbackForChecklist(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try{
			if(!isLogined){
				return RtnInfo.TokenErrWlRtnInfo();
			}
			FeedbackService feedbackService = CentralMobileServiceHandler.getFeedbackService();
			String feedbackcontext = bizInfo.get("feedbackcontext");
			if(StringUtil.isEmpty(feedbackcontext)){
				return RtnInfo.ParameterErrRtnInfo("feedbackcontext is null");
			}	
			//2016.7.5 增加上传图片
			String image1 = bizInfo.get("image1");
			String image2 = bizInfo.get("image2");
			String image3 = bizInfo.get("image3");
			
            Trader trader = this.getTraderFromContext(context);
            RtnInfo rtnInfo = vaildateTrader(trader);
            if (rtnInfo != null) {
                return rtnInfo;
            }
			//根据type判断如果用户传递了正确的type则使用用户反馈V2来记录用户反馈信息, 20代表清单用户反馈
			String type = bizInfo.get("type");
			
			//2016.1.19 增加保存联系方式
			String info = bizInfo.get("info");//暂定在info里面
			
			if(StringUtil.isNotEmpty(type)&&type.matches(RegexEnum.PURE_DIGITAL.getRegex())){
				ContentResult<String> result = feedbackService.addFeedbackV2(Long.valueOf(context.getCurrentUserId()), feedbackcontext, 
						image1, image2, image3, Integer.valueOf(type), trader, info);
			    return RtnInfo.RightWlRtnInfo(result);
			}else{
				Integer act = feedbackService.addFeedback(Long.valueOf(context.getCurrentUserId()), feedbackcontext,
						image1, image2, image3, trader,info);
			    return RtnInfo.RightWlRtnInfo(act);
			}
		}catch(Exception e){
			logger.error("ChecklistDispatchService=>addFeedback error", e);
			return RtnInfo.RightWlRtnInfo(FeedbackService.FAILED);
		}
		
	}
}
