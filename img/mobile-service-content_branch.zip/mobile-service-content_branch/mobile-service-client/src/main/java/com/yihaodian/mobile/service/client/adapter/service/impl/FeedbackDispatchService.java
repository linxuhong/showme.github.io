/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.hedwig.core.service.spi.FeedbackService;
import com.yihaodian.mobile.vo.result.ContentResult;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.feedback.FeedBackTypeInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class FeedbackDispatchService.
 */
public class FeedbackDispatchService extends BaseDiapatchService {
	
	/** The Constant logger. */
	private final static Logger logger = LoggerFactory
			.getLogger(FeedbackDispatchService.class);
	
	/**
	 * Adds the feedback.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo addFeedback(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try{
			if(!isLogined){
				return RtnInfo.TokenErrWlRtnInfo();
			}
			FeedbackService feedbackService = CentralMobileServiceHandler.getFeedbackService();
			String feedbackcontext = bizInfo.get("feedbackcontext");
			if(StringUtil.isEmpty(feedbackcontext)){
				return RtnInfo.ParameterErrRtnInfo("feedbackcontext is null");
				
			}	
			//2016.7.5 增加上传图片
			String image1 = bizInfo.get("image1");
			String image2 = bizInfo.get("image2");
			String image3 = bizInfo.get("image3");
			
            Trader trader = this.getTraderFromContext(context);
            RtnInfo rtnInfo = vaildateTrader(trader);
            if (rtnInfo != null) {
                return rtnInfo;
            }
			//根据type判断如果用户传递了正确的type则使用用户反馈V2来记录用户反馈信息
			String type = bizInfo.get("type");
			
			//2016.1.19 增加保存联系方式
			String info = bizInfo.get("info");//暂定在infor里面
			
			if(StringUtil.isNotEmpty(type)&&type.matches(RegexEnum.PURE_DIGITAL.getRegex())){
//				2016.1.19 增加保存联系方式
//				2016.7.5 增加上传图片
//			    ContentResult<String> result = feedbackService.addFeedbackV2(Long.valueOf(context.getCurrentUserId()), feedbackcontext, Integer.valueOf(type),trader);
				ContentResult<String> result = feedbackService.addFeedbackV2(Long.valueOf(context.getCurrentUserId()), feedbackcontext, 
						image1, image2, image3, Integer.valueOf(type), trader, info);
				return RtnInfo.RightWlRtnInfo(result);
			}else{
//				2016.1.19 增加保存联系方式;
//				2016.7.5 增加上传图片
//			    Integer act = feedbackService.addFeedback(Long.valueOf(context.getCurrentUserId()), feedbackcontext,trader);
				Integer act = feedbackService.addFeedback(Long.valueOf(context.getCurrentUserId()), feedbackcontext,
						image1, image2, image3, trader,info);
			    return RtnInfo.RightWlRtnInfo(act);
			}
		}catch(Exception e){
			logger.error("FeedbackDispatchService=>addFeedback error", e);
			return null;
		}
		
	}
	
	/**
	 * Gets the feed back type info list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the feed back type info list
	 */
	public RtnInfo getFeedBackTypeInfoList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try{
			Trader trader = this.getTraderFromContext(context);
			RtnInfo rtnInfo = vaildateTrader(trader);
			if(rtnInfo != null){
				return rtnInfo;
			}
			FeedbackService feedbackService = CentralMobileServiceHandler.getFeedbackService();
			List<FeedBackTypeInfoVO> result = feedbackService.getFeedBackTypeInfoList(trader);
			return RtnInfo.RightWlRtnInfo(result);
		}catch(Exception e){
			logger.error("FeedbackDispatchService=>getFeedBackTypeInfoList error", e);
			return RtnInfo.ParameterErrRtnInfo("some pram is null");
		}
		
	}

}
