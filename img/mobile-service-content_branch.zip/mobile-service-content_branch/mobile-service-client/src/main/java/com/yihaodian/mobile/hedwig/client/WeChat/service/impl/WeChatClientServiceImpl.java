package com.yihaodian.mobile.hedwig.client.WeChat.service.impl;

import com.yihaodian.mobile.hedwig.client.WeChat.service.WeChatClientService;
import com.yihaodian.mobile.hedwig.push.spi.WeChatFacdeService;
import com.yihaodian.mobile.hedwig.push.vo.WeChatProductVO;

public class WeChatClientServiceImpl implements WeChatClientService{
	
	private WeChatFacdeService<String> weChatHessianCall;

	public void setWeChatHessianCall(WeChatFacdeService<String> weChatHessianCall) {
		this.weChatHessianCall = weChatHessianCall;
	}

	@Override
	public WeChatProductVO getWeChatProductVODetail(Long productId,
			Long provinceId) {
		return weChatHessianCall.getWeChatProductVODetail(productId, provinceId);
	}

}
