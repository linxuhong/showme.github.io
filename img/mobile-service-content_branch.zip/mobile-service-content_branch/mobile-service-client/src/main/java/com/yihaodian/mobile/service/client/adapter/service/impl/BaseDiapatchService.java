/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.service.impl;

import org.springframework.beans.BeanUtils;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.domain.business.emuns.CommonResultCode;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.ResultHolderVo;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;
import com.yihaodian.mobile2.server.context.RequestInfo.ClientInfo;

/**
 * The Class BaseDiapatchService.
 */
public class BaseDiapatchService {

	/**
	 * Gets the trader from context.
	 *
	 * @param context the context
	 * @return the trader from context
	 */
	public Trader getTraderFromContext(AdapterContext context){
		ClientInfo clientInfo = context.getRequestInfo().getClientInfo();
        return getTraderFromClientInfo(clientInfo,context);
	}

    public static Trader getTraderFromClientInfo(ClientInfo clientInfo,AdapterContext context) {
        if (clientInfo != null) {
            Trader trader = new Trader();
            trader.setClientAppVersion(clientInfo.getClientAppVersion());
            trader.setClientSystem(clientInfo.getClientSystem());
            trader.setClientVersion(clientInfo.getClientVersion());
            trader.setDeviceCode(clientInfo.getDeviceCode());
            trader.setDeviceCodeNotEncrypt(clientInfo.getDeviceCode());
            if (clientInfo.getLatitude() != null) {
                trader.setLatitude(Double.parseDouble(clientInfo.getLatitude()));
            }
            if (clientInfo.getLongitude() != null) {
                trader.setLongitude(Double.parseDouble(clientInfo.getLongitude()));
            }
            trader.setProvinceId(context.getRequestInfo().getProvinceId());
            trader.setCityId(context.getRequestInfo().getCityId());
            trader.setTraderName(clientInfo.getTraderName());
            trader.setUnionKey(clientInfo.getUnionKey());
            trader.setInterfaceVersion("3.3.0");
            trader.setTraderPassword("123456");
            trader.setProtocol("Webservice");
            return trader;
        }
        return null;
    }
    
	/**
	 * 1 and true means true; otherwise false
	 * @param value
	 * @return
	 */
	public static Boolean convertBoolean(String value) {
		if ("1".equals(value)) {
			return Boolean.TRUE;
		}
		
		return Boolean.valueOf(value);
	}

	/**
	 * Convert client info vo.
	 *
	 * @param info the info
	 * @return the client info vo
	 */
	public ClientInfoVO convertClientInfoVO(ClientInfo info){
		ClientInfoVO vo = new ClientInfoVO();
		if(info!=null){
			BeanUtils.copyProperties(info, vo);
			vo.setNettype(info.getNetType());
			vo.setClientip(info.getClientIp());
			vo.setAbTest(info.getAbtest());
		}
		return vo;
	}
	
	/**
	 * Convert client info vo.
	 *
	 * @param info the info
	 * @return the client info vo
	 */
	public ClientInfoVO convertClientInfoVO(ClientInfo info, String provinceId, String cityId){
		ClientInfoVO vo = new ClientInfoVO();
		if(info!=null){
			BeanUtils.copyProperties(info, vo);
			vo.setNettype(info.getNetType());
			vo.setClientip(info.getClientIp());
			vo.setAbTest(info.getAbtest());
			vo.setProvinceId(provinceId);
			vo.setCityId(cityId);
		}
		return vo;
	}
	
	/**
	 * Gets the rtn info.
	 *
	 * @param result the result
	 * @return the rtn info
	 */
	public RtnInfo getRtnInfo(Result result){
		if(result == null){
			return null;
		}
		
		if(result.isSuccess()){
			if (result.getDefaultModel() == null) {
				result.setDefaultModel(holderVo);
			}
			return  RtnInfo.RightWlRtnInfo(result.getDefaultModel());
		}else{
			if(result.getBaseResultCode()==null){
				result.setBaseResultCode(CommonResultCode.SYSTEM_EXCEPTION);
			}
		    return new RtnInfo(result.getBaseResultCode().getCode(), result.getBaseResultCode().getMsg(), result.getBaseResultCode().getDetail());
		}
	}
	
	/**
	 * Gets the system error result.
	 *
	 * @return the system error result
	 */
	public static Result getSystemErrorResult(){
	    Result result = new ResultModel();
	    result.setSuccess(false);
        result.setBaseResultCode(CommonResultCode.PARAMS_SYSTEM_ID_ERROR_EXCEPTION);
        return result;
	}
	
	/**
	 * trader 参数校验.
	 *
	 * @param trader the trader
	 * @return the rtn info
	 */
	public RtnInfo vaildateTrader(Trader trader){
	    if(trader==null){
	        return RtnInfo.ParameterErrRtnInfo("trader is null"); 
	    }
	    
	    if(trader.getTraderName()==null){
            return RtnInfo.ParameterErrRtnInfo("tradername is null"); 	        
	    }
	    
	    return null;
	}
	
	/**
	 * 省份参数校验.
	 *
	 * @param provinceIdStr 省份ID字符串
	 * @return the rtn info
	 */
	public RtnInfo validateProvinceId(String provinceIdStr){
	    if(StringUtil.isBlank(provinceIdStr)||!provinceIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
            return RtnInfo.ParameterErrRtnInfo("provinceId 有误"); 	        
	    }
	    return null;
	}
	
    /**
     * 分页参数check.
     *
     * @param currentPage the current page
     * @param pageSize the page size
     * @return the rtn info
     */
    public RtnInfo validatePageInfo(String currentPage, String pageSize) {
        if (StringUtil.isBlank(currentPage)
            || !currentPage.matches(RegexEnum.PURE_DIGITAL.getRegex())) {
            return RtnInfo.ParameterErrRtnInfo("currentPage 有误");
        }
        
        if (StringUtil.isBlank(pageSize)
                || !pageSize.matches(RegexEnum.PURE_DIGITAL.getRegex())) {
            return RtnInfo.ParameterErrRtnInfo("pageSize 有误");
        }
        return null;
    }
    
    /**
     * 数字校验.
     *
     * @param field the field
     * @return the rtn info
     */
    public RtnInfo validateNumber(String field) {
        if (StringUtil.isBlank(field)
            || !field.matches(RegexEnum.PURE_DIGITAL.getRegex())) {
            return RtnInfo.ParameterErrRtnInfo("must be number");
        }
        return null;
    }
    
    /**
     * 对需要转为Integer 或者Long 类型数据做 为空校验 和格式校验
     * 
     * @param str
     * @return
     */
    public Result valiateGetParams(String str){
		 Result result = new ResultModel();
		 result.setSuccess(true);
		if(str==null||str.equals("")){
			result.setSuccess(false);
			result.setResultDesc("is null");
			return result;			
		}
		if(!str.matches(RegexEnum.PURE_DIGITAL.getRegex())){
			result.setSuccess(false);
			result.setResultDesc("formate error");
			return  result;	
		}
		return result;
	}
    /**
     * 比较客户端版本
     * @param versionSrc
     * @param versionDest
     * @return
     */
    public static int compareVersion(String versionSrc,String versionDest)
	{
		if(versionSrc == null && versionDest ==null){
			return 0;
		}else if(versionSrc == null){
			return 1;
		}else if(versionDest == null){
			return -1;
		}
		
		String [] src = versionSrc.split("\\.");
		String [] dest = versionDest.split("\\.");
		for(int i=0;i<src.length;i++)
		{
			if(i == dest.length)
				return -1;
			try{
				int s = Integer.parseInt(src[i]);
				int d = Integer.parseInt(dest[i]);
				if(d > s)
					return 1;
				if(d < s)
					return -1;
			}catch(Exception e)
			{
				return 0;
			}
		}
		if(src.length == dest.length)
			return 0;
		return 1;
	}

    // 站位VO,用于success的调用而没有data
    public static final ResultHolderVo holderVo = new ResultHolderVo();

	public Result valiateMultiParams(String... strs){
		 Result result = new ResultModel();
		 result.setSuccess(true);
		 for (String str : strs) {
			if (str == null || str.equals("")) {
				result.setSuccess(false);
				result.setResultDesc("is null");
				return result;
			}
			if (!str.matches(RegexEnum.PURE_DIGITAL.getRegex())) {
				result.setSuccess(false);
				result.setResultDesc("formate error");
				return result;
			}
		}
		return result;
	}
}
