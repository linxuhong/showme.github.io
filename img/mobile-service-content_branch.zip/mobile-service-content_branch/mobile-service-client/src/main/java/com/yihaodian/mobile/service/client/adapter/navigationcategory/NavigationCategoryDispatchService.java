/**
 * www.yhd.com-402 Inc.
 * Copyright (c) 2008-2015 All Rights Reserved.
 */
package com.yihaodian.mobile.service.client.adapter.navigationcategory;


import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.domain.vo.business.navigationcategory.CategoryAppVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;


public class NavigationCategoryDispatchService extends BaseDiapatchService {

	public RtnInfo getNavigationCategory(String urlPath, Boolean isLogined,  Map<String, String> bizInfo, AdapterContext context) {

		String level = bizInfo.get("level");
		RtnInfo rtn = validateNumber(level);
		if (rtn != null) {
			return rtn;
		}
 
		String sProvinceId = context.getRequestInfo().getProvinceId();
		rtn = validateNumber(sProvinceId);
		if(rtn != null){
			return rtn;
		}
		Long provinceId = Long.parseLong(sProvinceId);
		
		if ("1".equalsIgnoreCase(level)) {//取一级类目
			String sNavId = bizInfo.get("navid");
			rtn = validateNumber(sNavId);
			if (rtn != null) {
				return rtn;
			}
			Long navId = Long.parseLong(sNavId);
			List<CategoryAppVO> list = CentralMobileServiceHandler.getNavigationCategoryService().findRootCategories(navId, provinceId);
			return RtnInfo.RightWlRtnInfo(list);
		}
		
		if ("2".equalsIgnoreCase(level)) {
			String sRootcateid = bizInfo.get("rootcateid");
			rtn = validateNumber(sRootcateid);
			if (rtn != null) {
				return rtn;
			}
			Long rootCateId = Long.parseLong(sRootcateid);
			List<CategoryAppVO> list = CentralMobileServiceHandler.getNavigationCategoryService().findSubCategories(rootCateId, provinceId);
			return RtnInfo.RightWlRtnInfo(list);

		}
		return RtnInfo.ParameterErrRtnInfo("error:level=" + level);
	}

}
