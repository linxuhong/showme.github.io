package com.yihaodian.mobile.service.client.adapter;

import java.util.Map;

import com.yihaodian.mobile.service.client.adapter.service.impl.DispatchAdapterService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;
import com.yihaodian.mobile2.server.core.Adapter;

/**
 * 总的中转适配器 
 * @author yeliang
 *
 */
public class DispatchAdapter extends Adapter {
	DispatchAdapterService dispatchAdapterService;

	public RtnInfo execute(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context, Long hedwigTimeout) {
		
		if(urlPath.startsWith("/yhden/")){//英文app /yhden/mobileservice/*
			urlPath = urlPath.replaceFirst("/yhden", "");
		}
		
		if(urlPath.startsWith("/wishlist/")){//购物清单app /wishlist/mobileservice/*
			urlPath = urlPath.replaceFirst("/wishlist", "");
		}
		
		RtnInfo rtInfo = dispatchAdapterService.execute(urlPath, isLogined, bizInfo, context);
		if(rtInfo == null){
			 return new RtnInfo(DispatchAdapterService.ADAPTER_EXCEPTION, "rtInfo is null", "");
		}
		return rtInfo;
	}
	
	public DispatchAdapterService getDispatchAdapterService() {
		return dispatchAdapterService;
	}

	public void setDispatchAdapterService(
			DispatchAdapterService dispatchAdapterService) {
		this.dispatchAdapterService = dispatchAdapterService;
	}
}
