package com.yihaodian.mobile.service.client.adapter.cms;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.yihaodian.mobile.backend.cms.vo.NativePageVO;
import com.yihaodian.mobile.backend.cms.vo.cl.AbsColumnVO;
import com.yihaodian.mobile.backend.cms.vo.p.CmsNativeProductVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.cms.spi.CmsNativeService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnCodes;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class CmsNativeDispatchService extends BaseDiapatchService{
	
	public RtnInfo loadCmsPage(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Result result = valiateGetParams(bizInfo.get("pageid"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("pageid " + result.getResultDesc());
		}
		
		String uid = null;
		if (isLogined) {
			uid = context.getCurrentUserId();
		}
		
		String cityid = context.getRequestInfo().getCityId();
		Long pageId = Long.parseLong(bizInfo.get("pageid"));
		
		CmsNativeService service = CentralMobileServiceHandler.getCmsNativeService();
		NativePageVO vo =null;
		try {
			vo = service.loadCmsPage(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),pageId,  uid);
			return RtnInfo.RightWlRtnInfo(vo);
		} catch (Exception e) {
		    return new RtnInfo(RtnCodes.ADAPTER_EXCEPTION,e.getMessage(), "",null);
		}
	}
	
	
	public RtnInfo loadCmsColContent(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String idStr = bizInfo.get("id");
		RtnInfo info = validateNumber(idStr);
		if(info!=null){
			return info;
		}
		Long id = Long.parseLong(idStr);
		
		String uid = null;
		if (isLogined) {
			uid = context.getCurrentUserId();
		}
		String cityid = context.getRequestInfo().getCityId();
		CmsNativeService service = CentralMobileServiceHandler.getCmsNativeService();
		AbsColumnVO vo =null;
		try {
			vo = service.loadCmsColContent(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),id, uid);
			return RtnInfo.RightWlRtnInfo(vo);
		} catch (Exception e) {
		    return new RtnInfo(RtnCodes.ADAPTER_EXCEPTION,e.getMessage(), "",null);
		}
	}
	
	public RtnInfo getCmsVoucher(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String idStr = bizInfo.get("id");
		RtnInfo info = validateNumber(idStr);
		if(info!=null){
			return info;
		}
		Long id = Long.parseLong(idStr);
		String subGroupIdStr = bizInfo.get("subgroupid");
		info = validateNumber(subGroupIdStr);
		if(info!=null){
			return info;
		}
		Long subGroupId = Long.parseLong(subGroupIdStr);
		
		String userIdStr = null;
		if (isLogined) {
			userIdStr = context.getCurrentUserId();
		}
		Long userId=null;
		if(StringUtils.isNotBlank(userIdStr)){
			try {
				userId = Long.valueOf(userIdStr);
			} catch (Exception e) {
			}
		}
		
		CmsNativeService service = CentralMobileServiceHandler.getCmsNativeService();
		try {
			String code = service.getCmsVoucher(userId, subGroupId, id);
			return RtnInfo.RightWlRtnInfo(code);
		} catch (Exception e) {
		    return new RtnInfo(RtnCodes.ADAPTER_EXCEPTION,e.getMessage(), "",null);
		}
	}
	
	public RtnInfo loadSubGroupProducts(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String idStr = bizInfo.get("colid");
		RtnInfo info = validateNumber(idStr);
		if(info!=null){
			return info;
		}
		Long colId = Long.parseLong(idStr);
		String subGroupIdStr = bizInfo.get("subgroupid");
		info = validateNumber(subGroupIdStr);
		if(info!=null){
			return info;
		}
		Long subGroupId = Long.parseLong(subGroupIdStr);
		
		String uid = null;
		if (isLogined) {
			uid = context.getCurrentUserId();
		}
		
		String cityid = context.getRequestInfo().getCityId();
		CmsNativeService service = CentralMobileServiceHandler.getCmsNativeService();
		try {
			List<CmsNativeProductVO> list = service.loadSubGroupProducts(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),colId, subGroupId, uid);
			return RtnInfo.RightWlRtnInfo(list);
		} catch (Exception e) {
		    return new RtnInfo(RtnCodes.ADAPTER_EXCEPTION,e.getMessage(), "",null);
		}
	}
	
	
	public RtnInfo checkNative(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Result result = valiateGetParams(bizInfo.get("pageid"));
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("pageid " + result.getResultDesc());
		}
		result = valiateGetParams(context.getRequestInfo().getProvinceId());
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("provinceid " + result.getResultDesc());
		}
		
		String version = null;
		ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
		if(clientInfoVO!=null){
			version = clientInfoVO.getClientAppVersion();
		}
		
		Long pageId = Long.parseLong(bizInfo.get("pageid"));
		Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
		CmsNativeService service = CentralMobileServiceHandler.getCmsNativeService();
		try {
			Boolean isNative = service.checkNative(pageId, provinceId, version);
			return RtnInfo.RightWlRtnInfo(isNative);
		} catch (Exception e) {
		    return new RtnInfo(RtnCodes.ADAPTER_EXCEPTION,e.getMessage(), "",null);
		}
	}
	
}
