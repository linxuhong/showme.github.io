package com.yihaodian.mobile.hedwig.client.impl.tree;


import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.push.spi.ITreeService;


public class TreeClientServiceImpl implements ITreeService {
	
	private ITreeService treeHessianCall;

	public ITreeService getTreeHessianCall() {
		return treeHessianCall;
	}

	public void setTreeHessianCall(ITreeService treeHessianCall) {
		this.treeHessianCall = treeHessianCall;
	}

	@Override
	public ResultModel getTreePromotionInfo(Long activityId, Long userId,
			Integer provinceId) {

		return treeHessianCall.getTreePromotionInfo(activityId, userId, provinceId);
	}

	@Override
	public ResultModel doTree(Long activityId, Long userId, Integer provinceId) {

		return treeHessianCall.doTree(activityId, userId, provinceId);
	}

	@Override
	public ResultModel doTrackPoint(Long activityId, Long userId,
			Integer provinceId, Integer trackPointType, String traderName,
			String deviceToken, String ip,String sessionId) {

		return treeHessianCall.doTrackPoint(activityId, userId, provinceId, trackPointType, traderName, deviceToken, ip,sessionId);
	}

	@Override
	public ResultModel getAwardList(Long activityId, Long userId,
			Integer provinceId) {

		return treeHessianCall.getAwardList(activityId, userId, provinceId);
	}

	@Override
	public ResultModel doWeChatShare(Long activityId, Long userId,
			Integer provinceId, Integer shareType) {

		return treeHessianCall.doWeChatShare(activityId, userId, provinceId, shareType);
	}

	@Override
	public ResultModel doSun(Long activityId, Long shareToken,
			Integer provinceId,Long userId) {

		return treeHessianCall.doSun(activityId, shareToken, provinceId,userId);
	}

	@Override
	public ResultModel doTopPrizeInfo(Long activityId, Long userId,Long awardId, String phone, String address, String userName) {

		return treeHessianCall.doTopPrizeInfo(activityId, userId, awardId, phone, address, userName);
	}

	@Override
	public ResultModel yCacheTreePromotion(Long treePromotionId) {

		return treeHessianCall.yCacheTreePromotion(treePromotionId);
	}

	@Override
	public ResultModel yCacheTreePromotionExtList(Long treePromotionId) {

		return treeHessianCall.yCacheTreePromotionExtList(treePromotionId);
	}

	@Override
	public ResultModel yCacheAwardList(Long treePromotionId,
			Long treePromotionExtId) {

		return treeHessianCall.yCacheAwardList(treePromotionId, treePromotionExtId);
	}

	@Override
	public ResultModel yCacheTreePromotionAdList(Long treePromotionId) {

		return treeHessianCall.yCacheTreePromotionAdList(treePromotionId);
	}
	

 

}
