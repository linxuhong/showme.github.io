package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.hedwig.core.service.spi.UserPassport;
import com.yihaodian.mobile.vo.scratch.ScratchResultDetail;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnCodes;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class PassportDispatchService extends BaseDiapatchService{	
	
	
	public RtnInfo getUserById(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}		
		try{
		 	UserPassport userPassportService= CentralMobileServiceHandler.getUserPassportService();
		 	String userIdStr = context.getCurrentUserId();
		 	if(validateNumber(userIdStr)!=null){
		 		return RtnInfo.ParameterErrRtnInfo("userIdis null");
		 	}
			 Long userId = Long.parseLong(userIdStr);
			Result result= userPassportService.getUserById(userId);
			return RtnInfo.RightWlRtnInfo(result);
		}catch(Exception e){			
			return  RtnInfo.ParameterErrRtnInfo("PassportDispatchService=>getUserById error");
		}
	}
	
	public RtnInfo updateUserById(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}		
		try{
			String userIdStr = context.getCurrentUserId();
		 	if(validateNumber(userIdStr)!=null){
		 		return RtnInfo.ParameterErrRtnInfo("userIdis null");
		 	}
			 Long userId = Long.parseLong(userIdStr);
		 	UserPassport userPassportService= CentralMobileServiceHandler.getUserPassportService();
			Result result = userPassportService.updateUserById(userId);
			return RtnInfo.RightWlRtnInfo(result);
		}catch(Exception e){
			return new RtnInfo(RtnCodes.ADAPTER_EXCEPTION, "PassportDispatchService=>updateUserById error", null);
		}
	}
}
