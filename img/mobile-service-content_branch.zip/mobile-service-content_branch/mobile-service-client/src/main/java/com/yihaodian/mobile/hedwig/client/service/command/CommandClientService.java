package com.yihaodian.mobile.hedwig.client.service.command;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.command.ICommandService;
import com.yihaodian.mobile.service.facade.business.cut.ICutService;
import com.yihaodian.mobile.vo.ClientInfoVO;

/**
 * 
 * @author chenliang
 *
 */
public class CommandClientService implements ICommandService {
	
	private  ICommandService commandServiceHessianCall ;
	

	
	
	public ICommandService getCommandServiceHessianCall() {
		return commandServiceHessianCall;
	}

	public void setCommandServiceHessianCall(
			ICommandService commandServiceHessianCall) {
		this.commandServiceHessianCall = commandServiceHessianCall;
	}


	
	@Override
	public Result getSpellGroupInfo(ClientInfoVO clientInfoVO, Integer provinceId,	String command) {
		return commandServiceHessianCall.getSpellGroupInfo(clientInfoVO, provinceId, command);
	}

}
