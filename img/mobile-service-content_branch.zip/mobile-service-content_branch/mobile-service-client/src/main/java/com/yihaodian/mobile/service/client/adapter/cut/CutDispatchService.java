/**
 * www.yhd.com-402 Inc.
 * Copyright (c) 2008-2015 All Rights Reserved.
 */
package com.yihaodian.mobile.service.client.adapter.cut;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.cut.ICutService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 
 * @author huangqihui
 * @version $Id: CutDispatchService.java, v 0.1 2015年8月12日 下午4:16:27 huangqihui Exp $
 */
public class CutDispatchService extends BaseDiapatchService{
	
     
    //获得专享价所有栏目列表
    public RtnInfo getAllExclusivePriceColumns(String urlPath, Boolean isLogined,  Map<String, String> bizInfo, AdapterContext context) {
        if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        } 
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        clientInfoVO.setCityId(context.getRequestInfo().getCityId());
        clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
        Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        Result result = service.getAllExclusivePriceColumns(provinceId, clientInfoVO);
        return  getRtnInfo(result);
    }
    
    //获得专享价栏目下的商品列表
    public RtnInfo getExclusiveProductsByColumnIds(String urlPath, Boolean isLogined,  Map<String, String> bizInfo, AdapterContext context) {
        if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        }
        
        List<Long> ids = new ArrayList<Long>();
        try{
            if(StringUtil.isEmpty(bizInfo.get("ids"))){
                return  RtnInfo.ParameterErrRtnInfo("ids error :"+bizInfo.get("ids"));
            }else{
                String str[] = bizInfo.get("ids").split(",");
                for(String s:str){
                    ids.add(Long.parseLong(s));
                }
            }    
        }catch(Exception e){
            return  RtnInfo.ParameterErrRtnInfo("ids error :"+bizInfo.get("ids"));  
        }
        Long userId = null;
        if (isLogined) {
            userId = Long.parseLong(context.getCurrentUserId());
        }
        
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        clientInfoVO.setCityId(context.getRequestInfo().getCityId());
        clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
        Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        Result result = service.getExclusiveProductsByColumnIds(ids, provinceId,userId,clientInfoVO);
        return  getRtnInfo(result);
    }
    
    
    
    //获得剁手价底部tab
    public RtnInfo getCutPriceTab(String urlPath, Boolean isLogined,  Map<String, String> bizInfo, AdapterContext context) {
        if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        } 
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        Result result = service.getCutPriceTab(clientInfoVO, provinceId);
        return  getRtnInfo(result);
    }
    
    
    public RtnInfo getColumnAndActivity(String urlPath, Boolean isLogined,  Map<String, String> bizInfo, AdapterContext context) {
        if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        } 
        
        Result result = valiateGetParams(bizInfo.get("type"));
        if(!result.isSuccess()){
            return  RtnInfo.ParameterErrRtnInfo("type"+result.getResultDesc());
        } 
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        clientInfoVO.setCityId(context.getRequestInfo().getCityId());
        clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
       
        
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        Integer type = Integer.parseInt(bizInfo.get("type"));
        result = service.getColumnAndActivity(clientInfoVO,  type);
        return  getRtnInfo(result);
    }
    
    public RtnInfo getSimilarProducts(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
    	Result result = null;
		if(context.getRequestInfo() != null){
            result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        } 
		result = valiateGetParams(bizInfo.get("activityid"));
        if(!result.isSuccess()){
             return  RtnInfo.ParameterErrRtnInfo("activityid"+result.getResultDesc());
        }
		result = valiateGetParams(bizInfo.get("productid"));
        if(!result.isSuccess()){
             return  RtnInfo.ParameterErrRtnInfo("productid"+result.getResultDesc());
        }
        result = valiateGetParams(bizInfo.get("merchantid"));
        if(!result.isSuccess()){
            return  RtnInfo.ParameterErrRtnInfo("merchantid"+result.getResultDesc());
        }
        result = valiateGetParams(bizInfo.get("pmid"));
        if(!result.isSuccess()){
            return  RtnInfo.ParameterErrRtnInfo("pmid"+result.getResultDesc());
        }
        result = valiateGetParams(bizInfo.get("number"));
        if(!result.isSuccess()){
            return  RtnInfo.ParameterErrRtnInfo("number"+result.getResultDesc());
        }
        
        //Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        Long activityId = Long.parseLong(bizInfo.get("activityid"));
		Long productId = Long.parseLong(bizInfo.get("productid"));
		Long merchantId = Long.parseLong(bizInfo.get("merchantid"));
		Long pmId = Long.parseLong(bizInfo.get("pmid"));
		Integer number = Integer.parseInt(bizInfo.get("number"));
		Long lastId = null;
		if (StringUtils.isNotEmpty(bizInfo.get("lastid"))) {
			result = valiateGetParams(bizInfo.get("lastid"));
	        if(!result.isSuccess()){
	            return  RtnInfo.ParameterErrRtnInfo("lastid"+result.getResultDesc());
	        }
			lastId = Long.parseLong(bizInfo.get("lastid"));
		}
		
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        clientInfoVO.setCityId(context.getRequestInfo().getCityId());
        clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
		ICutService service = CentralMobileServiceHandler.getCutClientService();
		result = service.findSimilarProduct(activityId,clientInfoVO, productId, merchantId, pmId, number, lastId, 102L);
        return  getRtnInfo(result);
	}

    public RtnInfo getProductByActivityId(String urlPath, Boolean isLogined,    Map<String, String> bizInfo, AdapterContext context) {
        
        if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        }        
        //Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        List<Long> ids = new ArrayList<Long>();
        try{
            if(StringUtil.isEmpty(bizInfo.get("ids"))){
                return  RtnInfo.ParameterErrRtnInfo("ids error :"+bizInfo.get("ids"));
            }else{
                String str[] = bizInfo.get("ids").split(",");
                for(String s:str){
                    ids.add(Long.parseLong(s));
                }
            }    
        }catch(Exception e){
            return  RtnInfo.ParameterErrRtnInfo("ids error :"+bizInfo.get("ids"));  
        }
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        clientInfoVO.setCityId(context.getRequestInfo().getCityId());
        clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        Result result = service.getProductByActivityId(clientInfoVO, ids);
        return  getRtnInfo(result);
    }
    
    public RtnInfo getCurrentProductList(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
       
        if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        }
        //Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
      
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        clientInfoVO.setCityId(context.getRequestInfo().getCityId());
        clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        HashMap<String, Object> map = service.getCurrentProductList(clientInfoVO);
        return  RtnInfo.RightWlRtnInfo(map);
    }
    
    public RtnInfo getGroupProductListByLp(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
        
        if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        }
        //Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        clientInfoVO.setCityId(context.getRequestInfo().getCityId());
        clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        Map<String, Map> map = service.getGroupProductListByLp(clientInfoVO);
        return  RtnInfo.RightWlRtnInfo(map);
    }
      
    
    public RtnInfo getYesterdayProductList(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
        
        if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
            } 
        }
        //Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        clientInfoVO.setCityId(context.getRequestInfo().getCityId());
        clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
        String uid = context.getCurrentUserId();
        Long userId = null;
        if (StringUtils.isNumeric(uid)) {
        	userId = Long.valueOf(uid);
        }
      
        Map<String, Object> map = service.getYesterdayProductList(clientInfoVO,   userId);
        return  RtnInfo.RightWlRtnInfo(map);
    }
    
    public RtnInfo getProductReMindNum(String urlPath, Boolean isLogined,   Map<String, String> bizInfo, AdapterContext context) {
        //List<String> keys  
        List<String> keys = new ArrayList<String>();
        try{
            if(StringUtil.isEmpty(bizInfo.get("keys"))){
                return  RtnInfo.ParameterErrRtnInfo("keys error null");
            }else{
                String str[] = bizInfo.get("keys").split(",");
                for(String s:str){
                    keys.add(s);
                }
            }             
        }catch(Exception e){
            return  RtnInfo.ParameterErrRtnInfo("keys error :"+bizInfo.get("keys"));  
        }
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        Result result = service.getProductReMindNum(keys);
        return  getRtnInfo(result);
    }
    
    public RtnInfo updateProductReMindNum(String urlPath, Boolean isLogined,    Map<String, String> bizInfo, AdapterContext context) {
        //String key, Integer add
        if(StringUtil.isBlank(bizInfo.get("key"))){
            return  RtnInfo.ParameterErrRtnInfo("keys error null");
        }
        if(StringUtil.isBlank(bizInfo.get("add"))){
            return  RtnInfo.ParameterErrRtnInfo("add error null");
        }
        Integer add = Integer.parseInt(bizInfo.get("add"));
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        Result result = service.updateProductReMindNum(bizInfo.get("key"), add);
        return  getRtnInfo(result);     
    }
    
    public RtnInfo getBrandActivityDetailById(String urlPath, Boolean isLogined,    Map<String, String> bizInfo, AdapterContext context) {
    	 if(context.getRequestInfo() != null){
             Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
             if(!result.isSuccess()){
                 return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
             } 
         }
    	   ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
           clientInfoVO.setCityId(context.getRequestInfo().getCityId());
           clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
        if(StringUtil.isBlank(bizInfo.get("activityid"))){
            return  RtnInfo.ParameterErrRtnInfo("activityId error null");
        }
        Long activityId = Long.parseLong(bizInfo.get("activityid"));
       
        ICutService service = CentralMobileServiceHandler.getCutClientService();
        Result result = service.getBrandActivityDetailById(clientInfoVO, activityId);
        return  getRtnInfo(result);     
    }
    
    public RtnInfo getExclusiveAd(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+result.getResultDesc());
    		} 
    	}
    	
    	ICutService service = CentralMobileServiceHandler.getCutClientService();
    	Result result = service.getExclusiveAd(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Integer.valueOf(context.getRequestInfo().getProvinceId()));
        return  getRtnInfo(result);    
    }

    /**
     * 今日剁手价广告图
     * 
     * @param urlPath
     * @param isLogined
     * @param bizInfo
     * @param context
     * @return
     */
	public RtnInfo getTodayDuoshouPic(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context) {
		if (context.getRequestInfo() != null) {
			Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
			if (!result.isSuccess()) {
				return RtnInfo.ParameterErrRtnInfo("ProvinceId" + result.getResultDesc());
			}
		}

		ICutService service = CentralMobileServiceHandler.getCutClientService();
		Result result = service.getTodayDuoshouPic(convertClientInfoVO(context.getRequestInfo().getClientInfo()),
				Long.valueOf(context.getRequestInfo().getProvinceId()));
		return getRtnInfo(result);
	}
               
}
