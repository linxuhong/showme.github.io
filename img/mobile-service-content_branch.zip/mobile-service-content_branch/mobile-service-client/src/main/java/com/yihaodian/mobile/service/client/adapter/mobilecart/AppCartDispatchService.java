package com.yihaodian.mobile.service.client.adapter.mobilecart;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;

import com.yihaodian.mobile.backend.mobilecart.CartCommInputVO;
import com.yihaodian.mobile.backend.mobilecart.enums.ClientTypeEnum;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.mobilecart.spi.AppCartService;
import com.yihaodian.mobile.vo.wl2.ClientInfo;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class AppCartDispatchService extends BaseDiapatchService {
	private static final String INTERFACE_VERSION = "3.3.0";
	
	public RtnInfo getCheckoutProgressForPromotion(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		
		String promotionId = bizInfo.get("promotionid");
		RtnInfo rtn = validateNumber(promotionId);
		if (rtn != null) {
			return rtn;
		}
		String promotionLevelId = bizInfo.get("promotionlevelid");
		rtn = validateNumber(promotionLevelId);
		if (rtn != null) {
			return rtn;
		}
		
		String provinceId = context.getRequestInfo().getProvinceId();
		String cityId = bizInfo.get("cityid");
		String countyId = bizInfo.get("countyid");
		String shoppingBizType = bizInfo.get("shoppingbiztype");

		ClientInfo client = new ClientInfo();
		BeanUtils.copyProperties(context.getRequestInfo().getClientInfo(), client);
		client.setProvinceId(provinceId);
		
		CartCommInputVO commInput = new CartCommInputVO();
		commInput.setUserToken(context.getRequestInfo().getUserToken());
		commInput.setUserAgent(context.getRequestInfo().getUserAgent());
		commInput.setSessionId(bizInfo.get("sessionid"));
		commInput.setClientType(ClientTypeEnum.APP.getCode());
		commInput.setInterfaceVersion(INTERFACE_VERSION);
		if (StringUtils.isNumeric(provinceId)) {
			commInput.setProvinceId(Long.valueOf(provinceId));
		}
		if (StringUtils.isNumeric(cityId)) {
			commInput.setCityId(Long.valueOf(cityId));
		}
		if (StringUtils.isNumeric(countyId)) {
			commInput.setCountyId(Long.valueOf(countyId));
		}
		if (StringUtils.isNumeric(shoppingBizType)) {
			commInput.setShoppingBizType(Integer.valueOf(shoppingBizType));
		}

		Long userId = null;
		if (StringUtils.isNumeric(uid)) {
			userId = Long.valueOf(uid);
		}
		AppCartService service = CentralMobileServiceHandler.getAppCartService();
		Result result = service.getCheckoutProgressForPromotion(client, commInput, userId, 
				Long.valueOf(promotionId), Long.valueOf(promotionLevelId));
		
		return getRtnInfo(result);
	}
	
	public RtnInfo getCheckoutProgressForPromotionLevels(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		
		String promotionId = bizInfo.get("promotionid");
		RtnInfo rtn = validateNumber(promotionId);
		if (rtn != null) {
			return rtn;
		}
		String promotionLevelIdStr = bizInfo.get("promotionlevelid");
		Long promotionLevelId = null;
		if (StringUtils.isNumeric(promotionLevelIdStr)) {
			promotionLevelId = Long.valueOf(promotionLevelIdStr);
		}
		
		String provinceId = context.getRequestInfo().getProvinceId();
		String cityId = bizInfo.get("cityid");
		String countyId = bizInfo.get("countyid");

		ClientInfo client = new ClientInfo();
		BeanUtils.copyProperties(context.getRequestInfo().getClientInfo(), client);
		client.setProvinceId(provinceId);
		
		CartCommInputVO commInput = new CartCommInputVO();
		commInput.setUserToken(context.getRequestInfo().getUserToken());
		commInput.setUserAgent(context.getRequestInfo().getUserAgent());
		commInput.setSessionId(bizInfo.get("sessionid"));
		commInput.setClientType(ClientTypeEnum.APP.getCode());
		commInput.setInterfaceVersion(INTERFACE_VERSION);
		if (StringUtils.isNumeric(provinceId)) {
			commInput.setProvinceId(Long.valueOf(provinceId));
		}
		if (StringUtils.isNumeric(cityId)) {
			commInput.setCityId(Long.valueOf(cityId));
		}
		if (StringUtils.isNumeric(countyId)) {
			commInput.setCountyId(Long.valueOf(countyId));
		}

		Long userId = null;
		if (StringUtils.isNumeric(uid)) {
			userId = Long.valueOf(uid);
		}
		AppCartService service = CentralMobileServiceHandler.getAppCartService();
		Result result = service.getCheckoutProgressForPromotionLevels(client, commInput, userId, 
				Long.valueOf(promotionId), promotionLevelId);
		
		return getRtnInfo(result);
	}
}
