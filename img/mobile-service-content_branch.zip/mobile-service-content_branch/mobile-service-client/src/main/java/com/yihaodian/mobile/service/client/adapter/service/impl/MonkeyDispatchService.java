/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MonkeyService;
import com.yihaodian.mobile.vo.monkey.MonkeyExtratCouponResultVO;
import com.yihaodian.mobile.vo.order.CouponVerifyCheckCodeResult;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class MonkeyDispatchService.
 */
public class MonkeyDispatchService extends BaseDiapatchService {
	
	/**
	 * Monkey insert address.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo monkeyInsertAddress(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String receiverName = bizInfo.get("receivername");
		if(StringUtil.isEmpty(receiverName)){
			return RtnInfo.ParameterErrRtnInfo("receiverName is null");
		}
		String detailAddress = bizInfo.get("detailaddress");
		if(StringUtil.isEmpty(detailAddress)){
			return RtnInfo.ParameterErrRtnInfo("detailAddress is null");
		}
		String mobile = bizInfo.get("mobile");
		if(StringUtil.isEmpty(mobile)){
			return RtnInfo.ParameterErrRtnInfo("mobile is null");
		}
		
		String userId = context.getCurrentUserId();
		Result re =valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}		
		MonkeyService service = CentralMobileServiceHandler.getMonkeyService();
		Integer i = service.monkeyInsertAddress(Long.parseLong(userId), receiverName, detailAddress, mobile);
		return RtnInfo.RightWlRtnInfo(i);
	}
	
	
	public RtnInfo monkeyCheckMobileNumber(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String mobile = bizInfo.get("mobile");
		if(StringUtil.isEmpty(mobile)){
			return RtnInfo.ParameterErrRtnInfo("mobile is null");
		}		
		String token = context.getRequestInfo().getUserToken();		
		MonkeyService service = CentralMobileServiceHandler.getMonkeyService();
		Integer i = service.monkeyCheckMobileNumber(token, mobile);
		return RtnInfo.RightWlRtnInfo(i);
	}
	
	public RtnInfo monkeyVerifyCouponCheckCode(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String mobile = bizInfo.get("mobile");
		if(StringUtil.isEmpty(mobile)){
			return RtnInfo.ParameterErrRtnInfo("mobile is null");
		}	
		String checkCode = bizInfo.get("checkcode");
		if(StringUtil.isEmpty(checkCode)){
			return RtnInfo.ParameterErrRtnInfo("checkCode is null");
		}	
		String token = context.getRequestInfo().getUserToken();		
		MonkeyService service = CentralMobileServiceHandler.getMonkeyService();
		CouponVerifyCheckCodeResult result = service.monkeyVerifyCouponCheckCode(token, mobile, checkCode);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Monkey get extrat coupon result.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo monkeyGetExtratCouponResult(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if(!isLogined){
				return RtnInfo.TokenErrWlRtnInfo();
			}
			String userId = context.getCurrentUserId();
			Result re =valiateGetParams(userId);
			if(!re.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
			}
			String lng = bizInfo.get("lng");
			if(StringUtil.isEmpty(lng)){
				return RtnInfo.ParameterErrRtnInfo("lng is null");
			}
			String lat = bizInfo.get("lat");
			if(StringUtil.isEmpty(lat)){
				return RtnInfo.ParameterErrRtnInfo("lat is null");
			}
			MonkeyService service = CentralMobileServiceHandler.getMonkeyService();
			MonkeyExtratCouponResultVO result = service.monkeyGetExtratCouponResult(Long.parseLong(userId), Double.parseDouble(lng), Double.parseDouble(lat));
			return RtnInfo.RightWlRtnInfo(result);
		} catch (Exception e) {
			return null;
		}
		
	}
	
}
