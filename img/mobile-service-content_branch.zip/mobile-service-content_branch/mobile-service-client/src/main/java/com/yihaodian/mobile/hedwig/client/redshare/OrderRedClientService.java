package com.yihaodian.mobile.hedwig.client.redshare;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.push.spi.IOrderRedService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.coupon.ReceiveResult;

public class OrderRedClientService implements IOrderRedService{
	private IOrderRedService orderRedHessianCall;

	public void setOrderRedHessianCall(IOrderRedService orderRedHessianCall) {
		this.orderRedHessianCall = orderRedHessianCall;
	}

	@Override
	public Result isPromotionAvailable(Long userId, Long orderId) {
		return orderRedHessianCall.isPromotionAvailable(userId, orderId);
	}

	@Override
	public Result getPromotionDetail(Long userId, Long orderId) {
		return orderRedHessianCall.getPromotionDetail(userId, orderId);
	}

	@Override
	public Result getPromotionDescription(Long promotionId) {
		return orderRedHessianCall.getPromotionDescription(promotionId);
	}

	@Override
	public Result shareOrderRed(Long userId, Long orderId) {
		return orderRedHessianCall.shareOrderRed(userId, orderId);
	}

	@Override
	public Result openOrderRed(Long promotionId, String code) {
		return orderRedHessianCall.openOrderRed(promotionId, code);
	}

	@Override
	public Result getOrderRedByPhone(String code, String phone, Long userId, String awardId) {
		return orderRedHessianCall.getOrderRedByPhone(code, phone, userId, awardId);
	}

	@Override
	public Boolean sendSingleSMS(String mobile, String content) {
		return orderRedHessianCall.sendSingleSMS(mobile, content);
	}

   @Override
    public Result openIndependentOrderRed(Long promotionId ) {
        return orderRedHessianCall.openIndependentOrderRed(promotionId );
    }

    @Override
    public Result getIndependentOrderRedByPhone(  String phone, Long userId, String awardId) {
        return orderRedHessianCall.getIndependentOrderRedByPhone(  phone, userId, awardId);
    }

	@Override
	public Result addLpToCartByUserIdOrPhone(ClientInfoVO clientInfoVO,String sessionId,Long promotionId, Long productId,
			Long provinceId, Long userId, String phone,Integer quantity) {
		return orderRedHessianCall.addLpToCartByUserIdOrPhone(clientInfoVO,sessionId,promotionId, productId, provinceId, userId, phone,quantity);
	}

    @Override
    public Result openSimpleOrderRed() {
        return orderRedHessianCall.openSimpleOrderRed();
    }

    @Override
    public Result getSimpleOrderRedByOrderId(Long orderId, Long userId, String awardIdStr) {
        return orderRedHessianCall.getSimpleOrderRedByOrderId(orderId, userId, awardIdStr);
    }

    @Override
    public Result openShareGiftRed(Long promotionId) {
        return orderRedHessianCall.openShareGiftRed(promotionId);
    }

    @Override
    public Result shareGiftRed(Long promotionId, String phone) {
        return orderRedHessianCall.shareGiftRed(promotionId, phone);
    }

    @Override
    public Result isGetGrabGifRed(Long promotionId, String phone, String code) {
        return orderRedHessianCall.isGetGrabGifRed(promotionId, phone, code);
    }

    @Override
    public Result isGetShareGifRed(Long promotionId, String phone) {
        return orderRedHessianCall.isGetShareGifRed(promotionId, phone);
    }

    @Override
    public Result getShareGiftRedByPhone(String code, String phone, Long userId, String guid, Integer giftType, String ip  ) {
        return orderRedHessianCall.getShareGiftRedByPhone(code, phone, userId,guid, giftType,ip  );
    }

    @Override
    public Result getShareGiftRedByPhone(String code, String phone, Long userId, String guid, Integer giftType,
            String ip, String openId) {
        return orderRedHessianCall.getShareGiftRedByPhone(code, phone, userId, guid, giftType, ip, openId);
    }

    @Override
    public Result getInviteRedDetail(Long promotionId) {
       return orderRedHessianCall.getInviteRedDetail(promotionId);
    }

    @Override
    public Result getInviteRedUrl(Long promotionId, Long userId) {
        return orderRedHessianCall.getInviteRedUrl(promotionId, userId);
    }

    @Override
    public Result validateInviteRed(String code, String phone) {
        return orderRedHessianCall.validateInviteRed(code, phone);
    }

    @Override
    public Result grantInviteRed(String code, String phone, Long userId, String ip, String vCode) {
        return orderRedHessianCall.grantInviteRed(code, phone, userId, ip, vCode);
    }
 
 
    @Override
    public Result getUserInfoByOpenId(String openid) {
       return orderRedHessianCall.getUserInfoByOpenId(openid);
    }

    @Override
    public Result sendZyzCoupon(String phone, Long userId, String ip) {
        return orderRedHessianCall.sendZyzCoupon(phone, userId, ip);
    }

    @Override
    public Result toZyz(String phone, Long userId, Long touserId) {
        return orderRedHessianCall.toZyz(phone, userId, touserId);
    }

 
    @Override
    public Result changePhone(String openid, String phone, String oldPhone) {
        return orderRedHessianCall.changePhone(openid, phone, oldPhone);
    }

    @Override
    public Result getUserAwards(Long promotionId, String phone, String code, Long userId) {
        return orderRedHessianCall.getUserAwards(promotionId, phone, code, userId);
    }

    @Override
    public Result getGiftWechatInfo(String code) {
        return orderRedHessianCall.getGiftWechatInfo(code);
    }

 
 
    @Override
    public Result getWhiteCollarPromotionDetail(Long promotionId, Long userId) {
        return orderRedHessianCall.getWhiteCollarPromotionDetail(promotionId, userId);
    }

    @Override
    public Result getPrize(Long promotionId, Long userId, String code, String phone, String userName) {
        return orderRedHessianCall.getPrize(promotionId, userId, code, phone, userName);
    }

    @Override
    public Result addUserGiftPhoto(Long userid, Long promotionId, String url, String code) {
        return orderRedHessianCall.addUserGiftPhoto(userid, promotionId, url, code);
    }

    @Override
    public Result getUserGiftPhoto(String code) {
       return orderRedHessianCall.getUserGiftPhoto(code);
    }

    @Override
    public void inserErrorAwardLog(Long userId, Long awardId, ReceiveResult rr) {
          orderRedHessianCall.inserErrorAwardLog(userId, awardId, rr);
    }
    
    @Override
    public Result sendZyzCoupon(String phone, Long userId, String ip, String browser) {
        return orderRedHessianCall.sendZyzCoupon(phone, userId, ip, browser);
    }

	@Override
	public Result getCompanyVotingList(Long promotionId, Long userId, int page,	int pageSize) {
		return orderRedHessianCall.getCompanyVotingList(promotionId, userId, page, pageSize);
	}

	@Override
	public Result companyVoting(Long promotionId, Long userId,String companyName, Long companyId, int pageSize) {
		return orderRedHessianCall.companyVoting(promotionId, userId, companyName, companyId, pageSize);
	}


}
