package com.yihaodian.mobile.hedwig.client.impl.reward;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.reward.spi.IRewardService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class RewardClientService implements IRewardService {
	
	private IRewardService rewardHessianCall;

	@Override
	public Result rewardPrize(ClientInfoVO clientInfoVO, String userToken,
			Integer type, Long rewardId) {
		return rewardHessianCall.rewardPrize(clientInfoVO, userToken, type, rewardId);
	}

	@Override
	public Integer getRewardLogCount(Long userId, Integer type, Long rewardId) {
		return rewardHessianCall.getRewardLogCount(userId, type, rewardId);
	}

	public IRewardService getRewardHessianCall() {
		return rewardHessianCall;
	}

	public void setRewardHessianCall(IRewardService rewardHessianCall) {
		this.rewardHessianCall = rewardHessianCall;
	}

	@Override
	public Result rewardPrize(ClientInfoVO clientInfoVO, Long userId,
			Integer type, Long rewardId) {
		return rewardHessianCall.rewardPrize(clientInfoVO, userId, type, rewardId);
	}

}
