package com.yihaodian.mobile.hedwig.client.service.impl;

import java.util.List;

import com.yihaodian.mobile.service.hedwig.core.service.spi.PromotionService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.coupon.AddCouponByActivityIdResult;
import com.yihaodian.mobile.vo.promotion.AddStorageBoxResult;
import com.yihaodian.mobile.vo.promotion.AdvertisingPromotion;
import com.yihaodian.mobile.vo.promotion.AwardsResult;
import com.yihaodian.mobile.vo.promotion.CheckRockGameResult;
import com.yihaodian.mobile.vo.promotion.CheckRockResultResult;
import com.yihaodian.mobile.vo.promotion.CmsColumnVO;
import com.yihaodian.mobile.vo.promotion.CmsPageVO;
import com.yihaodian.mobile.vo.promotion.HotPointNewVO;
import com.yihaodian.mobile.vo.promotion.InviteeResult;
import com.yihaodian.mobile.vo.promotion.PromotionVO;
import com.yihaodian.mobile.vo.promotion.RockGameFlowVO;
import com.yihaodian.mobile.vo.promotion.RockGameProductVO;
import com.yihaodian.mobile.vo.promotion.RockGameVO;
import com.yihaodian.mobile.vo.promotion.RockProductVO;
import com.yihaodian.mobile.vo.promotion.RockResult;
import com.yihaodian.mobile.vo.promotion.RockResultV2;
import com.yihaodian.mobile.vo.promotion.StorageBoxVO;
import com.yihaodian.mobile.vo.promotion.UpdateStroageBoxResult;

public class PromotionClientServiceImpl implements PromotionService {
	private PromotionService promotionHessiancall;
      
	@Override
	public PromotionVO getPromotionByTopicID(Trader trader, Long id) {
		return promotionHessiancall.getPromotionByTopicID(trader, id);
	}

	@Override
	public Page<RockProductVO> getRockProductList(Trader trader,
			Long provinceId, Integer currentPage, Integer pageSize) {		
		return promotionHessiancall.getRockProductList(trader, provinceId, currentPage, pageSize);
	}

	@Override
	public String rockRock(Trader trader, Long provinceId, String promotionId,
			Long productId, Double lng, Double lat, String token) {		
		return promotionHessiancall.rockRock(trader, provinceId, promotionId, productId, lng, lat, token);
	}

	@Override
	public RockResult getRockResult(Trader trader, Long provinceId,
			String promotionId, Long productId) {		
		return promotionHessiancall.getRockResult(trader, provinceId, promotionId, productId);
	}

	@Override
	public Page<HotPointNewVO> getHomeHotPointListNew(Trader trader,
			Long provinceId, Integer currentPage, Integer pageSize) {
		// TODO Auto-generated method stub
		return promotionHessiancall.getHomeHotPointListNew(trader, provinceId, currentPage, pageSize);
	}

	@Override
	public Page<CmsPageVO> getCmsPageList(Trader trader, Long provinceId,
			Long activityId, Integer currentPage, Integer pageSize) {
		return promotionHessiancall.getCmsPageList(trader, provinceId, activityId, currentPage, pageSize);
	}

	@Override
	public Page<CmsColumnVO> getCmsColumnList(Trader trader, Long provinceId,
			Long cmsPageId, String type, Integer currentPage, Integer pageSize) {
		return promotionHessiancall.getCmsColumnList(trader, provinceId, cmsPageId, type, currentPage, pageSize);
	}

	@Override
	public Page<CmsColumnVO> getCmsColumnList(Trader trader, Long provinceId,
			Long cmsPageId, String type, String cmsType, Integer currentPage,
			Integer pageSize) {
		return promotionHessiancall.getCmsColumnList(trader, provinceId, cmsPageId, type, cmsType, currentPage, pageSize);
	}

	@Override
	public Page<CmsColumnVO> getCmsColumnListV2(Trader trader, Long provinceId,
			Long cmsPageId, String type, Integer currentPage, Integer pageSize) {
		// TODO Auto-generated method stub
		return promotionHessiancall.getCmsColumnListV2(trader, provinceId, cmsPageId, type, currentPage, pageSize);
	}

	@Override
	public CmsColumnVO getCmsColumnByColumnById(Trader trader, Long provinceId,
			Long cmsColumnId, String type, String cmsType, Integer currentPage,
			Integer pageSize) {
		return promotionHessiancall.getCmsColumnByColumnById(trader, provinceId, cmsColumnId, type, cmsType, currentPage, pageSize);
	}

	@Override
	public HotPointNewVO getHotPointNewVOById(Trader trader, Long provinceId,
			Long hotPointNewVOId) {
		return promotionHessiancall.getHotPointNewVOById(trader, provinceId, hotPointNewVOId);
	}

	@Override
	public AdvertisingPromotion getCmsAdvertisingPromotion(Trader trader,
			Long provinceId, String updateTag) {
		return promotionHessiancall.getCmsAdvertisingPromotion(trader, provinceId, updateTag);
	}

	@Override
	public Integer createRockGame(String token) {
		return promotionHessiancall.createRockGame(token);
	}

	@Override
	public RockGameVO getRockGameByToken(String token, Integer type) {
		return promotionHessiancall.getRockGameByToken(token, type);
	}

	@Override
	public List<RockGameProductVO> getPresentsByToken(String token) {
		return promotionHessiancall.getPresentsByToken(token);
	}

	@Override
	public Long createRockGameFlow(String token, RockGameFlowVO rockGameFlowVO) {
		return promotionHessiancall.createRockGameFlow(token, rockGameFlowVO);
	}

	@Override
	public Integer processGameFlow(String token, Long rockGameFlowID) {
		return promotionHessiancall.processGameFlow(token, rockGameFlowID);
	}

	@Override
	public RockGameProductVO getRockGameProductVO(Long rockGameFlowID) {
		return promotionHessiancall.getRockGameProductVO(rockGameFlowID);
	}

	@Override
	public CheckRockGameResult checkResult(Trader trader, Long rockGameFlowID,
			String resultCode) {
		return promotionHessiancall.checkResult(trader, rockGameFlowID, resultCode);
	}

	@Override
	public RockResultV2 getRockResultV2(Trader trader, Long provinceId) {
		return promotionHessiancall.getRockResultV2(trader, provinceId);
	}

	@Override
	public RockResultV2 getRockResultV2(String token) {
		return promotionHessiancall.getRockResultV2(token);
	}

	@Override
	public RockResultV2 getRockResultV3(Trader trader, Long provinceId,
			Double lng, Double lat) {
		return promotionHessiancall.getRockResultV3(trader, provinceId, lng, lat);
	}

	@Override
	public RockResultV2 getRockResultV3(String token, Double lng, Double lat) {
		return promotionHessiancall.getRockResultV3(token, lng, lat);
	}

	@Override
	public AwardsResult getAwardsResults(Trader trader) {
		return promotionHessiancall.getAwardsResults(trader);
	}

	@Override
	public Page<StorageBoxVO> getMyStorageBoxList(String token, Integer type,
			Integer currentPage, Integer pageSize) {
		return promotionHessiancall.getMyStorageBoxList(token, type, currentPage, pageSize);
	}

	@Override
	public AddStorageBoxResult addStorageBox(String token, Long productId,
			String promotionId, String couponNumber, Integer type,
			Long couponActiveId) {
		return promotionHessiancall.addStorageBox(token, productId, promotionId, couponNumber, type, couponActiveId);
	}

	@Override
	public CheckRockResultResult checkRockResult(String token, Long productId,
			String promotionId, Integer type, Long couponActiveId) {
		return promotionHessiancall.checkRockResult(token, productId, promotionId, type, couponActiveId);
	}

	@Override
	public InviteeResult isCanInviteeUser(Trader trader, String phoneNum) {
		return promotionHessiancall.isCanInviteeUser(trader, phoneNum);
	}

	@Override
	public AddCouponByActivityIdResult addCouponByActivityId(String token,
			Long activityId) {
		
		return promotionHessiancall.addCouponByActivityId(token, activityId);
	}

	@Override
	public Page<HotPointNewVO> getAdvertisingPromotionVOByType(Trader trader,
			Long provinceId, Integer type, Integer currentPage, Integer pageSize) {
		return promotionHessiancall.getAdvertisingPromotionVOByType(trader, provinceId, type, currentPage, pageSize);
	}

	@Override
	public UpdateStroageBoxResult updateStroageBoxProductType(String token,
			List<String> promotionIdList, List<Long> productIdList,
			Integer productStatus) {
		return promotionHessiancall.updateStroageBoxProductType(token, promotionIdList, productIdList, productStatus);
	}

	@Override
	public UpdateStroageBoxResult updateStroageBoxProductForDelAll(
			String token, Integer type) {
		return promotionHessiancall.updateStroageBoxProductForDelAll(token, type);
	}

	public PromotionService getPromotionHessiancall() {
		return promotionHessiancall;
	}

	public void setPromotionHessiancall(PromotionService promotionHessiancall) {
		this.promotionHessiancall = promotionHessiancall;
	}

	@Override
	public Page<StorageBoxVO> getMyStorageBoxListV2(Long userId, Integer type,
			Integer currentPage, Integer pageSize, Long provinceId,Trader trader) {
		return promotionHessiancall.getMyStorageBoxListV2(userId, type, currentPage, pageSize, provinceId,trader);
	}

	@Override
	public AddStorageBoxResult addStorageBoxV2(Long userId, Long productId,
			String promotionId, String couponNumber, Integer type,
			Long couponActiveId, Long provinceId) {
		return promotionHessiancall.addStorageBoxV2(userId, productId, promotionId, couponNumber, type, couponActiveId, provinceId);
	}

	@Override
	public RockResultV2 getRockResultV3(Long userId, Double lng, Double lat,
			Trader trader, Long provinceId, String userName) {
		return promotionHessiancall.getRockResultV2(userId, lng, lat, trader, provinceId, userName);
	}

	@Override
	public RockResultV2 getRockResultV2(Long userId, Double lng, Double lat,
			Trader trader, Long provinceId, String userName) {
		return promotionHessiancall.getRockResultV2(userId, lng, lat, trader, provinceId, userName);
	}

	@Override
	public AddCouponByActivityIdResult addCouponByActivityId(Long userId,
			Long activityId, Trader trader) {
		return promotionHessiancall.addCouponByActivityId(userId, activityId, trader);
	}

	@Override
	public CheckRockResultResult checkRockResult(Long userId, Long productId,
			String promotionId, Integer type, Long couponActiveId) {
		return promotionHessiancall.checkRockResult(userId, productId, promotionId, type, couponActiveId);
	}

	@Override
	public String rockRock(Trader trader, Long provinceId, String promotionId,
			Long productId, Double lng, Double lat, Long userId) {
		// TODO Auto-generated method stub
		return promotionHessiancall.rockRock(trader, provinceId, promotionId, productId, lng, lat, userId);
	}

	@Override
	public UpdateStroageBoxResult updateStroageBoxProductType(Long userId,
			List<String> promotionIdList, List<Long> productIdList,
			Integer productStatus) {
		// TODO Auto-generated method stub
		return promotionHessiancall.updateStroageBoxProductType(userId, promotionIdList, productIdList, productStatus);
	}

}
