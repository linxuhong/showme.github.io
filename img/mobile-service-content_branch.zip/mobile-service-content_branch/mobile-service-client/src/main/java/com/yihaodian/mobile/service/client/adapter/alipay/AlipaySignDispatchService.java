package com.yihaodian.mobile.service.client.adapter.alipay;

import java.util.Map;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.alipay.spi.IAlipaySignService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;
import com.yihaodian.mobile.framework.model.Result;
public class AlipaySignDispatchService extends BaseDiapatchService{
	
	public RtnInfo getAliPaySignature(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
			RtnInfo rtn = null;
			 String userIdStr = context.getCurrentUserId();
			 rtn = validateNumber(userIdStr);
			 if(rtn!=null){
				 return rtn;
			 }
			Long userId= Long.parseLong(userIdStr);
			IAlipaySignService alipaySignService = CentralMobileServiceHandler.getAlipaySignService();
			String orderIdStr = bizInfo.get("orderid");
			if(validateNumber(orderIdStr)!=null){
				return RtnInfo.ParameterErrRtnInfo("orderId is error");
			}
			Long orderId = Long.parseLong(orderIdStr);
			Trader trader = getTraderFromContext(context);
			if(trader==null||StringUtil.isEmpty(trader.getTraderName())){
				return RtnInfo.ParameterErrRtnInfo("traderName is error");
			}
			Result result = alipaySignService.getAliPaySignatureV2(userId, orderId, trader.getTraderName());		
			return getRtnInfo(result);
	}

}
