/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.List;
import java.util.Map;

import com.google.gson.reflect.TypeToken;
import com.yihaodian.mobile.backend.model.ActivityRule;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.hedwig.core.service.spi.AlipayService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.favorite.SharemyOrderResult;
import com.yihaodian.mobile.vo.seckill.AilpayResult;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class AlipayDispatchService.
 */
public class AlipayDispatchService extends BaseDiapatchService {
	
	/**
	 * Gets the sharemy order rule.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the sharemy order rule
	 */
	public RtnInfo getsharemyOrderRule(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		AlipayService alipayService = CentralMobileServiceHandler.getAlipayService();
		Trader trader = getTraderFromContext(context);
		if(trader == null ||trader.getTraderName()==null){
			return RtnInfo.ParameterErrRtnInfo("trader is null");
		}
		ActivityRule act = alipayService.getsharemyOrderRule(trader);
		return RtnInfo.RightWlRtnInfo(act);
	}
	
	/**
	 * Alipay login.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo alipayLogin(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String authCode = bizInfo.get("authcode");
		if(StringUtil.isEmpty(authCode)){
			return RtnInfo.ParameterErrRtnInfo("authCode is null");
		}
		String appId = bizInfo.get("appid");
		if(StringUtil.isEmpty(appId)){
			return RtnInfo.ParameterErrRtnInfo("appId is null");
		}
		Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
		
		AlipayService alipayService = CentralMobileServiceHandler.getAlipayService();
		AilpayResult result = alipayService.alipayLogin(getTraderFromContext(context), null, authCode, appId, provinceId, null);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the share my order list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the share my order list
	 */
	public RtnInfo getshareMyOrderList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String id = bizInfo.get("id");
		RtnInfo rtn = validateNumber(id);
		if (rtn != null) {
			return rtn;
		}
		String currentPage = bizInfo.get("currentpage");
		String pageSize = bizInfo.get("pagesize");
		rtn = validatePageInfo(currentPage, pageSize);
		if (rtn != null) {
			return rtn;
		}
		Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
		
		AlipayService alipayService = CentralMobileServiceHandler.getAlipayService();
		SharemyOrderResult result = alipayService.getshareMyOrderList(getTraderFromContext(context), Long.valueOf(id), provinceId, Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the alipay good receiver.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the alipay good receiver
	 */
	public RtnInfo getAlipayGoodReceiver(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();		
		Result re =valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("UserId"+re.getResultDesc());
		}
		AlipayService alipayService = CentralMobileServiceHandler.getAlipayService();
		AilpayResult result = alipayService.getAlipayGoodReceiver(Long.parseLong(userId));
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Shareto my order.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo sharetoMyOrder(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();
		Result re =valiateGetParams(userId);		
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("UserId"+re.getResultDesc());
		}
		String pidsStr = bizInfo.get("pids");
		if(StringUtil.isEmpty(pidsStr)){
			return RtnInfo.ParameterErrRtnInfo("pids is null");
		}
		List<Long> pids = null;
		try{
			pids = (List<Long>)GsonUtil.paseToObject(pidsStr, new TypeToken<List<Long>>(){}.getType());
		}catch(Exception e){
			return RtnInfo.ParameterErrRtnInfo("pids is error");
		}
		String imageurlsStr = bizInfo.get("imageurls");
		if(StringUtil.isEmpty(imageurlsStr)){
			return RtnInfo.ParameterErrRtnInfo("imageurls is null");
		}
		List<String> imageurls = null;
		try{
			imageurls = (List<String>)GsonUtil.paseToObject(imageurlsStr, new TypeToken<List<String>>(){}.getType());
		}catch(Exception e){
			return RtnInfo.ParameterErrRtnInfo("imageurls is error");
		}
		String Myiconurl = bizInfo.get("myiconurl");
		if(StringUtil.isEmpty(Myiconurl)){
			return RtnInfo.ParameterErrRtnInfo("Myiconurl is null");
		}
		String Content = bizInfo.get("content");
		if(StringUtil.isEmpty(Content)){
			return RtnInfo.ParameterErrRtnInfo("Content is null");
		}
		
		AlipayService alipayService = CentralMobileServiceHandler.getAlipayService();
		SharemyOrderResult result = alipayService.sharetoMyOrder(userId, pids, imageurls, Myiconurl, Content);
		return RtnInfo.RightWlRtnInfo(result);
	}
}
