package com.yihaodian.mobile.service.client.adapter.channal;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.channel.spi.QualityKitchenService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class QualityKitchenDispatchService extends BaseDiapatchService {

	
	public RtnInfo getQualityKitchenInfo(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
    		} 
    	}
    	Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
    	Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}    	
        String cityId = bizInfo.get("cityid");
        String pageId = bizInfo.get("pageid");
        String tpa = bizInfo.get("tpa");
        
        QualityKitchenService service = CentralMobileServiceHandler.getQualityKitchenService();
    	Result result = service.getQualityKitchenInfo(convertClientInfoVO(context.getRequestInfo().getClientInfo()), provinceId, userId, cityId,pageId,tpa);
        return  getRtnInfo(result);    
    }
	
}
