package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.client.advertisement.service.impl.CategoryAdClientService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class CategoryAdDispaterService extends BaseDiapatchService{

	public RtnInfo getHotRecommendCateList(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		 Long userId = null;
			if (isLogined) {
				userId = Long.parseLong(context.getCurrentUserId());
		  }
		 Trader trader = getTraderFromContext(context);
		 String deviceCode = bizInfo.get("devicetoken");
		 RtnInfo rtn = vaildateTrader(trader);
		 if(rtn!=null){
			 return rtn;
		 }
		 if(StringUtil.isBlank(deviceCode)){
			 deviceCode = trader.getDeviceCode();
		 }
		 String categoryId = bizInfo.get("categoryid");
		 rtn = validateNumber(categoryId);
		 if(rtn!=null){
			 return rtn;
		 }
		 CategoryAdClientService service = CentralMobileServiceHandler.getCategoryAdClientService();
		return getRtnInfo(service.getHotRecommendCateList(trader, deviceCode, Integer.valueOf(context.getRequestInfo().getProvinceId()),Long.valueOf(categoryId), userId));
		 
	 }

	 public RtnInfo getMobReCateList(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		 Long userId = null;
			if (isLogined) {
				userId = Long.parseLong(context.getCurrentUserId());
			  }
			 String deviceCode = context.getRequestInfo().getClientInfo().getDeviceCode();
			 String provinceId = context.getRequestInfo().getProvinceId();
			 if(StringUtil.isEmpty(provinceId)){
				 provinceId = "1";
			 }
			 String type = bizInfo.get("id");
			 CategoryAdClientService service = CentralMobileServiceHandler.getCategoryAdClientService();
			 return getRtnInfo(service.getMobReCateList(deviceCode, Long.valueOf(provinceId), userId, type));
		 }
	 
	 public RtnInfo getMobSubCategorysById(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		 String id = bizInfo.get("id");
		 if(StringUtil.isEmpty(id)){
			 return RtnInfo.ParameterErrRtnInfo("is has errors");
		 }
		 CategoryAdClientService service = CentralMobileServiceHandler.getCategoryAdClientService();
		 return getRtnInfo(service.getMobSubCategorysById(Long.parseLong(id)));
	 }
	 
}
