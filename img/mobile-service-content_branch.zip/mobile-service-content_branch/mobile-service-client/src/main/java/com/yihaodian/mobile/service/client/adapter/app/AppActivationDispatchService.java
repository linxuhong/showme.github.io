package com.yihaodian.mobile.service.client.adapter.app;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.app.spi.AppActivationService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class AppActivationDispatchService extends BaseDiapatchService {

	public RtnInfo jdActivationDataReceive(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String deviceCode = context.getRequestInfo().getClientInfo().getDeviceCode();
		String clientIp = context.getRequestInfo().getClientInfo().getClientIp();
//		String clientIp = context.getRequestIp(); //TODO client ip??
		String channelId = context.getRequestInfo().getClientInfo().getUnionKey();
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		RtnInfo rtn = validateProvinceId(provinceIdStr);
		if(rtn!=null){
			return rtn;
		}
		Integer provinceId = Integer.valueOf(provinceIdStr);
		String appCallTimeStr = bizInfo.get("timestamp");
		rtn = validateNumber(appCallTimeStr);
		if(rtn!=null){
			return rtn;
		}
		Long appCallTime = Long.valueOf(appCallTimeStr);
		String jdData = bizInfo.get("jddata");
		
		AppActivationService service = CentralMobileServiceHandler.getAppActivationClientService();
		Result result = service.jdActivationDataReceive(jdData, deviceCode, clientIp, channelId, provinceId, appCallTime);
		
		return getRtnInfo(result);
	}

}
