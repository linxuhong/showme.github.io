package com.yihaodian.mobile.service.client.adapter.channal;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.channel.spi.GlobalImportProductService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

import java.util.Map;

public class GlobalImportProductDispatchService extends BaseDiapatchService {

	
	public RtnInfo getGlobalImportProduct(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
    		} 
    	}
    	Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
    	Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}    	
		String cityid = context.getRequestInfo().getCityId();
    	GlobalImportProductService service = CentralMobileServiceHandler.getGlobalImportProductService();
    	Result result = service.getGlobalImportProduct(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid), provinceId, userId, bizInfo);
        return  getRtnInfo(result);    
    }
	
	public RtnInfo getNewProductsFromSearch(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
    		} 
    	}
    	Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
    	Long cityId = Long.parseLong(context.getRequestInfo().getCityId());
    	
    	GlobalImportProductService service = CentralMobileServiceHandler.getGlobalImportProductService();
    	Result result = service.getNewProductsFromSearch(provinceId,cityId, bizInfo);
        return  getRtnInfo(result);    
    }
	
	public RtnInfo getCategoryByAreaCode(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
    		} 
    	}
    	Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
    	String cityid = context.getRequestInfo().getCityId();
    	GlobalImportProductService service = CentralMobileServiceHandler.getGlobalImportProductService();
    	Result result = service.getCategoryByAreaCode(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid),provinceId, bizInfo);
        return  getRtnInfo(result);    
    }
	
	public RtnInfo getProductsByCategory(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
		if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
    		} 
    	}
    	Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        if(StringUtil.isBlank(bizInfo.get("categorys"))){
             return  RtnInfo.ParameterErrRtnInfo("categorys error null");
        }
        Long userId = null;
	    if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		} 
	    String cityid = context.getRequestInfo().getCityId();
       GlobalImportProductService service = CentralMobileServiceHandler.getGlobalImportProductService();
       Result result = service.getProductsByCategory(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid), provinceId, userId, bizInfo);
       return  getRtnInfo(result);    
    }
	
	public RtnInfo getProductsByBrandId(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
    		} 
    	}
    	Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        if(StringUtil.isBlank(bizInfo.get("brandids"))){
             return  RtnInfo.ParameterErrRtnInfo("brandids error null");
        }
        String brandIds = bizInfo.get("brandids");
        String cityId = context.getRequestInfo().getCityId();
        
    	GlobalImportProductService service = CentralMobileServiceHandler.getGlobalImportProductService();
    	Result result = service.getProductsByBrandId(provinceId, brandIds,cityId);
        return  getRtnInfo(result);    
    }
	
	public RtnInfo getHotRecProductByCategory(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	if(context.getRequestInfo() != null){
    		Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
    		if(!result.isSuccess()){
    			return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
    		} 
    	}
    	Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
    	Long userId = null;
	    if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		} 
	    String cityid = context.getRequestInfo().getCityId();
    	GlobalImportProductService service = CentralMobileServiceHandler.getGlobalImportProductService();
    	Result result = service.getHotRecProductByCategory(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid), provinceId, userId, bizInfo);
        return  getRtnInfo(result);    
    }

    public RtnInfo getHotSalesSingleProducts(String urlPath, Boolean isLogined, Map<String, String> bizInfo, AdapterContext context){
        if(context.getRequestInfo() != null){
            Result result = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!result.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("provinceid"+result.getResultDesc());
            }
        }
        Long provinceId = Long.parseLong(context.getRequestInfo().getProvinceId());
        Long userId = null;
        if (isLogined) {
            userId = Long.parseLong(context.getCurrentUserId());
        }
        String cityid = context.getRequestInfo().getCityId();
        GlobalImportProductService service = CentralMobileServiceHandler.getGlobalImportProductService();
        Result result = service.getHotSalesSingleProducts(convertClientInfoVO(context.getRequestInfo().getClientInfo(),context.getRequestInfo().getProvinceId(),cityid), provinceId, userId, bizInfo);
        return  getRtnInfo(result);
    }

}
