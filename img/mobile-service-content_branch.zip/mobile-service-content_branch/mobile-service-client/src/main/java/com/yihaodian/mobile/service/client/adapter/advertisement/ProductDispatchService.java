/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.ProductService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.product.AdvertisementVO;
import com.yihaodian.mobile.vo.product.HotPointVO;
import com.yihaodian.mobile.vo.product.ProductVO;
import com.yihaodian.mobile.vo.product.ProductYhbVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class ProductDispatchService.
 * @author zuodeng
 */
public class ProductDispatchService extends BaseDiapatchService{
		
	 /**
 	 * Gets the home hot point list.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the home hot point list
 	 */
 	public RtnInfo getHomeHotPointList(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
		 Trader trader =getTraderFromContext(context);
		 if(trader.getTraderName()==null){
			 return RtnInfo.ParameterErrRtnInfo("TraderName is null");
		 }
		 String provinceIdStr=context.getRequestInfo().getProvinceId();
		 Result result = valiateGetParams(provinceIdStr);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("provinceId"+result.getResultDesc());
		 }			 	
		 Long provinceId =Long.parseLong(provinceIdStr);
		 ProductService productService = CentralMobileServiceHandler.getProductService();
				
		 String currentPage=bizInfo.get("currentpage");
		 result = valiateGetParams(currentPage);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("currentpage"+result.getResultDesc());
		 }
		 
		 String pageSize=bizInfo.get("pagesize");
		 result = valiateGetParams(pageSize);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("pageSize "+result.getResultDesc());
		 }		 	
		
		 Page<HotPointVO> page= productService.getHomeHotPointList(trader, provinceId, Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		 
		 return RtnInfo.RightWlRtnInfo(page);
	 }
	 
	 /**
 	 * Gets the advertisement list.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the advertisement list
 	 */
 	public RtnInfo getAdvertisementList(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
		 Trader trader =getTraderFromContext(context);
		 
		 if(trader.getTraderName()==null){
			 return RtnInfo.ParameterErrRtnInfo("TraderName is null");
		 }
		 String provinceIdStr=context.getRequestInfo().getProvinceId();
		 Result result = valiateGetParams(provinceIdStr);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("provinceId"+result.getResultDesc());
		 }			 	
		 Long provinceId =Long.parseLong(provinceIdStr);		
		 ProductService productService = CentralMobileServiceHandler.getProductService();
		
		 String currentPage=bizInfo.get("currentpage");
		 result = valiateGetParams(currentPage);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("currentpage"+result.getResultDesc());
		 }
		 
		 String pageSize=bizInfo.get("pagesize");
		 result = valiateGetParams(pageSize);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("pageSize "+result.getResultDesc());
		 }		 	
		
		 Page<AdvertisementVO> page= productService.getAdvertisementList(trader, provinceId, Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		 
		 return RtnInfo.RightWlRtnInfo(page);
	 }
	 
	 /**
 	 * Gets the package products.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the package products
 	 */
 	public RtnInfo getPackageProducts(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
		 Trader trader =getTraderFromContext(context);
		 if(trader.getTraderName()==null){
			 return RtnInfo.ParameterErrRtnInfo("TraderName is null");
		 }
		 String provinceIdStr=context.getRequestInfo().getProvinceId();
		 Result result = valiateGetParams(provinceIdStr);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("provinceId"+result.getResultDesc());
		 }			 	
		 Long provinceId =Long.parseLong(provinceIdStr);	 
		
		 ProductService productService = CentralMobileServiceHandler.getProductService();
		 String currentPage=bizInfo.get("currentpage");
		 result = valiateGetParams(currentPage);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("currentpage"+result.getResultDesc());
		 }
		 
		 String pageSize=bizInfo.get("pagesize");
		 result = valiateGetParams(pageSize);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("pageSize "+result.getResultDesc());
		 }		 
		 String productId=bizInfo.get("productid");
		 result = valiateGetParams(productId);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("productId "+result.getResultDesc());
		 }			 
		 Page<ProductVO> page= productService.getPackageProducts(trader, Long.parseLong(productId), Integer.parseInt(currentPage), Integer.parseInt(pageSize),provinceId);
		 return RtnInfo.RightWlRtnInfo(page);
	 }
	
	 /**
 	 * Gets the user interested products.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the user interested products
 	 */
 	public RtnInfo getUserInterestedProducts(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
					 
		 if(!isLogined){
				return RtnInfo.TokenErrWlRtnInfo();
			}
		 
		 Trader trader =getTraderFromContext(context);
		 if(trader.getTraderName()==null){
			 return RtnInfo.ParameterErrRtnInfo("TraderName is null");
		 }
		 String provinceIdStr=context.getRequestInfo().getProvinceId();
		 Result result = valiateGetParams(provinceIdStr);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("provinceId"+result.getResultDesc());
		 }			 	
		 Long provinceId =Long.parseLong(provinceIdStr);	 
			 
		 ProductService productService = CentralMobileServiceHandler.getProductService();
			
		 String currentPage=bizInfo.get("currentpage");
		 result = valiateGetParams(currentPage);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("currentpage"+result.getResultDesc());
		 }
		 
		 String pageSize=bizInfo.get("pagesize");
		 result = valiateGetParams(pageSize);
		 if(!result.isSuccess()){
			 return RtnInfo.ParameterErrRtnInfo("pageSize "+result.getResultDesc());
		 }		 			 
		 Page<ProductVO> page= productService.getUserInterestedProductsV2(trader,provinceId, Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		 
		 return RtnInfo.RightWlRtnInfo(page);
	 }
	 
	 /**
 	 * Gets the more interested products.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the more interested products
 	 */
 	public RtnInfo getMoreInterestedProducts(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
		String currentPage = bizInfo.get("currentpage");
		String pageSize = bizInfo.get("pagesize");
		RtnInfo rtnInfo = validatePageInfo(currentPage, pageSize);
		if(rtnInfo !=null ){
			return rtnInfo;
		}
		Trader trader = getTraderFromContext(context);
		rtnInfo = vaildateTrader(trader);
		if(rtnInfo!=null){
			return rtnInfo;
		}
		String productId = bizInfo.get("productid");
		if(StringUtil.isEmpty(productId) || !productId.matches(RegexEnum.PURE_DIGITAL.getRegex())){
			return RtnInfo.ParameterErrRtnInfo("productId is error");
		}
		rtnInfo = validateProvinceId(context.getRequestInfo().getProvinceId());
		if(rtnInfo !=null){
			return rtnInfo;
		}
		ProductService productFacadeService = CentralMobileServiceHandler.getProductService();
		Page<ProductVO> page= productFacadeService.getMoreInterestedProducts(trader, Long.parseLong(productId), Long.parseLong(context.getRequestInfo().getProvinceId()), Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		return RtnInfo.RightWlRtnInfo(page);
	 }
	 
	 /**
 	 * Gets the hot random products.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the hot random products
 	 */
 	public RtnInfo getHotRandomProducts(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
					 
		 try {
			 ProductService productService = CentralMobileServiceHandler.getProductService();
			 String provinceIdStr = context.getRequestInfo().getProvinceId();
			 RtnInfo rtnInfo = validateProvinceId(provinceIdStr);
			 if(rtnInfo !=null){
				 return rtnInfo;
			 }
			 Long provinceId=Long.parseLong(provinceIdStr);		 
			 Trader trader = getTraderFromContext(context); 
			  rtnInfo = vaildateTrader(trader);
			 if(rtnInfo == null){
				 List<ProductVO> hotRandomProducts = productService.getHotRandomProducts(trader ,provinceId);
				 rtnInfo = RtnInfo.RightWlRtnInfo(hotRandomProducts);
			 }
			 return rtnInfo;
		 } catch (Exception e) {
			 return RtnInfo.ParameterErrRtnInfo("some pram null!");
		 }
	 }

	 /**
 	 * Gets the yhb by category id.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the yhb by category id
 	 */
 	public RtnInfo getYhbByCategoryId(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
					 
		 try {
			 String currentPage = bizInfo.get("currentpage");
			 String pageSize = bizInfo.get("pagesize");
			 RtnInfo rtnInfo = validatePageInfo(currentPage, pageSize);
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 rtnInfo = validateProvinceId(context.getRequestInfo().getProvinceId());
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 Trader trader = getTraderFromContext(context);
			 rtnInfo = vaildateTrader(trader);
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 String categoryId = bizInfo.get("categoryid");
			 if(StringUtil.isEmpty(categoryId) || !categoryId.matches(RegexEnum.PURE_DIGITAL.getRegex())){
				return RtnInfo.ParameterErrRtnInfo("categoryId is null");
			 }
			 String siteType = bizInfo.get("sitetype");
			 if(StringUtil.isEmpty(siteType) || !siteType.matches(RegexEnum.PURE_DIGITAL.getRegex())){
				return RtnInfo.ParameterErrRtnInfo("siteType is null");
			 }
			 String mcsiteid = bizInfo.get("mcsiteid");
			 if(StringUtil.isEmpty(mcsiteid) || !mcsiteid.matches(RegexEnum.PURE_DIGITAL.getRegex())){
				return RtnInfo.ParameterErrRtnInfo("mcsiteid is null");
			 }
			 ProductService productFacadeService = CentralMobileServiceHandler.getProductService();
		
			 Page<ProductYhbVO> result = productFacadeService.getYhbByCategoryId(trader, Long.parseLong(categoryId), Long.parseLong(mcsiteid), Long.parseLong(siteType), Long.parseLong(context.getRequestInfo().getProvinceId()), Integer.parseInt(currentPage), Integer.parseInt(pageSize));
			 return RtnInfo.RightWlRtnInfo(result);
		 } catch (Exception e) {
			 return RtnInfo.ParameterErrRtnInfo("some pram null!");
		 }
	 }
	 
	 /**
 	 * Gets the promotion product page.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the promotion product page
 	 */
 	public RtnInfo getPromotionProductPage(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
					 
		 try {
			 Trader trader = getTraderFromContext(context);
			 RtnInfo rtnInfo = vaildateTrader(trader);
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 rtnInfo = validateProvinceId(context.getRequestInfo().getProvinceId());
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 String currentPage = bizInfo.get("currentpage");
			 String pageSize = bizInfo.get("pagesize");
			 rtnInfo = validatePageInfo(currentPage, pageSize);
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 String categoryId = bizInfo.get("categoryid");
			 if(StringUtil.isEmpty(categoryId) || !categoryId.matches(RegexEnum.PURE_DIGITAL.getRegex())){
				return RtnInfo.ParameterErrRtnInfo("categoryId is error");
			 }
			 ProductService productService = CentralMobileServiceHandler.getProductService();
			 Page<ProductVO> result = productService.getPromotionProductPage(trader, Long.parseLong(context.getRequestInfo().getProvinceId()), Long.parseLong(categoryId), Integer.parseInt(currentPage), Integer.parseInt(pageSize));
			 return RtnInfo.RightWlRtnInfo(result);
		 } catch (Exception e) {
			 return RtnInfo.ParameterErrRtnInfo("some pram null!");
		 }
	 }
	 
	 /**
 	 * Gets the home hot product top5 list.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the home hot product top5 list
 	 */
 	public RtnInfo getHomeHotProductTop5List(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
		 try {
			 Trader trader = getTraderFromContext(context);
			 RtnInfo rtnInfo = vaildateTrader(trader);
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 rtnInfo = validateProvinceId(context.getRequestInfo().getProvinceId());
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 ProductService productService = CentralMobileServiceHandler.getProductService();
			 List<ProductVO> result = productService.getHomeHotProductTop5List(trader, Long.parseLong(context.getRequestInfo().getProvinceId()));
			 return RtnInfo.RightWlRtnInfo(result);
		 } catch (Exception e) {
			 return RtnInfo.ParameterErrRtnInfo("some pram null!");
		 }
	 }
	 
	 /**
 	 * Gets the hot product page by category id.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the hot product page by category id
 	 */
 	public RtnInfo getHotProductPageByCategoryId(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
					 
		 try {
			 Trader trader = getTraderFromContext(context);
			 RtnInfo rtnInfo = vaildateTrader(trader);
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 rtnInfo = validateProvinceId(context.getRequestInfo().getProvinceId());
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 String currentPage = bizInfo.get("currentpage");
			 String pageSize = bizInfo.get("pagesize");
			 rtnInfo = validatePageInfo(currentPage, pageSize);
			 if(rtnInfo != null){
				 return rtnInfo;
			 }
			 String categoryId = bizInfo.get("categoryid");
			 if(StringUtil.isEmpty(categoryId) || !categoryId.matches(RegexEnum.PURE_DIGITAL.getRegex())){
				return RtnInfo.ParameterErrRtnInfo("categoryId is error");
			 }
			 ProductService productService = CentralMobileServiceHandler.getProductService();
			 Page<ProductVO> result = productService.getHotProductPageByCategoryId(trader, Long.parseLong(context.getRequestInfo().getProvinceId()), Long.parseLong(categoryId), Integer.parseInt(currentPage), Integer.parseInt(pageSize));
			 return RtnInfo.RightWlRtnInfo(result);
		 } catch (Exception e) {
			 return RtnInfo.ParameterErrRtnInfo("some pram null!");
		 }
	 }
	 
	 /**
 	 * Gets the hot product by activity id.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the hot product by activity id
 	 */
 	public RtnInfo getHotProductByActivityID(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
					 
		 try {
			 String currentPage = bizInfo.get("currentpage");
			 if(StringUtil.isEmpty(currentPage)){
				return RtnInfo.ParameterErrRtnInfo("currentPage is null");
			 }
			 String pageSize = bizInfo.get("pagesize");
			 if(StringUtil.isEmpty(pageSize)){
				return RtnInfo.ParameterErrRtnInfo("pageSize is null");
			 }
			 String activityID = bizInfo.get("categoryid");
			 if(StringUtil.isEmpty(activityID)){
				return RtnInfo.ParameterErrRtnInfo("activityID is null");
			 }
			 ProductService productService = CentralMobileServiceHandler.getProductService();
			 Long provinceId=Long.parseLong(context.getRequestInfo().getProvinceId());		 
			 Trader trader = getTraderFromContext(context);
			 Page<ProductVO> result = productService.getHotProductByActivityID(trader, Long.parseLong(activityID), provinceId, Integer.parseInt(currentPage), Integer.parseInt(pageSize));
			 return RtnInfo.RightWlRtnInfo(result);
		 } catch (Exception e) {
			 return RtnInfo.ParameterErrRtnInfo("some pram null!");
		 }
	 }
	 
	 /**
 	 * Gets the user interested products categorys.
 	 *
 	 * @param urlPath the url path
 	 * @param isLogined the is logined
 	 * @param bizInfo the biz info
 	 * @param context the context
 	 * @return the user interested products categorys
 	 */
 	public RtnInfo getUserInterestedProductsCategorys(String urlPath, Boolean isLogined,
				Map<String, String> bizInfo, AdapterContext context){
		 try {
			Trader trader = getTraderFromContext(context);
			 ProductService service = CentralMobileServiceHandler.getProductService();
			 List<String> re = service.getUserInterestedProductsCategorys(trader);
			 return RtnInfo.RightWlRtnInfo(re);
		} catch (Exception e) {
			return RtnInfo.ParameterErrRtnInfo("some pram null!");
		}
		 
	 }
	 
 	
 	public RtnInfo getHotProductCountByCategoryId(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context){
 		Trader trader = getTraderFromContext(context);
 		if(trader==null||trader.getTraderName()==null){
 			return RtnInfo.ParameterErrRtnInfo("trader is null");
 		}
	String provinceId = context.getRequestInfo().getProvinceId();
	Result result = valiateGetParams(provinceId);
	if(!result.isSuccess()){
		return RtnInfo.ParameterErrRtnInfo("provinceId "+result.getResultDesc());
	}	
	String categoryId = bizInfo.get("categoryid");
	 result = valiateGetParams(categoryId);
	if(!result.isSuccess()){
		return RtnInfo.ParameterErrRtnInfo("categoryId "+result.getResultDesc());
	}
	ProductService service = CentralMobileServiceHandler.getProductService();
	Long temp = service.getHotProductCountByCategoryId(trader, Long.parseLong(provinceId), Long.parseLong(categoryId));			
	return RtnInfo.RightWlRtnInfo(temp);
 } 	
	
}
