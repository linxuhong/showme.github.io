/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.mobilecoupon;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.coupon.IMobileCouponFacadeService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.coupon.CouponActivityVO;
import com.yihaodian.mobile.vo.coupon.ReceiveResult;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class MobileCouponDispatchService.
 * @author zuodeng
 */
public class MobileCouponDispatchService extends BaseDiapatchService {
	
	/**
	 * Check couppn verfy code.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo checkCouppnVerfyCode(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		try {
			IMobileCouponFacadeService service = CentralMobileServiceHandler.getMobileCouponClientService();
			Trader trader = getTraderFromContext(context);
			String code = bizInfo.get("code");
			String sessionId = bizInfo.get("sessionid");
			ReceiveResult re = service.checkCouppnVerfyCode(trader, code, sessionId);
			
			return RtnInfo.RightWlRtnInfo(re);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * Gets the coupon activity vo by promotion id.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the coupon activity vo by promotion id
	 */
	public RtnInfo getCouponActivityVOByPromotionId(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		String type = bizInfo.get("type");
		RtnInfo rtn = validateNumber(type);
		if (rtn != null) {
			return rtn;
		}
		String promotionId = bizInfo.get("promotionid");
		rtn = validateNumber(promotionId);
		if (rtn != null) {
			return rtn;
		}
		String currentPage = bizInfo.get("currentpage");
		String pageSize = bizInfo.get("pagesize");
		rtn = validatePageInfo(currentPage, pageSize);
		if (rtn != null) {
			return rtn;
		}

		IMobileCouponFacadeService service = CentralMobileServiceHandler
				.getMobileCouponClientService();
		Page<CouponActivityVO> page = service.getCouponActivityVOByPromotionId(
				trader, Long.parseLong(promotionId), Integer.parseInt(type),
				Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		return RtnInfo.RightWlRtnInfo(page);
	}
	
	/**
	 * Receive coupon by activity id.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo receiveCouponByActivityId(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}

		String couponActivityId = bizInfo.get("couponactivityid");
		RtnInfo rtn = validateNumber(couponActivityId);
		if (rtn != null) {
			return rtn;
		}
		String entryActiveId = bizInfo.get("entryactiveid");
		if (StringUtil.isEmpty(entryActiveId)) {
			return RtnInfo.ParameterErrRtnInfo("entryActiveId is null");
		}

		
		Trader trader = getTraderFromContext(context);
		IMobileCouponFacadeService service = CentralMobileServiceHandler
				.getMobileCouponClientService();
		ReceiveResult result = service.receiveCouponByActivityId(Long.valueOf(context.getCurrentUserId()),
				Long.parseLong(couponActivityId), entryActiveId,trader);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	public RtnInfo grantCouponWithInfo(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}

		String code = bizInfo.get("couponcode");
		IMobileCouponFacadeService service = CentralMobileServiceHandler.getMobileCouponClientService();
		return getRtnInfo(service.grantCouponWithInfo(Long.valueOf(context.getCurrentUserId()), code));
	}
}
