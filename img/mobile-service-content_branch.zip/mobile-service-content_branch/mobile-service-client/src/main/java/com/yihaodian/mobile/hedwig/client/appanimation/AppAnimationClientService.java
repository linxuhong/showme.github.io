package com.yihaodian.mobile.hedwig.client.appanimation;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.core.business.service.AppAnimationService;

public class AppAnimationClientService implements AppAnimationService {
	
	private AppAnimationService appAnimationServiceHessianCall;


	@Override
	public Result getAppAnimation(String provinceId) {
		return appAnimationServiceHessianCall.getAppAnimation(provinceId);
	}


	public AppAnimationService getAppAnimationServiceHessianCall() {
		return appAnimationServiceHessianCall;
	}


	public void setAppAnimationServiceHessianCall(AppAnimationService appAnimationServiceHessianCall) {
		this.appAnimationServiceHessianCall = appAnimationServiceHessianCall;
	}

}
