package com.yihaodian.mobile.hedwig.client.service.tag;

import java.util.List;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.domain.business.dal.backend.AppTagVO;
import com.yihaodian.mobile.service.facade.business.tag.IAppTagService;

/**  
 * @author myx
 * @createTime 2016年5月23日 下午4:03:33  
 * 
 */
public class AppTagClientService implements IAppTagService{

	private IAppTagService appTagServiceHessianCall;
	
	public void setAppTagServiceHessianCall(IAppTagService appTagServiceHessianCall) {
		this.appTagServiceHessianCall = appTagServiceHessianCall;
	}

	@Override
	public Result getAppTagConfigRule() {
		
		return appTagServiceHessianCall.getAppTagConfigRule();
	}

	@Override
	public List<AppTagVO> getAppTagRuleList() {
		
		return appTagServiceHessianCall.getAppTagRuleList();
	}

	
}
