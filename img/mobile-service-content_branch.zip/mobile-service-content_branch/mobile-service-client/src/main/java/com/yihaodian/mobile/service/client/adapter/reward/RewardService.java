/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.reward;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.reward.spi.IRewardService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class RewardService.
 */
public class RewardService extends BaseDiapatchService {
	
	/**
	 * Reward prize.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo rewardPrize(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		try {
			IRewardService service = CentralMobileServiceHandler.getRewardClientService();
			Integer type = bizInfo.get("type")==null ? 1 : Integer.valueOf(bizInfo.get("type"));
            Long rewardId = bizInfo.get("rewardid")==null ? 0l : Long.valueOf(bizInfo.get("rewardid"));
            Result result = valiateGetParams(context.getCurrentUserId());
            if(!result.isSuccess()){
            	return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
            }
            Long userId = Long.parseLong(context.getCurrentUserId()); 
			result = service.rewardPrize(convertClientInfoVO(context.getRequestInfo().getClientInfo()), userId, type, rewardId);
			
			return getRtnInfo(result);
		} catch (Exception e) {
			return null;
		}
	}

}
