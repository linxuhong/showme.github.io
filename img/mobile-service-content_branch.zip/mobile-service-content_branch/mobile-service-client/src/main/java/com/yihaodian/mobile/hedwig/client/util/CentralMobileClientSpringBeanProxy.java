package com.yihaodian.mobile.hedwig.client.util;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;

public class CentralMobileClientSpringBeanProxy implements BeanFactoryAware{
	public void setBeanFactory(BeanFactory beanFactoryArg)
			throws BeansException {
		SpringBeanProxy.setBeanFactory(beanFactoryArg);
	}

	public static Object getBean(String beanName) {
		return SpringBeanProxy.getBean(beanName);
	}
}
