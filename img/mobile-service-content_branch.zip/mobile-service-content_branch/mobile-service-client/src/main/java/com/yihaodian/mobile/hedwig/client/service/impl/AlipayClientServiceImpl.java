package com.yihaodian.mobile.hedwig.client.service.impl;

import java.util.List;

import com.yihaodian.mobile.backend.model.ActivityRule;
import com.yihaodian.mobile.service.hedwig.core.service.spi.AlipayService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.favorite.SharemyOrderResult;
import com.yihaodian.mobile.vo.seckill.AilpayResult;

public class AlipayClientServiceImpl implements AlipayService {
	
	private AlipayService alipayHessianCall;
	
	@Override
	public String getAlipayDataServiceResult(String phoneNo) {
		return alipayHessianCall.getAlipayDataServiceResult(phoneNo);
	}

	@Override
	public AilpayResult alipayLogin(Trader trader, String ytoken,
			String authCode, String appId, Long provinceId, String DeviceToken) {
		return alipayHessianCall.alipayLogin(trader, ytoken, authCode, appId, provinceId, DeviceToken);
	}
	
	@Override
	public AilpayResult getAlipayGoodReceiver(String ytoken) {
		return alipayHessianCall.getAlipayGoodReceiver(ytoken);
	}
	
	@Override
	public AilpayResult getAlipayGoodReceiver(Long userId) {
		return alipayHessianCall.getAlipayGoodReceiver(userId);
	}

	@Override
	public AilpayResult getAlipayPayInfo(String ytoken) {
		return alipayHessianCall.getAlipayPayInfo(ytoken);
	}

	@Override
	public AilpayResult getAlipayPayInfo(Long userId) {
		return alipayHessianCall.getAlipayPayInfo(userId);
	}

	@Override
	public SharemyOrderResult sharetoMyOrder(String token, List<Long> pids,
			List<String> imageurls, String Myiconurl, String Content) {
		return alipayHessianCall.sharetoMyOrder(token, pids, imageurls, Myiconurl, Content);
	}

	@Override
	public SharemyOrderResult getshareMyOrderList(Trader trader, Long id,
			Long provinceId, Integer currentPage, Integer pageSize) {
		return alipayHessianCall.getshareMyOrderList(trader, id, provinceId, currentPage, pageSize);
	}

	@Override
	public ActivityRule getsharemyOrderRule(Trader trader) {
		return alipayHessianCall.getsharemyOrderRule(trader);
	}

	public AlipayService getAlipayHessianCall() {
		return alipayHessianCall;
	}

	public void setAlipayHessianCall(AlipayService alipayHessianCall) {
		this.alipayHessianCall = alipayHessianCall;
	}
}
