package com.yihaodian.mobile.hedwig.client.service;

import java.util.List;

import javax.annotation.Resource;

import com.yihaodian.mobile.service.facade.SeckillProductService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.promotion.SeckillCanBuyResult;
import com.yihaodian.mobile.vo.seckill.CheckSecKillResult;
import com.yihaodian.mobile.vo.seckill.SeckillResultVO;

public class SeckillProductClientService implements SeckillProductService{

	@Resource
	private SeckillProductService seckillHessiancall;
	
	@Override
	public SeckillResultVO preSeckillProduct(String token, Long provinceId,
			String promotionId, Long productId) {		
		return seckillHessiancall.preSeckillProduct(token, provinceId, promotionId, productId);
	}

	@Override
	public SeckillResultVO seckillProduct(String token, Long provinceId,
			String promotionId, Long productId) {
		return seckillHessiancall.seckillProduct(token, provinceId, promotionId, productId);
	}

	@Override
	public List<SeckillResultVO> getSeckillProductList(Long provinceId,
			String promotionId) {
		
		return seckillHessiancall.getSeckillProductList(provinceId, promotionId);
	}

	@Override
	public CheckSecKillResult checkIfSecKill(Trader trader, String promotionId,
			Long provinceId, Long productId) {
		return seckillHessiancall.checkIfSecKill(trader, promotionId, provinceId, productId);
	}

	@Override
	public List<CheckSecKillResult> checkIfSecKillForList(Trader trader,
			List<String> promotionIdList, List<Long> productIdList,
			Long provinceId) {
		return seckillHessiancall.checkIfSecKillForList(trader, promotionIdList, productIdList, provinceId);
	}

	@Override
	public List<SeckillCanBuyResult> checkSeckillCanBuy(String token,
			List<String> promotionIdList, List<Long> productIdList) {
		// TODO Auto-generated method stub
		return seckillHessiancall.checkSeckillCanBuy(token, promotionIdList, productIdList);
	}

	public SeckillProductService getSeckillHessiancall() {
		return seckillHessiancall;
	}

	public void setSeckillHessiancall(SeckillProductService seckillHessiancall) {
		this.seckillHessiancall = seckillHessiancall;
	}

	@Override
	public SeckillResultVO preSeckillProduct(Long userId, Long provinceId,
			String promotionId, Long productId) {		
		return seckillHessiancall.preSeckillProduct(userId, provinceId, promotionId, productId);
	}

	@Override
	public SeckillResultVO seckillProduct(Long userId, Long provinceId,
			String promotionId, Long productId) {
		
		return seckillHessiancall.seckillProduct(userId, provinceId, promotionId, productId);
	}

	@Override
	public List<SeckillCanBuyResult> checkSeckillCanBuy(Long userId,
			List<String> promotionIdList, List<Long> productIdList,
			Long provinceId) {
		
		return seckillHessiancall.checkSeckillCanBuy(userId, promotionIdList, productIdList, provinceId);
	}

}
