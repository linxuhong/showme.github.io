package com.yihaodian.mobile.hedwig.client.shop;

import com.yihaodian.mobile.framework.model.Result;

public interface ShopBrandClientService {
	
	/**
	 * 根据品牌名称查询门店信息
	 * @param brandName
	 * @param pageSize
	 * @param currentPage
	 * @return
	 */
	public Result getShopInfos(String brandName,int pageSize,int currentPage);
	
	/**
	 * 根据输入查询匹配品牌名称
	 * @param input
	 * @return
	 */
	public Result getBrandNameByChar(String input);

}
