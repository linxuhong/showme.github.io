package com.yihaodian.mobile.hedwig.client.service.content.impl;

import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.service.facade.content.spi.ScratchService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.scratch.CancelScratchReuslt;
import com.yihaodian.mobile.vo.scratch.ScratchResult;
import com.yihaodian.mobile.vo.scratch.ScratchResultDetail;

public class ScratchClientServiceImpl implements ScratchService{
	
	private ScratchService scratchHessionCall;


	@Override
	public List<ScratchResultDetail> getUserScratchResultDetailList(
			Trader trader) {
		return scratchHessionCall.getUserScratchResultDetailList(trader);
	}

	public ScratchService getScratchHessionCall() {
		return scratchHessionCall;
	}

	public void setScratchHessionCall(ScratchService scratchHessionCall) {
		this.scratchHessionCall = scratchHessionCall;
	}

	@Override
	public ScratchResult getScratchAvailable(Long userId, Long orderId,
			Integer siteType,Trader trader) {
		return scratchHessionCall.getScratchAvailable(userId, orderId, siteType,trader);
	}

	@Override
	public ScratchResultDetail getScratchReuslt(Long userId, Long orderId,
			Integer siteType,String userName,Trader trader) {
		return scratchHessionCall.getScratchReuslt(userId, orderId, siteType,userName,trader);
	}

	@Override
	public List<ScratchResult> getScratchInfoListForOrderList(Long userId,
			List<String> orderIdAndSiteType,Trader trader) {
		return scratchHessionCall.getScratchInfoListForOrderList(userId, orderIdAndSiteType,trader);
	}

	@Override
	public List<ScratchResult> getScratchInfoListForOrderList(Long userId,
			ClientInfoVO clientInfoVO, List<String> orderIdAndSiteType,Trader trader) {
		return scratchHessionCall.getScratchInfoListForOrderList(userId, clientInfoVO, orderIdAndSiteType,trader);
	}

	@Override
	public List<ScratchResultDetail> getRebatesNotification(Long userId) {
		return scratchHessionCall.getRebatesNotification(userId);
	}

	@Override
	public CancelScratchReuslt cancelScratchReuslt(Long userId, Long orderId,
			Integer siteType) {
		return scratchHessionCall.cancelScratchReuslt(userId, orderId, siteType);
	}

	@Override
	public void updateAccepetResult(Long userId, Long orderId) {
		
	}

	@Override
	public Map<String, Object> getScratchConfig() {		
		return scratchHessionCall.getScratchConfig();
	}
	
}
