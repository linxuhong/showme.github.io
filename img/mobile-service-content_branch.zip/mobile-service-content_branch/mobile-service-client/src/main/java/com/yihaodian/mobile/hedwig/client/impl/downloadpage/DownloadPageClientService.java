package com.yihaodian.mobile.hedwig.client.impl.downloadpage;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.downloadpage.spi.IDownloadPageService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class DownloadPageClientService implements IDownloadPageService {

	IDownloadPageService downloadPageHessianCall;
	
	@Override
	public Result getDownloadPageInfo(ClientInfoVO clientInfoVO, String pageUrl) {
		return downloadPageHessianCall.getDownloadPageInfo(clientInfoVO, pageUrl);
	}

	public IDownloadPageService getDownloadPageHessianCall() {
		return downloadPageHessianCall;
	}

	public void setDownloadPageHessianCall(
			IDownloadPageService downloadPageHessianCall) {
		this.downloadPageHessianCall = downloadPageHessianCall;
	}

}
