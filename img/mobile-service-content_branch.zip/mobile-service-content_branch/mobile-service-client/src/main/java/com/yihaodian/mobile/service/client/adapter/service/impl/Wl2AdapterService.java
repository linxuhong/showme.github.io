/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.wl2.spi.IWl2Service;
import com.yihaodian.mobile.vo.wl2.ClientInfo;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class Wl2AdapterService.
 */
public class Wl2AdapterService {
	
	/**
	 * Gets the my secret key.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info url请求参数
	 * @param context the context
	 * @return the my secret key
	 */
	public RtnInfo getMySecretKey(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		com.yihaodian.mobile2.server.context.RequestInfo.ClientInfo clientInfo =context.getRequestInfo().getClientInfo();
		if(clientInfo==null){
			return RtnInfo.ParameterErrRtnInfo("clientInfo is null");
		}
		String trader = bizInfo.get("trader");
		if(trader==null){
			return RtnInfo.ParameterErrRtnInfo("Trader is null");
		}
		IWl2Service wl2ClientService = CentralMobileServiceHandler.getWl2ClientService();
		
		//modify by zhangguangzhi
		String keyIndex = bizInfo.get("k_i");
		if(keyIndex == null || keyIndex.isEmpty()) {
			keyIndex = "1";
		}
		Result key = wl2ClientService.getSecretKeyByPlat(trader, keyIndex);
		
		
		if(key.isSuccess()){
			Map<String, Object> re = (Map)key.getDefaultModel() ;
			re.put("stime", new Date().getTime());
			key.setDefaultModel(re);
			return  RtnInfo.RightWlRtnInfo(key.getDefaultModel());
		}else{
			return new RtnInfo(key.getBaseResultCode().getCode(), key.getBaseResultCode().getMsg(), 
					key.getBaseResultCode().getDetail());
		}
	}
	
	/**
	 * Gets the app launch data.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the app launch data
	 */
	public RtnInfo getAppLaunchData(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		IWl2Service wl2ClientService = CentralMobileServiceHandler.getWl2ClientService();
		
		com.yihaodian.mobile2.server.context.RequestInfo.ClientInfo clientInfo =context.getRequestInfo().getClientInfo();
		if(clientInfo==null){
			return RtnInfo.ParameterErrRtnInfo("clientInfo is null");
		}
		if(bizInfo.get("hassonpics")==null){
			return RtnInfo.ParameterErrRtnInfo("hassonpics is null");
		}
		
		if(bizInfo.get("startuppicsize")==null){
			return RtnInfo.ParameterErrRtnInfo("startuppicsize is null");
		}
		String cityid = context.getRequestInfo().getCityId();
		ClientInfo ci = covertVenusCIToMyCI(context);
		String k_i = bizInfo.get("k_i");
		if(k_i == null || k_i.isEmpty()) {
			k_i = "1";
		}
		Long cityId = null;
		if (StringUtils.isNotBlank(cityid)) {
			try {
				cityId=Long.valueOf(cityid);
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}
		Result data = wl2ClientService.getAppLaunchData(ci,bizInfo.get("startuppicsize"), true, bizInfo.get("trader"), k_i,cityId);
		if(data.isSuccess()){
			Map<String, Object> re = (Map)data.getDefaultModel();
			re.put("stime", new Date().getTime());
			data.setDefaultModel(re);
			return  RtnInfo.RightWlRtnInfo(data.getDefaultModel());
		}else{
			return new RtnInfo(data.getBaseResultCode().getCode(), data.getBaseResultCode().getMsg(), 
					data.getBaseResultCode().getDetail());
		}
		
	}
	
	/**
	 * Covert venus ci to my ci.
	 *
	 * @param cx the cx
	 * @return the client info
	 */
	private ClientInfo covertVenusCIToMyCI(AdapterContext cx){
		com.yihaodian.mobile2.server.context.RequestInfo.ClientInfo c = cx.getRequestInfo().getClientInfo();
		ClientInfo myCI = new ClientInfo(c.getClientAppVersion(), c.getClientSystem(), c.getClientVersion(), 
				c.getDeviceCode(), c.getLatitude(), c.getLongitude(), c.getTraderName(), c.getUnionKey(), 
				c.getNetType(), c.getIaddr(), c.getClientIp(), cx.getRequestInfo().getProvinceId(),c.getImei());
		return myCI;
	}
}
