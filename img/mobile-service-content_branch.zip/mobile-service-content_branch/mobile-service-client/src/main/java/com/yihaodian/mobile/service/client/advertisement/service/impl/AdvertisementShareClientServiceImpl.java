package com.yihaodian.mobile.service.client.advertisement.service.impl;


import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.client.advertisement.service.AdvertisementShareClientService;
import com.yihaodian.mobile.service.facade.business.advertisement.AdvertisementShareService;
import com.yihaodian.mobile.vo.ClientInfoVO;

/**
 * hedwig CMS分享服务实现类
 * @author zhangwei5
 * @version $Id: AdvertisementShareClientServiceImpl.java, v 0.1 2014-6-10 下午3:40:53 zhangwei5 Exp $
 */
public class AdvertisementShareClientServiceImpl implements AdvertisementShareClientService{

    private AdvertisementShareService advertisementShareHessianCall;
    
    @Override
    public Result getShareInfoByCmsId(ClientInfoVO clientInfoVO, Long cmsId) {
        return advertisementShareHessianCall.getShareInfoByCmsId(clientInfoVO, cmsId);
    }

    public void setAdvertisementShareHessianCall(AdvertisementShareService advertisementShareHessianCall) {
        this.advertisementShareHessianCall = advertisementShareHessianCall;
    }

    
    
}
