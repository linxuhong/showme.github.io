package com.yihaodian.mobile.hedwig.client.service.survey;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.survey.spi.SurveyQuestionaireService;

public class SurveyQuestionaireClientService implements
		SurveyQuestionaireService {
	
	private SurveyQuestionaireService surveyQuestionaireServiceHessianCall;
	
	public void setSurveyQuestionaireServiceHessianCall(
			SurveyQuestionaireService surveyQuestionaireServiceHessianCall) {
		this.surveyQuestionaireServiceHessianCall = surveyQuestionaireServiceHessianCall;
	}

	@Override
	public Result getOpenQuestionairesForUser(Long userId) {
		return surveyQuestionaireServiceHessianCall.getOpenQuestionairesForUser(userId);
	}

}
