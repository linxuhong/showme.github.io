package com.yihaodian.mobile.service.client.advertisement.service;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.vo.ClientInfoVO;

/**
 * CMS分享信息hedwig客户端service
 * @author zhangwei5
 * @version $Id: AdvertisementShareClientService.java, v 0.1 2014-6-10 下午3:37:39 zhangwei5 Exp $
 */
public interface AdvertisementShareClientService {

    /**
     * 查询cms分享详细信息
     * @param clientInfoVO
     * @param cmsId
     * @return
     */
    Result getShareInfoByCmsId(ClientInfoVO clientInfoVO,Long cmsId);
}
