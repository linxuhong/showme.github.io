package com.yihaodian.mobile.service.client.adapter.voucher;

import java.util.Map;





import org.apache.commons.lang.math.NumberUtils;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.voucher.IVoucherService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;
import com.yihaodian.security.validcode.common.enums.ResultCodeEnum;

/**
 * 
 * @author chenliang
 *
 */
public class VoucherDispatchService extends BaseDiapatchService{

	/**
	 * 领券接口
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getVoucherByUser(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
    	
    	Long voucherId = NumberUtils.toLong(bizInfo.get("voucherid"));
		if (voucherId < 1L) {
			return  RtnInfo.ParameterErrRtnInfo("voucherid 输入参数不能为空");
		}
		
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		
		if (userId == null || userId < 1L) {
			return  RtnInfo.TokenErrWlRtnInfo();
		}
		String ip = context.getRequestInfo().getClientInfo().getClientIp();
		
		IVoucherService service = CentralMobileServiceHandler.getVoucherService();
    	Result result = service.getVoucherByUser(userId, voucherId, ip,ResultCodeEnum.SUCCESS.getCode());
    	if(result.isSuccess()){
    		if (result.getDefaultModel() == null) {
				result.setDefaultModel(holderVo);
			}
			return  RtnInfo.RightWlRtnInfo(result.getDefaultModel());
    	}else{
    		return new RtnInfo(result.getBaseResultCode().getCode(), result.getBaseResultCode().getMsg(),"", result.getDefaultModel());
    	}
    }
	
	/**
	 * 获取用户评论条数
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getUserCommentNumber(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
		
		Long voucherId = NumberUtils.toLong(bizInfo.get("voucherid"));
		if (voucherId < 1L) {
			return  RtnInfo.ParameterErrRtnInfo("voucherid 输入参数不能为空");
		}
		
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		
		if (userId == null || userId < 1L) {
			return  RtnInfo.TokenErrWlRtnInfo();
		}
		
		IVoucherService service = CentralMobileServiceHandler.getVoucherService();
		Result result = service.getUserCommentNumber(userId, voucherId);
		if(result.isSuccess()){
			if (result.getDefaultModel() == null) {
				result.setDefaultModel(holderVo);
			}
			return  RtnInfo.RightWlRtnInfo(result.getDefaultModel());
		}else{
			return new RtnInfo(result.getBaseResultCode().getCode(), result.getBaseResultCode().getMsg(),"", result.getDefaultModel());
		}
	}
	
}
