package com.yihaodian.mobile.service.client.adapter.red;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.push.spi.IOrderRedService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class OrderRedDispatchAdapter extends BaseDiapatchService {

	public RtnInfo isPromotionAvailable(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String orderId = bizInfo.get("orderid");
		RtnInfo rtn = validateNumber(orderId);
		if (rtn != null) {
			return rtn;
		}
		String userIdStr = context.getCurrentUserId();
		rtn = validateNumber(userIdStr);
		if(rtn!=null){
			return rtn;
		}
		Long userId= Long.parseLong(userIdStr);
		
		IOrderRedService service = CentralMobileServiceHandler.getOrderRedService();
		Result result = service.isPromotionAvailable(userId, Long.parseLong(orderId));

		return getRtnInfo(result);
	}

	public RtnInfo getPromotionDetail(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String orderId = bizInfo.get("orderid");
		RtnInfo rtn = validateNumber(orderId);
		if (rtn != null) {
			return rtn;
		}
		String userIdStr = context.getCurrentUserId();
		rtn = validateNumber(userIdStr);
		if(rtn!=null){
			return rtn;
		}
		Long userId= Long.parseLong(userIdStr);
		
		IOrderRedService service = CentralMobileServiceHandler.getOrderRedService();
		Result result = service.getPromotionDetail(userId, Long.parseLong(orderId));

		return getRtnInfo(result);
	}
	
	
	public RtnInfo getPromotionDescription(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {

		String promotionId = bizInfo.get("promotionid");
		RtnInfo rtn = validateNumber(promotionId);
		if (rtn != null) {
			return rtn;
		}
		
		IOrderRedService service = CentralMobileServiceHandler.getOrderRedService();
		Result result = service.getPromotionDescription(Long.parseLong(promotionId));
		
		return getRtnInfo(result);
	}
	
	public RtnInfo shareOrderRed(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String orderId = bizInfo.get("orderid");
		RtnInfo rtn = validateNumber(orderId);
		if (rtn != null) {
			return rtn;
		}
		String userIdStr = context.getCurrentUserId();
		rtn = validateNumber(userIdStr);
		if(rtn!=null){
			return rtn;
		}
		Long userId= Long.parseLong(userIdStr);
		
		IOrderRedService service = CentralMobileServiceHandler.getOrderRedService();
		Result result = service.shareOrderRed(userId, Long.parseLong(orderId));

		return getRtnInfo(result);
	}

}
