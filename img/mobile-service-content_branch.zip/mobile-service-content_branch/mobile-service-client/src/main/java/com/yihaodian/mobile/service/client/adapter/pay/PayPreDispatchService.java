/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.pay;

import java.util.Map;

import org.apache.log4j.Logger;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.domain.business.emuns.BusinessResultCode;
import com.yihaodian.mobile.service.domain.business.emuns.CommonResultCode;
import com.yihaodian.mobile.service.facade.business.pay.IPayPreService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 支付服务.
 *
 * @author zhangwei5
 * @version $Id: PayPreServiceDispatchService.java, v 0.1 2014年8月11日 下午2:15:53 zhangwei5 Exp $
 */
public class PayPreDispatchService extends BaseDiapatchService{

    /** The logger. */
    private Logger logger = Logger.getLogger(PayPreDispatchService.class);
    
    /**
     * 获取与支付信息.
     *
     * @param urlPath the url path
     * @param isLogined the is logined
     * @param bizInfo the biz info
     * @param context the context
     * @return the pay pre info
     */
    public RtnInfo getPayPreInfo(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
                                 AdapterContext context){
        try {
            if(isLogined){
                //得到订单Id
                String orderIdStr = bizInfo.get("orderid");
                Result result = valiateGetPayPreInfoParams(orderIdStr);
                if(result.isSuccess()){
                    IPayPreService payPreService = CentralMobileServiceHandler.getPayPreService();
                    result = payPreService.getPayPreInfo(Long.valueOf(context.getCurrentUserId()), Long.valueOf(orderIdStr)); 
                }
                return getRtnInfo(result);
            }else{
                return RtnInfo.TokenErrWlRtnInfo();
            }
        } catch (Exception e) {
            logger.error("getPayPreInfo has error", e);
            return null;
        }
        
    }
    
    /**
     * 自动切换网关.
     *
     * @param urlPath the url path
     * @param isLogined the is logined
     * @param bizInfo the biz info
     * @param context the context
     * @return the rtn info
     */
    public RtnInfo autoSwitchGateWay(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
                                     AdapterContext context){
        try {
            if(isLogined){
                //得到订单Id
                String orderIdStr = bizInfo.get("orderid");                
                Result result = validateAutoSwitchGateWay(orderIdStr, context.getRequestInfo().getProvinceId());
                if(result.isSuccess()){
                    IPayPreService payPreService = CentralMobileServiceHandler.getPayPreService();
                    result = payPreService.autoSwitchGateWay(Long.valueOf(context.getCurrentUserId()), Long.valueOf(orderIdStr), convertClientInfoVO(context.getRequestInfo().getClientInfo()), Integer.valueOf(context.getRequestInfo().getProvinceId()));
                }
                return getRtnInfo(result);
            }else{
                return RtnInfo.TokenErrWlRtnInfo();                
            }
        } catch (Exception e) {
            logger.error("getPayPreInfo has error", e);
            return null;
        }
    }
    
    /**
     * Valiate get pay pre info params.
     *
     * @param orderIdStr the order id str
     * @return the result
     */
    private Result valiateGetPayPreInfoParams(String orderIdStr){
        Result result = new ResultModel();
        result.setSuccess(true);
        try {
            if(StringUtil.isBlank(orderIdStr)||!orderIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
                logger.error("订单ID有误");
                result.setSuccess(false);
                result.setBaseResultCode(BusinessResultCode.PAY_PRE_ERROR_ORDER_EXCEPTION);
            }
        } catch (Exception e) {
            logger.error("valiateGetPayPreInfoParams has error", e);
            result.setSuccess(false);
            result.setBaseResultCode(CommonResultCode.PARAMS_SYSTEM_ID_ERROR_EXCEPTION);
        }
        return result;
    }
    
    /**
     * Validate auto switch gate way.
     *
     * @param orderIdStr the order id str
     * @param provinceIdStr the province id str
     * @return the result
     */
    private Result validateAutoSwitchGateWay(String orderIdStr,String provinceIdStr){
        Result result = new ResultModel();
        result.setSuccess(true);        
        try {
            if(StringUtil.isBlank(orderIdStr)||!orderIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
                logger.error("订单ID有误");
                result.setSuccess(false);
                result.setBaseResultCode(BusinessResultCode.PAY_PRE_ERROR_ORDER_EXCEPTION);
            }
            if(StringUtil.isBlank(provinceIdStr)||!provinceIdStr.matches(RegexEnum.PURE_DIGITAL.getRegex())){
                logger.error("订单ID有误");
                result.setSuccess(false);
                result.setBaseResultCode(BusinessResultCode.PARAMS_PROVINCEID_EXCEPTION);
            }
        } catch (Exception e) {
            logger.error("validateAutoSwitchGateWay has error", e);
            result.setSuccess(false);
            result.setBaseResultCode(CommonResultCode.PARAMS_SYSTEM_ID_ERROR_EXCEPTION);
        }
        return result;
    }
    /**
     * 判断新客
     * @param urlPath
     * @param isLogined
     * @param bizInfo
     * @param context
     * @return
     */
    public RtnInfo checkNewCustomer(String urlPath, Boolean isLogined, Map<String, String> bizInfo,AdapterContext context){
    	Trader trader = getTraderFromContext(context);
		 RtnInfo rtn = vaildateTrader(trader);
		 if(rtn!=null){
			 return rtn;
		 }
		//用户ID
		String userId = context.getCurrentUserId();
		rtn = validateNumber(userId);
		if(rtn!=null){
			rtn.setRtn_msg("userId must be number.");
			return rtn;
		}
		IPayPreService payPreService = CentralMobileServiceHandler.getPayPreService();
    	Result result = payPreService.checkNewCustomer(userId);
    	return getRtnInfo(result);
    }
    /**
     * 结算页促销信息* 
     * @param urlPath
     * @param isLogined
     * @param bizInfo
     * @param context
     * @return
     */
    public RtnInfo getPayGatePromotionTip(String urlPath, Boolean isLogined, Map<String, String> bizInfo,AdapterContext context){
    	Trader trader = getTraderFromContext(context);
		 RtnInfo rtn = vaildateTrader(trader);
		 if(rtn!=null){
			 return rtn;
		 }
    	IPayPreService payPreService = CentralMobileServiceHandler.getPayPreService();
		//取版本号区分 4.1.1之后的版本app请求时url在最后带上V2参数，
    	//如果在之后的某个版本上又加入新的功能，url在最后带上V3参数，
    	//且接口增加方法名为getPayGatePromotionTip_V3的新的方法，以些类推
    	String version= urlPath.substring(urlPath.lastIndexOf("/")+1);
    	Result result = null;
    	if("v3".equalsIgnoreCase(version)) {
    		String payType = bizInfo.get("paytype");
			String payGateWay = bizInfo.get("paygateway");
			String abtest = context.getRequestInfo().getClientInfo().getAbtest();
			result = payPreService.getPayGatePromotionTip_V3(payType,payGateWay,abtest,context.getCurrentUserId(),context.getRequestInfo().getClientInfo().getDeviceCode(),convertClientInfoVO(context.getRequestInfo().getClientInfo()));
		} else if ("v2".equalsIgnoreCase(version)) {
			result = payPreService.getPayGatePromotionTip_V2();
		} else {
			result = payPreService.getPayGatePromotionTip();
		}
    	return getRtnInfo(result);
    }
    /**
     * 支付页网关促销信息
     * 
     * @param urlPath
     * @param isLogined
     * @param bizInfo
     * @param context
     * @return
     */
    public RtnInfo getPayGatePromotionInfo(String urlPath, Boolean isLogined, Map<String, String> bizInfo,AdapterContext context){
    	IPayPreService payPreService = CentralMobileServiceHandler.getPayPreService();
    	String version= urlPath.substring(urlPath.lastIndexOf("/")+1);
    	Result result = null;
    	if ("v2".equalsIgnoreCase(version)) {
    		String payType = bizInfo.get("paytype");
			String payGateWay = bizInfo.get("paygateway");
			String abtest = context.getRequestInfo().getClientInfo().getAbtest();
    		result = payPreService.getPayGatePromotionInfo_V2(payType,payGateWay,abtest,context.getCurrentUserId(),context.getRequestInfo().getClientInfo().getDeviceCode(),convertClientInfoVO(context.getRequestInfo().getClientInfo()));
		} else {
			result = payPreService.getPayGatePromotionInfo();    	  
		}
    	
    	return getRtnInfo(result);
    }
}
