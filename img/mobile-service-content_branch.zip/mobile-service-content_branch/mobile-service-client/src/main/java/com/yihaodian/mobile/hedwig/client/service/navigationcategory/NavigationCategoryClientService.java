package com.yihaodian.mobile.hedwig.client.service.navigationcategory;

import java.util.List;

import com.yihaodian.mobile.service.domain.vo.business.navigationcategory.CategoryAppVO;
import com.yihaodian.mobile.service.facade.business.navigationcategory.INavigationCategoryService;


public class NavigationCategoryClientService implements INavigationCategoryService {
    
    private  INavigationCategoryService navigationCategoryServiceHessianCall ;

	@Override
	public List<CategoryAppVO> findRootCategories(Long navId, Long provinceId) {

		return navigationCategoryServiceHessianCall.findRootCategories(navId, provinceId);
	}

	@Override
	public List<CategoryAppVO> findSubCategories(Long rootCateId,Long provinceId) {

		return navigationCategoryServiceHessianCall.findSubCategories(rootCateId, provinceId);
	}

	public INavigationCategoryService getNavigationCategoryServiceHessianCall() {
		return navigationCategoryServiceHessianCall;
	}

	public void setNavigationCategoryServiceHessianCall(
			INavigationCategoryService navigationCategoryServiceHessianCall) {
		this.navigationCategoryServiceHessianCall = navigationCategoryServiceHessianCall;
	}

    
}
