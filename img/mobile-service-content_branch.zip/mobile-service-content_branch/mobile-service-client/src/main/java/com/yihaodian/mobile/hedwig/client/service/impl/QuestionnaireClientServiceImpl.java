package com.yihaodian.mobile.hedwig.client.service.impl;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.questionnaire.QuestionnaireService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class QuestionnaireClientServiceImpl implements QuestionnaireService {
	private QuestionnaireService questionnaireHessianCall;

	@Override
	public Result getQuestionnaireSwitch(ClientInfoVO clientInfoVO,
			String userToken, Integer provinceId) {
		return questionnaireHessianCall.getQuestionnaireSwitch(clientInfoVO, userToken, provinceId);
	}

	@Override
	public Result skipQuestionnaire(ClientInfoVO clientInfoVO, String userToken) {
		return questionnaireHessianCall.skipQuestionnaire(clientInfoVO, userToken);
	}

	public QuestionnaireService getQuestionnaireHessianCall() {
		return questionnaireHessianCall;
	}

	public void setQuestionnaireHessianCall(
			QuestionnaireService questionnaireHessianCall) {
		this.questionnaireHessianCall = questionnaireHessianCall;
	}

	@Override
	public Result getQuestionnaireSwitch(ClientInfoVO clientInfoVO,
			Long userId, Integer provinceId) {		
		return questionnaireHessianCall.getQuestionnaireSwitch(clientInfoVO, userId, provinceId);
	}

	@Override
	public Result skipQuestionnaire(ClientInfoVO clientInfoVO, Long userId) {		
		return questionnaireHessianCall.skipQuestionnaire(clientInfoVO, userId);
	}

}
