package com.yihaodian.mobile.hedwig.client.impl.dailybuy;

import com.yihaodian.mobile.backend.dailybuy.entity.DailyBuyComment;
import com.yihaodian.mobile.backend.dailybuy.vo.DailyBuyMessage;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.push.spi.IDailyBuyService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class DailyBuyClientService implements IDailyBuyService {
	
	private IDailyBuyService dailyBuyHessianCall;

	public void setDailyBuyHessianCall(IDailyBuyService dailyBuyHessianCall) {
		this.dailyBuyHessianCall = dailyBuyHessianCall;
	}

	@Override
	public Result praiseTopic(Long userId, String praise, String topicId) {
		return dailyBuyHessianCall.praiseTopic(userId, praise, topicId);
	}

	@Override
	public Result getCategory() {
		return dailyBuyHessianCall.getCategory();
	}

	@Override
	public Result getTopicByCategoryId(Long userId, Long categoryId,int startPage, int pageSize, int template) {
		return dailyBuyHessianCall.getTopicByCategoryId(userId, categoryId, startPage, pageSize, template);
	}

	@Override
	public Result getTopicById(Long provinceId, Long topicId, Long userId) {
		return dailyBuyHessianCall.getTopicById(provinceId, topicId, userId);
	}

	@Override
	public Result getTopicByAllCategory(Long userId) {
		return dailyBuyHessianCall.getTopicByAllCategory(userId);
	}

    @Override
    public Result getTopicById_v2(Long provinceId, Long topicId, Long userId) {
        return dailyBuyHessianCall.getTopicById_v2(provinceId, topicId, userId);
    }
    
    @Override
    public Result getTopicById_v3(Long provinceId, Long topicId, Long userId) {
        return dailyBuyHessianCall.getTopicById_v3(provinceId, topicId, userId);
    }
    

    @Override
    public Result getTopicIdsByProductId(Long productId) {
        return dailyBuyHessianCall.getTopicIdsByProductId(productId);
    }

    @Override
    public Result getTopicByCategoryIds(Long userId, String CategoryIds, int startPage, int pageSize, int template) {
        return dailyBuyHessianCall.getTopicByCategoryIds(userId, CategoryIds, startPage, pageSize, template);
    }

	@Override
	public Result getTopicWithVideo(Long userId, Integer praised, int startPage, int pageSize) {
		return dailyBuyHessianCall.getTopicWithVideo(userId, praised, startPage, pageSize);
	}

	@Override
	public Result submitComment(DailyBuyComment dailyBuyComment) {
		return dailyBuyHessianCall.submitComment(dailyBuyComment);
	}

	@Override
	public Result deleteComment(Long userId, Long commentId) {
		return dailyBuyHessianCall.deleteComment(userId, commentId);
	}

	@Override
	public Result getCommentPage(Long loginUserId, Long userId, Integer type, Integer startPage, Integer pageSize, Long provinceId) {
		return dailyBuyHessianCall.getCommentPage(loginUserId, userId, type, startPage, pageSize, provinceId);
	}

	@Override
	public Result praiseComment(Long userId, Long commentId, Integer cancel) {
		return dailyBuyHessianCall.praiseComment(userId, commentId, cancel);
	}

	@Override
	public Result visitComment(Long commentId) {
		return dailyBuyHessianCall.visitComment(commentId);
	}

	@Override
	public Result getCommentInfo(Long loginUserId, Long commentId, Long provinceId) {
		return dailyBuyHessianCall.getCommentInfo(loginUserId, commentId, provinceId);
	}

	@Override
	public Result replyTopicOrComment(Long loginUserId, Long userId, Long threadId, String content, Integer type) {
		return dailyBuyHessianCall.replyTopicOrComment(loginUserId, userId, threadId, content, type);
	}

	@Override
	public Result deleteReply(Long loginUserId, Long replyId) {
		return dailyBuyHessianCall.deleteReply(loginUserId, replyId);
	}

	@Override
	public Result getReplyPage(Long loginUserId, Long threadId, Integer type, Integer pageNumber, Integer pageSize) {
		return dailyBuyHessianCall.getReplyPage(loginUserId, threadId, type, pageNumber, pageSize);
	}

	@Override
	public Result getPraisePage(Long loginUserId, Long threadId, Integer type, Integer pageNumber, Integer pageSize) {
		return dailyBuyHessianCall.getPraisePage(loginUserId, threadId, type, pageNumber, pageSize);
	}

	@Override
	public Result getEndUserInfo(Long userId) {
		return dailyBuyHessianCall.getEndUserInfo(userId);
	}

	@Override
	public Result getUserAttentionBrand() {
		return dailyBuyHessianCall.getUserAttentionBrand();
	}

	@Override
	public Result getRecommendInfo() {
		return dailyBuyHessianCall.getRecommendInfo();
	}

	@Override
	public Result getUserRecommendBrandList(Long userId,ClientInfoVO clientInfoVO, Long provinceId, String pageId,
			String sectionId, int pageSize, int currentPage) {
		return dailyBuyHessianCall.getUserRecommendBrandList(userId, clientInfoVO, provinceId, pageId, sectionId, pageSize, currentPage);
	}

	@Override
	public Result cancelUserRecommendBrand(Long userId, Long brandId, Integer type) {
		return dailyBuyHessianCall.cancelUserRecommendBrand(userId, brandId, type);
	}

	@Override
	public Result recommendBrandPraise(Long userId, Long brandId, Integer type) {
		return dailyBuyHessianCall.recommendBrandPraise(userId, brandId, type);
	}

	@Override
	public Result sendYcmMessage(DailyBuyMessage msg) {
		return dailyBuyHessianCall.sendYcmMessage(msg);
	}

	@Override
	public Result getTopicByCategoryId(Long userId, Long CategoryId, int startPage) {
		return dailyBuyHessianCall.getTopicByCategoryId(userId, CategoryId, startPage);
	}

	@Override
	public Result getTopicByCategoryIds(Long userId, String CategoryIds, int startPage) {
		return dailyBuyHessianCall.getTopicByCategoryIds(userId, CategoryIds, startPage);
	}

	@Override
	public Result getTopicWithVideo(Long userId, Integer praised, int startPage) {
		return dailyBuyHessianCall.getTopicWithVideo(userId, praised, startPage);
	}

	@Override
	public Result getCommentCats() {
		return dailyBuyHessianCall.getCommentCats();
	}

	@Override
	public Result getTrialReports(Long cateId, Long lastReportId, Long provinceId) {
		return dailyBuyHessianCall.getTrialReports(cateId, lastReportId, provinceId);
	}

	@Override
	public Result getTrialReportInfo(Long cateId, Long provinceId) {
		return dailyBuyHessianCall.getTrialReportInfo(cateId, provinceId);
	}

	@Override
	public Result getCommentPageByVCate(Long loginUserId, Long userId, Integer type, Integer startPage, Integer pageSize, Long provinceId, Long vcate) {
		return dailyBuyHessianCall.getCommentPageByVCate(loginUserId, userId, type, startPage, pageSize, provinceId, vcate);
	}

	@Override
	public Result getMoreTopics(Long topicId, Long userId, Long categoryId) {
		return dailyBuyHessianCall.getMoreTopics(topicId, userId, categoryId);
	}
}
