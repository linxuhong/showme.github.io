/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.List;
import java.util.Map;





import com.google.gson.reflect.TypeToken;

import org.apache.log4j.Logger;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.facade.content.spi.ScratchService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.scratch.CancelScratchReuslt;
import com.yihaodian.mobile.vo.scratch.ScratchResult;
import com.yihaodian.mobile.vo.scratch.ScratchResultDetail;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnCodes;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class ScratchDispatchService.
 */
public class ScratchDispatchService extends BaseDiapatchService {
	
	/** The logger. */
	private Logger logger = Logger.getLogger(ScratchDispatchService.class);
	
	/**
	 * Gets the rebates notification.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rebates notification
	 */
	public RtnInfo getRebatesNotification(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		List<ScratchResultDetail> str = null;
		try{
			RtnInfo rtn = null;
			 String userIdStr = context.getCurrentUserId();
			 rtn = validateNumber(userIdStr);
			 if(rtn!=null){
				 return rtn;
			 }
			Long userId= Long.parseLong(userIdStr);
			ScratchService scratchService = CentralMobileServiceHandler.getScratchService();
			str = scratchService.getRebatesNotification(userId);
			
			return RtnInfo.RightWlRtnInfo(str);
		}catch(Exception e){
			logger.error("ScratchDispatchService=>getRebatesNotification error");
			return new RtnInfo(RtnCodes.ADAPTER_EXCEPTION, "ScratchDispatchService=>getRebatesNotification error", null);
		}
	}

	/**
	 * Gets the scratch info list for order list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the scratch info list for order list
	 */
	public RtnInfo getScratchInfoListForOrderList(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {

		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String orderIdAndSiteType = bizInfo.get("orderidandsitetype");
		if (orderIdAndSiteType == null || orderIdAndSiteType.equals("")) {
			return RtnInfo.ParameterErrRtnInfo("orderIdAndSiteType is null");
		}
		String userIdStr = context.getCurrentUserId();
		RtnInfo rtn = null;
		rtn = validateNumber(userIdStr);
		if (rtn != null) {
			return rtn;
		}
		Long userId = Long.parseLong(userIdStr);
		Trader trader = getTraderFromContext(context);
		//rtn = vaildateTrader(trader);
		List<String> orderIdAndSiteTypeList = (List<String>) GsonUtil.paseToObject(orderIdAndSiteType,new TypeToken<List<String>>() {}.getType());
		// List<ScratchResult> list =
		// scratchService.getScratchInfoListForOrderList(token,orderIdAndSiteTypeList);
		ScratchService scratchService = CentralMobileServiceHandler
				.getScratchService();
		ClientInfoVO clientInfoVO = convertClientInfoVO(context
				.getRequestInfo().getClientInfo());
		List<ScratchResult> list = scratchService
				.getScratchInfoListForOrderList(userId, clientInfoVO,
						orderIdAndSiteTypeList, trader);

		return RtnInfo.RightWlRtnInfo(list);
	}
	
	public RtnInfo getScratchInfoListForOrderListNoCilentInfo(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {

		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String orderIdAndSiteType = bizInfo.get("orderidandsitetype");
		if (orderIdAndSiteType == null || orderIdAndSiteType.equals("")) {
			return RtnInfo.ParameterErrRtnInfo("orderIdAndSiteType is null");
		}
		String userIdStr = context.getCurrentUserId();
		RtnInfo rtn = null;
		rtn = validateNumber(userIdStr);
		if (rtn != null) {
			return rtn;
		}
		Long userId = Long.parseLong(userIdStr);
		Trader trader = getTraderFromContext(context);
		//rtn = vaildateTrader(trader);
		List<String> orderIdAndSiteTypeList = (List<String>) GsonUtil.paseToObject(orderIdAndSiteType,new TypeToken<List<String>>() {}.getType());
		// List<ScratchResult> list =
		// scratchService.getScratchInfoListForOrderList(token,orderIdAndSiteTypeList);
		ScratchService scratchService = CentralMobileServiceHandler
				.getScratchService();
		List<ScratchResult> list = scratchService
				.getScratchInfoListForOrderList(userId, orderIdAndSiteTypeList, trader);
		return RtnInfo.RightWlRtnInfo(list);
	}
	
	/**
	 * 检查刮刮卡功能是否可用
	 * Gets the scratch available.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the scratch available
	 */
	public RtnInfo getScratchAvailable(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		ScratchService scratchService = CentralMobileServiceHandler.getScratchService();
		String oderStr = bizInfo.get("orderid");
		RtnInfo rtn = validateNumber(oderStr);
		if(rtn!=null){
			return rtn;
		}
		Long orderId = Long.parseLong(oderStr);
		Integer siteType;
		String siteTypeStr = bizInfo.get("sitetype");
		rtn = validateNumber(siteTypeStr);
		if(rtn==null){
			 siteType = Integer.parseInt(siteTypeStr);
		}else{
			siteType = 1;
		}
		 String userIdStr = context.getCurrentUserId();
		 rtn = validateNumber(userIdStr);
		 if(rtn!=null){
			 return rtn;
		 }
		 Long userId = Long.parseLong(userIdStr);
		Trader trader = getTraderFromContext(context);
		RtnInfo rtnInfo = vaildateTrader(trader);
		if(rtnInfo != null){
			return rtnInfo;
		}
		ScratchResult scr = scratchService.getScratchAvailable(userId, orderId, siteType, trader );
		return RtnInfo.RightWlRtnInfo(scr);
	}
	
	/**暂时没用到吧
	 * Cancel scratch reuslt.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo cancelScratchReuslt(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		 String oderIdStr = bizInfo.get("orderid");
		 if(StringUtil.isEmpty(oderIdStr)){
			return  RtnInfo.ParameterErrRtnInfo("orderid is null");
		 }
		Long orderId = Long.parseLong(oderIdStr);
		 String siteTypeStr = bizInfo.get("sitetype");
		 if(StringUtil.isEmpty(siteTypeStr)){
			return  RtnInfo.ParameterErrRtnInfo("sitetype is null");
		 }
		Integer siteType = Integer.parseInt(siteTypeStr);
		RtnInfo rtn = null;
		String userIdStr = context.getCurrentUserId();
		 rtn = validateNumber(userIdStr);
		 if(rtn!=null){
			 return rtn;
		 }
		 Long userId = Long.parseLong(userIdStr);
		 ScratchService scratchService = CentralMobileServiceHandler.getScratchService();
		CancelScratchReuslt  re = scratchService.cancelScratchReuslt(userId, orderId, siteType);
		return RtnInfo.RightWlRtnInfo(re);
	}
	
	/**刮奖
	 * Gets the scratch reuslt.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the scratch reuslt
	 */
	public RtnInfo getScratchReuslt(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		RtnInfo rtn = null;
		String orderidStr = bizInfo.get("orderid");
		rtn = validateNumber(orderidStr);
		if(rtn!=null){
			return rtn;
		}
		Long orderid = Long.parseLong(orderidStr);
		String sitetype = bizInfo.get("sitetype");
		rtn = validateNumber(sitetype);
		if(rtn!=null){
			return rtn;
		}
		 String userName = context.getCurrentUserName();
		 Trader trader = getTraderFromContext(context);
		
		rtn = vaildateTrader(trader);
		if(rtn != null){
			return rtn;
		}
		 String userIdStr = context.getCurrentUserId();
		 rtn = validateNumber(userIdStr);
		 if(rtn!=null){
			 return rtn;
		 }
		if(context.getRequestInfo() != null){
			Result re = valiateGetParams(context.getRequestInfo().getProvinceId());
            if(!re.isSuccess()){
                return  RtnInfo.ParameterErrRtnInfo("ProvinceId"+re.getResultDesc());
            } 
            trader.setProvinceId(context.getRequestInfo().getProvinceId());
        } 
		Long userId = Long.parseLong(userIdStr);
		ScratchService scratchService = CentralMobileServiceHandler.getScratchService();
		ScratchResultDetail result = scratchService.getScratchReuslt(userId, orderid, Integer.parseInt(sitetype), userName, trader);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * 暂时没用到
	 * Gets the user scratch result detail list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the user scratch result detail list
	 */
	public RtnInfo getUserScratchResultDetailList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		RtnInfo rtnInfo = vaildateTrader(trader);
		if(rtnInfo != null){
			return rtnInfo;
		}
		ScratchService scratchService = CentralMobileServiceHandler.getScratchService();
		List<ScratchResultDetail> result = scratchService.getUserScratchResultDetailList(trader);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	public RtnInfo getScratchConfig(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		ScratchService scratchService = CentralMobileServiceHandler.getScratchService();
		Map<String,Object> result = scratchService.getScratchConfig();
		return RtnInfo.RightWlRtnInfo(result);
	}
	
}
