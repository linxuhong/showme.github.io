package com.yihaodian.mobile.hedwig.client.update;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.push.spi.UpdateAwardService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class UpdateAwardClientServiceImpl implements UpdateAwardService {

	private UpdateAwardService updateAwardHessianCall;
	
	public void setUpdateAwardHessianCall(UpdateAwardService updateAwardHessianCall) {
		this.updateAwardHessianCall = updateAwardHessianCall;
	}

	@Override
	public Result getUpdateAwardOrder(String traderName, String appVersion,
			String userToken) {
		return updateAwardHessianCall.getUpdateAwardOrder(traderName, appVersion, userToken);
	}

	@Override
	public Result createMessageForUpdateAward(ClientInfoVO clientInfo,
			Long userId) {
		return updateAwardHessianCall.createMessageForUpdateAward(clientInfo, userId);
	}

}
