package com.yihaodian.mobile.hedwig.client.service.impl;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.apollo.IApolloPromotionService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class ApolloPromotionClientServiceImpl implements IApolloPromotionService {
	private IApolloPromotionService apolloPromotionHessianCall;
	
	@Override
	public Result getApolloPromotionInfoByClientLocation(String cityName,
			ClientInfoVO clientInfoVO) {
		return apolloPromotionHessianCall.getApolloPromotionInfoByClientLocation(cityName, clientInfoVO);
	}

	public IApolloPromotionService getApolloPromotionHessianCall() {
		return apolloPromotionHessianCall;
	}

	public void setApolloPromotionHessianCall(
			IApolloPromotionService apolloPromotionHessianCall) {
		this.apolloPromotionHessianCall = apolloPromotionHessianCall;
	}

}
