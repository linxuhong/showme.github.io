/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.sharecoupon;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.domain.vo.business.share.GenerateUrlVO;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponDetailInputVO;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponFindInputVO;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponInputVO;
import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class ShareCouponService.
 */
public class ShareCouponService extends BaseDiapatchService {

	/**
	 * Gets the receive coupon count.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the receive coupon count
	 */
	public RtnInfo getReceiveCouponCount(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		IShareCouponService service = CentralMobileServiceHandler
				.getShareCouponClientService();
		Result re = service.getReceiveCouponCountWl2(Long.valueOf(context.getCurrentUserId()));

		return getRtnInfo(re);
	}

	/**
	 * Gets the share coupon detail.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the share coupon detail
	 */
	public RtnInfo getShareCouponDetail(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String couponActivityId = bizInfo.get("couponactivityid");
		RtnInfo rtn = validateNumber(couponActivityId);
		if (rtn != null) {
			return rtn;
		}
		String couponId = bizInfo.get("couponid");
		rtn = validateNumber(couponId);
		if (rtn != null) {
			return rtn;
		}
		String type = bizInfo.get("type");
		rtn = validateNumber(type);
		if (rtn != null) {
			return rtn;
		}
		String userid = bizInfo.get("userid");
		rtn = validateNumber(userid);
		if (rtn != null) {
			return rtn;
		}

		ShareCouponDetailInputVO vo = new ShareCouponDetailInputVO();
		vo.setCouponActivityId(Long.valueOf(couponActivityId));
		vo.setCouponId(Long.valueOf(couponId));
		vo.setType(Integer.valueOf(type));
		vo.setUserId(Long.valueOf(userid));
		vo.setUserToken(context.getRequestInfo().getUserToken());

		IShareCouponService service = CentralMobileServiceHandler
				.getShareCouponClientService();
		Result re = service.getShareCouponDetail(vo);
		return getRtnInfo(re);
	}

	/**
	 * Gets the share coupon page.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the share coupon page
	 */
	public RtnInfo getShareCouponPage(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String userId = context.getCurrentUserId();
		Result result=valiateGetParams(userId);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId" + result.getResultDesc());
		}
		String currentPage = bizInfo.get("currentpage");
		String pageSize = bizInfo.get("pagesize");
		RtnInfo rtn = validatePageInfo(currentPage, pageSize);
		if (rtn != null) {
			return rtn;
		}		
		String type = bizInfo.get("type");
		result=valiateGetParams(type);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("type" + result.getResultDesc());
		}
		
		String receiveUserId = bizInfo.get("receiveuserid");
		result=valiateGetParams(receiveUserId);
		if(receiveUserId !=null &&!"".equals(receiveUserId) && !result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("receiveuserid" + result.getResultDesc());
		}
	
		ShareCouponFindInputVO vo = new ShareCouponFindInputVO();
		vo.setCurrentPage(Integer.valueOf(currentPage));
		vo.setPageSize(Integer.valueOf(pageSize));
		if(receiveUserId!=null && receiveUserId.length()>0){
			vo.setReceiverUserId(Long.valueOf(receiveUserId));			
		}
		vo.setType(Integer.valueOf(type));

		IShareCouponService service = CentralMobileServiceHandler
				.getShareCouponClientService();
		Result re = service.getShareCouponPageForWl2(vo, Long.parseLong(userId));
		return getRtnInfo(re);
	}

	/**
	 * Gets the share coupon page for wechat.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the share coupon page for wechat
	 */
	public RtnInfo getShareCouponPageForWechat(String urlPath,
			Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String currentPage = bizInfo.get("currentpage");
		String pageSize = bizInfo.get("pagesize");
		RtnInfo rtn = validatePageInfo(currentPage, pageSize);
		if (rtn != null) {
			return rtn;
		}
		String receiveUserId = bizInfo.get("receiveuserid");
		rtn = validateNumber(receiveUserId);
		if (rtn != null) {
			return rtn;
		}
		String type = bizInfo.get("type");
		rtn = validateNumber(type);
		if (rtn != null) {
			return rtn;
		}

		ShareCouponFindInputVO vo = new ShareCouponFindInputVO();
		vo.setCurrentPage(Integer.valueOf(currentPage));
		vo.setPageSize(Integer.valueOf(pageSize));
		vo.setReceiverUserId(Long.valueOf(receiveUserId));
		vo.setType(Integer.valueOf(type));
		vo.setUserToken(context.getRequestInfo().getUserToken());

		IShareCouponService service = CentralMobileServiceHandler
				.getShareCouponClientService();
		Result re = service.getShareCouponPageForWechat(vo);
		return getRtnInfo(re);
	}

	/**
	 * Share coupon.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo shareCoupon(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String couponActiveId = bizInfo.get("couponactiveid");
		RtnInfo rtn = validateNumber(couponActiveId);
		if (rtn != null) {
			return rtn;
		}
		String couponId = bizInfo.get("couponid");
		rtn = validateNumber(couponId);
		if (rtn != null) {
			return rtn;
		}		
		String shareFrom = bizInfo.get("sharefrom");
		rtn = validateNumber(shareFrom);
		if (rtn != null) {
			return rtn;
		}
		String triggerType = bizInfo.get("triggertype");
		rtn = validateNumber(triggerType);
		if (rtn != null) {
			return rtn;
		}

		ShareCouponInputVO vo = new ShareCouponInputVO();
		vo.setCouponActiveId(Long.valueOf(couponActiveId));
		vo.setCouponId(Long.valueOf(couponId));
		vo.setShareFrom(Integer.valueOf(shareFrom));		
		vo.setTriggerType(Integer.valueOf(triggerType));

		if (1 == vo.getTriggerType() || 3 == vo.getTriggerType()) {//此时context中的userId是分享人
//			vo.setShareUserToken(context.getRequestInfo().getUserToken());
			vo.setShareUserId(Long.valueOf(context.getCurrentUserId()));
			String receiveUserId = bizInfo.get("receiveuserid");			
			if (receiveUserId == null||"".equals(receiveUserId)) {
				return RtnInfo.ParameterErrRtnInfo("receiveUserId is empty");
			}
			vo.setReceiveUserId(Long.parseLong(receiveUserId));
//			vo.setReceiveUserToken(receiveUser);
		} else if (2 == vo.getTriggerType()) {//此时context中的userId是接收人
//			vo.setReceiveUserToken(context.getRequestInfo().getUserToken());
			vo.setReceiveUserId(Long.valueOf(context.getCurrentUserId()));
			String shareUserId = bizInfo.get("shareuserid");			
			if (shareUserId == null||"".equals(shareUserId)) {
				return RtnInfo.ParameterErrRtnInfo("shareuserid is empty");
			}
			vo.setShareUserId(Long.parseLong(shareUserId));
//			vo.setShareUserToken(shareusertoken);
		}

		IShareCouponService service = CentralMobileServiceHandler
				.getShareCouponClientService();
		Result re = service.shareCoupon_wl2(vo);
		return getRtnInfo(re);
	}

	/**
	 * Gets the share coupon url.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the share coupon url
	 */
	public RtnInfo getShareCouponUrl(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		GenerateUrlVO vo = new GenerateUrlVO();
		String typeStr = bizInfo.get("type");
		RtnInfo rtn = validateNumber(typeStr);
		if (rtn != null) {
			return rtn;
		}
		Integer type = Integer.parseInt(typeStr);
		if(type==1){
			String couponActiveId = bizInfo.get("couponactiveid");
			rtn = validateNumber(couponActiveId);
			if (rtn != null) {
				return rtn;
			}
			
			String couponId = bizInfo.get("couponid");
			rtn = validateNumber(couponId);
			if (rtn != null) {
				return rtn;
			}
			vo.setCouponActiveId(Long.valueOf(couponActiveId));
			vo.setCouponId(Long.valueOf(couponId));
		}	
		
//		String receiveUserId = bizInfo.get("receiveuserid");
//		rtn = validateNumber(receiveUserId);
//		if (rtn != null) {
//			return rtn;
//		}
//		String shareUserId = bizInfo.get("shareuserid");
//		rtn = validateNumber(shareUserId);
//		if (rtn != null) {
//			return rtn;
//		}	
		
		vo.setType(type);
		vo.setUserToken(context.getCurrentUserId());// 改造：vo.userToken中的值 是userId

		IShareCouponService service = CentralMobileServiceHandler
				.getShareCouponClientService();
		Result re = service.getShareCouponUrl_wl2(vo);
		return getRtnInfo(re);
	}

}
