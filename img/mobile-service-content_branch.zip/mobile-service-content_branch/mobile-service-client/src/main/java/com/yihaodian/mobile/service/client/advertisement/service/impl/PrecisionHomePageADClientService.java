package com.yihaodian.mobile.service.client.advertisement.service.impl;

import java.util.Date;
import java.util.List;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.advertisement.IPrecisionHomePageService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class PrecisionHomePageADClientService implements
		IPrecisionHomePageService {
	
	private IPrecisionHomePageService precisionHomePageADHessianCall;

	@Override
	public Result getPrecisionHomePageADV4(ClientInfoVO clientInfoVO,
			Integer provinceId, Long userId, String interfaceVersion,
			String cityid) {
		return precisionHomePageADHessianCall.getPrecisionHomePageADV4(clientInfoVO, provinceId, userId, interfaceVersion, cityid);
	}
	
	@Override
	public Result getPrecisionHomePageProducts(ClientInfoVO clientInfoVO,
			Integer provinceId, Long userId, Integer currentPage,
			Integer pageSize) {
		return precisionHomePageADHessianCall.getPrecisionHomePageProducts(clientInfoVO, provinceId, userId, currentPage, pageSize);
	}
	

	@Override
	public Result switchToLocalUrl(ClientInfoVO clientInfoVO , String url, String merchantName,
			Long merchantId) {
		return precisionHomePageADHessianCall.switchToLocalUrl(clientInfoVO , url, merchantName, merchantId);
	}
	
	@Override
	public Result getHomePageproducts(ClientInfoVO clientInfoVO,
			Integer provinceId, Long userId, Integer currentPage,
			Integer pageSize) {
		return precisionHomePageADHessianCall.getHomePageproducts(clientInfoVO, provinceId, userId, currentPage, pageSize);
	}
	
	@Override
	public Result getGrouponBanner(ClientInfoVO clientInfoVO,
			Integer provinceId, Long userId, String interfaceVersion,String viewCode) {
		return precisionHomePageADHessianCall.getGrouponBanner(clientInfoVO, provinceId, userId, interfaceVersion,viewCode);
	}

	public IPrecisionHomePageService getPrecisionHomePageADHessianCall() {
		return precisionHomePageADHessianCall;
	}

	public void setPrecisionHomePageADHessianCall(
			IPrecisionHomePageService precisionHomePageADHessianCall) {
		this.precisionHomePageADHessianCall = precisionHomePageADHessianCall;
	}

	@Override
	public Result getHomePageproductsNew(ClientInfoVO clientInfoVO,
			Integer provinceId, Long userId, Integer currentPage,
			Integer pageSize) {
		return precisionHomePageADHessianCall.getHomePageproductsNew(clientInfoVO, provinceId, userId, currentPage, pageSize);
	}
	
	@Override
	public Result getHomePageGuessUlikeProducts(ClientInfoVO clientInfoVO,
			Integer provinceId, Long userId, String productIds) {
		return precisionHomePageADHessianCall.getHomePageGuessUlikeProducts(clientInfoVO, provinceId, userId, productIds);
	}

	@Override
	public Result getHomePageColumnProducts(ClientInfoVO clientInfoVO,
			Integer provinceId, Long userId) {
		return precisionHomePageADHessianCall.getHomePageColumnProducts(clientInfoVO, provinceId, userId);
	}
	
	@Override
	public Result getPromoteSpecialTopic(ClientInfoVO clientInfoVO,
			Long provinceId, Long cityId, String userId) {
		return precisionHomePageADHessianCall.getPromoteSpecialTopic(clientInfoVO, provinceId, cityId, userId);
	}

	@Override
	public Result doushouProduct(ClientInfoVO clientInfoVO, Integer provinceId) {
		return precisionHomePageADHessianCall.doushouProduct(clientInfoVO, provinceId);
	}
	
	@Override
    public Result doushouProduct(ClientInfoVO clientInfoVO, Integer provinceId, Long userid) {
        return precisionHomePageADHessianCall.doushouProduct(clientInfoVO, provinceId,userid);
    }

    @Override
	public Result getHomeRecommendProducts(ClientInfoVO clientInfoVO,
			Integer provinceId, Long userId) {
		return precisionHomePageADHessianCall.getHomeRecommendProducts(clientInfoVO, provinceId, userId);
	}

	@Override
	public Result getAnnouncements(ClientInfoVO clientInfoVO,
			String provinceId, String seatType, String pageId, Long userId) {
		return precisionHomePageADHessianCall.getAnnouncements(clientInfoVO, provinceId, seatType, pageId, userId);
	}

	@Override
	public Long getActivityTime(String provinceId) {
		return precisionHomePageADHessianCall.getActivityTime(provinceId);
	}

	@Override
	public List<Long> getActivityTimeV2(String provinceId) {
		return precisionHomePageADHessianCall.getActivityTimeV2(provinceId);
	}

	@Override
	public Result getPrecisionHomePagePreview(Integer provinceId,String cityid,
			String traderName, String clientAppVersion, String deviceCode) {
		return precisionHomePageADHessianCall.getPrecisionHomePagePreview(provinceId, cityid,traderName, clientAppVersion, deviceCode);
	}

	@Override
	public Result getNewPrecisionHomePagePreview(Integer provinceId, String cityid, String traderName, String clientAppVersion, Date advTime) {
		return precisionHomePageADHessianCall.getNewPrecisionHomePagePreview(provinceId, cityid, traderName, clientAppVersion, advTime);
	}
	
    @Override
    public Result getHomePageGuessUlikeProducts(ClientInfoVO clientInfoVO, Integer provinceId, Long userId,
            String productIds, List<Long> aiNoRecommendProductList) {
        return precisionHomePageADHessianCall.getHomePageGuessUlikeProducts(clientInfoVO, provinceId, userId, productIds, aiNoRecommendProductList);
    }

	@Override
	public Result getChoicenessCity(ClientInfoVO clientInfoVO) {
		return precisionHomePageADHessianCall.getChoicenessCity(clientInfoVO);
		
	}

	@Override
	public Result getCityHomePageGuessUlikeProducts(ClientInfoVO clientInfoVO, Integer provinceId, Long userId,
			String productIds) {
		return precisionHomePageADHessianCall.getCityHomePageGuessUlikeProducts(clientInfoVO, provinceId, userId, productIds);
	}

}
