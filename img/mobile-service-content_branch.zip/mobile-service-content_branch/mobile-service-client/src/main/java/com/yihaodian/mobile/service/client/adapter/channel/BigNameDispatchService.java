package com.yihaodian.mobile.service.client.adapter.channel;

import java.util.Map;

import com.yihaodian.architecture.hedwig.common.util.StringUtils;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.channel.spi.BigNameService;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class BigNameDispatchService extends BaseDiapatchService {
	
	public RtnInfo loadBigNameIndex(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		Long userId = null;
		if (StringUtils.isNumeric(uid)) {
			userId = Long.valueOf(uid);
		}
		Long provinceId = 1L; //default to ShangHai
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		if (StringUtils.isNumeric(provinceIdStr)) {
			provinceId = Long.valueOf(provinceIdStr);
		}
		ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
		Integer bigNameType = 1; //default to brand
		String bigNameTypeStr = bizInfo.get("bignametype");
		if (StringUtils.isNumeric(bigNameTypeStr)) {
			bigNameType = Integer.valueOf(bigNameTypeStr);
		}
		String pageId = bizInfo.get("pageid");
		String tpa = bizInfo.get("tpa");
		BigNameService service = CentralMobileServiceHandler.getBigNameService();
		Result result = service.loadBigNameIndex(bigNameType, clientInfoVO, userId, provinceId, pageId, tpa);
		
		return getRtnInfo(result);
	}
	
	public RtnInfo getBigNameBrandsForCategory(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Long provinceId = 1L; //default to ShangHai
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		if (StringUtils.isNumeric(provinceIdStr)) {
			provinceId = Long.valueOf(provinceIdStr);
		}
		ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
		Long categoryId = null;
		String categoryIdStr = bizInfo.get("indexcategoryid");
		if (StringUtils.isNumeric(categoryIdStr)) {
			categoryId = Long.valueOf(categoryIdStr);
		}
		String pageId = bizInfo.get("pageid");
		String tpa = bizInfo.get("tpa");
		BigNameService service = CentralMobileServiceHandler.getBigNameService();
		Result result = service.getBigNameBrandsForCategory(clientInfoVO, categoryId, provinceId, pageId, tpa);
		
		return getRtnInfo(result);
	}
	
	public RtnInfo getBigNameStoresForCategory(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Long provinceId = 1L; //default to ShangHai
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		if (StringUtils.isNumeric(provinceIdStr)) {
			provinceId = Long.valueOf(provinceIdStr);
		}
		ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
		Long categoryId = null;
		String categoryIdStr = bizInfo.get("indexcategoryid");
		if (StringUtils.isNumeric(categoryIdStr)) {
			categoryId = Long.valueOf(categoryIdStr);
		}
		String isGoldMerchantSearch = bizInfo.get("isgoldmerchantsearch");
		String pageId = bizInfo.get("pageid");
		String tpa = bizInfo.get("tpa");
		BigNameService service = CentralMobileServiceHandler.getBigNameService();
		Result result = service.getBigNameStoresForCategory(clientInfoVO, categoryId, provinceId, convertBoolean(isGoldMerchantSearch), pageId, tpa);
		
		return getRtnInfo(result);
	}
	
	public RtnInfo getPagedCategoryBrands(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Long provinceId = 1L; //default to ShangHai
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		if (StringUtils.isNumeric(provinceIdStr)) {
			provinceId = Long.valueOf(provinceIdStr);
		}
		Long categoryId = null;
		String categoryIdStr = bizInfo.get("categoryid");
		if (StringUtils.isNumeric(categoryIdStr)) {
			categoryId = Long.valueOf(categoryIdStr);
		}
		Integer currentPage = null;
		String currentPageStr = bizInfo.get("currentpage");
		if (StringUtils.isNumeric(currentPageStr)) {
			currentPage = Integer.valueOf(currentPageStr);
		}
		Integer pageSize = null;
		String pageSizeStr = bizInfo.get("pagesize");
		if (StringUtils.isNumeric(pageSizeStr)) {
			pageSize = Integer.valueOf(pageSizeStr);
		}
		BigNameService service = CentralMobileServiceHandler.getBigNameService();
		Result result = service.getPagedCategoryBrands(categoryId, provinceId, currentPage, pageSize);
		
		return getRtnInfo(result);
	}
	
	public RtnInfo getPagedCategoryStores(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Long provinceId = 1L; //default to ShangHai
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		if (StringUtils.isNumeric(provinceIdStr)) {
			provinceId = Long.valueOf(provinceIdStr);
		}
		Long categoryId = null;
		String categoryIdStr = bizInfo.get("categoryid");
		if (StringUtils.isNumeric(categoryIdStr)) {
			categoryId = Long.valueOf(categoryIdStr);
		}
		Integer currentPage = null;
		String currentPageStr = bizInfo.get("currentpage");
		if (StringUtils.isNumeric(currentPageStr)) {
			currentPage = Integer.valueOf(currentPageStr);
		}
		Integer pageSize = null;
		String pageSizeStr = bizInfo.get("pagesize");
		if (StringUtils.isNumeric(pageSizeStr)) {
			pageSize = Integer.valueOf(pageSizeStr);
		}
		String isGoldMerchantSearch = bizInfo.get("isgoldmerchantsearch");
		BigNameService service = CentralMobileServiceHandler.getBigNameService();
		Result result = service.getPagedCategoryStores(categoryId, provinceId, convertBoolean(isGoldMerchantSearch), currentPage, pageSize);

		return getRtnInfo(result);
	}
	
}
