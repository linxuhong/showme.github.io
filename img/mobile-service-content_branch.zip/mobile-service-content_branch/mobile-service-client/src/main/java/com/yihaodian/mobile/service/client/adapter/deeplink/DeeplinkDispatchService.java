/**
 * www.yhd.com-402 Inc.
 * Copyright (c) 2008-2015 All Rights Reserved.
 */
package com.yihaodian.mobile.service.client.adapter.deeplink;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.deeplink.IDeeplinkService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 
 * @author wuheng1
 * @version $Id: DeeplinkDispatchService.java, v 0.1 2015年12月02日 上午10:32:14 wuheng1 Exp $
 */
public class DeeplinkDispatchService extends BaseDiapatchService{
	
	public RtnInfo getDeeplinkInfo(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
		IDeeplinkService service =  CentralMobileServiceHandler.getDeeplinkClientService();
		Trader trader = getTraderFromContext(context);
		if(trader==null||trader.getTraderName() == null){
			return RtnInfo.ParameterErrRtnInfo("traderName is null");
		}
        String key = bizInfo.get("thirdPartyKey");
        if(StringUtil.isEmpty(key)){
            return RtnInfo.ParameterErrRtnInfo("pram : thirdPartyKey is null");
        }
        Result result = service.getThirdAppInfo(key,trader.getTraderName());
        return getRtnInfo(result);
    }
	
	public RtnInfo verifyThirdPart(String urlPath, Boolean isLogined,Map<String, String> bizInfo, AdapterContext context) {
		IDeeplinkService service =  CentralMobileServiceHandler.getDeeplinkClientService();
        String bundleId = bizInfo.get("id");
        if(StringUtil.isEmpty(bundleId)){
            return RtnInfo.ParameterErrRtnInfo("pram : bundleId is null");
        }
        String key = bizInfo.get("key");
        if(StringUtil.isEmpty(key)){
            return RtnInfo.ParameterErrRtnInfo("pram : key is null");
        }
        String trader = bizInfo.get("trader");
		if(trader==null){
			return RtnInfo.ParameterErrRtnInfo("Trader is null");
		}
        Result result = service.verifyThirdParty(bundleId, key, trader);
        return getRtnInfo(result);
    }
}
