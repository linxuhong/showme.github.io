package com.yihaodian.mobile.hedwig.client.service.mobilecart;

import com.yihaodian.mobile.backend.mobilecart.CartCommInputVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.mobilecart.spi.AppCartService;
import com.yihaodian.mobile.vo.wl2.ClientInfo;

public class AppCartClientService implements AppCartService {
	
	private AppCartService appCartServiceHessianCall;

	public void setAppCartServiceHessianCall(
			AppCartService appCartServiceHessianCall) {
		this.appCartServiceHessianCall = appCartServiceHessianCall;
	}

	@Override
	public Result getCheckoutProgressForPromotion(ClientInfo client, CartCommInputVO commInput, Long userId, Long promotionId, Long promotionLevelId) {
		return appCartServiceHessianCall.getCheckoutProgressForPromotion(client, commInput, userId, promotionId, promotionLevelId);
	}
	
	@Override
	public Result getCheckoutProgressForPromotionLevels(ClientInfo client, CartCommInputVO commInput, Long userId, Long promotionId, Long promotionLevelId) {
		return appCartServiceHessianCall.getCheckoutProgressForPromotionLevels(client, commInput, userId, promotionId, promotionLevelId);
	}

}
