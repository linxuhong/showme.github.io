package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.Map;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.domain.business.emuns.CommonResultCode;
import com.yihaodian.mobile.service.facade.business.advertisement.CurtainAdvertisementService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class CurtainAdDispaterService extends BaseDiapatchService{
	
	 public RtnInfo getCurtainAdvertisement(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		 if(!isLogined && context.isHasToken()){//ut失效
			 Result result = new ResultModel();
			 result.setSuccess(false);
			 result.setBaseResultCode(CommonResultCode.CURTAIN_AD_NULL_MESSAGE);
			 return getRtnInfo(result);
		 }
		 Trader trader = getTraderFromContext(context);
		 RtnInfo rtn = vaildateTrader(trader);
		 if(rtn!=null){
			 return rtn;
		 }
		 Long userId = null;
		 if(context.getCurrentUserId()!=null){
			 userId = Long.parseLong(context.getCurrentUserId());
		 }
		 CurtainAdvertisementService service = CentralMobileServiceHandler.getCurtainADClientService();
		 return getRtnInfo(service.getCurtainAdvertisement(trader, trader.getDeviceCode(), Integer.valueOf(context.getRequestInfo().getProvinceId()), userId, trader.getInterfaceVersion()));
		 
	 }
	 
	 public RtnInfo openCurtainAdvertisement(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
             AdapterContext context){
		 Trader trader = getTraderFromContext(context);
		 String deviceCode = bizInfo.get("devicetoken");
		 RtnInfo rtn = vaildateTrader(trader);
		 if(rtn!=null){
			 return rtn;
		 }
		 if(StringUtil.isBlank(deviceCode)){
			 deviceCode = trader.getDeviceCode();
		 }
		 CurtainAdvertisementService service =  CentralMobileServiceHandler.getCurtainADClientService();
		 return getRtnInfo(service.openCurtainAdvertisement(trader, deviceCode, Integer.valueOf(context.getRequestInfo().getProvinceId())));
	 }

}
