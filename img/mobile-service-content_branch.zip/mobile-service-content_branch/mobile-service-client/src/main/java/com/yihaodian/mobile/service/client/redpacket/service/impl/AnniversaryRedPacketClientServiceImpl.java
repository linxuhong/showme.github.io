package com.yihaodian.mobile.service.client.redpacket.service.impl;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.client.redpacket.service.AnniversaryRedPacketClientService;
import com.yihaodian.mobile.service.facade.business.redpacket.IAnniversaryRedPacketService;
import com.yihaodian.mobile.vo.ClientInfoVO;

/**
 * 
 * @author zhangwei5
 * @version $Id: AnniversaryRedPacketClientServiceImpl.java, v 0.1 2014-6-23 下午6:23:29 zhangwei5 Exp $
 */
public class AnniversaryRedPacketClientServiceImpl implements AnniversaryRedPacketClientService{

    private IAnniversaryRedPacketService anniversaryRedPacketHessianCall;
    
    @Override
    public Result checkActivityEffective(ClientInfoVO clientInfoVO) {
        return anniversaryRedPacketHessianCall.checkActivityEffective(clientInfoVO);
    }

    @Override
    public Result getRedPacketResult(ClientInfoVO clientInfoVO) {
        return anniversaryRedPacketHessianCall.getRedPacketResult(clientInfoVO);
    }
    
    public void setAnniversaryRedPacketHessianCall(IAnniversaryRedPacketService anniversaryRedPacketHessianCall) {
        this.anniversaryRedPacketHessianCall = anniversaryRedPacketHessianCall;
    }

    
    
}
