package com.yihaodian.mobile.hedwig.client.impl.rock;

import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.push.spi.IPromotionGameService;


public class PromotionGameClientServiceImpl implements IPromotionGameService {
	
	private IPromotionGameService promotionGameHessianCall;

	public IPromotionGameService getPromotionGameHessianCall() {
		return promotionGameHessianCall;
	}

	public void setPromotionGameHessianCall(
			IPromotionGameService promotionGameHessianCall) {
		this.promotionGameHessianCall = promotionGameHessianCall;
	}

	@Override
	public ResultModel getGamePromotionInfo(Long gameId, Long userId,
			Integer provinceId) {
		
		return promotionGameHessianCall.getGamePromotionInfo(gameId, userId, provinceId);
	}

	@Override
	public ResultModel getGamePromotionInfoWithShareToken(Long gameId,
			Long userId, Integer provinceId, Long shareToken) {

		return promotionGameHessianCall.getGamePromotionInfoWithShareToken(gameId, userId, provinceId, shareToken);
	}

	@Override
	public ResultModel doShaking(Long gameId, Long userId, String traderName,
			String deviceToken, String ip, Integer provinceId) {

		return promotionGameHessianCall.doShaking(gameId, userId, traderName, deviceToken, ip, provinceId);
	}

	@Override
	public ResultModel doShakingWithAwardPoolIds(Long gameId, Long userId,
			String awardPoolIds, String traderName, String deviceToken,
			String ip, Integer provinceId) {

		return promotionGameHessianCall.doShakingWithAwardPoolIds(gameId, userId, awardPoolIds, traderName, deviceToken, ip, provinceId);
	}

	@Override
	public ResultModel acceptAward(Long gameId, Long userId, Long awardId,
			Integer isDiscard, Integer provinceId, String traderName,
			String deviceToken, String tokenSession, String phone,
			String address, String userName, String sessionId, String ip) {
		
		return promotionGameHessianCall.acceptAward(gameId, userId, awardId, isDiscard, provinceId, traderName, deviceToken, tokenSession, phone, address, userName, sessionId, ip);
	}

	@Override
	public ResultModel unlockAwardPool(Long gameId, Long userId,
			Integer provinceId, Long shareToken, Long gamePoolId) {
	
		return promotionGameHessianCall.unlockAwardPool(gameId, userId, provinceId, shareToken, gamePoolId);
	}

	@Override
	public ResultModel getAchievementList(Long gameId, Long userId,
			Integer provinceId) {
		
		return promotionGameHessianCall.getAchievementList(gameId, userId, provinceId);
	}
	
	@Override
	public ResultModel getUserAcceptAwardList(Long gameId, Long userId) {
		
		return promotionGameHessianCall.getUserAcceptAwardList(gameId, userId);
	}

	@Override
	public ResultModel changeLP(Long gameId, Long userId, Long awardId,
			Integer provinceId, String traderName, String deviceToken,
			String sessionId, String ip) {

		return promotionGameHessianCall.changeLP(gameId, userId, awardId, provinceId, traderName, deviceToken, sessionId, ip);
	}

	@Override
	public ResultModel yCacheGamePromotion(Long gameId) {

		return promotionGameHessianCall.yCacheGamePromotion(gameId);
	}

	@Override
	public ResultModel yCacheGameAwardPoolList(Long gameId) {

		return promotionGameHessianCall.yCacheGameAwardPoolList(gameId);
	}

	@Override
	public ResultModel yCacheGameAwardList(Long gameId, Long gamePoolId) {

		return promotionGameHessianCall.yCacheGameAwardList(gameId, gamePoolId);
	}

	@Override
	public ResultModel yCacheGameAdList(Long gameId) {

		return promotionGameHessianCall.yCacheGameAdList(gameId);
	}

	@Override
	public ResultModel doShakingByPoint(Long gameId, Long userId,
			String traderName, String deviceToken, String ip, Integer provinceId) {
		
		return promotionGameHessianCall.doShakingByPoint(gameId, userId, traderName, deviceToken, ip, provinceId);
	}

	@Override
	public ResultModel getUnlockInfo(Long gameId, Long userId,Integer provinceId, Long gamePoolId) {
		
		return promotionGameHessianCall.getUnlockInfo(gameId, userId, provinceId, gamePoolId);
	}

	@Override
	public ResultModel saveUserGameShareRecord(Long gameId, Long userId) {
		return promotionGameHessianCall.saveUserGameShareRecord(gameId, userId);
	}

}
