package com.yihaodian.mobile.service.client.adapter.home;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.home.spi.AppIndexService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 
 * @author wulibing
 *
 */
public class AppIndexDispatchService extends BaseDiapatchService {


	public RtnInfo loadMobileAds(String urlPath, Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		try {
			Long userId = null;
			if (isLogined) {
				userId = Long.parseLong(context.getCurrentUserId());
			}
			
			String provinceId = context.getRequestInfo().getProvinceId();
			RtnInfo rtnInfo = validateNumber(provinceId);
			if(rtnInfo != null){
				return rtnInfo;
			}
			
//			if(bizInfo.get("hassonpics")==null){
//				return RtnInfo.ParameterErrRtnInfo("hassonpics is null");
//			}
			
			if(bizInfo.get("startuppicsize")==null){
				return RtnInfo.ParameterErrRtnInfo("startuppicsize is null");
			}
			
			String k_i = bizInfo.get("k_i");
			if(k_i == null || k_i.isEmpty()) {
				k_i = "1";
			}
			
			String typeStr = bizInfo.get("type");
			int type = 0;
			if(StringUtils.isNotBlank(typeStr)){
				try {
					type = Integer.valueOf(typeStr);
				} catch (Exception e) {
				}
			}
			
			
			ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo(), provinceId, context.getRequestInfo().getCityId());
			AppIndexService service = CentralMobileServiceHandler.getAppIndexService();
			Result result =  service.loadMobileAds(clientInfoVO,userId,bizInfo.get("startuppicsize"), k_i,Integer.valueOf(provinceId),type);
			
			// 新人礼弹窗ut失效问题
			if(result.isSuccess()){
				 if(!isLogined && context.isHasToken()){//ut失效
					 Map<String,Object> resultMap = (Map<String,Object>)result.getDefaultModel();
					 resultMap.remove("getCurtainAdvertisement");
				 }
			}
			return getRtnInfo(result);
		} catch (Exception e) {
			return null;
		}
	}
	
	public RtnInfo loadPmsProducts(String urlPath, Boolean isLogined, Map<String, String> bizInfo,
			AdapterContext context) {
		try {
			RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
			if (rtnInfo != null) {
				return rtnInfo;
			}
			
			String cityid = bizInfo.get("cityid");
			if(cityid==null)
			    cityid=context.getRequestInfo().getCityId();
			
			rtnInfo = validateNumber(cityid);
			if (rtnInfo != null) {
				return rtnInfo;
			}
			
			AppIndexService service = CentralMobileServiceHandler.getAppIndexService();
			ClientInfoVO clientVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
			clientVO.setCityId(cityid);
			
			Result result = null;
			String version = urlPath.substring(urlPath.lastIndexOf("/") + 1);
			if ("v2".equalsIgnoreCase(version)) {
				// v2版本对应于首页改版(2017年02月),excludeproducts是厨房精品中已经显示的3件商品ID(逗号分隔)
				String excluds = bizInfo.get("excludeproducts");
				result = service.loadPmsProductsV2(clientVO,
					Long.valueOf(context.getRequestInfo().getProvinceId()), context.getCurrentUserId(),Long.valueOf(cityid),excluds);
			} else {
				result = service.loadPmsProducts(clientVO,
					Long.valueOf(context.getRequestInfo().getProvinceId()), context.getCurrentUserId(),Long.valueOf(cityid));
			}

			return getRtnInfo(result);
		} catch (Exception e) {
			return null;
		}
	}
}
