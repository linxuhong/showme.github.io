package com.yihaodian.mobile.hedwig.client.service.impl;

import java.util.List;

import com.yihaodian.mobile.service.hedwig.core.service.spi.FeedbackService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.feedback.FeedBackTypeInfoVO;
import com.yihaodian.mobile.vo.result.ContentResult;

public class FeedbackClientServiceImpl implements FeedbackService {

	private FeedbackService feedbackHessiancall;
	@Override
	public Integer addFeedback(String token, String feedbackcontext) {
		return feedbackHessiancall.addFeedback(token, feedbackcontext);
	}

	@Override
	public ContentResult<String> addFeedbackV2(String token,
			String feedbackContext, Integer type) {
		return feedbackHessiancall.addFeedbackV2(token, feedbackContext, type);
	}

	@Override
	public List<FeedBackTypeInfoVO> getFeedBackTypeInfoList(Trader trader) {
		return feedbackHessiancall.getFeedBackTypeInfoList(trader);
	}

	public FeedbackService getFeedbackHessiancall() {
		return feedbackHessiancall;
	}

	public void setFeedbackHessiancall(FeedbackService feedbackHessiancall) {
		this.feedbackHessiancall = feedbackHessiancall;
	}

    @Override
    public Integer addFeedback(Long userId, String feedbackcontext, Trader trader) {
        return feedbackHessiancall.addFeedback(userId, feedbackcontext, trader);
    }

    @Override
    public ContentResult<String> addFeedbackV2(Long userId, String feedbackContext, Integer type,
                                               Trader trader) {
        return feedbackHessiancall.addFeedbackV2(userId, feedbackContext, type, trader);
    }

	@Override
	public ContentResult<String> addFeedbackV2(Long userId,String feedbackcontext, Integer type, Trader trader, String info) {
		
		return feedbackHessiancall.addFeedbackV2(userId, feedbackcontext, type, trader, info);
	}

	@Override
	public Integer addFeedback(Long userId, String feedbackcontext,Trader trader, String info) {
		
		return feedbackHessiancall.addFeedback(userId, feedbackcontext, trader, info);
	}

	@Override
	public ContentResult<String> addFeedbackV2(Long userId, String feedbackcontext, String image1, String image2, String image3, 
			Integer type, Trader trader, String info) {
		return feedbackHessiancall.addFeedbackV2(userId, feedbackcontext, image1, image2, image3, type, trader, info);
	}

	@Override
	public Integer addFeedback(Long userId, String feedbackcontext, String image1, String image2, String image3, 
			Trader trader, String info) {
		return feedbackHessiancall.addFeedback(userId, feedbackcontext, image1, image2, image3, trader, info);
	}

	

}
