package com.yihaodian.mobile.hedwig.client.service.impl;

import com.yihaodian.mobile.service.hedwig.core.service.spi.MiracleService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.miracle.MiracleRegisterResult;

public class MiracleClientServiceImpl implements MiracleService {
	
	private MiracleService miracleHessiancall;
	@Override
	public MiracleRegisterResult miracleAutoRegister(Trader trader, String regId) {
		
		return miracleHessiancall.miracleAutoRegister(trader, regId);
	}
	public MiracleService getMiracleHessiancall() {
		return miracleHessiancall;
	}
	public void setMiracleHessiancall(MiracleService miracleHessiancall) {
		this.miracleHessiancall = miracleHessiancall;
	}

}
