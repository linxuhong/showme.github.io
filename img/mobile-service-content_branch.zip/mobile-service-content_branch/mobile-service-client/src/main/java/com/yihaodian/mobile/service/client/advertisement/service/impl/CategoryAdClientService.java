package com.yihaodian.mobile.service.client.advertisement.service.impl;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.advertisement.CategoryAdService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class CategoryAdClientService implements CategoryAdService{
	private CategoryAdService categoryADHessianCall;


	@Override
	public Result getHotRecommendCateList(Trader trader, String deviceCode,
			Integer provinceId, Long categoryId, Long userId) {
		return categoryADHessianCall.getHotRecommendCateList(trader, deviceCode, provinceId, categoryId, userId);
	}

	public CategoryAdService getCategoryADHessianCall() {
		return categoryADHessianCall;
	}

	public void setCategoryADHessianCall(CategoryAdService categoryADHessianCall) {
		this.categoryADHessianCall = categoryADHessianCall;
	}

	@Override
	public Result getMobReCateList(String deviceCode, Long provinceId,
			Long userId, String id) {
		return categoryADHessianCall.getMobReCateList(deviceCode, provinceId, userId, id);
	}

	@Override
	public Result getMobSubCategorysById(Long categoryId) {
		return categoryADHessianCall.getMobSubCategorysById(categoryId);
	}


	
}
