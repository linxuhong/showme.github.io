package com.yihaodian.mobile.service.client.adapter.tag;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.tag.IAppTagService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**  
 * @author myx
 * @createTime 2016年5月23日 下午4:30:17  
 * 
 */
public class AppTagDispatchService extends BaseDiapatchService{	
	/**
	 * 获取App标签规则资源和APP动画资源
	 * @return
	 */
	public RtnInfo getAppTagConfigRule(String urlPath,Boolean isLogined, Map<String, String> bizInfo,AdapterContext context) {
		IAppTagService service = CentralMobileServiceHandler.getAppTagClientService();
		Result result = service.getAppTagConfigRule();
		return getRtnInfo(result);
	}
}
