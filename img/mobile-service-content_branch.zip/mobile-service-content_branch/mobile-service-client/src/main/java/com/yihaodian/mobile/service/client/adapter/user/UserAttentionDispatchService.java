package com.yihaodian.mobile.service.client.adapter.user;

import java.util.Map;

import org.apache.log4j.Logger;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.user.spi.UserFacadeService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.user.PushMappingResult;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 用户关注项目
 * @author chenliang
 *
 */
public class UserAttentionDispatchService extends BaseDiapatchService{
	
	private Logger logger = Logger.getLogger(UserAttentionDispatchService.class);
	

	public RtnInfo insertAppErrorLog(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			UserFacadeService userFacadeService = CentralMobileServiceHandler.getUserClientService();
			Trader trader = getTraderFromContext(context);
			RtnInfo rtnInfo = vaildateTrader(trader);
			if(rtnInfo == null){
				String log = bizInfo.get("log")!=null?bizInfo.get("log"):"";
				String phoneNumber = bizInfo.get("phonenumber")!=null?bizInfo.get("phonenumber"):"";
				Long userId = context.getCurrentUserId()!=null ? Long.valueOf(context.getCurrentUserId()) : null;
				Integer result = userFacadeService.insertAppErrorLog(trader, log, phoneNumber, userId);
				rtnInfo = RtnInfo.RightWlRtnInfo(result);
			}
			return rtnInfo;
		} catch (Exception e) {
			logger.error("UserDispatchService=>insertAppErrorLog error",e);
			return RtnInfo.ParameterErrRtnInfo("some pram is null");
		}
	}

}
