package com.yihaodian.mobile.hedwig.client.WeChat.service;

import com.yihaodian.mobile.hedwig.push.vo.WeChatProductVO;

public interface WeChatClientService {
	public WeChatProductVO getWeChatProductVODetail(Long productId,
			Long provinceId); 
}
