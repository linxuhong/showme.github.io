package com.yihaodian.mobile.hedwig.client.service.impl;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.system.SystemService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.UserPassport;

public class UserPassportClientServiceImpl implements UserPassport {
	private UserPassport userPassportHessianCall ;
	@Override
	public Result getUserById(String userToken) {		
		return userPassportHessianCall.getUserById(userToken);
	}

	@Override
	public Result updateUserById(String userToken) {		
		return userPassportHessianCall.updateUserById(userToken);
	}

	public UserPassport getUserPassportHessianCall() {
		return userPassportHessianCall;
	}

	public void setUserPassportHessianCall(UserPassport userPassportHessianCall) {
		this.userPassportHessianCall = userPassportHessianCall;
	}

	@Override
	public Result getUserById(Long userId) {
		return userPassportHessianCall.getUserById(userId);
	}

	@Override
	public Result updateUserById(Long userId) {
		return userPassportHessianCall.updateUserById(userId);
	}

}
