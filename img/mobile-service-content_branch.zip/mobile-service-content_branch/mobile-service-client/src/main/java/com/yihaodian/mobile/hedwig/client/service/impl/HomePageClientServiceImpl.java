package com.yihaodian.mobile.hedwig.client.service.impl;

import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.hedwig.push.spi.HomePageService;
import com.yihaodian.mobile.service.domain.vo.business.homepage.RedisHomeKey;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.community.CheckCommunityVO;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.home.CalendarBuyDetail;
import com.yihaodian.mobile.vo.home.CalendarBuyVO;
import com.yihaodian.mobile.vo.home.DailyTimeVO;
import com.yihaodian.mobile.vo.home.HomeFloorPromotion;
import com.yihaodian.mobile.vo.home.HomePromotionDetailVO;
import com.yihaodian.mobile.vo.home.HomePromotionVO;
import com.yihaodian.mobile.vo.home.ViewVO;
import com.yihaodian.mobile.vo.home.WeEasyBuyVO;
import com.yihaodian.mobile.vo.product.ProductVO;
import com.yihaodian.mobile.vo.promotion.CmsColumnVO;
import com.yihaodian.mobile.vo.promotion.CmsPromotionVO;
import com.yihaodian.mobile.vo.promotion.PromotionSortAttributes;
import com.yihaodian.mobile.vo.user.UserVO;

public class HomePageClientServiceImpl implements HomePageService{

	                              
	private HomePageService homePageHessianCall;


	@Override
	public CalendarBuyDetail getCalendarBuyDetail(Trader trader,
			Long provinceId, String dateDay) {
		
		return homePageHessianCall.getCalendarBuyDetail(trader, provinceId, dateDay);
	}


	@Override
	public CmsColumnVO getCmsColumnDetail(Trader trader, Long provinceId,
			Long cmsColumnId, Integer sortType, Integer currentPage,
			Integer pageSize) {
		
		return homePageHessianCall.getCmsColumnDetail(trader, provinceId, cmsColumnId, sortType, currentPage, pageSize);
	}

	@Override
	public List<ProductVO> getCalendarBuyProductList(Trader trader,
			Long provinceId, String dateDay) {
		
		return homePageHessianCall.getCalendarBuyProductList(trader, provinceId, dateDay);
	}

	@Override
	public List<HomePromotionDetailVO> getBrandShopPromotion(Trader trader,
			Long provinceId) {
		
		return homePageHessianCall.getBrandShopPromotion(trader, provinceId);
	}


	@Override
	public ViewVO getMobileIndexViewForBI(Trader trader, Long provinceId) {
		
		return homePageHessianCall.getMobileIndexViewForBI(trader, provinceId);
	}


	@Override
	public ViewVO getMobileIndexViewByType(Trader trader, Long provinceId,
			Long viewType) {
		
		return homePageHessianCall.getMobileIndexViewByType(trader, provinceId, viewType);
	}

	@Override
	public ViewVO getMobileViewById(Trader trader, Long provinceId, Long viewId) {
		
		return homePageHessianCall.getMobileViewById(trader, provinceId, viewId);
	}
	
	@Override
	public ViewVO getCommunityView(Trader trader, String provinceName,
			String cityName, String areaName, String streetName) {
		return homePageHessianCall.getCommunityView(trader, provinceName, cityName, areaName, streetName);
	}
	
	@Override
	public ViewVO getCommunityViewForBIProduct(Long provinceId) {
		return homePageHessianCall.getCommunityViewForBIProduct(provinceId);
	}
	
	@Override
	public CheckCommunityVO checkCommunity(Long provinceId,
			String provinceName, String cityName, String areaName,
			String streetName) {
		return homePageHessianCall.checkCommunity(provinceId, provinceName, cityName, areaName, streetName);
	}

	public HomePageService getHomePageHessianCall() {
		return homePageHessianCall;
	}

	public void setHomePageHessianCall(HomePageService homePageHessianCall) {
		this.homePageHessianCall = homePageHessianCall;
	}

	@Override
	public List<ProductVO> getHomePageProductVO(Trader trader,
			Long provinceId, Integer currentPage,
			Integer pageSize) {
		return null;
	}

	@Override
	public ViewVO getGrouponBanner(Trader trader, Long provinceId,
			Long userType, String viewCode) {
		return null;
	}


	@Override
	public Map<String,RedisHomeKey> getAllAndRemoveInValidHomePageKeys() {
		return homePageHessianCall.getAllAndRemoveInValidHomePageKeys();
	}

	@Override
	public void deleteHomePageKeysAndContent(List<String> keys) {
		homePageHessianCall.deleteHomePageKeysAndContent(keys);
	}
}
