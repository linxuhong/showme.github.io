package com.yihaodian.mobile.service.client.adapter.survey;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.survey.spi.SurveyQuestionaireService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class SurveyQuestionaireDispatchService extends BaseDiapatchService {
	public RtnInfo getOpenQuestionairesForUser(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String uid = context.getCurrentUserId();
		
		if (!isLogined || StringUtils.isBlank(uid)) {
			return RtnInfo.ParameterErrRtnInfo("There's no login user!");
		}
		
		SurveyQuestionaireService service = CentralMobileServiceHandler.getSurveyQuestionaireClientService();
		Result result = service.getOpenQuestionairesForUser(Long.valueOf(uid));
		return getRtnInfo(result);
	}
}
