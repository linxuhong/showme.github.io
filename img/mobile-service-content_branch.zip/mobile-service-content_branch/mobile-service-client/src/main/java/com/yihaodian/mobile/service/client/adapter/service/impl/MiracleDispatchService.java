package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MiracleService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.miracle.MiracleRegisterResult;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class MiracleDispatchService extends BaseDiapatchService{
	private Logger logger = LoggerFactory.getLogger(MiracleDispatchService.class);
	public RtnInfo miracleAutoRegister(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		try {			
			Trader trader = getTraderFromContext(context);
			if(trader ==null ||StringUtil.isEmpty(trader.getTraderName())){
				return RtnInfo.ParameterErrRtnInfo("trader or tradername is null");
			}
			String regId = bizInfo.get("regid");
			if(StringUtil.isEmpty(regId)){
				return RtnInfo.ParameterErrRtnInfo("regid is null");
			}
			MiracleService service = CentralMobileServiceHandler.getMiracleService();
			MiracleRegisterResult re = service.miracleAutoRegister(trader, regId);
			
			return RtnInfo.RightWlRtnInfo(re);
		} catch (Exception e) {
			logger.error("MiracleDispatchService=>miracleAutoRegister", e);
			return null;
		}
	}

}
