package com.yihaodian.mobile.hedwig.client.service.impl;

import java.util.Date;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.integral.IintergralWallService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class IntergralWallClientServiceImpl implements IintergralWallService {
	private IintergralWallService intergralWallHessianCall;

	@Override
	public Result registerIntergralWallInfo(String mac, String appId,
			String idFa, String oem) {
		return intergralWallHessianCall.registerIntergralWallInfo(mac, appId, idFa, oem);
	}

	@Override
	public Result activatingIntergralWallInfo(ClientInfoVO clientInfoVO, String mac, String appId,
			String idFa, String oem) {
		return intergralWallHessianCall.activatingIntergralWallInfo(clientInfoVO, mac, appId, idFa, oem);
	}

	public IintergralWallService getIntergralWallHessianCall() {
		return intergralWallHessianCall;
	}

	public void setIntergralWallHessianCall(
			IintergralWallService intergralWallHessianCall) {
		this.intergralWallHessianCall = intergralWallHessianCall;
	}

	@Override
	public Result registerIntergralWallInfoForGDT(String muid,
			String clickTime, String clickId, String appId, String advertiseId,
			String appType) {
		
		return intergralWallHessianCall.registerIntergralWallInfoForGDT(muid, clickTime, clickId, appId, advertiseId, appType);
	}

	@Override
	public Result activatingIntergralWallInfoForGDT(String muid,
			String clickTime, String clickId, String appId, String advertiseId,
			String appType) {		
		return null;
	}

	@Override
	public Result getIntergralWallInfoByIdfa(String appId, String idFas) {
		return intergralWallHessianCall.getIntergralWallInfoByIdfa(appId, idFas);
	}

	@Override
	public Result registerIntergralWallInfoForInmobi(String mac, String appId,
			String idfa, String oem, String clickid, String propertyId, String cityStr) {
		return intergralWallHessianCall.registerIntergralWallInfoForInmobi(mac, appId, idfa, oem, clickid, propertyId, cityStr);
	}
	
	@Override
	public Result registerIntergralWallInfoForYoudao(String mac, String appId,
			String idfa, String oem, String clickid) {
		return intergralWallHessianCall.registerIntergralWallInfoForYoudao(mac, appId, idfa, oem, clickid);
	}
	
	@Override
	public Result registerIntergralWallInfoForGlispa(String mac, String appId,
			String idfa, String oem, String clickid, String extendStr) {
		return intergralWallHessianCall.registerIntergralWallInfoForGlispa(mac, appId, idfa, oem, clickid, extendStr);
	}

    /** 
     * @see com.yihaodian.mobile.service.facade.business.integral.IintergralWallService#activatingIntergralWallInfo(com.yihaodian.mobile.vo.ClientInfoVO, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Long)
     */
    @Override
    public Result activatingIntergralWallInfo(ClientInfoVO clientInfoVO, String mac, String appId,
                                              String idFa, String oem, Long provinceId) {
       return  intergralWallHessianCall.activatingIntergralWallInfo(clientInfoVO, mac, appId, idFa, oem, provinceId);
    }
    
	@Override
	public Result activatingIntergralWallInfo(ClientInfoVO clientInfoVO,
			String mac, String appId, String idFa, String oem, Long provinceId,
			String userAgent) {
		return intergralWallHessianCall.activatingIntergralWallInfo(clientInfoVO, mac, appId, idFa, oem, provinceId, userAgent);
	}

	@Override
	public Result getIdfaAndDeviceCode() {
		return intergralWallHessianCall.getIdfaAndDeviceCode();
	}

	@Override
	public Result getIdfaAndDeviceCodeByDate(Date startTime, Date endTime) {
		return intergralWallHessianCall.getIdfaAndDeviceCodeByDate(startTime, endTime);
	}

}
