package com.yihaodian.mobile.hedwig.client.service.impl;

import com.google.gson.JsonObject;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MobileProfileService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.home.ShareContentVO;

public class MobileProfileClientServiceImpl implements MobileProfileService{
	
	private MobileProfileService mobileProfileHessianCall;
	@Override
	public String getIndexProfile(Trader trader, Long provinceId) {
	
		return mobileProfileHessianCall.getIndexProfile(trader, provinceId);
	}
     /**
     * 晒单活动规则
     * @param trader
	 * @param provinceId
	 * @return
     */
	@Override
	public String getCalendarProfile(Trader trader, Long provinceId) {
		return mobileProfileHessianCall.getCalendarProfile(trader, provinceId);
	}

	@Override
	public String getCalendarDetailProfile(Trader trader, Long provinceId,
			String date) {
		return mobileProfileHessianCall.getCalendarDetailProfile(trader, provinceId, date);
	}

	@Override
	public String getDailyOneProfile(Trader trader, Long provinceId) {
		return mobileProfileHessianCall.getDailyOneProfile(trader, provinceId);
	}

	@Override
	public JsonObject getActivityProductList(Trader trader, Long provinceId,
			Long linkId, Integer currentPage, Integer pageSize, int sortType) {
		return mobileProfileHessianCall.getActivityProductList(trader, provinceId, linkId, currentPage, pageSize, sortType);
	}

	@Override
	public String getExportGoodsView(Trader trader, Long linkId, Long provinceId) {
		
		return mobileProfileHessianCall.getExportGoodsBrand(trader, linkId, provinceId);
	}

	@Override
	public String getExportGoodsCategory(Trader trader, Long provinceId) {
		return mobileProfileHessianCall.getExportGoodsCategory(trader, provinceId);
	}

	@Override
	public String getActivityRule(Trader trader, Long provinceId) {
		return mobileProfileHessianCall.getActivityRule(trader, provinceId);
	}

	@Override
	public String getExportGoodsBrand(Trader trader, Long categoryId,
			Long provinceId) {
		
		return mobileProfileHessianCall.getExportGoodsBrand(trader, categoryId, provinceId);
	}

	@Override
	public ShareContentVO getShareContent(Trader trader, Long viewId) {
		return mobileProfileHessianCall.getShareContent(trader, viewId);
	}

	@Override
	public String getIndexProfileByType(Trader trader, Long provinceId,
			Long viewType) {
		return mobileProfileHessianCall.getIndexProfileByType(trader, provinceId, viewType);
	}
	 /**
	   * 各种页面统一入口
	   * @param trader
	   * @param provinceId
	   * @return
	   */
	@Override
	public String getViewProfile(Trader trader, Long linkId, Long provinceId) {
		
		return mobileProfileHessianCall.getViewProfile(trader, linkId, provinceId);
	}

	public MobileProfileService getMobileProfileHessianCall() {
		return mobileProfileHessianCall;
	}

	public void setMobileProfileHessianCall(
			MobileProfileService mobileProfileHessianCall) {
		this.mobileProfileHessianCall = mobileProfileHessianCall;
	}

}
