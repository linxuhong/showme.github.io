package com.yihaodian.mobile.hedwig.client.service.seckill;

import java.util.List;
import java.util.Map;

import com.yihaodian.front.busystock.vo.BSProductPromRuleVo;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.seckill.spi.SeckillQueueService;
import com.yihaodian.mobile.vo.seckill.SeckillMetaData;
import com.yihaodian.mobile.vo.seckill.TaskStatusVo;

public class SeckillQueueClientService implements SeckillQueueService {

	private SeckillQueueService seckillQueueServiceHessianCall;

	public void setSeckillQueueServiceHessianCall(SeckillQueueService seckillQueueServiceHessianCall) {
		this.seckillQueueServiceHessianCall = seckillQueueServiceHessianCall;
	}

	@Override
	public Result getTaskStatus(String token) {
		return seckillQueueServiceHessianCall.getTaskStatus(token);
	}

	@Override
	public Result fetchTasks(Integer count) {
		return seckillQueueServiceHessianCall.fetchTasks(count);
	}

	@Override
	public Result sendTask(String dataJson, SeckillMetaData meta) {
		return seckillQueueServiceHessianCall.sendTask(dataJson, meta);
	}

	@Override
	public Result cancelTask(String token) {
		return seckillQueueServiceHessianCall.cancelTask(token);
	}

	@Override
	public Result setTaskStatus(TaskStatusVo taskStatusVo) {
		return seckillQueueServiceHessianCall.setTaskStatus(taskStatusVo);
	}

	@Override
	public Result initRuleInfo(List<BSProductPromRuleVo> productPromRuleVos) {
		return seckillQueueServiceHessianCall.initRuleInfo(productPromRuleVos);
	}

	@Override
	public Result decrTaskCount(SeckillMetaData meta) {
		return seckillQueueServiceHessianCall.decrTaskCount(meta);
	}

}
