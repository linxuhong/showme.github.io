/**
 * www.yhd.com-402 Inc.
 * Copyright (c) 2008-2015 All Rights Reserved.
 */
package com.yihaodian.mobile.hedwig.client.service.cut;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.cut.ICutService;
import com.yihaodian.mobile.vo.ClientInfoVO;

/**
 * 
 * @author huangqihui
 * @version $Id: CutClientService.java, v 0.1 2015年8月12日 下午4:00:44 huangqihui Exp $
 */
public class CutClientService implements ICutService {
    
    private  ICutService cutServiceHessianCall ;

    
     
    
  
    /** 
     * @see com.yihaodian.mobile.service.facade.business.cut.ICutService#getColumnAndActivity(com.yihaodian.mobile.vo.ClientInfoVO, java.lang.Long, java.lang.Integer)
     */
    @Override
    public Result getColumnAndActivity(ClientInfoVO clientInfoVO,  
                                              Integer type) {
        return cutServiceHessianCall.getColumnAndActivity(clientInfoVO,   type);
    }

    /** 
     * @see com.yihaodian.mobile.service.facade.business.cut.ICutService#getProductByActivityId(java.lang.Long, java.util.List)
     */
    @Override
    public Result getProductByActivityId(ClientInfoVO clientInfoVO, List<Long> ids) {
        
        return cutServiceHessianCall.getProductByActivityId(clientInfoVO, ids);
    }

    /** 
     * @see com.yihaodian.mobile.service.facade.business.cut.ICutService#getCurrentProductList(java.lang.Long)
     */
    @Override
    public HashMap<String, Object> getCurrentProductList(ClientInfoVO clientInfoVO) {
        return cutServiceHessianCall.getCurrentProductList(clientInfoVO);
    }
    
    
    @Override
    public HashMap<String, Object> getCurrentProductList(ClientInfoVO clientInfoVO,   Long userid) {
        // TODO Auto-generated method stub
        return cutServiceHessianCall.getCurrentProductList(clientInfoVO,   userid);
    }
 

    /** 
     * @see com.yihaodian.mobile.service.facade.business.cut.ICutService#getProductReMindNum(java.util.List)
     */
    @Override
    public Result getProductReMindNum(List<String> keys) {
        
        return cutServiceHessianCall.getProductReMindNum(keys);
    }

    /** 
     * @see com.yihaodian.mobile.service.facade.business.cut.ICutService#updateProductReMindNum(java.lang.String, java.lang.Integer)
     */
    @Override
    public Result updateProductReMindNum(String key, Integer add) {
        
        return cutServiceHessianCall.updateProductReMindNum(key, add);
    }

        /**
         * Getter method for property <tt>cutServiceHessianCall</tt>.
         * 
         * @return property value of cutServiceHessianCall
         */
    public ICutService getCutServiceHessianCall() {
        return cutServiceHessianCall;
    }

        /**
         * Setter method for property <tt>cutServiceHessianCall</tt>.
         * 
         * @param cutServiceHessianCall value to be assigned to property cutServiceHessianCall
         */
    public void setCutServiceHessianCall(ICutService cutServiceHessianCall) {
        this.cutServiceHessianCall = cutServiceHessianCall;
    }

	@Override
	public Result findSimilarProduct(Long activityId,ClientInfoVO clientInfoVO,Long productId, Long merchantId, Long pmId, Integer number, Long lastId, Long channelId) {
		return cutServiceHessianCall.findSimilarProduct(activityId,clientInfoVO, productId,merchantId,pmId,number,lastId,channelId);
	}

	@Override
	public Result getBrandActivityDetailById(ClientInfoVO clientInfoVO, Long activityId) {
		return cutServiceHessianCall.getBrandActivityDetailById(clientInfoVO, activityId);
	}

    @Override
    public Result getCutPriceTab(ClientInfoVO clientInfoVO, Long provinceId) {
        return cutServiceHessianCall.getCutPriceTab(clientInfoVO, provinceId);
    }

    @Override
    public Map<String, Map> getGroupProductListByLp(ClientInfoVO clientInfoVO) {
        return cutServiceHessianCall.getGroupProductListByLp(clientInfoVO);
    }

    @Override
    public Result getExclusiveAd(ClientInfoVO clientInfoVO,Integer provinceId) {
        return cutServiceHessianCall.getExclusiveAd(clientInfoVO,provinceId);
    }
    
    

    @Override
    public Result getAllExclusivePriceColumns() {
        return cutServiceHessianCall.getAllExclusivePriceColumns();
    }

    @Override
    public Result getAllExclusivePriceColumns(Long provinceId, ClientInfoVO clientInfoVO) {
        return cutServiceHessianCall.getAllExclusivePriceColumns(provinceId, clientInfoVO);
    }

    @Override
    public Result getExclusiveProductsByColumnIds(List<Long> columnids, Long provinceId) {
        return cutServiceHessianCall.getExclusiveProductsByColumnIds(columnids, provinceId);
    }

    @Override
    public Map<String, Object> getYesterdayProductList(
            ClientInfoVO clientInfoVO,   Long userid) {
        return cutServiceHessianCall.getYesterdayProductList(clientInfoVO,  userid);
    }
    
    
    @Override
    public Result getExclusiveProductsByColumnIds(List<Long> columnids, Long provinceId, Long userId,
            ClientInfoVO clientInfoVO) {
        return cutServiceHessianCall.getExclusiveProductsByColumnIds(columnids, provinceId, userId, clientInfoVO);
    }

    @Override
    public Result getExclusiveDayRecommendPros() {
        return cutServiceHessianCall.getExclusiveDayRecommendPros();
    }

	@Override
	public Result getTodayDuoshouPic(ClientInfoVO clientInfoVO, Long provinceId) {
		return cutServiceHessianCall.getTodayDuoshouPic(clientInfoVO, provinceId);
	}

	
	//补全旧版
    @Override
    public Result getColumnAndActivity(ClientInfoVO clientInfoVO, Long provinceId, Integer type) {
        // TODO Auto-generated method stub
        return cutServiceHessianCall.getColumnAndActivity(clientInfoVO, provinceId, type);
    }

    @Override
    public Result getProductByActivityId(Long provinceId, List<Long> ids) {
        // TODO Auto-generated method stub
        return cutServiceHessianCall.getProductByActivityId(provinceId, ids);
    }

    @Override
    public HashMap<String, Object> getCurrentProductList(Long provinceId) {
        // TODO Auto-generated method stub
        return cutServiceHessianCall.getCurrentProductList(provinceId);
    }

    @Override
    public HashMap<String, Object> getCurrentProductList(ClientInfoVO clientInfoVO, Long provinceId, Long userid) {
        // TODO Auto-generated method stub
        return cutServiceHessianCall.getCurrentProductList(clientInfoVO, provinceId, userid);
    }

    @Override
    public Result findSimilarProduct(Long activityId, Long province, Long productId, Long merchantId, Long pmId,
            Integer number, Long lastId, Long channelId) {
        // TODO Auto-generated method stub
        return cutServiceHessianCall.findSimilarProduct(activityId, province, productId, merchantId, pmId, number, lastId, channelId);
    }

    @Override
    public Result getBrandActivityDetailById(Long province, Long activityId) {
        // TODO Auto-generated method stub
        return cutServiceHessianCall.getBrandActivityDetailById(province, activityId);
    }

    
    @Override
    public Map<String, Object> getYesterdayProductList(Long provinceId) {
        return cutServiceHessianCall.getYesterdayProductList(provinceId);
    }

    @Override
    public Map<String, Object> getYesterdayProductList(ClientInfoVO clientInfoVO, Long provinceId, Long userid) {
        return cutServiceHessianCall.getYesterdayProductList(clientInfoVO, provinceId, userid);
    }

    @Override
    public Map<String, Map> getGroupProductListByLp(Long provinceId) {
        return cutServiceHessianCall.getGroupProductListByLp(provinceId);
    }

	
	 
	
	
	

}
