/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.lottery;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.lottery.spi.ILotteryTicketService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class LotteryTickets.
 * @author zuodeng
 */
public class LotteryTickets extends BaseDiapatchService {
	
	/**
	 * Gets the lottery ticket url for500.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the lottery ticket url for500
	 */
	public RtnInfo getLotteryTicketUrlFor500(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		try {
		    if (!isLogined) {
	            return RtnInfo.TokenErrWlRtnInfo();
	        }else{
	            ILotteryTicketService service = CentralMobileServiceHandler.getLotteryTicketsClientService();
	            Trader trader = getTraderFromContext(context);
	            Result re = service.getLotteryTicketUrlFor500(Long.valueOf(context.getCurrentUserId()), context.getRequestInfo().getClientInfo().getTraderName(), Integer.valueOf(bizInfo.get("type")),trader);
	            return getRtnInfo(re);
	        }
		} catch (Exception e) {
			return null;
		}
	}
}
