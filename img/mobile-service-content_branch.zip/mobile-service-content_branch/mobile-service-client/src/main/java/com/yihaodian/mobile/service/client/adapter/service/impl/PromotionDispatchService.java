/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.reflect.TypeToken;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.hedwig.core.service.spi.PromotionService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.coupon.AddCouponByActivityIdResult;
import com.yihaodian.mobile.vo.promotion.AdvertisingPromotion;
import com.yihaodian.mobile.vo.promotion.AwardsResult;
import com.yihaodian.mobile.vo.promotion.CheckRockGameResult;
import com.yihaodian.mobile.vo.promotion.CheckRockResultResult;
import com.yihaodian.mobile.vo.promotion.CmsColumnVO;
import com.yihaodian.mobile.vo.promotion.AddStorageBoxResult;
import com.yihaodian.mobile.vo.promotion.CmsPageVO;
import com.yihaodian.mobile.vo.promotion.HotPointNewVO;
import com.yihaodian.mobile.vo.promotion.InviteeResult;
import com.yihaodian.mobile.vo.promotion.PromotionVO;
import com.yihaodian.mobile.vo.promotion.RockGameProductVO;
import com.yihaodian.mobile.vo.promotion.RockGameVO;
import com.yihaodian.mobile.vo.promotion.RockProductVO;
import com.yihaodian.mobile.vo.promotion.RockResultV2;
import com.yihaodian.mobile.vo.promotion.StorageBoxVO;
import com.yihaodian.mobile.vo.promotion.UpdateStroageBoxResult;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class PromotionDispatchService.
 */
public class PromotionDispatchService extends BaseDiapatchService{
	
	/** The logger. */
	private Logger logger = LoggerFactory.getLogger(PromotionDispatchService.class);
	
	/**
	 * Adds the coupon by activity id.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo addCouponByActivityId(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		Trader trader = getTraderFromContext(context);
		if(trader==null ||StringUtil.isEmpty(trader.getTraderName())){
			return RtnInfo.ParameterErrRtnInfo("trader or traderName is null");
		}
		String activityIdStr = bizInfo.get("activityid");
		RtnInfo rtn = validateNumber(activityIdStr);
		if(activityIdStr==null||"".equals(activityIdStr)){
			return RtnInfo.ParameterErrRtnInfo("activityId is null");
		}
		if(rtn!=null){
			return rtn;
		}
		Long activityId = Long.valueOf(activityIdStr);
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		String userIdStr = context.getCurrentUserId();
		if(validateNumber(userIdStr)!=null){
			return RtnInfo.ParameterErrRtnInfo("userid is error");
		}
		Long userId  = Long.parseLong(userIdStr);
		AddCouponByActivityIdResult cou = promotionService.addCouponByActivityId(userId, activityId, trader);
		return RtnInfo.RightWlRtnInfo(cou);
	}
	
	/**
	 * Gets the cms column by column by id.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the cms column by column by id
	 */
	public RtnInfo getCmsColumnByColumnById(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		Trader trader = getTraderFromContext(context);
	    if(trader==null ||trader.getTraderName()==null){
	    	return RtnInfo.ParameterErrRtnInfo("trader  is null");
	    }
	    String pid = context.getRequestInfo().getProvinceId();
	    RtnInfo rtn =validateProvinceId(pid);
	    if(rtn!=null){
			return rtn;
		}
		Long provinceId = Long.parseLong(pid);
		String col = bizInfo.get("cmscolumnid");
		rtn = validateNumber(col);
		if(rtn!=null){
			return rtn;
		}
		Long cmsColumnId = Long.parseLong(col);
		String type =bizInfo.get("type");
		if(StringUtil.isEmpty(type)){
			return RtnInfo.ParameterErrRtnInfo("type is null");
		}
		String cmsType = bizInfo.get("cmstype");
		if(StringUtil.isEmpty(cmsType)){
			return RtnInfo.ParameterErrRtnInfo("cmstype  is null");
		}
		String cp = bizInfo.get("currentpage");
		String ps = bizInfo.get("pagesize");
		rtn = validatePageInfo(cp, ps);
		if(rtn!= null){
			return rtn;
		}
		 Integer currentPage = Integer.parseInt(cp);
		Integer pageSize = Integer.parseInt(ps);
		CmsColumnVO cmsColumnVO = promotionService.getCmsColumnByColumnById(trader, provinceId, cmsColumnId, type, cmsType, currentPage, pageSize);
		return RtnInfo.RightWlRtnInfo(cmsColumnVO);
	}
	
	/**
	 * Gets the cms column list with cms type.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the cms column list with cms type
	 */
	public RtnInfo getCmsColumnListWithCMSType(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String cmsPageId = bizInfo.get("cmspageid");
		if(StringUtil.isEmpty(cmsPageId)){
			return RtnInfo.ParameterErrRtnInfo("cmsPageId is null");
		}
		String type = bizInfo.get("type");
		if(StringUtil.isEmpty(type)){
			return RtnInfo.ParameterErrRtnInfo("type is null");
		}
		String cmsType = bizInfo.get("cmstype");
		if(StringUtil.isEmpty(cmsType)){
			return RtnInfo.ParameterErrRtnInfo("cmsType is null");
		}
		String currentPage = bizInfo.get("currentpage");
		if(StringUtil.isEmpty(currentPage)){
			return RtnInfo.ParameterErrRtnInfo("currentPage is null");
		}
		String pageSize = bizInfo.get("pagesize");
		if(StringUtil.isEmpty(pageSize)){
			return RtnInfo.ParameterErrRtnInfo("pageSize is null");
		}
		Long provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
		
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		Page<CmsColumnVO> page = promotionService.getCmsColumnList(getTraderFromContext(context), provinceId, Long.parseLong(cmsPageId), type, cmsType, Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		return RtnInfo.RightWlRtnInfo(page);
	}
	
	/**
	 * Gets the cms column list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the cms column list
	 */
	public RtnInfo getCmsColumnList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String cmsPageId = bizInfo.get("cmspageid");
		RtnInfo rtn = validateNumber(cmsPageId);
		if (rtn != null) {
			return rtn;
		}
		String type = bizInfo.get("type");
		if(StringUtil.isEmpty(type)){
			return RtnInfo.ParameterErrRtnInfo("type is null");
		}
		String currentPage = bizInfo.get("currentpage");
		String pageSize = bizInfo.get("pagesize");
		rtn = validatePageInfo(currentPage, pageSize);
		if (rtn != null) {
			return rtn;
		}
		Long provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
		
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		Page<CmsColumnVO> page = promotionService.getCmsColumnList(getTraderFromContext(context), provinceId, Long.parseLong(cmsPageId), type, Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		return RtnInfo.RightWlRtnInfo(page);
	}
	
	/**
	 * Gets the cms page list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the cms page list
	 */
	public RtnInfo getCmsPageList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		String activityId = bizInfo.get("activityid");
		RtnInfo rtn = validateNumber(activityId);
		if (rtn != null) {
			return rtn;
		}
		String currentPage = bizInfo.get("currentpage");
		String pageSize = bizInfo.get("pagesize");
		rtn = validatePageInfo(currentPage, pageSize);
		if (rtn != null) {
			return rtn;
		}
		Long provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
		
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		Page<CmsPageVO> page = promotionService.getCmsPageList(getTraderFromContext(context), provinceId, Long.parseLong(activityId), Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		return RtnInfo.RightWlRtnInfo(page);
	}
	
	/**
	 * Adds the storage box.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo addStorageBox(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if (!isLogined) {
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userIdStr = context.getCurrentUserId();
		String productId = bizInfo.get("productid");
		RtnInfo rtn = validateNumber(productId);
		if (rtn != null) {
			return rtn;
		}
		rtn = validateNumber(userIdStr);
		if(rtn !=null){
			return rtn;
		}
		String promotionId = bizInfo.get("promotionid");
		String couponNumber = bizInfo.get("couponnumber");
		String type = bizInfo.get("type");
		rtn = validateNumber(type);
		if (rtn != null) {
			return rtn;
		}
		String couponActiveId = bizInfo.get("couponactiveid");
		String provinceStr = context.getRequestInfo().getProvinceId();
		rtn = validateNumber(provinceStr);
		if(rtn!=null){
			return rtn;
		}
		Long provinceId = Long.parseLong(provinceStr);
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();

		Long userId = Long.parseLong(userIdStr);
		AddStorageBoxResult result = promotionService.addStorageBoxV2(userId, productId!=null?Long.parseLong(productId):null, promotionId, couponNumber, Integer.parseInt(type), couponActiveId!=null?Long.parseLong(couponActiveId):null,provinceId );
		return RtnInfo.RightWlRtnInfo(result);
		
	}
	
	/**
	 * Gets the rock result v3 not logined.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rock result v3 not logined
	 */
	public RtnInfo getRockResultV3NotLogined(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		PromotionService service = CentralMobileServiceHandler.getPromotionService();
		Trader trader = getTraderFromContext(context);
		if(trader.getTraderName() == null || trader.getTraderName().isEmpty()){
			return RtnInfo.ParameterErrRtnInfo("traderName is null");
		}
		
		String provinceId = context.getRequestInfo().getProvinceId();
		if(provinceId == null){
			return RtnInfo.ParameterErrRtnInfo("province id is null");
		}
		
		Double lng = bizInfo.get("lng") == null ? 0d : Double.valueOf(bizInfo.get("lng"));
		Double lat = bizInfo.get("lat") == null ? 0d : Double.valueOf(bizInfo.get("lat"));
		
		RockResultV2 result = service.getRockResultV3(trader, Long.valueOf(provinceId), lng, lat);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the rock result v3 with token.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rock result v3 with token
	 */
	public RtnInfo getRockResultV3WithToken(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if(!isLogined){
				return RtnInfo.TokenErrWlRtnInfo();
			}
			PromotionService service = CentralMobileServiceHandler.getPromotionService();
			Double lng = bizInfo.get("lng") == null ? 0d : Double.valueOf(bizInfo.get("lng"));
			Double lat = bizInfo.get("lat") == null ? 0d : Double.valueOf(bizInfo.get("lat"));
			Trader trader = getTraderFromContext(context);
			if(trader==null ||trader.getTraderName().equals("")){
				return RtnInfo.ParameterErrRtnInfo("trader name is null");
			}
			String pid = context.getRequestInfo().getProvinceId();
			if(validateProvinceId(pid)!=null){
				return RtnInfo.ParameterErrRtnInfo("province id error");
			}
			Long provinceId = Long.parseLong(pid);
			String userIdStr = context.getCurrentUserId();
			if(validateNumber(userIdStr)!=null){
				return RtnInfo.ParameterErrRtnInfo("userid is error");
			}
			Long userId  = Long.parseLong(userIdStr);
			String userName = context.getCurrentUserName();
			RockResultV2 result = service.getRockResultV3(userId, lng, lat, trader, provinceId,userName);//getRockResultV3(context.getRequestInfo().getUserToken(), lng, lat);
			return RtnInfo.RightWlRtnInfo(result);
		} catch (Exception e) {
			return null;
		}
		
	}
	
	/**
	 * Gets the my storage box list.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the my storage box list
	 */
	public RtnInfo getMyStorageBoxList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		Trader trader = getTraderFromContext(context);
		RtnInfo rtn = null;
		String type = bizInfo.get("type");
		rtn = validateNumber(type);
		if(rtn!=null){
			return rtn;
		}
		if(trader==null||StringUtil.isEmpty(trader.getTraderName())){
			return RtnInfo.ParameterErrRtnInfo("trader or traderName is null");
		}
		String currentPage = bizInfo.get("currentpage");
	    rtn = validateNumber(currentPage);
		if(rtn!=null){
			return rtn;
		}
		String pageSize = bizInfo.get("pagesize");
		rtn = validateNumber(pageSize);
		if(rtn!=null){
			return rtn;
		}
		String provinceIdStr = context.getRequestInfo().getProvinceId();
		rtn = validateNumber(provinceIdStr);
		if(rtn!=null){
			return rtn;
		}
		Long provinceId = Long.parseLong(provinceIdStr);
		String userIdStr = context.getCurrentUserId();
		if(validateNumber(userIdStr)!=null){
			return RtnInfo.ParameterErrRtnInfo("userid is error");
		}
		Long userId  = Long.parseLong(userIdStr);
		PromotionService service = CentralMobileServiceHandler.getPromotionService();
		Page<StorageBoxVO> result = service.getMyStorageBoxListV2(userId, Integer.valueOf(type), Integer.valueOf(currentPage), Integer.valueOf(pageSize),provinceId,trader);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the promotion by topic id.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the promotion by topic id
	 */
	public RtnInfo getPromotionByTopicID(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		PromotionVO result = null;
		try{
			PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
			String idStr = bizInfo.get("id");
			RtnInfo rtn = validateNumber(idStr);
			if(rtn!=null){
				return rtn;
			}
			Long id = Long.parseLong(idStr);
			Trader trader = getTraderFromContext(context);
			if(trader == null ||trader.getTraderName() == null){
				return RtnInfo.ParameterErrRtnInfo("trader or tradername is null");
			}
			result = promotionService.getPromotionByTopicID(trader, id);
		}catch(Exception e){
			logger.error("getPromotionByTopicID has error ", e);
		}	
		return RtnInfo.RightWlRtnInfo(result);	
	}
	
	/**
	 * Gets the presents by token.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the presents by token
	 */
	public RtnInfo getPresentsByToken(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String token = context.getRequestInfo().getUserToken();
		
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		List<RockGameProductVO> list = promotionService.getPresentsByToken(token);
		return RtnInfo.RightWlRtnInfo(list);
	}
	
	/**
	 * Check result.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo checkResult(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		String rockGameFlowID = bizInfo.get("rockgameflowid");
		if(StringUtil.isEmpty(rockGameFlowID)){
			return RtnInfo.ParameterErrRtnInfo("rockGameFlowID is null");
		}
		String resultCode = bizInfo.get("resultcode");
		if(StringUtil.isEmpty(resultCode)){
			return RtnInfo.ParameterErrRtnInfo("resultCode is null");
		}
		
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		CheckRockGameResult result = promotionService.checkResult(trader, Long.parseLong(rockGameFlowID), resultCode);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	public RtnInfo processGameFlow(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		
		String rockGameFlowID = bizInfo.get("rockgameflowid");
		if(StringUtil.isEmpty(rockGameFlowID)){
			return RtnInfo.ParameterErrRtnInfo("rockGameFlowID is null");
		}	
		String token = context.getRequestInfo().getUserToken();
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		Integer result = promotionService.processGameFlow(token, Long.parseLong(rockGameFlowID));
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the awards results.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the awards results
	 */
	public RtnInfo getAwardsResults(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		AwardsResult result = promotionService.getAwardsResults(trader);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Update stroage box product type.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo updateStroageBoxProductType(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String token = context.getRequestInfo().getUserToken();
		String promotionIdListStr = bizInfo.get("promotionidlist");
		if(StringUtil.isEmpty(promotionIdListStr)){
			return RtnInfo.ParameterErrRtnInfo("promotionIdList is null");
		}
		List<String> promotionIdList = null;
		try{
			promotionIdList = (List<String>)GsonUtil.paseToObject(promotionIdListStr, new TypeToken<List<String>>(){}.getType());
		}catch(Exception e){
			return RtnInfo.ParameterErrRtnInfo("promotionIdList is error");
		}
		String productIdListStr = bizInfo.get("productidlist");
		if(StringUtil.isEmpty(productIdListStr)){
			return RtnInfo.ParameterErrRtnInfo("productIdList is null");
		}
		List<Long> productIdList = null;
		try{
			productIdList = (List<Long>)GsonUtil.paseToObject(productIdListStr, new TypeToken<List<Long>>(){}.getType());
		}catch(Exception e){
			return RtnInfo.ParameterErrRtnInfo("productIdList is error");
		}
		String productStatus = bizInfo.get("productstatus");
		if(StringUtil.isEmpty(productStatus)){
			return RtnInfo.ParameterErrRtnInfo("productStatus is null");
		}
		
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		UpdateStroageBoxResult result = promotionService.updateStroageBoxProductType(token, promotionIdList, productIdList, Integer.parseInt(productStatus));
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	
	
	/**
	 * Gets the rock result v2.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rock result v2
	 */
	public RtnInfo getRockResultV2(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		RtnInfo rtnInfo = vaildateTrader(trader);
		if(rtnInfo != null){
			return rtnInfo;
		}
		rtnInfo = validateProvinceId(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		RockResultV2 result = promotionService.getRockResultV2(trader, Long.parseLong(context.getRequestInfo().getProvinceId()));
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the rock result v2 with token.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rock result v2 with token
	 */
	public RtnInfo getRockResultV2WithToken(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		String userIdStr = context.getCurrentUserId();
		Trader trader = getTraderFromContext(context);
		if(validateNumber(userIdStr)!=null){
			return RtnInfo.ParameterErrRtnInfo("userid is error");
		}
		if(trader==null ||trader.getTraderName().equals("")){
			return RtnInfo.ParameterErrRtnInfo("trader name is null");
		}
		String pid = context.getRequestInfo().getProvinceId();
		if(validateProvinceId(pid)!=null){
			return RtnInfo.ParameterErrRtnInfo("provinceid error");
		}
		Double lng = bizInfo.get("lng") == null ? 0d : Double.valueOf(bizInfo.get("lng"));
		Double lat = bizInfo.get("lat") == null ? 0d : Double.valueOf(bizInfo.get("lat"));
		Long provinceId = Long.parseLong(pid);
		Long userId = Long.parseLong(userIdStr);
		String userName = context.getCurrentUserName();
		RockResultV2 result = promotionService.getRockResultV2(userId, lng, lat, trader, provinceId,userName);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * Gets the hot point new vo by id.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the hot point new vo by id
	 */
	public RtnInfo getHotPointNewVOById(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		String pid = context.getRequestInfo().getProvinceId();
		Long provinceId = null;
		RtnInfo rtnInfo = validateProvinceId(pid);
		if(rtnInfo != null){
			return rtnInfo;
		}
		provinceId = Long.parseLong(pid);
		String hot = bizInfo.get("hotpointnewvoid");
		rtnInfo = validateNumber(hot);
		Long hotPointNewVOId = Long.parseLong(hot);
		rtnInfo = vaildateTrader(trader);
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		if(rtnInfo == null){
			HotPointNewVO cou = promotionService.getHotPointNewVOById(trader, provinceId, hotPointNewVOId);
			rtnInfo =  RtnInfo.RightWlRtnInfo(cou);
		 }		
		return rtnInfo;
	}
	
	/**
	 * Gets the advertising promotion vo by type.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the advertising promotion vo by type
	 */
	public RtnInfo getAdvertisingPromotionVOByType(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {	
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		Trader trader = getTraderFromContext(context);
		String pid = context.getRequestInfo().getProvinceId();
		Long provinceId = null;
		RtnInfo rtnInfo = validateProvinceId(pid);
		if(rtnInfo != null){
			return rtnInfo;
		}
		provinceId = Long.parseLong(pid);	
		String typeStr = bizInfo.get("type");
		rtnInfo = validateNumber(typeStr);
		if(rtnInfo != null){
			return rtnInfo;
		}
		Integer type = Integer.parseInt(typeStr);
		String currentPageStr = bizInfo.get("currentpage");		
		String pageSizeStr = bizInfo.get("pagesize");
		rtnInfo = validatePageInfo(currentPageStr, pageSizeStr);
		if(rtnInfo != null){
			return rtnInfo;
		}
		Integer currentPage = Integer.parseInt(currentPageStr);
		Integer pageSize = Integer.parseInt(pageSizeStr);
		rtnInfo = vaildateTrader(trader);
		if(rtnInfo == null){
			Page<HotPointNewVO> cou = promotionService.getAdvertisingPromotionVOByType(trader, provinceId, type, currentPage,pageSize);
			rtnInfo =  RtnInfo.RightWlRtnInfo(cou);
		 }	
		return rtnInfo;
	}
	
	/**
	 * Creates the rock game.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo createRockGame(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if(!isLogined){
				return RtnInfo.TokenErrWlRtnInfo();
			}
			PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
			Integer result = promotionService.createRockGame(context.getRequestInfo().getUserToken());
			RtnInfo	rtnInfo =  RtnInfo.RightWlRtnInfo(result);
			return rtnInfo;
		} catch (Exception e) {
			return null;
		}
		
	}
	
	/**
	 * Gets the rock game product vo.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rock game product vo
	 */
	public RtnInfo getRockGameProductVO(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
			String rockGameFlowID = bizInfo.get("rockgameflowid");
			if(StringUtil.isEmpty(rockGameFlowID)){
				return RtnInfo.ParameterErrRtnInfo("rockGameFlowID is null");
			}
			RockGameProductVO result = promotionService.getRockGameProductVO(Long.parseLong(rockGameFlowID));
			RtnInfo	rtnInfo =  RtnInfo.RightWlRtnInfo(result);
			return rtnInfo;
		} catch (Exception e) {
			return null;
		}
		
	}
	
	/**
	 * 老版本首页轮播图.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the home hot point list new
	 */
	public RtnInfo getHomeHotPointListNew(String urlPath, Boolean isLogined,
	                                      Map<String, String> bizInfo, AdapterContext context){
	    try {
	        Trader trader = getTraderFromContext(context);
	        RtnInfo rtnInfo = vaildateTrader(trader);
	        if(rtnInfo==null){
	            String provinceId = context.getRequestInfo().getProvinceId();
	            rtnInfo = validateProvinceId(provinceId);
	            if(rtnInfo==null){
	                String currentPage = bizInfo.get("currentpage");
	                String pageSize = bizInfo.get("pagesize"); 
	                rtnInfo = validatePageInfo(currentPage, pageSize);
	                if(rtnInfo==null){
	                    PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
	                    Page<HotPointNewVO> result = promotionService.getHomeHotPointListNew(trader, Long.valueOf(provinceId), Integer.valueOf(currentPage), Integer.valueOf(pageSize));
	                    rtnInfo =  RtnInfo.RightWlRtnInfo(result);
	                }
	            }
	        }
	        return rtnInfo;
        } catch (Exception e) {
            logger.error(" getHomeHotPointListNew has error ", e);
            return null;
        }
	}
	
	/**
	 * 老版本首页楼层.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the cms advertising promotion
	 */
	public RtnInfo getCmsAdvertisingPromotion(String urlPath, Boolean isLogined,
	                                          Map<String, String> bizInfo, AdapterContext context){
	    try {
            Trader trader = getTraderFromContext(context);
            RtnInfo rtnInfo = vaildateTrader(trader);
            if(rtnInfo==null){
            	
                String provinceId = context.getRequestInfo().getProvinceId();                
                rtnInfo = validateProvinceId(provinceId);
                if(rtnInfo==null){
                    String updateTag = bizInfo.get("updatetag");
                    PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();    
                    AdvertisingPromotion result = promotionService.getCmsAdvertisingPromotion(trader, Long.valueOf(provinceId), updateTag);
                    rtnInfo =  RtnInfo.RightWlRtnInfo(result);
                }
            }
            return rtnInfo;
        } catch (Exception e) {
            logger.error(" getCmsAdvertisingPromotion has error ", e);
            return null;
        }
	}
	
	/**
	 * 查询用户游戏.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rock game by token
	 */
	public RtnInfo getRockGameByToken(String urlPath, Boolean isLogined,
                                      Map<String, String> bizInfo, AdapterContext context){
	    try {
            if(isLogined){
                String type = bizInfo.get("type");
                RtnInfo rtnInfo = null;
                if(type==null||!type.matches(RegexEnum.PURE_DIGITAL.getRegex())){
                    rtnInfo = RtnInfo.ParameterErrRtnInfo("type has error ");
                }else{
                    PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();    
                    RockGameVO result = promotionService.getRockGameByToken(context.getRequestInfo().getUserToken(), Integer.valueOf(type));
                    rtnInfo =  RtnInfo.RightWlRtnInfo(result);
                }
                return rtnInfo;
            }else{
                return RtnInfo.TokenErrWlRtnInfo();
            }
        } catch (Exception e) {
            logger.error(" getRockGameByToken has error ", e);
            return null;
        }
	}
	
	   /**
   	 * 检查摇奖结果.
   	 *
   	 * @param urlPath the url path
   	 * @param isLogined the is logined
   	 * @param bizInfo the biz info
   	 * @param context the context
   	 * @return the rtn info
   	 */
    public RtnInfo checkRockResult(String urlPath, Boolean isLogined,
                                      Map<String, String> bizInfo, AdapterContext context){
        try {
            if(isLogined){
                Long productId = bizInfo.get("productid")==null ? 0l : Long.valueOf(bizInfo.get("productid"));
                String promotionId = bizInfo.get("promotionid");   
                String type = bizInfo.get("type");
                String couponActiveId = bizInfo.get("couponactiveid");
                RtnInfo rtnInfo = null;
        		String userIdStr = context.getCurrentUserId();
        		if(validateNumber(userIdStr)!=null){
        			return RtnInfo.ParameterErrRtnInfo("userid is error");
        		}
        		Long userId  = Long.parseLong(userIdStr);
                if(type==null||!type.matches(RegexEnum.PURE_DIGITAL.getRegex())){
                    rtnInfo = RtnInfo.ParameterErrRtnInfo("type is null");
                }else{
                    PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();    
                    CheckRockResultResult result = promotionService.checkRockResult(userId, productId, promotionId, Integer.valueOf(type), Long.valueOf(couponActiveId));
                    rtnInfo =  RtnInfo.RightWlRtnInfo(result);
                }
                return rtnInfo;
            }else{
                return RtnInfo.TokenErrWlRtnInfo();
            }
        } catch (Exception e) {
            logger.error(" getRockGameByToken has error ", e);
            return null;
        }
    }
    public RtnInfo getRockProductList(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(trader==null||trader.getTraderName()==null){
			return RtnInfo.ParameterErrRtnInfo("trader is null");			
		}
		
		String provinceId =context.getRequestInfo().getProvinceId();
		Result result = this.valiateGetParams(provinceId);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("provinceId "+result.getResultDesc());
		}
		String currentPage = bizInfo.get("currentpage");
		result = this.valiateGetParams(currentPage);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("currentPage "+result.getResultDesc());
		}
		String pageSize = bizInfo.get("pagesize");
		result = this.valiateGetParams(pageSize);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("pageSize "+result.getResultDesc());
		}		
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		Page<RockProductVO> page = promotionService.getRockProductList(trader,Long.parseLong(provinceId), Integer.parseInt(currentPage), Integer.parseInt(pageSize));
		return RtnInfo.RightWlRtnInfo(page);
	}
    
    public RtnInfo rockRock(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		if(trader==null||trader.getTraderName()==null){
			return RtnInfo.ParameterErrRtnInfo("trader is null");			
		}
		String ip = context.getRequestIp();
		if(StringUtil.isEmpty(ip)){
			return RtnInfo.ParameterErrRtnInfo("ip is null");
		}
		String provinceId =context.getRequestInfo().getProvinceId();
		Result result = this.valiateGetParams(provinceId);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("provinceId "+result.getResultDesc());
		}
		String promotionId = bizInfo.get("promotionid");
		if(promotionId==null||"".equals(promotionId)){
			return RtnInfo.ParameterErrRtnInfo("promotionId null");
		}		
		String productId = bizInfo.get("productid");
		result = this.valiateGetParams(productId);
		if(!result.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("productId "+result.getResultDesc());
		}		
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		String lng = bizInfo.get("lng");
		if(lng==null||"".equals(lng)){
			return RtnInfo.ParameterErrRtnInfo("lng is null");
		}
		String lat = bizInfo.get("lat");
		if(lat==null||"".equals(lat)){
			return RtnInfo.ParameterErrRtnInfo("lat "+result.getResultDesc());
		}
		String userIdStr = context.getCurrentUserId();
		if(validateNumber(userIdStr)!=null){
			return RtnInfo.ParameterErrRtnInfo("userid is error");
		}
		Long userId  = Long.parseLong(userIdStr);
		String str = promotionService.rockRock(trader, Long.parseLong(provinceId), promotionId, Long.parseLong(productId),Double.parseDouble(lng) , Double.parseDouble(lat), userId);
		return RtnInfo.RightWlRtnInfo(str);
	}
    
    public RtnInfo isCanInviteeUser(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		Trader trader = getTraderFromContext(context);
		if(trader==null||trader.getTraderName()==null){
			return RtnInfo.ParameterErrRtnInfo("trader is null");			
		}
		String phoneNum = bizInfo.get("phonenum");
		PromotionService promotionService = CentralMobileServiceHandler.getPromotionService();
		InviteeResult re = promotionService.isCanInviteeUser(trader, phoneNum);
		return RtnInfo.RightWlRtnInfo(re);
	}
    
}
