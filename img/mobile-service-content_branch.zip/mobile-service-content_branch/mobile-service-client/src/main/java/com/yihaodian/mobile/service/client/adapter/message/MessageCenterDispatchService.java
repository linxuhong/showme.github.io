/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.message;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.domain.business.emuns.BusinessResultCode;
import com.yihaodian.mobile.service.facade.business.message.MessageCenterService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * 消息中心拦截service.
 *
 * @author zhangwei5
 * @version $Id: MessageCenterDispatchService.java, v 0.1 2014年8月12日 下午2:29:34
 *          zhangwei5 Exp $
 */
public class MessageCenterDispatchService extends BaseDiapatchService {

	/** The logger. */
	private static Logger logger = Logger
			.getLogger(MessageCenterDispatchService.class);

	/**
	 * 用户未读消息数量.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the no read count with user id
	 */
	public RtnInfo getNoReadCountWithUserId(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (isLogined) {
				// 得到订单Id
				String isReadStr = bizInfo.get("isread");
				Result result = validateGetNoReadCountWithUserId(isReadStr);
				if(!result.isSuccess()){
					return RtnInfo.ParameterErrRtnInfo("isReadStr"+result.getResultDesc());
				}
				result = valiateGetParams(context.getCurrentUserId());
				if(!result.isSuccess()){
					return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
				}
				Long userId = Long.parseLong(context.getCurrentUserId());
				if (result.isSuccess()) {
					MessageCenterService messageCenterService = CentralMobileServiceHandler
							.getMessageCenterService();
					result = messageCenterService.getNoReadCountWithUserId(userId,Integer.valueOf(isReadStr));
				}
				return getRtnInfo(result);
			} else {
				return RtnInfo.TokenErrWlRtnInfo();
			}
		} catch (Exception e) {
			logger.error("getNoReadCountWithUserId has error ", e);
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}

	/**
	 * Gets the f mess type sub status.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the f mess type sub status
	 */
	public RtnInfo getFMessTypeSubStatus(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (isLogined) {
				Result result = valiateGetParams(context.getCurrentUserId());
				if(!result.isSuccess()){
					return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
				}
				Long userId = Long.parseLong(context.getCurrentUserId());
				
				MessageCenterService messageCenterService = CentralMobileServiceHandler
						.getMessageCenterService();
				result = messageCenterService
						.getFMessTypeSubStatus(userId);
				return getRtnInfo(result);
			} else {
				return RtnInfo.TokenErrWlRtnInfo();
			}
		} catch (Exception e) {
			logger.error("getFMessTypeSubStatus has error ", e);
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}

	/**
	 * Gets the messages with m src.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the messages with m src
	 */
	public RtnInfo getMessagesWithMSrc(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {

		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());

			Integer size = bizInfo.get("size") == null ? 1 : Integer
					.valueOf(bizInfo.get("size"));
			Integer startIndex = bizInfo.get("startindex") == null ? 1
					: Integer.valueOf(bizInfo.get("startindex"));
			Integer platform = bizInfo.get("platform") == null ? 1 : Integer
					.valueOf(bizInfo.get("platform"));
			Long messageType = Long.valueOf(bizInfo.get("messagetype"));

			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			result = service.getMessagesWithMSrc(userId, messageType, startIndex, size, platform);
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}

	}

	/**
	 * Update message is read.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo updateMessageISRead(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}

			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			Long messageId = Long.valueOf(bizInfo.get("messageid"));

			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			result = service.updateMessageISRead(userId, messageId);
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}

	}

	/**
	 * Delete multi messsage.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo deleteMultiMesssage(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {

		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}

			String ids = bizInfo.get("messageids");
			if (ids == null || ids.isEmpty()) {
				return RtnInfo.ParameterErrRtnInfo("messageids is empty");
			}

			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			List<Long> messageList = (List<Long>) new Gson().fromJson(ids,
					new TypeToken<List<Long>>() {
					}.getType());
			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			 result = service.deleteMultiMesssage(userId, messageList);
			return getRtnInfo(result);
		} catch (JsonSyntaxException e) {
			return RtnInfo
					.ParameterErrRtnInfo("parse messageids JsonSyntaxException");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}

	/**
	 * Validate get no read count with user id.
	 *
	 * @param isReadStr the is read str
	 * @return the result
	 */
	private Result validateGetNoReadCountWithUserId(String isReadStr) {
		Result result = new ResultModel();
		result.setSuccess(true);
		try {
			if (StringUtil.isBlank(isReadStr)
					|| !isReadStr.matches(RegexEnum.PURE_DIGITAL.getRegex())) {
				result.setSuccess(false);
				result.setBaseResultCode(BusinessResultCode.MESSAGE_CENTER_IS_READ_PARAMTER_ERROR);
			}
			return result;
		} catch (Exception e) {
			logger.error("getNoReadCountWithUserId has error ", e);
			return getSystemErrorResult();
		}
	}

	/**
	 * Delete single messsage.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo deleteSingleMesssage(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}

			Long messageId = Long.valueOf(bizInfo.get("messageid"));
			
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());

			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			result = service.deleteSingleMesssage(userId, messageId);
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}

	}
	
	/**
	 * Update message is read with mess t.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo updateMessageISReadWithMessT(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());

			Long messageType = Long.valueOf(bizInfo.get("messagetype"));

			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			result = service.updateMessageISReadWithMessT(userId, messageType);
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}

	}
	
	/**
	 * Gets the messages with user id.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the messages with user id
	 */
	public RtnInfo getMessagesWithUserId(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}

			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			Integer startIndex = Integer.valueOf(bizInfo.get("startindex"));
			Integer size = Integer.valueOf(bizInfo.get("size"));

			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			result  = service.getMessagesWithUserId(userId, startIndex, size);
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}

	}
	
	
	public RtnInfo getNoReadMessageF(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			result  = service.getNoReadMessageF(userId);
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}
	
	public RtnInfo updateSubStatusWithFiType(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			String firstCateType = bizInfo.get("firstcatetype");			
			if(firstCateType==null||"".equals(firstCateType)){
				return RtnInfo.ParameterErrRtnInfo("firstcatetype null");
			}
			RtnInfo rtn=validateNumber(firstCateType);
			if(rtn!=null){
				return rtn;
			}
			result  = service.updateSubStatusWithFiType(userId,Long.parseLong(firstCateType));
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}
	
	public RtnInfo updateUnSubStatusWithFiType(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			String firstCateType = bizInfo.get("firstcatetype");			
			if(firstCateType==null||"".equals(firstCateType)){
				return RtnInfo.ParameterErrRtnInfo("firstcatetype null");
			}
			RtnInfo rtn=validateNumber(firstCateType);
			if(rtn!=null){
				return rtn;
			}
			result = service.updateUnSubStatusWithFiType(userId,Long.parseLong(firstCateType));
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}
	
	public RtnInfo deleteMesssaageWithMType(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			String messageType = bizInfo.get("messagetype");			
			if(messageType==null||"".equals(messageType)){
				return RtnInfo.ParameterErrRtnInfo("messageType null");
			}
			RtnInfo rtn=validateNumber(messageType);
			if(rtn!=null){
				return rtn;
			}
			result = service.deleteMesssaageWithMType(userId,Long.parseLong(messageType));
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}
	
	public RtnInfo getMessageCatelogByParent(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();					
		
			Result re = service.getMessageCatelogByParent();
			return getRtnInfo(re);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}
	
	public RtnInfo isUserSubscribeBatch(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			String cateIds = bizInfo.get("cateids");			
			if(cateIds==null||"".equals(cateIds)){
				return RtnInfo.ParameterErrRtnInfo("messageType null");
			}
			List<Long> cateIdlist =(List<Long>) GsonUtil.paseToObject(cateIds, new TypeToken<List<String>>(){}.getType());
			result = service.isUserSubscribeBatch(userId,cateIdlist);
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}
	
	public RtnInfo subscribeMessage(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			
			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			String cateId = bizInfo.get("cateid");			
			if(cateId==null||"".equals(cateId)){
				return RtnInfo.ParameterErrRtnInfo("cateid null");
			}
			RtnInfo rtn=validateNumber(cateId);
			if(rtn!=null){
				return rtn;
			}
			result = service.subscribeMessage(userId,Long.parseLong(cateId));
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}
	
	public RtnInfo unsubscribeMessage(String urlPath, Boolean isLogined,
			Map<String, String> bizInfo, AdapterContext context) {
		try {
			if (!isLogined) {
				return RtnInfo.TokenErrWlRtnInfo();
			}
			Result result = valiateGetParams(context.getCurrentUserId());
			if(!result.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+result.getResultDesc());
			}
			Long userId = Long.parseLong(context.getCurrentUserId());
			
			MessageCenterService service = CentralMobileServiceHandler
					.getMessageCenterService();
			String cateId = bizInfo.get("cateid");			
			if(cateId==null||"".equals(cateId)){
				return RtnInfo.ParameterErrRtnInfo("cateId null");
			}
			RtnInfo rtn=validateNumber(cateId);
			if(rtn!=null){
				return rtn;
			}
			result  = service.unsubscribeMessage(userId,Long.parseLong(cateId));
			return getRtnInfo(result);
		} catch (NumberFormatException e) {
			return RtnInfo.ParameterErrRtnInfo("number param format error");
		} catch (Exception e2) {
			return RtnInfo.ParameterErrRtnInfo("some param null");
		}
	}
}
