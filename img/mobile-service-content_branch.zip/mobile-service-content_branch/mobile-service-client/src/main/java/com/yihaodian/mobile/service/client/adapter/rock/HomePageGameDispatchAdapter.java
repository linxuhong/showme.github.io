/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.rock;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.homegame.HomePageGameService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class HomePageGameDispatchAdapter.
 */
public class HomePageGameDispatchAdapter extends BaseDiapatchService {
	

	/**
	 * 
	 * Do shaking.
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo doShaking(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		HomePageGameService service = CentralMobileServiceHandler.getHomePageGameClientService();
		
		//游戏ID
		String strGameId = bizInfo.get("gameid");
		RtnInfo rtn = validateNumber(strGameId);
		if (rtn != null) {
			rtn.setRtn_msg("gameId must be number.");
			return rtn;
		}
		Long gameId = Long.valueOf(strGameId);
		
		//用户ID
		String strUserId = context.getCurrentUserId();
		rtn = validateNumber(strUserId);
		if(rtn!=null){
			rtn.setRtn_msg("userId must be number.");
			return rtn;
		}
		Long userId  = Long.parseLong(strUserId);
		
		//游戏场次ID
		String strBatchId = bizInfo.get("batchid");
		rtn = validateNumber(strBatchId);
		if (rtn != null) {
			rtn.setRtn_msg("batchId must be number.");
			return rtn;
		}
		Long batchId = Long.valueOf(strBatchId);
		
		//红包数量
		String strRedPacketNum = bizInfo.get("redpacketnum");
		rtn = validateNumber(strRedPacketNum);
		if (rtn != null) {
			rtn.setRtn_msg("redPacketNum must be number.");
			return rtn;
		}
		Integer redPacketNum = Integer.valueOf(strRedPacketNum);
		
		String traderName  = context.getRequestInfo().getClientInfo().getTraderName();
		String deviceToken = context.getRequestInfo().getClientInfo().getDeviceCode();
		
		Result result = service.doShaking(getTraderFromContext(context), gameId, userId, batchId, redPacketNum, traderName, deviceToken);
		return getRtnInfo(result);
	}
	
	/**
	 * 
	 * redIsReady.
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo redIsReady(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		HomePageGameService service = CentralMobileServiceHandler.getHomePageGameClientService();
		
		//游戏ID
		String strGameId = bizInfo.get("gameid");
		RtnInfo rtn = validateNumber(strGameId);
		if (rtn != null) {
			rtn.setRtn_msg("gameId must be number.");
			return rtn;
		}
		Long gameId = Long.valueOf(strGameId);
		
//		//用户ID
//		String strUserId = context.getCurrentUserId();
//		rtn = validateNumber(strUserId);
//		if(rtn!=null){
//			rtn.setRtn_msg("userId must be number.");
//			return rtn;
//		}
//		Long userId  = Long.parseLong(strUserId);
		
		//游戏场次ID
		String strBatchId = bizInfo.get("batchid");
		rtn = validateNumber(strBatchId);
		if (rtn != null) {
			rtn.setRtn_msg("batchId must be number.");
			return rtn;
		}
		Long batchId = Long.valueOf(strBatchId);
		
		
		Result result = service.redIsReady(gameId, batchId, null);
		return getRtnInfo(result);
	}
	
	
	/**
	 * 
	 * 摇奖：红包数通过混淆
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	@Deprecated
	public RtnInfo doShaking2(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		HomePageGameService service = CentralMobileServiceHandler.getHomePageGameClientService();
		
		//游戏ID
		String strGameId = bizInfo.get("gameid");
		RtnInfo rtn = validateNumber(strGameId);
		if (rtn != null) {
			rtn.setRtn_msg("gameId must be number.");
			return rtn;
		}
		Long gameId = Long.valueOf(strGameId);
		
		//用户ID
		String strUserId = context.getCurrentUserId();
		rtn = validateNumber(strUserId);
		if(rtn!=null){
			rtn.setRtn_msg("userId must be number.");
			return rtn;
		}
		Long userId  = Long.parseLong(strUserId);
		
		//游戏场次ID
		String strBatchId = bizInfo.get("batchid");
		rtn = validateNumber(strBatchId);
		if (rtn != null) {
			rtn.setRtn_msg("batchId must be number.");
			return rtn;
		}
		Long batchId = Long.valueOf(strBatchId);
		
		//红包数量
		String strRedPacketNum = bizInfo.get("redpacketnum");
//		rtn = validateNumber(strRedPacketNum);
//		if (rtn != null) {
//			rtn.setRtn_msg("redPacketNum must be number.");
//			return rtn;
//		}
		if (StringUtil.isBlank(strRedPacketNum)) {
			rtn = RtnInfo.ParameterErrRtnInfo("redPacketNum must be required.");
			return rtn;
        }
		Integer redPacketNum = null;
		try {
			redPacketNum = Integer.valueOf(strRedPacketNum);
		} catch (Exception e) {
			rtn = RtnInfo.ParameterErrRtnInfo("redPacketNum must be number.");
			return rtn;
		}
		if(redPacketNum==null){
			rtn = RtnInfo.ParameterErrRtnInfo("redPacketNum must be number.");
			return rtn;
		}
		
		//还原混淆的红包
		String timestampStr = bizInfo.get("timestamp");
		rtn = validateNumber(timestampStr);
		if (rtn != null) {
			rtn.setRtn_msg("timestamp must be number.");
			return rtn;
		}
		
		String traderName  = context.getRequestInfo().getClientInfo().getTraderName();
		String deviceToken = context.getRequestInfo().getClientInfo().getDeviceCode();
		
		//人机交互输入
		String hcitoken = bizInfo.get("hcitoken");
		if(StringUtils.isBlank(hcitoken)){
			rtn = RtnInfo.ParameterErrRtnInfo("hcitoken is null"); 	
			return rtn;
		}
		
		String userIp = context.getRequestIp();
//		String uid = null;
//		if (isLogined) {
//			uid = context.getCurrentUserId();
//		}
//		
//		String guid = null;
//		ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
//		if(clientInfoVO!=null){
//			guid = clientInfoVO.getDeviceCode();
//		}
		Result result = service.doShaking2(getTraderFromContext(context), gameId, userId, batchId, redPacketNum, traderName, deviceToken,Long.valueOf(timestampStr),hcitoken,userIp);
		return getRtnInfo(result);
	}
	
	/**
	 * 
	 * 摇奖：红包数通过混淆:fixed 加密
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo doShaking3(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context) {
		
		HomePageGameService service = CentralMobileServiceHandler.getHomePageGameClientService();
		
		//游戏ID
		String strGameId = bizInfo.get("gameid");
		RtnInfo rtn = validateNumber(strGameId);
		if (rtn != null) {
			rtn.setRtn_msg("gameId must be number.");
			return rtn;
		}
		Long gameId = Long.valueOf(strGameId);
		
		//用户ID
		String strUserId = context.getCurrentUserId();
		rtn = validateNumber(strUserId);
		if(rtn!=null){
			rtn.setRtn_msg("userId must be number.");
			return rtn;
		}
		Long userId  = Long.parseLong(strUserId);
		
		//游戏场次ID
		String strBatchId = bizInfo.get("batchid");
		rtn = validateNumber(strBatchId);
		if (rtn != null) {
			rtn.setRtn_msg("batchId must be number.");
			return rtn;
		}
		Long batchId = Long.valueOf(strBatchId);
		
		//红包数量
		String strRedPacketNum = bizInfo.get("redpacketnum");
//		rtn = validateNumber(strRedPacketNum);
//		if (rtn != null) {
//			rtn.setRtn_msg("redPacketNum must be number.");
//			return rtn;
//		}
		if (StringUtil.isBlank(strRedPacketNum)) {
			rtn = RtnInfo.ParameterErrRtnInfo("redPacketNum must be required.");
			return rtn;
        }
		Integer redPacketNum = null;
		try {
			redPacketNum = Integer.valueOf(strRedPacketNum);
		} catch (Exception e) {
			rtn = RtnInfo.ParameterErrRtnInfo("redPacketNum must be number.");
			return rtn;
		}
		if(redPacketNum==null){
			rtn = RtnInfo.ParameterErrRtnInfo("redPacketNum must be number.");
			return rtn;
		}
		
		//还原混淆的红包
		String timestampStr = bizInfo.get("timestamp");
		rtn = validateNumber(timestampStr);
		if (rtn != null) {
			rtn.setRtn_msg("timestamp must be number.");
			return rtn;
		}
				
		String tstamp = bizInfo.get("tstamp");
		rtn = validateNumber(tstamp);
		if (rtn != null) {
			rtn.setRtn_msg("tstamp must be number.");
			return rtn;
		}
		
		String traderName  = context.getRequestInfo().getClientInfo().getTraderName();
		String deviceToken = context.getRequestInfo().getClientInfo().getDeviceCode();
		
		//人机交互输入
		String hcitoken = bizInfo.get("hcitoken");
		if(StringUtils.isBlank(hcitoken)){
			rtn = RtnInfo.ParameterErrRtnInfo("hcitoken is null"); 	
			return rtn;
		}
		
		String userIp = context.getRequestIp();
//		String uid = null;
//		if (isLogined) {
//			uid = context.getCurrentUserId();
//		}
//		
//		String guid = null;
//		ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
//		if(clientInfoVO!=null){
//			guid = clientInfoVO.getDeviceCode();
//		}
		Result result = service.doShaking3(getTraderFromContext(context), gameId, userId, batchId, redPacketNum, traderName, deviceToken,Long.valueOf(timestampStr),Long.valueOf(tstamp),hcitoken,userIp);
		return getRtnInfo(result);
	}
}
