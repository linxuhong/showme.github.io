/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.advertisement.IPrecisionHomePageService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class PrecisionHomePageAd.
 * @author zuodeng
 */
public class PrecisionHomePageAd extends BaseDiapatchService{
	
	/**
	 * Gets the precision home page ad v2.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the precision home page ad v2
	 */
	public RtnInfo getPrecisionHomePageADV3(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String interfaceVersion = bizInfo.get("interfaceversion");
		String cityid = bizInfo.get("cityid");
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = service.getPrecisionHomePageADV4(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Integer.valueOf(context.getRequestInfo().getProvinceId()), userId,interfaceVersion,cityid);
		return getRtnInfo(result);
	}
	
	/**
	 * Gets home page products.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the precision home page products
	 */
	public RtnInfo getHomePageProduct(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String currentPage=bizInfo.get("currentpage");
		String pageSize=bizInfo.get("pagesize");
		rtnInfo = validatePageInfo(currentPage, pageSize);
		if(rtnInfo != null){
			return rtnInfo;
		}
		String version = urlPath.substring(urlPath.lastIndexOf("/")+1);
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = null;
		if("v4.1".equalsIgnoreCase(version)){
			result = service.getHomePageproductsNew(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Integer.valueOf(context.getRequestInfo().getProvinceId()), userId,Integer.parseInt(currentPage),Integer.parseInt(pageSize));
		}else{
			result = service.getHomePageproducts(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Integer.valueOf(context.getRequestInfo().getProvinceId()), userId,Integer.parseInt(currentPage),Integer.parseInt(pageSize));
		}
		return getRtnInfo(result);
	}
	
	public RtnInfo getHomePageGuessUlikeProducts(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String productIds=bizInfo.get("productids");
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = null;
		ClientInfoVO clientVo = convertClientInfoVO(context.getRequestInfo().getClientInfo());
		clientVo.setCityId(context.getRequestInfo().getCityId());
        result = service.getHomePageGuessUlikeProducts(clientVo, Integer.valueOf(context.getRequestInfo().getProvinceId()), userId,productIds);
		return getRtnInfo(result);
	}
	
	public RtnInfo getHomePageColumnProducts(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = null;
		result = service.getHomePageColumnProducts(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Integer.valueOf(context.getRequestInfo().getProvinceId()), userId);
		return getRtnInfo(result);
	}
	
	/**
	 * 获取“猜你喜欢”栏位下的促销专题
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getPromoteSpecialTopic(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		String userId = null;
		if (isLogined) {
			userId = context.getCurrentUserId();
		}
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String cityId = bizInfo.get("cityid");
		rtnInfo = validateNumber(cityId);
		if(rtnInfo != null){
			return rtnInfo;
		}
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = service.getPromoteSpecialTopic(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Long.valueOf(context.getRequestInfo().getProvinceId()), Long.valueOf(cityId), userId);
		return getRtnInfo(result);
	}

	/**
	 * Gets the precision home page products.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the precision home page products
	 */
	public RtnInfo getPrecisionHomePageProducts(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String currentPage=bizInfo.get("currentpage");
		String pageSize=bizInfo.get("pagesize");
		rtnInfo = validatePageInfo(currentPage, pageSize);
		if(rtnInfo != null){
			return rtnInfo;
		}
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = service.getPrecisionHomePageProducts(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Integer.valueOf(context.getRequestInfo().getProvinceId()), userId,Integer.parseInt(currentPage),Integer.parseInt(pageSize));
		return getRtnInfo(result);
	}
	
	/**
	 * 客户端二维码扫描URL转换
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo switchToLocalUrl(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		String url=bizInfo.get("url");
		if(StringUtil.isBlank(url)){
			return RtnInfo.ParameterErrRtnInfo("url is null");
		}
		String merchantName = bizInfo.get("merchantname");
		String merchantId = bizInfo.get("merchantid");
		Long mId = null;
		if(StringUtil.isNotBlank(merchantId)){
			 if (!merchantId.matches(RegexEnum.PURE_DIGITAL.getRegex())) {
			     return RtnInfo.ParameterErrRtnInfo("merchantId 有误");
			 }else{
				 mId = Long.parseLong(merchantId);
			 }
		}
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = service.switchToLocalUrl(convertClientInfoVO(context.getRequestInfo().getClientInfo()),url, merchantName, mId);
		return getRtnInfo(result);
		
	}
	
	/**
	 * 剁手价
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 */
	public RtnInfo doushouProduct(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
	    
	    Long userId = null;
        if (isLogined) {
            userId = Long.parseLong(context.getCurrentUserId());
        }
        ClientInfoVO clientInfoVO = convertClientInfoVO(context.getRequestInfo().getClientInfo());
        clientInfoVO.setCityId(context.getRequestInfo().getCityId());
        clientInfoVO.setProvinceId(context.getRequestInfo().getProvinceId());
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = service.doushouProduct(clientInfoVO, Integer.valueOf(context.getRequestInfo().getProvinceId()),userId);
		return getRtnInfo(result);
		
	}
	
	public RtnInfo getHomeRecommendProducts(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = service.getHomeRecommendProducts(convertClientInfoVO(context.getRequestInfo().getClientInfo()), Integer.valueOf(context.getRequestInfo().getProvinceId()), userId);
		return getRtnInfo(result);
	}
	/**
	 * 首页公告
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getAnnouncements(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String provinceId = context.getRequestInfo().getProvinceId();
		rtnInfo = validateNumber(provinceId);
		if(rtnInfo != null){
			return rtnInfo;
		}
		Long userId = null;
		if (isLogined) {
			userId = Long.parseLong(context.getCurrentUserId());
		}
		String pageId = bizInfo.get("pageid");
		String seatType = bizInfo.get("seattype");
		
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = service.getAnnouncements(convertClientInfoVO(context.getRequestInfo().getClientInfo(), provinceId, context.getRequestInfo().getCityId()),provinceId,seatType,pageId,userId );
		return getRtnInfo(result);
	}
	
	/**
	 * 判断精选城市
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return
	 */
	public RtnInfo getChoicenessCity(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		RtnInfo rtnInfo = validateNumber(context.getRequestInfo().getProvinceId());
		if(rtnInfo != null){
			return rtnInfo;
		}
		String provinceId = context.getRequestInfo().getProvinceId();
		rtnInfo = validateNumber(provinceId);
		if(rtnInfo != null){
			return rtnInfo;
		}
		
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		Result result = service.getChoicenessCity(convertClientInfoVO(context.getRequestInfo().getClientInfo(), provinceId, context.getRequestInfo().getCityId()));
		return getRtnInfo(result);
	}
	
	/**
	 * 
	 * @Description: 获得团购倒计时
	 * @author zhuchao1
	 * @date 2015年12月15日 下午3:39:51
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return 
	 */
	public RtnInfo getActivityTime(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		String provinceId = context.getRequestInfo().getProvinceId();
		RtnInfo rtnInfo = validateNumber(provinceId);
		if(rtnInfo != null){
			return rtnInfo;
		}
		Long time = service.getActivityTime(provinceId);
		Map<String,Long> result = new HashMap<String, Long>();
		result.put("activityTime", time);
		return RtnInfo.RightWlRtnInfo(result);
	}
	
	/**
	 * 
	 * @Description: 获取2天内的倒计时，当请求时，将已过期的置为-1
	 * @author wulibing
	 * @param urlPath
	 * @param isLogined
	 * @param bizInfo
	 * @param context
	 * @return 
	 */
	public RtnInfo getActivityTimeV2(String urlPath, Boolean isLogined, Map<String, String> bizInfo, 
			AdapterContext context){
		IPrecisionHomePageService service = CentralMobileServiceHandler.getPrecisionHomePageADClientService();
		String provinceId = context.getRequestInfo().getProvinceId();
		RtnInfo rtnInfo = validateNumber(provinceId);
		if(rtnInfo != null){
			return rtnInfo;
		}
		List<Long> times = service.getActivityTimeV2(provinceId);
		Map<String,List<Long>> result = new HashMap<String, List<Long>>();
		result.put("activityTime", times);
		return RtnInfo.RightWlRtnInfo(result);
	}
}
