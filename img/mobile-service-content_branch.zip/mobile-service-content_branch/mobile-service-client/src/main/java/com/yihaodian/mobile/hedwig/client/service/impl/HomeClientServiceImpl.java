package com.yihaodian.mobile.hedwig.client.service.impl;

import java.util.List;

import com.yihaodian.mobile.service.hedwig.core.service.spi.HomeService;
import com.yihaodian.mobile.vo.bussiness.FacetValue;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.home.HomeModuleVO;
import com.yihaodian.mobile.vo.home.HomeSelectionVO;
import com.yihaodian.mobile.vo.home.QualityAppVO;

public class HomeClientServiceImpl implements HomeService {

	private HomeService homeHessiancall ;
	@Override
	public Page<HomeSelectionVO> getHomeSelection(Trader trader,
			Long provinceId, Integer currentPage, Integer pageSize) {
		return homeHessiancall.getHomeSelection(trader, provinceId, currentPage, pageSize);
	}

	@Override
	public List<FacetValue> getHomeHotElement(Trader trader, int type) {
		
		return homeHessiancall.getHomeHotElement(trader, type);
	}

	@Override
	public List<HomeModuleVO> getHomeModuleList(Trader trader) {
		
		return homeHessiancall.getHomeModuleList(trader);
	}

	@Override
	public Page<QualityAppVO> getQualityAppList(Trader trader,
			Integer currentPage, Integer pageSize) {
		
		return homeHessiancall.getQualityAppList(trader, currentPage, pageSize);
	}

	public HomeService getHomeHessiancall() {
		return homeHessiancall;
	}

	public void setHomeHessiancall(HomeService homeHessiancall) {
		this.homeHessiancall = homeHessiancall;
	}
}
