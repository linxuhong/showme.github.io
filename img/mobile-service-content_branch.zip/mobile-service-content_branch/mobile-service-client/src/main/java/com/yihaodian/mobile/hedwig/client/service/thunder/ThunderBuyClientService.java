package com.yihaodian.mobile.hedwig.client.service.thunder;

import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.thunder.ThunderBuyService;
import com.yihaodian.mobile.vo.thunder.MobileProductVO;

public class ThunderBuyClientService implements ThunderBuyService {

	private ThunderBuyService thunderBuyHessianCall;
	
	public ThunderBuyService getThunderBuyHessianCall() {
		return thunderBuyHessianCall;
	}

	public void setThunderBuyHessianCall(ThunderBuyService thunderBuyHessianCall) {
		this.thunderBuyHessianCall = thunderBuyHessianCall;
	}

	@Override
	public Result getThunderHomeBannerAndDes(Long provinceId) {
		return thunderBuyHessianCall.getThunderHomeBannerAndDes(provinceId);
	}

	@Override
	public Result getThunderProvinceInfo(String provinceName, String cityName,
			String areaName, String streetName) {
		return thunderBuyHessianCall.getThunderProvinceInfo(provinceName, cityName, areaName, streetName);
	}

	@Override
	public Result arrivalReminding(Long provinceId, Long pmId, Long userId, Boolean isReminding) {
		return thunderBuyHessianCall.arrivalReminding(provinceId, pmId, userId, isReminding);
	}

	@Override
	public Result getThunderCategory(Long provinceId) {
		return thunderBuyHessianCall.getThunderCategory(provinceId);
	}
	
	@Override
	public Result getProductsByCategoryIds(List<Long> categoryIds,
			Long provinceId, Integer size, Long userId) {
		return thunderBuyHessianCall.getProductsByCategoryIds(categoryIds, provinceId, size, userId);
	}

	@Override
	public Result getProductsByCategoryId(Long categoryId, Long provinceId, Long userId) {
		return thunderBuyHessianCall.getProductsByCategoryId(categoryId, provinceId, userId);
	}
	
	@Override
	public Result getProductsByProvinceId(Long provinceId, Long userId) {
		return thunderBuyHessianCall.getProductsByProvinceId(provinceId, userId);
	}
	
	@Override
	public Result validateThunderOrder(Long userId,Long rayBuyActiveId,Double amount,List<MobileProductVO> productIds) {
		return thunderBuyHessianCall.validateThunderOrder(userId,rayBuyActiveId,amount,productIds);
	}

	@Override
	public Result getStockNumByPminfoAndProvince(Long pmId, Long provinceId) {
		return thunderBuyHessianCall.getStockNumByPminfoAndProvince(pmId, provinceId);
	}

	@Override
	public Result checkStockNumByPminfoAndProvince(Map<Long, Long> map,	Long provinceId) {
		return thunderBuyHessianCall.checkStockNumByPminfoAndProvince(map, provinceId);
	}

	@Override
	public Result getProductStatusByProductIds(Long provinceId,
			List<Long> productIds) {
		return thunderBuyHessianCall.getProductStatusByProductIds(provinceId, productIds);
	}

	@Override
	public Result getProductInfoByProductIds(Long provinceId,
			List<Long> productIds) {
		return thunderBuyHessianCall.getProductInfoByProductIds(provinceId, productIds);
	}

    @Override
    public String getProPromotionDate(Long merchantId, Long productId) {
        return thunderBuyHessianCall.getProPromotionDate(merchantId, productId);
    }
 
	@Override
	public Result getNativeThunderProvinceInfo(String provinceName,
			String cityName, String areaName, String streetName,Long provinceId) {
		return thunderBuyHessianCall.getNativeThunderProvinceInfo(provinceName, cityName, areaName, streetName,provinceId);
	}

	@Override
	public Result getNativeThunderMerchantInfo(Double lng,
			Double lat, String cellId, Long currentPage) {
		return thunderBuyHessianCall.getNativeThunderMerchantInfo(lng, lat, cellId, currentPage);
	}

	@Override
	public Result getAddressListByKeyword(String keywords, String location, String city) {
		return thunderBuyHessianCall.getAddressListByKeyword(keywords, location, city);
	}

	@Override
	public Result getNativeThunderShopInfo(Long provinceId) {
		return thunderBuyHessianCall.getNativeThunderShopInfo(provinceId);
	}
 
	@Override
	public Result getNativeThunderBanner(String traderName, Long userId,
			Long blockId) {
		return thunderBuyHessianCall.getNativeThunderBanner(traderName, userId, blockId);
	}

	@Override
	public Result getNativeThunderIndexInfo(String traderName,Long userId,Long blockId,Long vProvinceId) {
		return thunderBuyHessianCall.getNativeThunderIndexInfo(traderName, userId, blockId, vProvinceId);
	}

	@Override
	public Result getPmIdsByProvinceIds(Long provinceId) {
		return thunderBuyHessianCall.getPmIdsByProvinceIds(provinceId);
	}

	@Override
	public Result getNativeThunderUserInfo(Long userId) {
		return thunderBuyHessianCall.getNativeThunderUserInfo(userId);
	}

	@Override
	public Result getPmidsForProducts(List<Long> productIds, Long provinceId) {
		return thunderBuyHessianCall.getPmidsForProducts(productIds, provinceId);
	}
}
