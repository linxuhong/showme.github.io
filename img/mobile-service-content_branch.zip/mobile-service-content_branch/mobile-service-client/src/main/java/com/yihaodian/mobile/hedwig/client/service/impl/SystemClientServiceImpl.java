package com.yihaodian.mobile.hedwig.client.service.impl;

import java.util.List;

import com.yihaodian.mobile.service.facade.business.system.SystemService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.system.AppFunctionSwitchVO;
import com.yihaodian.mobile.vo.system.DownloadVO;
import com.yihaodian.mobile.vo.system.ShowControlVO;
import com.yihaodian.mobile.vo.system.StartupPicVO;
import com.yihaodian.mobile.vo.system.StartupPictureVO;

public class SystemClientServiceImpl implements SystemService{

	private SystemService systemServiceHessianCall ;
	@Override
	public Long getServerTimeStamp(Trader trader) {
		return systemServiceHessianCall.getServerTimeStamp(trader);
	}

	public SystemService getSystemServiceHessianCall() {
		return systemServiceHessianCall;
	}

	@Override
	public DownloadVO getClientApplicationDownloadUrl(Trader trader) {
		return systemServiceHessianCall.getClientApplicationDownloadUrl(trader);
	}

	@Override
    public DownloadVO getClientApplicationDownloadUrl(Trader trader, ClientInfoVO clientInfoVO) {
	    return systemServiceHessianCall.getClientApplicationDownloadUrl(trader,clientInfoVO);
    }

    @Override
	public Integer registerLaunchInfo(Trader trader, String iMei, String phoneNo) {
		return systemServiceHessianCall.registerLaunchInfo(trader, iMei, phoneNo);
	}

	@Override
	public String getProductQRcode(Trader trader, String qrCodeText,
			Long productId, Integer imageSize) {
		return null;
	}


	@Override
	public List<StartupPicVO> getStartupPicVOList(Trader trader, String size,
			Long siteType) {
		return systemServiceHessianCall.getStartupPicVOList(trader, size, siteType);
	}

	@Override
	public StartupPictureVO getStartupPicture(Trader trader, String size,
			Boolean getTrimed,String cityId) {
		return null;
	}

	@Override
	public List<AppFunctionSwitchVO> getAppFunctionSwitch(Trader trader) {
		return systemServiceHessianCall.getAppFunctionSwitch(trader);
	}
	
	@Override
	public List<AppFunctionSwitchVO> getEnSwitches(Trader trader) {
		return systemServiceHessianCall.getEnSwitches(trader);
	}

    public void setSystemServiceHessianCall(SystemService systemServiceHessianCall) {
        this.systemServiceHessianCall = systemServiceHessianCall;
    }

	@Override
	public ShowControlVO getAppShowControl(Trader trader) {
		return systemServiceHessianCall.getAppShowControl(trader);
	}

	@Override
	public Integer registerLaunchInfo(Trader trader, String iMei,
			String phoneNo, String ip) {
		return systemServiceHessianCall.registerLaunchInfo(trader, iMei, phoneNo, ip);
	}
}
