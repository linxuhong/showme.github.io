package com.yihaodian.mobile.hedwig.client.impl.wl2;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.wl2.spi.IWl2Service;
import com.yihaodian.mobile.vo.wl2.ClientInfo;

public class Wl2ServiceClientServiceImpl implements IWl2Service {
	
	private IWl2Service wl2HessianCall;

	@Override
	public Result getSecretKeyByPlat(String plat, String keyIndex) {
		return wl2HessianCall.getSecretKeyByPlat(plat, keyIndex);
	}

	@Override
	public Result getAppLaunchData(ClientInfo client, String startupPicSize,
			Boolean hasSonPics, String trader, String k_i,Long cityId) {
		return wl2HessianCall.getAppLaunchData(client, startupPicSize, hasSonPics, trader,  k_i,cityId);
	}

	public IWl2Service getWl2HessianCall() {
		return wl2HessianCall;
	}

	public void setWl2HessianCall(IWl2Service wl2HessianCall) {
		this.wl2HessianCall = wl2HessianCall;
	}

}
