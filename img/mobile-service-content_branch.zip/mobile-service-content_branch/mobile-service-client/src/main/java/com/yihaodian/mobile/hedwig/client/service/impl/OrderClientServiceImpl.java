package com.yihaodian.mobile.hedwig.client.service.impl;

import com.yihaodian.mobile.service.hedwig.core.service.spi.OrderService;

public class OrderClientServiceImpl implements OrderService {
	private OrderService orderHessiancall;

	@Override
	public String CUPSignature(String token, String merchantOrderId) {
		return orderHessiancall.CUPSignature(token, merchantOrderId);
	}

	@Override
	public String aliPaySignature(String token, String merchantOrderId) {
		return orderHessiancall.aliPaySignature(token, merchantOrderId);
	}

	@Override
	public String aliPaySignatureV2(String token, String merchantOrderId) {
		return orderHessiancall.aliPaySignatureV2(token, merchantOrderId);
	}

	@Override
	public String aliPaySignatureV2(String token, String merchantOrderId,
			Integer type) {
		return orderHessiancall.aliPaySignatureV2(token, merchantOrderId, type);
	}

	public OrderService getOrderHessiancall() {
		return orderHessiancall;
	}

	public void setOrderHessiancall(OrderService orderHessiancall) {
		this.orderHessiancall = orderHessiancall;
	}

	@Override
	public String CUPSignature(Long userId, String merchantOrderId) {
		return orderHessiancall.CUPSignature(userId, merchantOrderId);
	}

	@Override
	public String aliPaySignature(Long userId, String merchantOrderId) {
		return orderHessiancall.aliPaySignatureV2(userId, merchantOrderId);
	}

	@Override
	public String aliPaySignatureV2(Long userId, String merchantOrderId) {
		return orderHessiancall.aliPaySignatureV2(userId, merchantOrderId);
	}

	@Override
	public String aliPaySignatureV2(Long userId, String merchantOrderId,
			Integer type) {
		return orderHessiancall.aliPaySignatureV2(userId, merchantOrderId, type);
	}

}
