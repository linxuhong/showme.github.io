/**
 * @author zuodeng
 */
package com.yihaodian.mobile.service.client.adapter.seckill;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.reflect.TypeToken;
import com.yihaodian.front.busystock.vo.BSProductPromRuleVo;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.service.seckill.SeckillQueueClientService;
import com.yihaodian.mobile.service.client.adapter.enums.RegexEnum;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.SeckillProductService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.promotion.SeckillCanBuyResult;
import com.yihaodian.mobile.vo.seckill.CheckSecKillResult;
import com.yihaodian.mobile.vo.seckill.SeckillMetaData;
import com.yihaodian.mobile.vo.seckill.SeckillResultVO;
import com.yihaodian.mobile.vo.seckill.TaskStatusVo;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

/**
 * The Class SeckillDispatchService.
 */
public class SeckillDispatchService extends BaseDiapatchService {
	private final static Logger logger = LoggerFactory
			.getLogger(SeckillDispatchService.class);
	/**
	 * Check if sec kill.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo checkIfSecKill(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		try {
			Trader trader = getTraderFromContext(context);
			RtnInfo rtnInfo = vaildateTrader(trader);
			if(rtnInfo != null){
				return rtnInfo;
			}
			rtnInfo = validateProvinceId(context.getRequestInfo().getProvinceId());
			if(rtnInfo != null){
				return rtnInfo;
			}
			String productId = bizInfo.get("productid");
			if(StringUtil.isEmpty(productId) || !productId.matches(RegexEnum.PURE_DIGITAL.getRegex())){
				return RtnInfo.ParameterErrRtnInfo("productId is error");
			}
			String promotionId = bizInfo.get("promotionid");
			if(StringUtil.isEmpty(promotionId) || !promotionId.matches(RegexEnum.PURE_DIGITAL.getRegex())){
				return RtnInfo.ParameterErrRtnInfo("promotionId is error");
			}
			SeckillProductService seckillProductService = CentralMobileServiceHandler.getSeckillClientService();
			CheckSecKillResult result = seckillProductService.checkIfSecKill(trader, promotionId, Long.valueOf(context.getRequestInfo().getProvinceId()), Long.parseLong(productId));
			rtnInfo = RtnInfo.RightWlRtnInfo(result);
			return rtnInfo;
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * Seckill product.
	 *
	 * @param urlPath the url path
	 * @param isLogined the is logined
	 * @param bizInfo the biz info
	 * @param context the context
	 * @return the rtn info
	 */
	public RtnInfo seckillProduct(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		try {
			if(!isLogined){
				return RtnInfo.TokenErrWlRtnInfo();
			}
			String userId =context.getCurrentUserId();
			Result re= valiateGetParams(userId);
			if(!re.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId" +re.getResultDesc());
			}
			re= valiateGetParams(context.getRequestInfo().getProvinceId());
			if(!re.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("ProvinceId" +re.getResultDesc());
			}
			Long provinceId = Long.valueOf(context.getRequestInfo().getProvinceId());
			String productId = bizInfo.get("productid");
			if(StringUtil.isEmpty(productId)){
				return RtnInfo.ParameterErrRtnInfo("productId is null");
			}
			String promotionId = bizInfo.get("promotionid");
			if(StringUtil.isEmpty(promotionId)){
				return RtnInfo.ParameterErrRtnInfo("promotionId is null");
			}
			SeckillProductService seckillProductService = CentralMobileServiceHandler.getSeckillClientService();
			SeckillResultVO result = seckillProductService.seckillProduct(userId, provinceId, promotionId, Long.parseLong(productId));
			RtnInfo rtnInfo = RtnInfo.RightWlRtnInfo(result);
			return rtnInfo;
		} catch (Exception e) {
			return null;
		}
	}
	
	public RtnInfo preSeckillProduct(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		
			if(!isLogined){
				return RtnInfo.TokenErrWlRtnInfo();
			}
			String provinceId = context.getRequestInfo().getProvinceId();
			if(StringUtil.isEmpty(provinceId)){
				return RtnInfo.ParameterErrRtnInfo("provinceId is null");
			}
			String productId = bizInfo.get("productid");
			if(StringUtil.isEmpty(productId)){
				return RtnInfo.ParameterErrRtnInfo("productId is null");
			}
			String promotionId = bizInfo.get("promotionid");
			if(StringUtil.isEmpty(promotionId)){
				return RtnInfo.ParameterErrRtnInfo("promotionId is null");
			}
			String userId = context.getCurrentUserId();
			Result re = valiateGetParams(userId);
			if(!re.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
			}
			SeckillProductService seckillProductService = CentralMobileServiceHandler.getSeckillClientService();
			SeckillResultVO result = seckillProductService.preSeckillProduct(Long.parseLong(userId), Long.parseLong(provinceId), promotionId, Long.parseLong(productId));			
			return RtnInfo.RightWlRtnInfo(result);
		
	}
	
	public RtnInfo checkSeckillCanBuy(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		try {
			
			String userId = context.getCurrentUserId();
			Result re =valiateGetParams(userId);
			if(!re.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
			}
			String provinceId = context.getRequestInfo().getProvinceId();
			
			re =valiateGetParams(provinceId);
			if(!re.isSuccess()){
				return RtnInfo.ParameterErrRtnInfo("provinceId"+re.getResultDesc());
			}
			String promotionIdListStr = bizInfo.get("promotionidlist");
			if(StringUtil.isEmpty(promotionIdListStr)){
				return RtnInfo.ParameterErrRtnInfo("promotionidlist is null");
			}
			List<String> promotionIdList = null;
			try{
				promotionIdList = (List<String>)GsonUtil.paseToObject(promotionIdListStr,new TypeToken<List<String>>(){}.getType());
			}catch(Exception e){
				logger.error("SeckillDispatchService = >checkSeckillCanBuy =>json 转成 promotionIdList时出错", e);
				return null;
			}
			String productidlistStr = bizInfo.get("productidlist");
			if(StringUtil.isEmpty(productidlistStr)){
				return RtnInfo.ParameterErrRtnInfo("productidlist is null");
			}
			List<Long> productIdList = null;
			try{
				productIdList = (List<Long>)GsonUtil.paseToObject(productidlistStr, new TypeToken<List<Long>>(){}.getType());
			}catch(Exception e){
				logger.error("SeckillDispatchService = >checkSeckillCanBuy =>json 转成 productIdList时出错", e);
				return null;
			}
			SeckillProductService seckillProductService = CentralMobileServiceHandler.getSeckillClientService();

			List<SeckillCanBuyResult> result = seckillProductService.checkSeckillCanBuy(Long.parseLong(userId), promotionIdList, productIdList,Long.parseLong(provinceId));
			RtnInfo rtnInfo = RtnInfo.RightWlRtnInfo(result);
			return rtnInfo;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public RtnInfo getSeckillTaskStatus(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();
		Result re = valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}

		// 获取参数
		String token = bizInfo.get("token");
		if (token == null || token.trim().isEmpty()) {
			return RtnInfo.ParameterErrRtnInfo("token is null");
		}

		// 调用队列服务
		SeckillQueueClientService service = CentralMobileServiceHandler.getSeckillQueueClientService();
		re = service.getTaskStatus(token);
		return this.getRtnInfo(re);
	}

	public RtnInfo fetchSeckillTasks(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();
		Result re = valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}

		// 获取参数
		String count = bizInfo.get("count");
		re = valiateGetParams(count);
		if (!re.isSuccess()) {
			return RtnInfo.ParameterErrRtnInfo("count"+re.getResultDesc());
		}

		// 调用队列服务
		SeckillQueueClientService service = CentralMobileServiceHandler.getSeckillQueueClientService();
		re = service.fetchTasks(Integer.valueOf(count));
		return this.getRtnInfo(re);
	}

	public RtnInfo sendSeckillTask(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();
		Result re = valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}

		// 获取参数
		String jsondata = bizInfo.get("jsondata");
		if (jsondata == null || jsondata.trim().isEmpty()) {
			return RtnInfo.ParameterErrRtnInfo("jsondata is null");
		}
		Long ruleId = null;
		re = valiateGetParams(bizInfo.get("ruleid"));
		if (re.isSuccess()) {
			ruleId = Long.valueOf(bizInfo.get("ruleid"));
		} else {
			return RtnInfo.ParameterErrRtnInfo("ruleid"+re.getResultDesc());
		}
		Integer purchaseNum = null;
		re = valiateGetParams(bizInfo.get("purchasenum"));
		if (re.isSuccess()) {
			purchaseNum = Integer.valueOf(bizInfo.get("purchasenum"));
		} else {
			return RtnInfo.ParameterErrRtnInfo("purchasenum"+re.getResultDesc());
		}

		// 调用队列服务
		SeckillMetaData meta = new SeckillMetaData(ruleId, Long.valueOf(userId), purchaseNum);
		SeckillQueueClientService service = CentralMobileServiceHandler.getSeckillQueueClientService();
		re = service.sendTask(jsondata, meta);
		return this.getRtnInfo(re);
	}

	public RtnInfo cancelSeckillTask(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();
		Result re = valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}

		// 获取参数
		String token = bizInfo.get("token");
		if (token == null || token.trim().isEmpty()) {
			return RtnInfo.ParameterErrRtnInfo("token is null");
		}

		// 调用队列服务
		SeckillQueueClientService service = CentralMobileServiceHandler.getSeckillQueueClientService();
		re = service.cancelTask(token);
		return this.getRtnInfo(re);
	}

	public RtnInfo setSeckillTaskStatus(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();
		Result re = valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}

		// 获取参数
		String jsondata = bizInfo.get("bussinessresultjson");
		if (jsondata == null || jsondata.trim().isEmpty()) {
			return RtnInfo.ParameterErrRtnInfo("bussinessresultjson is null");
		}
		int bizSuccess = 0;
		re = valiateGetParams(bizInfo.get("bussinesssuccess"));
		if (re.isSuccess()) {
			bizSuccess = Integer.valueOf(bizInfo.get("bussinesssuccess"));
		}
		Long ruleId = null;
		re = valiateGetParams(bizInfo.get("ruleid"));
		if (re.isSuccess()) {
			ruleId = Long.valueOf(bizInfo.get("ruleid"));
		} else {
			return RtnInfo.ParameterErrRtnInfo("ruleid"+re.getResultDesc());
		}
		Integer statusCode = null;
		re = valiateGetParams(bizInfo.get("statuscode"));
		if (re.isSuccess()) {
			statusCode = Integer.valueOf(bizInfo.get("statuscode"));
		}
		Long taskNo = null;
		re = valiateGetParams(bizInfo.get("taskno"));
		if (re.isSuccess()) {
			taskNo = Long.valueOf(bizInfo.get("taskno"));
		} else {
			return RtnInfo.ParameterErrRtnInfo("taskno"+re.getResultDesc());
		}
		String token = bizInfo.get("token");
		if (token == null || token.trim().isEmpty()) {
			return RtnInfo.ParameterErrRtnInfo("token is null");
		}

		// 调用队列服务
		TaskStatusVo taskStatusVo = new TaskStatusVo();
		taskStatusVo.setBussinessResultJson(jsondata);
		taskStatusVo.setBussinessSuccess(bizSuccess==1);
		taskStatusVo.setRuleId(ruleId);
		taskStatusVo.setStatusCode(statusCode);
		taskStatusVo.setTaskNo(taskNo);
		taskStatusVo.setToken(token);
		SeckillQueueClientService service = CentralMobileServiceHandler.getSeckillQueueClientService();
		re = service.setTaskStatus(taskStatusVo);
		return this.getRtnInfo(re);
	}

	public RtnInfo decrSeckillTaskCount(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();
		Result re = valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}

		// 获取参数
		Long ruleId = null;
		re = valiateGetParams(bizInfo.get("ruleid"));
		if (re.isSuccess()) {
			ruleId = Long.valueOf(bizInfo.get("ruleid"));
		} else {
			return RtnInfo.ParameterErrRtnInfo("ruleid"+re.getResultDesc());
		}
		Integer purchaseNum = null;
		re = valiateGetParams(bizInfo.get("purchasenum"));
		if (re.isSuccess()) {
			purchaseNum = Integer.valueOf(bizInfo.get("purchasenum"));
		} else {
			return RtnInfo.ParameterErrRtnInfo("purchasenum"+re.getResultDesc());
		}

		// 调用队列服务
		SeckillMetaData meta = new SeckillMetaData(ruleId, Long.valueOf(userId), purchaseNum);
		SeckillQueueClientService service = CentralMobileServiceHandler.getSeckillQueueClientService();
		re = service.decrTaskCount(meta);
		return this.getRtnInfo(re);
	}

	public RtnInfo initSeckillRuleInfo(String urlPath, Boolean isLogined,
            Map<String, String> bizInfo, AdapterContext context){
		if(!isLogined){
			return RtnInfo.TokenErrWlRtnInfo();
		}
		String userId = context.getCurrentUserId();
		Result re = valiateGetParams(userId);
		if(!re.isSuccess()){
			return RtnInfo.ParameterErrRtnInfo("userId"+re.getResultDesc());
		}

		// 获取参数
		String pmId = bizInfo.get("pmid");
		String id = bizInfo.get("id");
		String productId = bizInfo.get("productid");
		String merchantId = bizInfo.get("merchantid");
		String userPriceLimitNumber = bizInfo.get("userpricelimitnumber");
		String specialPriceLimitNumber = bizInfo.get("specialpricelimitnumber");
		String orderPriceLimitNumber = bizInfo.get("orderpricelimitnumber");
		String promoteType = bizInfo.get("promotetype");
		String promNonMemberPrice = bizInfo.get("promnonmemberprice");
		String promStartTime = bizInfo.get("promstarttime");
		String promEndTime = bizInfo.get("promendtime");
		String promName = bizInfo.get("promname");
		String backendOperatorId = bizInfo.get("backendoperatorid");
		String updateTime = bizInfo.get("updatetime");
		String soldNum = bizInfo.get("soldnum");
		String isQueuing = bizInfo.get("isqueuing");
		String parentRuleId = bizInfo.get("parentruleid");
		String isVisualSerial = bizInfo.get("isvisualserial");
		String ruleType = bizInfo.get("ruletype");
		String mutexPromotion = bizInfo.get("mutexpromotion");
		String discount = bizInfo.get("discount");
		String minCount = bizInfo.get("mincount");
		String channelId = bizInfo.get("channelid");
		String payNum = bizInfo.get("paynum");
		String priceLockType = bizInfo.get("pricelocktype");
		String priceChangeRemind = bizInfo.get("pricechangeremind");
		String bagSoldNum = bizInfo.get("bagsoldnum");
		String activityId = bizInfo.get("activityid");
		String weight = bizInfo.get("weight");
		String lockStatus = bizInfo.get("lockstatus");
		String businessTagId = bizInfo.get("businesstagid");
		String discountType = bizInfo.get("discounttype");
		String promNonMemberPriceWithoutBadge = bizInfo.get("promnonmemberpricewithoutbadge");

		// 调用队列服务
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		BSProductPromRuleVo vo = new BSProductPromRuleVo();
		vo.setPmId(valiateGetParams(pmId).isSuccess() ? Long.valueOf(pmId) : null);
		vo.setId(valiateGetParams(id).isSuccess() ? Long.valueOf(id) : null);
		vo.setProductId(valiateGetParams(productId).isSuccess() ? Long.valueOf(productId) : null);
		vo.setMerchantId(valiateGetParams(merchantId).isSuccess() ? Long.valueOf(merchantId) : null);
		vo.setUserPriceLimitNumber(valiateGetParams(userPriceLimitNumber).isSuccess() ? Integer.valueOf(userPriceLimitNumber) : 0);
		vo.setSpecialPriceLimitNumber(valiateGetParams(specialPriceLimitNumber).isSuccess() ? Integer.valueOf(specialPriceLimitNumber) : 0);
		vo.setOrderPriceLimitNumber(valiateGetParams(orderPriceLimitNumber).isSuccess() ? Integer.valueOf(orderPriceLimitNumber) : 0);
		vo.setPromoteType(valiateGetParams(promoteType).isSuccess() ? Integer.valueOf(promoteType) : 0);
		vo.setPromNonMemberPrice(StringUtils.isEmpty(promNonMemberPrice) ? new BigDecimal(0) : new BigDecimal(promNonMemberPrice));
		vo.setPromStartTime(StringUtils.isEmpty(promStartTime) ? null : parseTime(sdf, promStartTime));
		vo.setPromEndTime(StringUtils.isEmpty(promEndTime) ? null : parseTime(sdf, promEndTime));
		vo.setPromName(promName);
		vo.setBackendOperatorId(valiateGetParams(backendOperatorId).isSuccess() ? Long.valueOf(backendOperatorId) : null);
		vo.setUpdateTime(StringUtils.isEmpty(updateTime) ? null : parseTime(sdf, updateTime));
		vo.setSoldNum(valiateGetParams(soldNum).isSuccess() ? Integer.valueOf(soldNum) : null);
		vo.setIsQueuing(valiateGetParams(isQueuing).isSuccess() ? Integer.valueOf(isQueuing) : 0);
		vo.setParentRuleId(valiateGetParams(parentRuleId).isSuccess() ? Long.valueOf(parentRuleId) : 0);
		vo.setIsVisualSerial(valiateGetParams(isVisualSerial).isSuccess() ? Integer.valueOf(isVisualSerial) : 0);
		vo.setRuleType(valiateGetParams(ruleType).isSuccess() ? Integer.valueOf(ruleType) : null);
		vo.setMutexPromotion(valiateGetParams(mutexPromotion).isSuccess() ? Integer.valueOf(mutexPromotion) : null);
		vo.setDiscount(StringUtils.isEmpty(discount) ? null: new BigDecimal(discount));
		vo.setMinCount(valiateGetParams(minCount).isSuccess() ? Long.valueOf(minCount) : null);
		vo.setChannelId(valiateGetParams(channelId).isSuccess() ? Long.valueOf(channelId) : 0);
		vo.setPayNum(valiateGetParams(payNum).isSuccess() ? Integer.valueOf(payNum) : null);
		vo.setPriceLockType(valiateGetParams(priceLockType).isSuccess() ? Integer.valueOf(priceLockType) : null);
		vo.setPriceChangeRemind(valiateGetParams(priceChangeRemind).isSuccess() ? Integer.valueOf(priceChangeRemind) : 0);
		vo.setBagSoldNum(valiateGetParams(bagSoldNum).isSuccess() ? Integer.valueOf(bagSoldNum) : null);
		vo.setActivityId(valiateGetParams(activityId).isSuccess() ? Long.valueOf(activityId) : null);
		vo.setWeight(valiateGetParams(weight).isSuccess() ? Integer.valueOf(weight) : null);
		vo.setLockStatus(valiateGetParams(lockStatus).isSuccess() ? Integer.valueOf(lockStatus) : null);
		vo.setBusinessTagId(valiateGetParams(businessTagId).isSuccess() ? Long.valueOf(businessTagId) : null);
		vo.setDiscountType(valiateGetParams(discountType).isSuccess() ? Integer.valueOf(discountType) : 0);
		vo.setPromNonMemberPriceWithoutBadge(StringUtils.isEmpty(promNonMemberPriceWithoutBadge) ? null : new BigDecimal(promNonMemberPriceWithoutBadge));
		SeckillQueueClientService service = CentralMobileServiceHandler.getSeckillQueueClientService();
		re = service.initRuleInfo(Arrays.asList(vo));
		return this.getRtnInfo(re);
	}

	/**
	 * 转换字符串到日期
	 * 
	 * @param sdf
	 * @param source
	 * @return
	 */
	private Date parseTime(SimpleDateFormat sdf, String source) {
		try {
			return sdf.parse(source);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
