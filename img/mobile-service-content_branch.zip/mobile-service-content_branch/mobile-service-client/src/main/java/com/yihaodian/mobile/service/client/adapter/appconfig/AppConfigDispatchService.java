package com.yihaodian.mobile.service.client.adapter.appconfig;

import java.util.Map;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.service.client.adapter.service.impl.BaseDiapatchService;
import com.yihaodian.mobile.service.facade.business.apollo.IApolloPromotionService;
import com.yihaodian.mobile.service.facade.business.appconfig.AppConfigService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RtnInfo;

public class AppConfigDispatchService extends BaseDiapatchService {

	public RtnInfo getAppTab(String urlPath,Boolean isLogined, Map<String, String> bizInfo,AdapterContext context) {
	
		AppConfigService service = CentralMobileServiceHandler.getAppConfigClientService();
		Result result = service.getAppTab(getTraderFromContext(context));				
		return getRtnInfo(result);
	}
	public RtnInfo getDefaultHit(String urlPath,Boolean isLogined, Map<String, String> bizInfo,AdapterContext context) {
		AppConfigService service = CentralMobileServiceHandler.getAppConfigClientService();
		Result result = service.getDefaultHit(getTraderFromContext(context));				
		return getRtnInfo(result);
	}
	public RtnInfo getDefaultHitForPad(String urlPath,Boolean isLogined, Map<String, String> bizInfo,AdapterContext context) {
		AppConfigService service = CentralMobileServiceHandler.getAppConfigClientService();
		Trader trader = getTraderFromContext(context);
		if(trader!=null){
			trader.setClientAppVersion("4.1.0");
		}
		Result result = service.getDefaultHit(trader);				
		return getRtnInfo(result);
	}
	public RtnInfo getAppRefInfo(String urlPath,Boolean isLogined, Map<String, String> bizInfo,AdapterContext context) {
		AppConfigService service = CentralMobileServiceHandler.getAppConfigClientService();
		Trader trader = getTraderFromContext(context);
		Long userId = null;
		if(isLogined){
			RtnInfo rtn = validateNumber(context.getCurrentUserId());
			if(null == rtn){
				userId = Long.valueOf(context.getCurrentUserId());
			}
		}
		Result result = service.getAppRefInfo(trader,userId);				
		return getRtnInfo(result);
	}
}
