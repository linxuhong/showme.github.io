package com.yihaodian.mobile.hedwig.client.redshare;

import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.hedwig.push.spi.IRedShareService;

public class RedShareClientService implements IRedShareService{
	private IRedShareService redShareHessianCall;

	public IRedShareService getRedShareHessianCall() {
		return redShareHessianCall;
	}

	public void setRedShareHessianCall(IRedShareService redShareHessianCall) {
		this.redShareHessianCall = redShareHessianCall;
	}

	@Override
	public ResultModel getPromotionInfo(Long activityId) {
		return redShareHessianCall.getPromotionInfo(activityId);
	}

	@Override
	public ResultModel getShareInfo(Long activityId, Long userId) {
		return redShareHessianCall.getShareInfo(activityId, userId);
	}

	@Override
	public ResultModel shareRed(Long activityId, Long userId, Integer type) {
		return redShareHessianCall.shareRed(activityId, userId, type);
	}

	@Override
	public ResultModel getUserInfo(Long activityId, Long userId) {
		return redShareHessianCall.getUserInfo(activityId, userId);
	}

	@Override
	public ResultModel accepctRed(Long activityId, Long userId, String openid,
			String redCipher, int type) {
		return redShareHessianCall.accepctRed(activityId, userId, openid, redCipher, type);
	}

	@Override
	public ResultModel exchangeAward(Long activityId, Long awardId, Long userId) {
		return redShareHessianCall.exchangeAward(activityId, awardId, userId);
	}

	@Override
	public ResultModel getUserRedList(Long activityId, String redCipher) {
		return redShareHessianCall.getUserRedList(activityId, redCipher);
	}

}
