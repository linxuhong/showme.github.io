package com.yihaodian.mobile.service.client.advertisement.service.impl;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.facade.business.advertisement.CurtainAdvertisementService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class CurtainADClientService implements CurtainAdvertisementService{
	
	private CurtainAdvertisementService curtainADHessianCall;

	public CurtainAdvertisementService getCurtainADHessianCall() {
		return curtainADHessianCall;
	}

	public void setCurtainADHessianCall(
			CurtainAdvertisementService curtainADHessianCall) {
		this.curtainADHessianCall = curtainADHessianCall;
	}

	@Override
	public Result getCurtainAdvertisement(Trader trader, String deviceCode,
			Integer provinceId, Long userId, String interfaceVersion) {
		return curtainADHessianCall.getCurtainAdvertisement(trader, deviceCode, provinceId, userId, interfaceVersion);
	}

	@Override
	public Result openCurtainAdvertisement(Trader trader, String deviceCode,
			Integer provinceId) {
		return curtainADHessianCall.openCurtainAdvertisement(trader, deviceCode, provinceId);
	}

	@Override
	public Result getCurtainAdvertisementV2(Trader trader, String deviceCode, Integer provinceId, Long userId,
			String unionKey, boolean isFilter) {
		return curtainADHessianCall.getCurtainAdvertisementV2(trader, deviceCode, provinceId, userId, unionKey,isFilter);
	}

}
