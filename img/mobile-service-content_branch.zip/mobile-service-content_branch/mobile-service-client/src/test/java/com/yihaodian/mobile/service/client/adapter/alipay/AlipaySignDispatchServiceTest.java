package com.yihaodian.mobile.service.client.adapter.alipay;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.alipay.spi.IAlipaySignService;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class AlipaySignDispatchServiceTest extends BaseTest {
	AlipaySignDispatchService alipaySignDispatchService = new AlipaySignDispatchService();
	@Test
	public void testGetAliPaySignature() {
		try {
		
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
			IAlipaySignService alipaySignService = PowerMockito.mock(IAlipaySignService.class);
			PowerMockito.when(CentralMobileServiceHandler.getAlipaySignService()).thenReturn(alipaySignService);
			PowerMockito.when(alipaySignService.getAliPaySignatureV2(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString()));	
			bizInfo.put("orderid", "1");
			alipaySignDispatchService.getAliPaySignature(urlPath, isLogined, bizInfo, content);
		} catch (Exception e) {
			
			assertTrue(true);
		}
	}

}
