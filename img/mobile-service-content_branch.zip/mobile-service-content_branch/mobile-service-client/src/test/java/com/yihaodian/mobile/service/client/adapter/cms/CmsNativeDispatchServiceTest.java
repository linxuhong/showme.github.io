package com.yihaodian.mobile.service.client.adapter.cms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.mobile.backend.cms.vo.NativePageVO;
import com.yihaodian.mobile.backend.cms.vo.cl.AbsColumnVO;
import com.yihaodian.mobile.backend.cms.vo.p.CmsNativeProductVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.cms.spi.CmsNativeService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class CmsNativeDispatchServiceTest extends BaseTest{
	CmsNativeDispatchService cmsNativeDispatchService = new CmsNativeDispatchService();
	
	@Test
	public void testloadCmsPage(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CmsNativeService service = PowerMockito.mock(CmsNativeService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCmsNativeService()).thenReturn(service);
		NativePageVO vo = new NativePageVO();
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setCityId("1");
		clientInfoVO.setProvinceId("1");
		clientInfoVO.setDeviceCode("1");
		PowerMockito.when(service.loadCmsPage(clientInfoVO,1,"1")).thenReturn(vo);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("pageid", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		this.cmsNativeDispatchService.loadCmsPage(urlPath, true, bizInfo, content);
		this.cmsNativeDispatchService.loadCmsPage(urlPath, true, bizInfo1, content);
		this.cmsNativeDispatchService.loadCmsPage(urlPath, true, bizInfo, content);
		this.cmsNativeDispatchService.loadCmsPage(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testloadCmsColContent(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CmsNativeService service = PowerMockito.mock(CmsNativeService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCmsNativeService()).thenReturn(service);
		AbsColumnVO vo = new AbsColumnVO() {
			
			@Override
			public String getColumnType() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setCityId("1");
		clientInfoVO.setProvinceId("1");
		clientInfoVO.setDeviceCode("1");
		PowerMockito.when(service.loadCmsColContent(clientInfoVO,1,"1")).thenReturn(vo);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("id", "12");
        this.cmsNativeDispatchService.loadCmsColContent(urlPath, true, bizInfo, content);
        this.cmsNativeDispatchService.loadCmsColContent(urlPath, true, bizInfo, content);
        this.cmsNativeDispatchService.loadCmsColContent(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetCmsVoucher(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CmsNativeService service = PowerMockito.mock(CmsNativeService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCmsNativeService()).thenReturn(service);
		PowerMockito.when(service.getCmsVoucher(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn("12");
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("id", "12");
		bizInfo.put("subgroupid", "10");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("id", "ab");
		bizInfo1.put("subgroupid", "10");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("id", "12");
		bizInfo1.put("subgroupid", "ab");
		this.cmsNativeDispatchService.getCmsVoucher(urlPath, true, bizInfo, content);
		this.cmsNativeDispatchService.getCmsVoucher(urlPath, true, bizInfo1, content);
		this.cmsNativeDispatchService.getCmsVoucher(urlPath, true, bizInfo2, content);
		this.cmsNativeDispatchService.getCmsVoucher(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testloadSubGroupProducts(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CmsNativeService service = PowerMockito.mock(CmsNativeService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCmsNativeService()).thenReturn(service);
		List<CmsNativeProductVO> list = new ArrayList<CmsNativeProductVO>();
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setCityId("1");
		clientInfoVO.setProvinceId("1");
		clientInfoVO.setDeviceCode("1");
		PowerMockito.when(service.loadSubGroupProducts(clientInfoVO,1,1L,"1")).thenReturn(list);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("colid", "12");
		bizInfo.put("subgroupid", "10");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("colid", "ab");
		bizInfo1.put("subgroupid", "10");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("colid", "12");
		bizInfo2.put("subgroupid", "ab");
		this.cmsNativeDispatchService.loadSubGroupProducts(urlPath, true, bizInfo, content);
		this.cmsNativeDispatchService.loadSubGroupProducts(urlPath, true, bizInfo1, content);
		this.cmsNativeDispatchService.loadSubGroupProducts(urlPath, true, bizInfo2, content);
	}
	
	@Test
	public void testcheckNative(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CmsNativeService service = PowerMockito.mock(CmsNativeService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCmsNativeService()).thenReturn(service);
		PowerMockito.when(service.checkNative(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString())).thenReturn(true);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("pageid", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		this.cmsNativeDispatchService.checkNative(urlPath, true, bizInfo, content);
		this.cmsNativeDispatchService.checkNative(urlPath, true, bizInfo1, content);
	}
}
