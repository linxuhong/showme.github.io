package com.yihaodian.mobile.hedwig.client.service.content.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.content.spi.ScratchService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.wl2.ClientInfo;

public class ScratchClientServiceImplTest {
	private ScratchClientServiceImpl SCSImpl = new ScratchClientServiceImpl();
	
	@Mock
	private ScratchService scratchHessionCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(SCSImpl, "scratchHessionCall", scratchHessionCall);
	}


	@Test
	public void testGetUserScratchResultDetailList() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android3.0");
		trader.setDeviceCode("htcm8");
		
		SCSImpl.getUserScratchResultDetailList(trader );
	}

	@Test
	public void testGetScratchHessionCall() {
		SCSImpl.getScratchHessionCall();
	}

	@Test
	public void testSetScratchHessionCall() {
		SCSImpl.setScratchHessionCall(scratchHessionCall);
	}

	@Test
	public void testGetScratchAvailableLongLongIntegerTrader() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android3.0");
		trader.setDeviceCode("htcm8");
		SCSImpl.getScratchAvailable(23L, 22L, 3, trader);
	}

	@Test
	public void testGetScratchReusltLongLongIntegerStringTrader() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android3.0");
		trader.setDeviceCode("htcm8");
		SCSImpl.getScratchReuslt(23L, 22L, 3, "django", trader);
	}

	@Test
	public void testGetScratchInfoListForOrderListLongListOfStringTrader() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android3.0");
		trader.setDeviceCode("htcm8");
		
		List<String> orderIdAndSiteType = new ArrayList<String>();
		orderIdAndSiteType.add("type1");
		orderIdAndSiteType.add("type2");
		orderIdAndSiteType.add("type3");
		SCSImpl.getScratchInfoListForOrderList(56L, orderIdAndSiteType, trader);
	}

	@Test
	public void testGetScratchInfoListForOrderListLongClientInfoVOListOfStringTrader() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android3.0");
		trader.setDeviceCode("htcm8");
		List<String> orderIdAndSiteType = new ArrayList<String>();
		orderIdAndSiteType.add("type1");
		orderIdAndSiteType.add("type2");
		orderIdAndSiteType.add("type3");
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientSystem("Android5.0");
		clientInfoVO.setDeviceCode("似水流年p8");
		SCSImpl.getScratchInfoListForOrderList(45L, clientInfoVO , orderIdAndSiteType, trader);
	}

	@Test
	public void testGetRebatesNotificationLong() {
		SCSImpl.getRebatesNotification(35L);
	}

	@Test
	public void testCancelScratchReusltLongLongInteger() {
		SCSImpl.cancelScratchReuslt(36L, 25L, 4);
	}

}
