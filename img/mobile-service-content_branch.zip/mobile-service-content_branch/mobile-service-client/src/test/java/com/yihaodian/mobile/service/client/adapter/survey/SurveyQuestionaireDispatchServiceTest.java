package com.yihaodian.mobile.service.client.adapter.survey;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.survey.spi.SurveyQuestionaireService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;


@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class SurveyQuestionaireDispatchServiceTest extends BaseTest{
	SurveyQuestionaireDispatchService surveyQuestionaireDispatchService = new SurveyQuestionaireDispatchService();
	
	@Test
	public void testgetOpenQuestionairesForUser(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		SurveyQuestionaireService service = PowerMockito.mock(SurveyQuestionaireService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getSurveyQuestionaireClientService()).thenReturn(service);
		PowerMockito.when(service.getOpenQuestionairesForUser(Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.surveyQuestionaireDispatchService.getOpenQuestionairesForUser(urlPath, false, bizInfo, content);
		this.surveyQuestionaireDispatchService.getOpenQuestionairesForUser(urlPath, true, bizInfo, content);
	}
}
