package com.yihaodian.mobile.service.client.adapter.push;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.push.PushService;
import com.yihaodian.mobile.service.facade.product.spi.IProductSignService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.wl2.ClientInfo;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class PushDispatchServiceTest extends BaseTest{
	PushDispatchService pushDispatchService = new PushDispatchService();
	@Test
	public void testLogReporting() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		PushService service = PowerMockito.mock(PushService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getPushService()).thenReturn(service);
		bizInfo.put("sendtime", "123");
		pushDispatchService.logReporting(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testMessageOpen() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		PushService service = PowerMockito.mock(PushService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getPushService()).thenReturn(service);
		PowerMockito.doNothing().when(service).messageOpen(Mockito.any(Trader.class), Mockito.anyLong(),Mockito.anyLong(), Mockito.anyLong(), Mockito.anyInt());
		bizInfo.put("opentime", "2");
		bizInfo.put("pageid", "2");
		bizInfo.put("promotionid", "2");
		bizInfo.put("promotiontype", "2");
		pushDispatchService.messageOpen(urlPath, isLogined, bizInfo, content);
	
	}

	@Test
	public void testStoreUserInfo() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		PushService service = PowerMockito.mock(PushService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getPushService()).thenReturn(service);
		PowerMockito.when(service.storeUserPushMapping(Mockito.anyLong(), Mockito.any(ClientInfo.class), Mockito.anyString())).thenReturn(null);
	    pushDispatchService.storeUserInfo(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetPushInformation() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		PushService service = PowerMockito.mock(PushService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getPushService()).thenReturn(service);
		PowerMockito.when(service.getPushInformation(Mockito.any(Trader.class), Mockito.anyLong())).thenReturn(null);
	    pushDispatchService.getPushInformation(urlPath, isLogined, bizInfo, content);
	}

}
