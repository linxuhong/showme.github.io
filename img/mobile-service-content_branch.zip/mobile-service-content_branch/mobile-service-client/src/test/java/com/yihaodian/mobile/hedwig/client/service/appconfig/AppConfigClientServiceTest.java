package com.yihaodian.mobile.hedwig.client.service.appconfig;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.appconfig.AppConfigService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class AppConfigClientServiceTest {
	
	private AppConfigClientService appConfigClientService = new AppConfigClientService();
	
	@Mock
	private AppConfigService appConfigHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(appConfigClientService, "appConfigHessianCall", appConfigHessianCall);
	}

	@Test
	public void testGetDefaultHit() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android5.0");
		trader.setClientTelnetPhone("phone");
		trader.setDeviceCode("p8");
		appConfigClientService.getDefaultHit(trader );
	}

	@Test
	public void testGetAppTabTrader() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android5.0");
		trader.setClientTelnetPhone("phone");
		trader.setDeviceCode("p8");
		appConfigClientService.getAppTab(trader);
	}

	@Test
	public void testGetAppTab() {
		appConfigClientService.getAppTab();
	}

	@Test
	public void testGetAppConfigHessianCall() {
		appConfigClientService.getAppConfigHessianCall();
	}

	@Test
	public void testSetAppConfigHessianCall() {
		appConfigClientService.setAppConfigHessianCall(appConfigHessianCall);
	}

}
