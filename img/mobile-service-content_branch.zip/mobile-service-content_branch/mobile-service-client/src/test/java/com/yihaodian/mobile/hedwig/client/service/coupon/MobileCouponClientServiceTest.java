package com.yihaodian.mobile.hedwig.client.service.coupon;


import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.coupon.IMobileCouponFacadeService;

public class MobileCouponClientServiceTest {
	MobileCouponClientService mobileCouponClientService = new MobileCouponClientService();
	@Mock
	IMobileCouponFacadeService mobileCouponHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(mobileCouponClientService, "mobileCouponHessianCall", mobileCouponHessianCall);
	}
	@Test
	public void test() {
		mobileCouponClientService.receiveCouponByActivityId(null, null, null);
		mobileCouponClientService.checkCouppnVerfyCode(null, null, null);
		mobileCouponClientService.getCouponActivityVOByPromotionId(null, null, null, null, null);
		mobileCouponClientService.getMobileCouponHessianCall();
		mobileCouponClientService.setMobileCouponHessianCall(mobileCouponHessianCall);

	}

}
