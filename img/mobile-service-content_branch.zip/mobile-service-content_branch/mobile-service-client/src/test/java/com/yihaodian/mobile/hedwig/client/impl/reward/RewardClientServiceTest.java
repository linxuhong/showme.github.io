package com.yihaodian.mobile.hedwig.client.impl.reward;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.reward.spi.IRewardService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class RewardClientServiceTest {
	private RewardClientService rewardClientService = new RewardClientService();
	
	@Mock
	private IRewardService rewardHessianCall;

	@Before
	public void initMock() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(rewardClientService, "rewardHessianCall", rewardHessianCall);
	}

	@Test
	public void testRewardPrizeClientInfoVOStringIntegerLong() {
		Long rewardId = 34L;
		
		Integer type = 132;
		String userToken = "userToken";
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.0.123");
		clientInfoVO.setClientSystem("Android5.0");
		clientInfoVO.setDeviceCode("iphone6plus");
		rewardClientService.rewardPrize(clientInfoVO, userToken, 
				type, rewardId);
	}

	@Test
	public void testGetRewardLogCount() {
		Long rewardId = 34L;
		Integer type = 34;
		Long userId = 123L;
		rewardClientService.getRewardLogCount(userId, type, rewardId);
	}

	@Test
	public void testGetRewardHessianCall() {
		rewardClientService.getRewardHessianCall();
	}

	@Test
	public void testSetRewardHessianCall() {
		rewardClientService.setRewardHessianCall(rewardHessianCall);
	}

	@Test
	public void testRewardPrizeClientInfoVOLongIntegerLong() {
	Long rewardId = 34L;
		
		Integer type = 132;
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.0.123");
		clientInfoVO.setClientSystem("Android5.0");
		clientInfoVO.setDeviceCode("iphone6plus");
		String userId = "yhd009878";
		rewardClientService.rewardPrize(clientInfoVO, userId , type, rewardId);
	}

}
