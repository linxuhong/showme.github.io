package com.yihaodian.mobile.service.client.adapter.push;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.domain.vo.business.push.OpenMessageParamVO;
import com.yihaodian.mobile.service.facade.business.push.IPushMessageStatisticsService;
import com.yihaodian.mobile.service.facade.product.spi.IProductSignService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.wl2.ClientInfo;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class PushMessageStatisticsDispatchServiceTest extends BaseTest{
	PushMessageStatisticsDispatchService pushMessageStatisticsDispatchService = new PushMessageStatisticsDispatchService();
	@Test
	public void testMessageStatistics() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		IPushMessageStatisticsService pushMessageStatisticsService = PowerMockito.mock(IPushMessageStatisticsService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getPushMessageStatisticsService()).thenReturn(pushMessageStatisticsService);
		PowerMockito.when(pushMessageStatisticsService.messageStatistics(Mockito.any(ClientInfoVO.class), Mockito.anyLong(), Mockito.anyListOf(OpenMessageParamVO.class), Mockito.anyString(), Mockito.anyLong(), Mockito.anyInt())).thenReturn(null);
		bizInfo.put("time", "123");
		bizInfo.put("devicetoken", "Q43");
		bizInfo.put("type", "1");
		bizInfo.put("messageinfo", "");
		pushMessageStatisticsDispatchService.messageStatistics(urlPath, isLogined, bizInfo, content);
	}

}
