package com.yihaodian.mobile.service.client.message.service.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.message.MessageCenterService;

public class MessageCenterClientServiceImplTest {
	private MessageCenterClientServiceImpl MCClientServiceimpl = new MessageCenterClientServiceImpl();
	@Mock
	private MessageCenterService  messageCenterHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(MCClientServiceimpl, "messageCenterHessianCall", messageCenterHessianCall);
	}

	@Test
	public void testSetMessageCenterHessianCall() {
		MCClientServiceimpl.setMessageCenterHessianCall(messageCenterHessianCall);
	}

	@Test
	public void testGetNoReadCountWithUserIdStringInt() {
		MCClientServiceimpl.getNoReadCountWithUserId("yhd_tokem", 89);
		}

	@Test
	public void testGetMessagesWithUserIdStringIntInt() {
		MCClientServiceimpl.getMessagesWithUserId("yhd_token", 4, 30);
		}

	@Test
	public void testGetMessagesWithMSrcStringLongIntIntInt() {
		MCClientServiceimpl.getMessagesWithMSrc("yhd_token", 45L, 3, 10, 5);
	}

	@Test
	public void testUpdateMessageISReadStringLong() {
		MCClientServiceimpl.updateMessageISRead("yhd_token", 45l);
	}

	@Test
	public void testUpdateMessageISReadWithMessTStringLong() {
		MCClientServiceimpl.updateMessageISReadWithMessT("yhd_token", 4L);
	}

	@Test
	public void testGetFMessTypeSubStatusString() {
		MCClientServiceimpl.getFMessTypeSubStatus("yhd_token");
	}

	@Test
	public void testUpdateSubStatusWithFiTypeStringLong() {
		MCClientServiceimpl.updateSubStatusWithFiType("yhd_token", 45L);
	}

	@Test
	public void testUpdateUnSubStatusWithFiTypeStringLong() {
		MCClientServiceimpl.updateUnSubStatusWithFiType("yhd_tpken", 45L);
	}

	@Test
	public void testDeleteMesssaageWithMTypeStringLong() {
		MCClientServiceimpl.deleteMesssaageWithMType("yhd_tpken", 45L);
	}

	@Test
	public void testDeleteSingleMesssageStringLong() {
		MCClientServiceimpl.deleteSingleMesssage("yhd_tpken", 45L);
	}

	@Test
	public void testDeleteMultiMesssageStringListOfLong() {
		List<Long> messageIds = new ArrayList<Long>();
		messageIds.add(3L);
		messageIds.add(4L);
		messageIds.add(1L);
		messageIds.add(8L);
		MCClientServiceimpl.deleteMultiMesssage("yhd_token", messageIds );
	}

	@Test
	public void testGetNoReadMessageFString() {
		MCClientServiceimpl.getNoReadMessageF(45L);
		}

	@Test
	public void testGetMessageCatelogByParent() {
		MCClientServiceimpl.getMessageCatelogByParent();
	}

	@Test
	public void testIsUserSubscribeBatchStringListOfLong() {
		
		List<Long> cateIds = new ArrayList<Long>();
		cateIds.add(3L);
		cateIds.add(4L);
		cateIds.add(1L);
		cateIds.add(8L);
		
		MCClientServiceimpl.isUserSubscribeBatch("yhd_token", cateIds );
	}

	@Test
	public void testSubscribeMessageStringLong() {
		MCClientServiceimpl.subscribeMessage("yhd_token", 34L);
	}

	@Test
	public void testUnsubscribeMessageStringLong() {
		MCClientServiceimpl.unsubscribeMessage("yhd_token", 45L);
	}

	@Test
	public void testGetNoReadCountWithUserIdLongInt() {
		MCClientServiceimpl.getNoReadCountWithUserId(45L, 3);
	}

	@Test
	public void testGetNoReadMessageFLong() {
		MCClientServiceimpl.getNoReadMessageF(34L);
	}

	@Test
	public void testGetMessagesWithUserIdLongIntInt() {
		MCClientServiceimpl.getMessagesWithUserId(454L, 1, 20);
	}

	@Test
	public void testGetMessagesWithMSrcLongLongIntIntInt() {
		MCClientServiceimpl.getMessagesWithMSrc(34L, 34L, 3, 10, 4);
	}

	@Test
	public void testUpdateMessageISReadLongLong() {
		MCClientServiceimpl.updateMessageISRead(34L, 23L);
	}

	@Test
	public void testUpdateMessageISReadWithMessTLongLong() {
		MCClientServiceimpl.updateMessageISReadWithMessT(34L, 56L);
	}

	@Test
	public void testGetFMessTypeSubStatusLong() {
		MCClientServiceimpl.getFMessTypeSubStatus(34L);
	}

	@Test
	public void testUpdateSubStatusWithFiTypeLongLong() {
		MCClientServiceimpl.updateSubStatusWithFiType(34L, 2L);
	}

	@Test
	public void testUpdateUnSubStatusWithFiTypeLongLong() {
		MCClientServiceimpl.updateUnSubStatusWithFiType(45L, 3L);
	}

	@Test
	public void testDeleteMesssaageWithMTypeLongLong() {
		MCClientServiceimpl.deleteMesssaageWithMType(223L, 5L);
	}

	@Test
	public void testDeleteSingleMesssageLongLong() {
		MCClientServiceimpl.deleteSingleMesssage(345L, 567L);
	}

	@Test
	public void testDeleteMultiMesssageLongListOfLong() {
		List<Long> messageIds = new ArrayList<Long>();
		messageIds.add(34L);;
		messageIds.add(36L);;
		messageIds.add(32L);;
		messageIds.add(12L);;
		messageIds.add(114L);;
		MCClientServiceimpl.deleteMultiMesssage(34L, messageIds );
	}

	@Test
	public void testIsUserSubscribeBatchLongListOfLong() {
		List<Long> cateIds = new ArrayList<Long>();
		cateIds.add(114L);
		cateIds.add(323L);
		cateIds.add(34L);
		cateIds.add(44L);
		cateIds.add(44L);
		MCClientServiceimpl.isUserSubscribeBatch(45L, cateIds );
	}

	@Test
	public void testSubscribeMessageLongLong() {
		MCClientServiceimpl.subscribeMessage(34L, 33L);
	}

	@Test
	public void testUnsubscribeMessageLongLong() {
		MCClientServiceimpl.unsubscribeMessage(45L, 12L);
	}

}
