package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.apollo.IApolloPromotionService;

public class ApolloPromotionClientServiceImplTest {
	ApolloPromotionClientServiceImpl apolloPromotionClientServiceImpl = new ApolloPromotionClientServiceImpl();
	@Mock
	IApolloPromotionService apolloPromotionHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(apolloPromotionClientServiceImpl, "apolloPromotionHessianCall", apolloPromotionHessianCall);
	}
	@Test
	public void test() {
		apolloPromotionClientServiceImpl.getApolloPromotionHessianCall();
		apolloPromotionClientServiceImpl.getApolloPromotionInfoByClientLocation(null, null);
		apolloPromotionClientServiceImpl.setApolloPromotionHessianCall(apolloPromotionHessianCall);
	}

}
