package com.yihaodian.mobile.service.client.adapter.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.wl2.spi.IWl2Service;
import com.yihaodian.mobile.vo.wl2.ClientInfo;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({Wl2AdapterService.class,CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class Wl2AdapterServiceTest extends BaseTest{
	Wl2AdapterService wl2AdapterService = new  Wl2AdapterService();
	private BaseResultCode baseResultCode;
	@Test
	public void testGetMySecretKey() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		IWl2Service wl2ClientService = PowerMockito.mock(IWl2Service.class);
		PowerMockito.when(CentralMobileServiceHandler.getWl2ClientService()).thenReturn(wl2ClientService);
		Result key = PowerMockito.mock(Result.class);
		PowerMockito.when(key.isSuccess()).thenReturn(true).thenReturn(false);
		Map<String, Object> value1 = new HashMap<String, Object>();
		PowerMockito.when(key.getDefaultModel()).thenReturn(value1);
		PowerMockito.when(wl2ClientService.getSecretKeyByPlat(Mockito.anyString(),Mockito.anyString())).thenReturn(key);	   
	    wl2AdapterService.getMySecretKey(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("trader", "1");
	     
	    PowerMockito.when(key.getBaseResultCode()).thenReturn(baseResultCode);
	    PowerMockito.when(baseResultCode.getCode()).thenReturn("123");
	    PowerMockito.when(baseResultCode.getMsg()).thenReturn("456");
	    PowerMockito.when(baseResultCode.getDetail()).thenReturn("123");
	    wl2AdapterService.getMySecretKey(urlPath, isLogined, bizInfo, content);
	    wl2AdapterService.getMySecretKey(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetAppLaunchData() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		Result key = PowerMockito.mock(Result.class);
		Map<String, Object> value1 = new HashMap<String, Object>();
		PowerMockito.when(key.getDefaultModel()).thenReturn(value1);
		
		IWl2Service wl2ClientService = PowerMockito.mock(IWl2Service.class);
		PowerMockito.when(CentralMobileServiceHandler.getWl2ClientService()).thenReturn(wl2ClientService);
	    PowerMockito.when(wl2ClientService.getAppLaunchData(Mockito.any(ClientInfo.class), Mockito.anyString(),Mockito.anyBoolean(), Mockito.anyString(),Mockito.anyString(),Mockito.anyLong())).thenReturn(key);
	    wl2AdapterService.getAppLaunchData(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("hassonpics", "1");
	    wl2AdapterService.getAppLaunchData(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("startuppicsize", "1");
	    bizInfo.put("trader", "1");
	    PowerMockito.when(key.isSuccess()).thenReturn(true).thenReturn(false);
	    PowerMockito.when(key.getBaseResultCode()).thenReturn(baseResultCode);
	    PowerMockito.when(baseResultCode.getCode()).thenReturn("123");
	    PowerMockito.when(baseResultCode.getMsg()).thenReturn("456");
	    PowerMockito.when(baseResultCode.getDetail()).thenReturn("123");
	    wl2AdapterService.getAppLaunchData(urlPath, isLogined, bizInfo, content);
	    wl2AdapterService.getAppLaunchData(urlPath, isLogined, bizInfo, content);
	}	
}
