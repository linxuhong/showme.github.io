package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.hedwig.core.service.spi.ProductService;

public class ProductClientServiceImplTest {
	ProductClientServiceImpl productClientServiceImpl = new ProductClientServiceImpl();
	@Mock
	ProductService productHessiancall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(productClientServiceImpl, "productHessiancall", productHessiancall);
	}
	@Test
	public void test() {
		productClientServiceImpl.getAdvertisementList(null, null, null, null);
		productClientServiceImpl.getHomeHotPointList(null, null, null, null);
		productClientServiceImpl.getHomeHotProductTop5List(null, null);
		productClientServiceImpl.getHotProductByActivityID(null, null, null, null, null);
		productClientServiceImpl.getHotProductCountByCategoryId(null, null, null);
		productClientServiceImpl.getHotProductPageByCategoryId(null, null, null, null, null);
		productClientServiceImpl.getHotRandomProducts(null, null);
		productClientServiceImpl.getMoreInterestedProducts(null, null, null, null);
		productClientServiceImpl.getMoreInterestedProducts(null, null, null, null, null);
		productClientServiceImpl.getYhbPageByCategoryId(null, null, null, null, null, null, null);
		productClientServiceImpl.getYhbByCategoryId(null, null, null, null, null, null, null);
		productClientServiceImpl.getYhbByCategoryId(null, null, null, null, null, null, null);
		productClientServiceImpl.getUserInterestedProductsV2(null, null, null, null);
		productClientServiceImpl.getUserInterestedProductsCategorys(null);
		productClientServiceImpl.getUserInterestedProducts(null, null, null);
		productClientServiceImpl.getUserBehavior(null, null, null);
		productClientServiceImpl.getPromotionProductPage(null, null, null, null, null);
		productClientServiceImpl.getProductHessiancall();
		productClientServiceImpl.getPackageProducts(null, null, null, null, null);
		
		productClientServiceImpl.setProductHessiancall(productHessiancall);
		productClientServiceImpl.getMoreInterestedProducts(null, null, null, null, null);
		
	}

}
