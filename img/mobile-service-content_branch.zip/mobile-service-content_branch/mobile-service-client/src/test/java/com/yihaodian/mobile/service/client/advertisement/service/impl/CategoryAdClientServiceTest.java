package com.yihaodian.mobile.service.client.advertisement.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.advertisement.CategoryAdService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class CategoryAdClientServiceTest {
	private CategoryAdClientService CAClientservie = new CategoryAdClientService();
	@Mock
	private CategoryAdService categoryADHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(CAClientservie, "categoryADHessianCall", categoryADHessianCall);
	}

	@Test
	public void testGetHotRecommendCateList() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android5.0");
		trader.setDeviceCode("huaweip8");
		CAClientservie.getHotRecommendCateList(trader , "iphone5", 4, 6L, 76L);
	}

	@Test
	public void testGetCategoryADHessianCall() {
		CAClientservie.getCategoryADHessianCall();
	}

	@Test
	public void testSetCategoryADHessianCall() {
		CAClientservie.setCategoryADHessianCall(categoryADHessianCall);
	}

}
