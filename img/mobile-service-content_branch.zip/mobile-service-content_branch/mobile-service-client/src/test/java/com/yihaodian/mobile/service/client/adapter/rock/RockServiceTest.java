package com.yihaodian.mobile.service.client.adapter.rock;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.service.rock.RockClientService;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.product.spi.IProductSignService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class RockServiceTest extends BaseTest{
	RockService rock = new RockService();
	@Test
	public void testGetRockPromotionInfo() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		RockClientService service = PowerMockito.mock(RockClientService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getRockClientService()).thenReturn(service);
		PowerMockito.when(service.getRockPromotionInfo(Mockito.anyString(), Mockito.anyLong(), Mockito.anyInt())).thenReturn(null);
		bizInfo.put("activityid", "1");
		rock.getRockPromotionInfo(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetWinnersList() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		RockClientService service = PowerMockito.mock(RockClientService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getRockClientService()).thenReturn(service);
		PowerMockito.when(service.getWinnersList(Mockito.anyString())).thenReturn(null);
		bizInfo.put("activityid", "1");
		rock.getWinnersList(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testDoShaking() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		RockClientService service = PowerMockito.mock(RockClientService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getRockClientService()).thenReturn(service);
		PowerMockito.when(service.doShaking(Mockito.anyLong(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt())).thenReturn(null);
		bizInfo.put("activityid", "1");
		bizInfo.put("devicetoken", "1");
		bizInfo.put("explodesecindex", "1");
		rock.doShaking(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testAcceptAward() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		RockClientService service = PowerMockito.mock(RockClientService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getRockClientService()).thenReturn(service);
		PowerMockito.when(service.acceptAward(Mockito.anyLong(), Mockito.anyString(),Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		bizInfo.put("activityid", "1");
		bizInfo.put("devicetoken", "1");
		bizInfo.put("awardid", "1");
		bizInfo.put("isdiscard", "1");
		bizInfo.put("isdiscard", "1");
		bizInfo.put("explodesecindex", "1");
		
		rock.acceptAward(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetUsersForPush() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		RockClientService service = PowerMockito.mock(RockClientService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getRockClientService()).thenReturn(service);
		PowerMockito.when(service.getUsersForPush(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		bizInfo.put("startminutetime", "1");
		bizInfo.put("step", "1");
		rock.getUsersForPush(urlPath, isLogined, bizInfo, content);
		//PowerMockito.when(service.getUsersForPush(startMin, step)).thenReturn(null);
		//rock
	}

	@Test
	public void testGetNewTimeStart() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		RockClientService service = PowerMockito.mock(RockClientService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getRockClientService()).thenReturn(service);
		PowerMockito.when(service.getNewTimeStart(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		bizInfo.put("newsecindex", "1");
		bizInfo.put("trrigercount", "1");
		rock.getNewTimeStart(urlPath, isLogined, bizInfo, content);
	}

}
