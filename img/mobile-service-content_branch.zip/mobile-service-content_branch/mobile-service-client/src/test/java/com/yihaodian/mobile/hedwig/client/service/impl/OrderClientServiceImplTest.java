package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.hedwig.core.service.spi.OrderService;

public class OrderClientServiceImplTest {
	OrderClientServiceImpl orderClientServiceImpl = new OrderClientServiceImpl();
	@Mock
	OrderService orderHessiancall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(orderClientServiceImpl, "orderHessiancall", orderHessiancall);
	}
	@Test
	public void test() {
//		orderClientServiceImpl.aliPaySignature(, null);
//		orderClientServiceImpl.aliPaySignatureV2(null, null);
//		orderClientServiceImpl.aliPaySignatureV2(null, null, null);
//		orderClientServiceImpl.CUPSignature(null, null);
		orderClientServiceImpl.setOrderHessiancall(orderHessiancall);
		orderClientServiceImpl.getOrderHessiancall();
	}

}
