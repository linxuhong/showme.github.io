package com.yihaodian.mobile.service.client.adapter.dailybuy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.alibaba.fastjson.JSON;
import com.yihaodian.mobile.backend.dailybuy.entity.DailyBuyComment;
import com.yihaodian.mobile.backend.dailybuy.vo.DailyBuyCommentInfo;
import com.yihaodian.mobile.backend.dailybuy.vo.DailyBuyCommentVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.hedwig.push.spi.IDailyBuyService;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;


@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class DailyBuyDispatchServiceTest extends BaseTest{
	DailyBuyDispatchService dailyBuyDispatchService = new DailyBuyDispatchService();
	
	@Test
	public void testgetTopicById(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getTopicById_v2(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(service.getTopicById_v3(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(service.getTopicById(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("topicid", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("topicid", "ad");
		this.dailyBuyDispatchService.getTopicById("12/v2", true, bizInfo, content);
		this.dailyBuyDispatchService.getTopicById("12/v3", true, bizInfo1, content);
		this.dailyBuyDispatchService.getTopicById("12/v", true, bizInfo, content);
		this.dailyBuyDispatchService.getTopicById("12/v2", true, bizInfo, content);
		this.dailyBuyDispatchService.getTopicById("12/v3", true, bizInfo, content);
	}
	
	@Test
	public void testpraiseTopic(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.praiseTopic(Mockito.anyLong(),Mockito.anyString(),Mockito.anyString())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("praise", "12");
		bizInfo.put("topicid", "ad");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("praise", "12");
		bizInfo1.put("topicid", "12");
		
		this.dailyBuyDispatchService.praiseTopic(urlPath, false, bizInfo, content);
		this.dailyBuyDispatchService.praiseTopic(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.praiseTopic(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testgetCategory(){
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getCategory()).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.dailyBuyDispatchService.getCategory(urlPath, true, bizInfo, context);
	}
	
	@Test
	public void testgetTopicByCategoryId(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getTopicByCategoryId(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("startpage", "12");
		bizInfo2.put("categoryid", "-1");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("praise", "12");
		bizInfo1.put("startpage", "ab");
		bizInfo1.put("categoryid", "12");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("startpage", "12");
		bizInfo3.put("categoryid", "12");	
		this.dailyBuyDispatchService.getTopicByCategoryId(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.getTopicByCategoryId(urlPath, true, bizInfo1, content);
		this.dailyBuyDispatchService.getTopicByCategoryId(urlPath, false, bizInfo2, content);
		this.dailyBuyDispatchService.getTopicByCategoryId(urlPath, true, bizInfo3, content);
	}
	
	@Test
	public void testgetTopicByCategoryIds(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getTopicByCategoryIds(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("startpage", "12");
		bizInfo2.put("categoryids", "-1");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("praise", "12");
		bizInfo1.put("startpage", "ab");
		bizInfo1.put("categoryids", "12");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("startpage", "12");
		bizInfo3.put("categoryids", "12");	
		this.dailyBuyDispatchService.getTopicByCategoryIds(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.getTopicByCategoryIds(urlPath, true, bizInfo1, content);
		this.dailyBuyDispatchService.getTopicByCategoryIds(urlPath, false, bizInfo2, content);
		this.dailyBuyDispatchService.getTopicByCategoryIds(urlPath, true, bizInfo3, content);
	}
	
	@Test
	public void testgetTopicByAllCategory(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getTopicByAllCategory(Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.dailyBuyDispatchService.getTopicByAllCategory(urlPath, isLogined, bizInfo, content);
	}
	
	@Test
	public void testgetTopicWithVideo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getTopicWithVideo(Mockito.anyLong(),Mockito.isA(Integer.class),Mockito.anyInt(),Mockito.anyInt())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("startpage", "12");
		bizInfo2.put("praised", "1");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("praised", "12");
		bizInfo1.put("startpage", "ab");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("startpage", "12");
		bizInfo3.put("praised", "12");	
		this.dailyBuyDispatchService.getTopicWithVideo(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.getTopicWithVideo(urlPath, true, bizInfo1, content);
		this.dailyBuyDispatchService.getTopicWithVideo(urlPath, false, bizInfo2, content);
		this.dailyBuyDispatchService.getTopicWithVideo(urlPath, true, bizInfo3, content);
	}
	
	@Test
	public void testgetCommentPage(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getCommentPage(Mockito.anyLong(),Mockito.anyLong(),Mockito.isA(Integer.class),Mockito.isA(Integer.class),Mockito.isA(Integer.class),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		Page<DailyBuyCommentInfo> page = new Page<DailyBuyCommentInfo>();
		java.util.List<DailyBuyCommentInfo> list = new ArrayList<DailyBuyCommentInfo>();
		DailyBuyCommentInfo dailyBuyCommentInfo = new DailyBuyCommentInfo();
		list.add(dailyBuyCommentInfo);
		page.setObjList(list);
		PowerMockito.when(result.getDefaultModel()).thenReturn(page);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("startpage", "12");
		bizInfo2.put("pagesize", "12");
		bizInfo2.put("type", "1");
		bizInfo2.put("userid", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("type", "2");
		bizInfo1.put("pagesize", "12");
		bizInfo1.put("startpage", "ab");
		bizInfo1.put("userid", "ab");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("startpage", "ab");
		bizInfo3.put("pagesize", "12");
		bizInfo3.put("type", "12");
		Map<String, String> bizInfo4 = new HashMap<String, String>();
		bizInfo4.put("startpage", "12");
		bizInfo4.put("pagesize", "ab");
		bizInfo4.put("type", "12");
		Map<String, String> bizInfo5 = new HashMap<String, String>();
		bizInfo5.put("startpage", "12");
		bizInfo5.put("pagesize", "12");
		bizInfo5.put("type", "12");
		this.dailyBuyDispatchService.getCommentPage(urlPath, false, bizInfo1, content);
		this.dailyBuyDispatchService.getCommentPage(urlPath, true, bizInfo2, content);
		this.dailyBuyDispatchService.getCommentPage(urlPath, true, bizInfo3, content);
		this.dailyBuyDispatchService.getCommentPage(urlPath, true, bizInfo4, content);
		this.dailyBuyDispatchService.getCommentPage(urlPath, true, bizInfo5, content);
	}
	
	@Test
	public void testpraiseComment(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.praiseComment(Mockito.anyLong(),Mockito.anyLong(),Mockito.isA(Integer.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("cancel", "12");
		bizInfo.put("commentid", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("cancel", "ab");
		bizInfo1.put("commentid", "12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("cancel", "12");
		bizInfo2.put("commentid", "ab");
		this.dailyBuyDispatchService.praiseComment(urlPath, false, bizInfo, content);
		this.dailyBuyDispatchService.praiseComment(urlPath, true, bizInfo1, content);
		this.dailyBuyDispatchService.praiseComment(urlPath, true, bizInfo2, content);
		this.dailyBuyDispatchService.praiseComment(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testdeleteComment(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.deleteComment(Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("commentid", "ab");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("commentid", "12");
		this.dailyBuyDispatchService.deleteComment(urlPath, false, bizInfo, content);
		this.dailyBuyDispatchService.deleteComment(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.deleteComment(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testvisitComment(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.visitComment(Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("commentid", "ab");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("commentid", "12");
		this.dailyBuyDispatchService.visitComment(urlPath, false, bizInfo, content);
		this.dailyBuyDispatchService.visitComment(urlPath, false, bizInfo1, content);
	}
	
	@Test
	public void testsubmitComment(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.submitComment(Mockito.isA(DailyBuyComment.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		DailyBuyCommentVO commentInfo = new DailyBuyCommentVO();
		commentInfo.setContent("12");
		commentInfo.setPhoto("12");
		commentInfo.setPminfoId(12l);
		commentInfo.setProductCode("12");
		commentInfo.setProductId(12l);
		commentInfo.setSource(12l);
		Map<String, String> bizInfo = new HashMap<String, String>();
		String comment = JSON.toJSONString(commentInfo);
		bizInfo.put("comment", comment);
		Map<String, String> bizInfo1 = new HashMap<String, String>();
	    this.dailyBuyDispatchService.submitComment(urlPath, false, bizInfo1, content);
	    this.dailyBuyDispatchService.submitComment(urlPath, true, bizInfo1, content);
	    this.dailyBuyDispatchService.submitComment(urlPath, true, bizInfo1, content);
	    this.dailyBuyDispatchService.submitComment(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetCommentInfo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getCommentInfo(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("commentid", "ab");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("commentid", "12");
		this.dailyBuyDispatchService.getCommentInfo(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.getCommentInfo(urlPath, true, bizInfo1, content);
		this.dailyBuyDispatchService.getCommentInfo(urlPath, true, bizInfo1, content);
		this.dailyBuyDispatchService.getCommentInfo(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testgetPraisePage(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getPraisePage(Mockito.anyLong(),Mockito.anyLong(),Mockito.isA(Integer.class),Mockito.isA(Integer.class),Mockito.isA(Integer.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("threadid", "12");
		bizInfo.put("type", "12");
		bizInfo.put("pagenumber", "12");
		bizInfo.put("pagesize", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("threadid", "ab");
		bizInfo1.put("type", "12");
		bizInfo1.put("pagenumber", "12");
		bizInfo1.put("pagesize", "12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("threadid", "12");
		bizInfo2.put("type", "ab");
		bizInfo2.put("pagenumber", "12");
		bizInfo2.put("pagesize", "12");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("threadid", "12");
		bizInfo3.put("type", "12");
		bizInfo3.put("pagenumber", "ab");
		bizInfo3.put("pagesize", "12");
		Map<String, String> bizInfo4 = new HashMap<String, String>();
		bizInfo4.put("threadid", "12");
		bizInfo4.put("type", "12");
		bizInfo4.put("pagenumber", "12");
		bizInfo4.put("pagesize", "ab");
		this.dailyBuyDispatchService.getPraisePage(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.getPraisePage(urlPath, true, bizInfo1, content);
		this.dailyBuyDispatchService.getPraisePage(urlPath, true, bizInfo2, content);
		this.dailyBuyDispatchService.getPraisePage(urlPath, true, bizInfo3, content);
		this.dailyBuyDispatchService.getPraisePage(urlPath, true, bizInfo4, content);
	}
	
	@Test
	public void testgetReplyPage(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getReplyPage(Mockito.anyLong(),Mockito.anyLong(),Mockito.isA(Integer.class),Mockito.isA(Integer.class),Mockito.isA(Integer.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("threadid", "12");
		bizInfo.put("type", "12");
		bizInfo.put("pagenumber", "12");
		bizInfo.put("pagesize", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("threadid", "ab");
		bizInfo1.put("type", "12");
		bizInfo1.put("pagenumber", "12");
		bizInfo1.put("pagesize", "12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("threadid", "12");
		bizInfo2.put("type", "ab");
		bizInfo2.put("pagenumber", "12");
		bizInfo2.put("pagesize", "12");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("threadid", "12");
		bizInfo3.put("type", "12");
		bizInfo3.put("pagenumber", "ab");
		bizInfo3.put("pagesize", "12");
		Map<String, String> bizInfo4 = new HashMap<String, String>();
		bizInfo4.put("threadid", "12");
		bizInfo4.put("type", "12");
		bizInfo4.put("pagenumber", "12");
		bizInfo4.put("pagesize", "ab");
		this.dailyBuyDispatchService.getReplyPage(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.getReplyPage(urlPath, true, bizInfo1, content);
		this.dailyBuyDispatchService.getReplyPage(urlPath, true, bizInfo2, content);
		this.dailyBuyDispatchService.getReplyPage(urlPath, true, bizInfo3, content);
		this.dailyBuyDispatchService.getReplyPage(urlPath, true, bizInfo4, content);
	}
	
	@Test
	public void testdeleteReply(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.deleteReply(Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("replyid", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("replyid", "ab");
		this.dailyBuyDispatchService.deleteReply(urlPath, false, bizInfo, content);
		this.dailyBuyDispatchService.deleteReply(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.deleteReply(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testreplyTopicOrComment(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.replyTopicOrComment(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString(),Mockito.isA(Integer.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("userid", "12");
		bizInfo.put("content", "12");
		bizInfo.put("threadid", "12");
		bizInfo.put("type", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("threadid", "ab");
		bizInfo1.put("type", "12");
		bizInfo1.put("pagenumber", "12");
		bizInfo1.put("pagesize", "12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("threadid", "12");
		bizInfo2.put("type", "ab");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("userid", "12");
		bizInfo3.put("threadid", "12");
		bizInfo3.put("type", "12");
		this.dailyBuyDispatchService.replyTopicOrComment(urlPath, false, bizInfo, content);
		this.dailyBuyDispatchService.replyTopicOrComment(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.replyTopicOrComment(urlPath, true, bizInfo1, content);
		this.dailyBuyDispatchService.replyTopicOrComment(urlPath, true, bizInfo2, content);
		this.dailyBuyDispatchService.replyTopicOrComment(urlPath, true, bizInfo3, content);
	}
	
	@Test
	public void testgetEndUserInfo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IDailyBuyService service = PowerMockito.mock(IDailyBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getDailyBuyService()).thenReturn(service);
		PowerMockito.when(service.getEndUserInfo(Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("userid", "ab");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("userid", "12");
		this.dailyBuyDispatchService.getEndUserInfo(urlPath, true, bizInfo, content);
		this.dailyBuyDispatchService.getEndUserInfo(urlPath, false, bizInfo, content);
		this.dailyBuyDispatchService.getEndUserInfo(urlPath, false, bizInfo1, content);
	}
}
