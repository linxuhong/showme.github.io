package com.yihaodian.mobile.service.client.adapter.questionnaire;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.questionnaire.QuestionnaireService;
import com.yihaodian.mobile.service.facade.product.spi.IProductSignService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class QuestionnaireDispatchServiceTest extends BaseTest{
	QuestionnaireDispatchService questionnaireDispatchService = new QuestionnaireDispatchService();
	@Test
	public void testGetQuestionnaireSwitch() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		QuestionnaireService service = PowerMockito.mock(QuestionnaireService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getQuestionnaireService()).thenReturn(service);
	    PowerMockito.when(service.getQuestionnaireSwitch(Mockito.any(ClientInfoVO.class), Mockito.anyString(), Mockito.anyInt())).thenReturn(null);
	    questionnaireDispatchService.getQuestionnaireSwitch(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testSkipQuestionnaire() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		QuestionnaireService service = PowerMockito.mock(QuestionnaireService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getQuestionnaireService()).thenReturn(service);
	    PowerMockito.when(service.skipQuestionnaire(Mockito.any(ClientInfoVO.class), Mockito.anyLong())).thenReturn(null);
		questionnaireDispatchService.skipQuestionnaire(urlPath, isLogined, bizInfo, content);
	}

}
