package com.yihaodian.mobile.service.client.pay.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.pay.IPayPreService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class PayPreClientServiceImplTest {
	private PayPreClientServiceImpl PayPreClientServiceImpl = new PayPreClientServiceImpl();
	@Mock
	private IPayPreService payPreHessianCall;  

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(PayPreClientServiceImpl, "payPreHessianCall", payPreHessianCall);
	}

	@Test
	public void testSetPayPreHessianCall() {
		PayPreClientServiceImpl.setPayPreHessianCall(payPreHessianCall);
	}

	@Test
	public void testGetPayPreInfoStringLong() {
		PayPreClientServiceImpl.getPayPreInfo("yhd_token", 34L);
	}

	@Test
	public void testAutoSwitchGateWayStringLongClientInfoVOInteger() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.9,90");
		clientInfoVO.setClientSystem("Andorid3.9");
		clientInfoVO.setDeviceCode("iphone");
		PayPreClientServiceImpl.autoSwitchGateWay("yhd_token", 34L, clientInfoVO , 4);
	}

	@Test
	public void testAutoSwitchGateWayLongLongClientInfoVOInteger() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.9,90");
		clientInfoVO.setClientSystem("Andorid3.9");
		clientInfoVO.setDeviceCode("iphone");
		PayPreClientServiceImpl.autoSwitchGateWay(34L, 23L, clientInfoVO, 3);
	}

	@Test
	public void testGetPayPreInfoLongLong() {
		PayPreClientServiceImpl.getPayPreInfo(34L, 35L);
	}

	@Test
	public void testGetPayGatePromotionInfo() {
		PayPreClientServiceImpl.getPayGatePromotionInfo();
	}

	@Test
	public void testGetPayGatePromotionTip() {
		PayPreClientServiceImpl.getPayGatePromotionTip();
	}

}
