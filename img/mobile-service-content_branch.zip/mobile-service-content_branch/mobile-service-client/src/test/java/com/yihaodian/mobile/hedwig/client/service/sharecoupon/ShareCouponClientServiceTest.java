package com.yihaodian.mobile.hedwig.client.service.sharecoupon;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;

public class ShareCouponClientServiceTest {
	ShareCouponClientService shareCouponClientService = new ShareCouponClientService();
	@Mock
	IShareCouponService shareCouponHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(shareCouponClientService, "shareCouponHessianCall", shareCouponHessianCall);
	}
	@Test
	public void test() {
		
//		shareCouponClientService.setShareCouponHessianCall(shareCouponHessianCall);
//		shareCouponClientService.shareCoupon(null);
//		shareCouponClientService.getReceiveCouponCount(null);
//		shareCouponClientService.getShareCouponDetail(null);
//		shareCouponClientService.getShareCouponHessianCall();
//		shareCouponClientService.getShareCouponPage(null);
//		shareCouponClientService.getShareCouponPageForWechat(null);
//		shareCouponClientService.getShareCouponUrl(null);
	}

}
