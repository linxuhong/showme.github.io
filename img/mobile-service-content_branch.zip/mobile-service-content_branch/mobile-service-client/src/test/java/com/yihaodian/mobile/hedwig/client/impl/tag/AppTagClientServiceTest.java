package com.yihaodian.mobile.hedwig.client.impl.tag;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.client.impl.dailybuy.DailyBuyClientService;
import com.yihaodian.mobile.hedwig.client.service.tag.AppTagClientService;
import com.yihaodian.mobile.hedwig.push.spi.IDailyBuyService;
import com.yihaodian.mobile.service.facade.business.tag.IAppTagService;

/**  
 * @author myx
 * @createTime 2016年5月25日 下午3:09:22  
 * 
 */
public class AppTagClientServiceTest {
	
private  AppTagClientService  appTagClientService =new AppTagClientService();
	
	@Mock
	private IAppTagService appTagServiceHessianCall;

	@Before
	public void initMock() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(appTagClientService, "appTagServiceHessianCall", appTagServiceHessianCall);
	}

	@Test
	public void testAppTagServiceHessianCall() {
		appTagClientService.setAppTagServiceHessianCall(appTagServiceHessianCall);
	
	}
	
	@Test
	public void testGetAppTagConfigRule() {
		appTagClientService.getAppTagConfigRule();
	}

}
