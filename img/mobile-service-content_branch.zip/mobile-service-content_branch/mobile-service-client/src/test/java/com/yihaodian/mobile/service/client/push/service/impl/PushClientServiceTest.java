package com.yihaodian.mobile.service.client.push.service.impl;


import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.push.PushService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.wl2.ClientInfo;

public class PushClientServiceTest {
	private PushClientService pushClientService = new PushClientService();
	@Mock
	 private PushService pushServiceHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(pushClientService, "pushServiceHessianCall", pushServiceHessianCall);
	}

	@Test
	public void testSetPushServiceHessianCall() {
		pushClientService.setPushServiceHessianCall(pushServiceHessianCall);
	}

	@Test
	public void testMessageOpenTraderLongLongLongInteger() {

		Integer promotionType = 3;
		Long promotionId = 87L;
		Long pageId = 45L;
		Date date = new Date();
		Long openTime = date.getTime();
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("android5.0");
		trader.setDeviceCode("iphone7");
		pushClientService.messageOpen(trader, openTime, pageId, promotionId, promotionType);
	}


	@Test
	public void testCreateAppPushInfo() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("android5.0");
		trader.setDeviceCode("iphone7");
		pushClientService.createAppPushInfo(trader, 34L);
	}

	@Test
	public void testStoreUserInfoLongTrader() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("android5.0");
		trader.setDeviceCode("iphone7");
		pushClientService.storeUserInfo(34L, trader);
	}

	@Test
	public void testMessageOpenTraderLongLongLongIntegerLong() {
		Integer promotionType = 3;
		Long promotionId = 87L;
		Long pageId = 45L;
		Date date = new Date();
		Long openTime = date.getTime();
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("android5.0");
		trader.setDeviceCode("iphone7");
		pushClientService.messageOpen(trader, openTime, pageId, promotionId, promotionType, 23L);
	}

	@Test
	public void testLogReportingTraderLongLong() {
		Date date = new Date();
		Long sendTime = date.getTime();
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("android5.0");
		trader.setDeviceCode("iphone7");
		pushClientService.logReporting(trader, sendTime, 45L);
	}

	@Test
	public void testGetPushInformationTraderLong() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("android5.0");
		trader.setDeviceCode("iphone7");
		pushClientService.getPushInformation(trader, 45L);
	}

	@Test
	public void testStoreUserPushMapping() {
		ClientInfo clientInfo = new ClientInfo();
		clientInfo.setClientAppVersion("v2.0");
		clientInfo.setClientIp("192.168.4.34");
		clientInfo.setDeviceCode("iphone5");
		String deviceToken = "yhd_p6_token";
		pushClientService.storeUserPushMapping(34L, clientInfo, deviceToken );
	}

}
