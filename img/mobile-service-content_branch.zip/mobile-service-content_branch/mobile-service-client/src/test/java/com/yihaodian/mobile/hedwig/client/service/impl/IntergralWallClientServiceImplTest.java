package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.integral.IintergralWallService;

public class IntergralWallClientServiceImplTest {
	IntergralWallClientServiceImpl IntergralWallClientServiceImpl = new IntergralWallClientServiceImpl();
	@Mock
	IintergralWallService intergralWallHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(IntergralWallClientServiceImpl, "intergralWallHessianCall", intergralWallHessianCall);
	}
	@Test
	public void test() {
		IntergralWallClientServiceImpl.registerIntergralWallInfo(null, null, null, null);
		IntergralWallClientServiceImpl.activatingIntergralWallInfo(null, null, null, null,null);
		IntergralWallClientServiceImpl.getIntergralWallHessianCall();
		IntergralWallClientServiceImpl.setIntergralWallHessianCall(intergralWallHessianCall);
	}

}
