package com.yihaodian.mobile.service.client.push.service.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.domain.vo.business.push.OpenMessageParamVO;
import com.yihaodian.mobile.service.facade.business.push.IPushMessageStatisticsService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class PushMessageStatisticsClientServiceTest {
	private PushMessageStatisticsClientService PMSClientService  = new PushMessageStatisticsClientService();
	
	@Mock
	private IPushMessageStatisticsService pushMessageStatisticsHessianCall; 

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(PMSClientService, "pushMessageStatisticsHessianCall", pushMessageStatisticsHessianCall);
	}

	@Test
	public void testSetPushMessageStatisticsHessianCall() {
		PMSClientService.setPushMessageStatisticsHessianCall(pushMessageStatisticsHessianCall);
		}

	@Test
	public void testMessageStatistics() {
		ClientInfoVO clientInfoVo = new ClientInfoVO();
		clientInfoVo.setClientAppVersion("v4.o");
		clientInfoVo.setClientip("192.168.3.67");
		clientInfoVo.setDeviceCode("huaweip8");
		Long openTime = (new Date()).getTime();
		OpenMessageParamVO opv = new OpenMessageParamVO();
			opv.setPageId(4L);
			opv.setPromotionId("dacu45");
			opv.setPromotionType("decount");
			opv.setTaskId("taskId");
		List<OpenMessageParamVO> messageList = new ArrayList<OpenMessageParamVO>();
		messageList.add(opv);
	
		String deviceToken = "yhd_p6_token";
		Long userId = 34L;
		Integer type = 5;
		PMSClientService.messageStatistics(clientInfoVo, openTime, messageList, deviceToken, userId, type);
	}

}
