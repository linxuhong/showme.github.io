package com.yihaodian.mobile.hedwig.client.impl.wl2;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.wl2.spi.IWl2Service;
import com.yihaodian.mobile.vo.wl2.ClientInfo;

public class Wl2ServiceClientServiceImplTest {
	private Wl2ServiceClientServiceImpl wl2ServiceClientServiceImpl = new Wl2ServiceClientServiceImpl();
	@Mock
	private IWl2Service wl2HessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(wl2ServiceClientServiceImpl, "wl2HessianCall", wl2HessianCall);
	}

	@Test
	public void testGetSecretKeyByPlat() {
		String plat = "srcretKey";
		wl2ServiceClientServiceImpl.getSecretKeyByPlat(plat,"1" );
	}

	@Test
	public void testGetAppLaunchData() {
		String trader = "trader";
		Boolean hasSonPics = true;
		String startupPicSize = "staetUpPicsize";
		ClientInfo client = new ClientInfo();
		client.setClientAppVersion("v1.0");
		client.setClientIp("192.168.56.23");
		client.setClientVersion("v2.0");
		wl2ServiceClientServiceImpl.getAppLaunchData(client, startupPicSize, hasSonPics, trader,"1",null );
	}

	@Test
	public void testGetWl2HessianCall() {
		wl2ServiceClientServiceImpl.getWl2HessianCall();
	}

	@Test
	public void testSetWl2HessianCall() {
		wl2ServiceClientServiceImpl.setWl2HessianCall(wl2HessianCall);
	}

}
