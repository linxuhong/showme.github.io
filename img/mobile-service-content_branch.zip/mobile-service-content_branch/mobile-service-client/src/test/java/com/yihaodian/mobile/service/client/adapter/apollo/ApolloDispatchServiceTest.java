package com.yihaodian.mobile.service.client.adapter.apollo;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.service.impl.ApolloPromotionClientServiceImpl;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.apollo.IApolloPromotionService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class ApolloDispatchServiceTest extends BaseTest{
	ApolloDispatchService service = new ApolloDispatchService();
	
	
	@Test
	public void testGetApolloPromotionInfoByClientLocation() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		IApolloPromotionService mock = PowerMockito.mock(ApolloPromotionClientServiceImpl.class);
		PowerMockito.when(CentralMobileServiceHandler.getApolloPromotionService()).thenReturn(mock);
		PowerMockito.doReturn(null).when(mock).getApolloPromotionInfoByClientLocation(null, null);
		
		service.getApolloPromotionInfoByClientLocation(urlPath, isLogined, bizInfo, content);
		
		bizInfo.put("cityname", "shanghai");
		service.getApolloPromotionInfoByClientLocation(urlPath, isLogined, bizInfo, content);
	}

}
