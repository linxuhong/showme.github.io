package com.yihaodian.mobile.service.client.adapter;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.DispatchAdapter;
import com.yihaodian.mobile.service.client.adapter.service.impl.DispatchAdapterService;
import com.yihaodian.mobile2.server.context.Context;
import com.yihaodian.mobile2.server.context.RtnInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class DispatchAdapterTest {
	DispatchAdapter a = new DispatchAdapter();
	@Mock
	DispatchAdapterService dispatchAdapterService;
	
	 @Before
	    public void initMocks(){
	    	ReflectionTestUtils.setField(a, "dispatchAdapterService", dispatchAdapterService);
	 }
	String urlPath = "/mobileservice/isWeiDianHasDevice";
	boolean isLogined = true;
	Map<String, String> bizInfo = new HashMap<String, String>();
	
	Context context = null;

	@Test
	public void test() {
		bizInfo.put("vuserId", "4");
		PowerMockito.when(dispatchAdapterService.execute(urlPath, isLogined, bizInfo, context)).thenReturn(null);
		RtnInfo rtInfo = a.execute(urlPath, isLogined, bizInfo, context, 0L);
		a.getDispatchAdapterService();
		a.setDispatchAdapterService(null);
	}

}
