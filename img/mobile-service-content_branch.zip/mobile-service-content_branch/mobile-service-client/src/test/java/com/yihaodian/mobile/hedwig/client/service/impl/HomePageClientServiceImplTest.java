package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.HomePageService;


public class HomePageClientServiceImplTest {
	HomePageClientServiceImpl homePageClientService = new HomePageClientServiceImpl();
	
	@Mock
	HomePageService homePageHessianCall;
	
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(homePageClientService, "homePageHessianCall", homePageHessianCall);
	}


	@Test
	public void testGetCalendarBuyDetail() {
		homePageClientService.getCalendarBuyDetail(null, null, null);
	}


	@Test
	public void testGetCmsColumnDetail() {
		homePageClientService.getCmsColumnDetail(null, null, null, null, null, null);
	}


	@Test
	public void testGetCalendarBuyProductList() {
		homePageClientService.getCalendarBuyProductList(null, null, null);
	}

	@Test
	public void testGetBrandShopPromotion() {
		homePageClientService.getBrandShopPromotion(null, null);
	}


	@Test
	public void testGetMobileIndexViewForBI() {
		homePageClientService.getMobileIndexViewForBI(null, null);
	}


	@Test
	public void testGetMobileIndexViewByType() {
		homePageClientService.getMobileIndexViewByType(null, null, null);
	}

	@Test
	public void testGetMobileViewById() {
		homePageClientService.getMobileViewById(null, null, null);
	}

	@Test
	public void testGetHomePageHessianCall() {
		homePageClientService.getHomePageHessianCall();
	}

	@Test
	public void testSetHomePageHessianCall() {
		homePageClientService.setHomePageHessianCall(homePageHessianCall);
	}

}
