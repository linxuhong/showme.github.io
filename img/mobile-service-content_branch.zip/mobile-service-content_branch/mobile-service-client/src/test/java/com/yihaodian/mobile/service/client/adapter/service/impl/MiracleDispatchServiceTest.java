package com.yihaodian.mobile.service.client.adapter.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MiracleService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class MiracleDispatchServiceTest extends BaseTest{
	MiracleDispatchService miracleDispatchService = new MiracleDispatchService();
	@Test
	public void testMiracleAutoRegister() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		MiracleService service = PowerMockito.mock(MiracleService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMiracleService()).thenReturn(service);
		PowerMockito.when(service.miracleAutoRegister(Mockito.any(Trader.class), Mockito.anyString())).thenReturn(null);
		bizInfo.put("regid", "1");
		miracleDispatchService.miracleAutoRegister(urlPath, isLogined, bizInfo, content);
	}

}
