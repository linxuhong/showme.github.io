package com.yihaodian.mobile.service.client.maps.service.impl;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.front.shopping.interfaces.vo.CommInputVo;
import com.yihaodian.mobile.service.map.spi.MapsFrontService;

public class MapsFrontClientServiceTest {
	private MapsFrontClientService MFClientService = new MapsFrontClientService();
	@Mock
	private MapsFrontService mapsFrontServiceHessianCall ;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(MFClientService, "mapsFrontServiceHessianCall", mapsFrontServiceHessianCall);
	}

	@Test
	public void testLoadCachedPage() {
		MFClientService.loadCachedPage(45L, 34L);
	}

	@Test
	public void testLoadCachedProducts() {
		MFClientService.loadCachedProducts(34L, 3L, 4, 5);
		}

	@Test
	public void testLoadCachedPageEntitys() {
		MFClientService.loadCachedPageEntitys("png", 56L, 66, 93);
	}

	@Test
	public void testUserGetCouponFromActivity() {
		MFClientService.userGetCouponFromActivity(45L, "meishi", 45L);
	}

	@Test
	public void testClearCachedPage() {
		MFClientService.clearCachedPage(45L);
	}

	@Test
	public void testClearCachedProduct() {
		MFClientService.clearCachedProduct(45L, 4L);
	}

	@Test
	public void testClearCachedEntitys() {
		MFClientService.clearCachedEntitys("imag", 45L);
	}

	@Test
	public void testGetMapsFrontServiceHessianCall() {
		MFClientService.getMapsFrontServiceHessianCall();
	}

	@Test
	public void testSetMapsFrontServiceHessianCall() {
		MFClientService.setMapsFrontServiceHessianCall(mapsFrontServiceHessianCall);
	}

	@Test
	public void testSearchPage() {
		MFClientService.searchPage(34L, 4L, "meishi", 4);
	}

	@Test
	public void testAddNormal() {
		CommInputVo inputoVo = new CommInputVo();
		inputoVo.setClientAppVersion("v1.2");
		inputoVo.setClientIp("192.168.3.243");
		inputoVo.setDeviceCode("huaweip7");
		inputoVo.setTradeName("大促销");
		MFClientService.addNormal(inputoVo , 45L, 453L, 765);
	}

	@Test
	public void testAddPromotion() {
		CommInputVo inputoVo = new CommInputVo();
		inputoVo.setClientAppVersion("v1.2");
		inputoVo.setClientIp("192.168.3.243");
		inputoVo.setDeviceCode("huaweip7");
		inputoVo.setTradeName("大促销");
		
		Map<String, Integer> pmIdNums = new HashMap<String, Integer>();
		pmIdNums.put("dacue39", 345);
		Long merchantId = 45L;
		Long promotionLevelId = 34L;
		MFClientService.addPromotion(inputoVo, 45L, 5, 457L, promotionLevelId, merchantId, pmIdNums);
	}

	@Test
	public void testLoadGrouponBrandVO() {
		MFClientService.loadGrouponBrandVO(45L);
	}

}
