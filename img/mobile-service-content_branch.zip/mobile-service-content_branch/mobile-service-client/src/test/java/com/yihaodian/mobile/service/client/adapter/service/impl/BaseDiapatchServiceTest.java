package com.yihaodian.mobile.service.client.adapter.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
import com.yihaodian.mobile2.server.context.RequestInfo.ClientInfo;

public class BaseDiapatchServiceTest extends BaseTest {
	BaseDiapatchService baseDiapatchService = new BaseDiapatchService();
	@Test
	public void testGetTraderFromContext() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		baseDiapatchService.getTraderFromContext(content);
	}


	@Test
	public void testConvertClientInfoVO() {
		baseDiapatchService.convertClientInfoVO(clientInfo);
	}

	@Test
	public void testGetRtnInfo() {
		baseDiapatchService.getRtnInfo(null);

	}

	@Test
	public void testGetSystemErrorResult() {
		baseDiapatchService.getSystemErrorResult();
	}

	@Test
	public void testVaildateTrader() {
		Trader trader = new Trader();
		baseDiapatchService.vaildateTrader(trader);
		baseDiapatchService.vaildateTrader(null);
		trader.setTraderName("a");
		baseDiapatchService.vaildateTrader(trader);
	}

	@Test
	public void testValidateProvinceId() {
		baseDiapatchService.validateProvinceId("1");
		baseDiapatchService.validateProvinceId("a");
	}

	@Test
	public void testValidatePageInfo() {
		baseDiapatchService.validatePageInfo("1", "1");
		baseDiapatchService.validatePageInfo("1", "q");
	}

	@Test
	public void testValidateNumber() {
		baseDiapatchService.validateNumber("1");
		baseDiapatchService.validateNumber("a");
	}

	@Test
	public void testValiateGetParams() {
		baseDiapatchService.valiateGetParams("1");
		baseDiapatchService.valiateGetParams("");
	}

}
