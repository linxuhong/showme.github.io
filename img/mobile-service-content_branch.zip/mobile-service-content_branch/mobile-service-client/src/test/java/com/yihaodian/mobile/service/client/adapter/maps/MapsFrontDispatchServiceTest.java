package com.yihaodian.mobile.service.client.adapter.maps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.front.shopping.interfaces.vo.CommInputVo;
import com.yihaodian.mobile.backend.maps.model.PageSearchEntity;
import com.yihaodian.mobile.backend.maps.vo.BizVO;
import com.yihaodian.mobile.backend.maps.vo.GrouponBrandVO;
import com.yihaodian.mobile.backend.maps.vo.PageWholeVO;
import com.yihaodian.mobile.backend.maps.vo.ProductInfoVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.hedwig.push.spi.IDailyBuyService;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.map.spi.MapsFrontService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;


@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class MapsFrontDispatchServiceTest extends BaseTest{
	MapsFrontDispatchService mapsFrontDispatchService = new MapsFrontDispatchService();
	
	@Test
	public void testloadCachedPage(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		MapsFrontService service = PowerMockito.mock(MapsFrontService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PageWholeVO vo = new PageWholeVO();
		PowerMockito.when(CentralMobileServiceHandler.getMapsFrontClientService()).thenReturn(service);
		PowerMockito.when(service.loadCachedPage(Mockito.anyLong(),Mockito.anyLong())).thenReturn(vo);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("pageid", "12");
		this.mapsFrontDispatchService.loadCachedPage(urlPath, true, bizInfo, content);
		this.mapsFrontDispatchService.loadCachedPage(urlPath, true, bizInfo1, content);
	}
	@Test
	public void testloadCachedProducts(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		MapsFrontService service = PowerMockito.mock(MapsFrontService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		List<ProductInfoVO>  list = new ArrayList<ProductInfoVO>();
		PowerMockito.when(CentralMobileServiceHandler.getMapsFrontClientService()).thenReturn(service);
		PowerMockito.when(service.loadCachedProducts(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(list);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("cmsmouldid", "12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("cmsmouldid", "12");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("cmsmouldid", "12");
		bizInfo3.put("startnum","13");
		Map<String, String> bizInfo4 = new HashMap<String, String>();
		bizInfo4.put("cmsmouldid", "12");
		bizInfo4.put("startnum","13");
		bizInfo4.put("endnum","13");
		this.mapsFrontDispatchService.loadCachedProducts(urlPath, true, bizInfo, content);
		this.mapsFrontDispatchService.loadCachedProducts(urlPath, true, bizInfo1, content);
		this.mapsFrontDispatchService.loadCachedProducts(urlPath, true, bizInfo2, content);
		this.mapsFrontDispatchService.loadCachedProducts(urlPath, true, bizInfo3, content);
		this.mapsFrontDispatchService.loadCachedProducts(urlPath, true, bizInfo4, content);
	}
	
	@Test
	public void testloadCachedPageEntitys(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		MapsFrontService service = PowerMockito.mock(MapsFrontService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		List<BizVO> list = new ArrayList<BizVO>();
		PowerMockito.when(CentralMobileServiceHandler.getMapsFrontClientService()).thenReturn(service);
		PowerMockito.when(service.loadCachedPageEntitys(Mockito.anyString(),Mockito.anyLong(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(list);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("entitytype", "12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("entitytype", "12");
		bizInfo2.put("mid", "13");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("entitytype", "12");
		bizInfo3.put("mid", "13");
		bizInfo3.put("startnum", "0");
		Map<String, String> bizInfo4 = new HashMap<String, String>();
		bizInfo4.put("entitytype", "12");
		bizInfo4.put("mid", "13");
		bizInfo4.put("startnum", "0");
		bizInfo4.put("endnum", "10");
		this.mapsFrontDispatchService.loadCachedPageEntitys(urlPath, true, bizInfo, content);
		this.mapsFrontDispatchService.loadCachedPageEntitys(urlPath, true, bizInfo1, content);
		this.mapsFrontDispatchService.loadCachedPageEntitys(urlPath, true, bizInfo2, content);
		this.mapsFrontDispatchService.loadCachedPageEntitys(urlPath, true, bizInfo3, content);
		this.mapsFrontDispatchService.loadCachedPageEntitys(urlPath, true, bizInfo4, content);
	}
	
	@Test
	public void testuserGetCouponFromActivity(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		MapsFrontService service = PowerMockito.mock(MapsFrontService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getMapsFrontClientService()).thenReturn(service);
		PowerMockito.when(service.userGetCouponFromActivity(Mockito.anyLong(),Mockito.anyString(),Mockito.anyLong())).thenReturn("12");
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("mid", "12");
		this.mapsFrontDispatchService.userGetCouponFromActivity(urlPath, false, bizInfo, content);
		this.mapsFrontDispatchService.userGetCouponFromActivity(urlPath, true, bizInfo, content);
		this.mapsFrontDispatchService.userGetCouponFromActivity(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testuserGetCouponFromShop(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		MapsFrontService service = PowerMockito.mock(MapsFrontService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getMapsFrontClientService()).thenReturn(service);
		PowerMockito.when(service.userGetCouponFromShop(Mockito.anyLong(),Mockito.anyString(),Mockito.anyLong())).thenReturn("12");
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("shopid", "12");
		bizInfo1.put("checkcode", "12");
		this.mapsFrontDispatchService.userGetCouponFromShop(urlPath, false, bizInfo, content);
		this.mapsFrontDispatchService.userGetCouponFromShop(urlPath, true, bizInfo, content);
		this.mapsFrontDispatchService.userGetCouponFromShop(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testsearchPage(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		MapsFrontService service = PowerMockito.mock(MapsFrontService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		List<PageSearchEntity> re = new ArrayList<PageSearchEntity>();
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getMapsFrontClientService()).thenReturn(service);
		PowerMockito.when(service.searchPage(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(re);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("provinceid", "12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("provinceid", "12");
		bizInfo2.put("type", "12");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("provinceid", "12");
		bizInfo3.put("type", "12");
		bizInfo3.put("categoryid", "12");
		Map<String, String> bizInfo4 = new HashMap<String, String>();
		bizInfo4.put("provinceid", "12");
		bizInfo4.put("type", "12");
		bizInfo4.put("categoryid", "12");
		bizInfo4.put("keyword", "12");
		this.mapsFrontDispatchService.searchPage(urlPath, true, bizInfo, content);
		this.mapsFrontDispatchService.searchPage(urlPath, true, bizInfo1, content);
		this.mapsFrontDispatchService.searchPage(urlPath, true, bizInfo2, content);
		this.mapsFrontDispatchService.searchPage(urlPath, true, bizInfo3, content);
		this.mapsFrontDispatchService.searchPage(urlPath, true, bizInfo4, content);
	}
	
	@Test
	public void testaddToCart(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		MapsFrontService service = PowerMockito.mock(MapsFrontService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getMapsFrontClientService()).thenReturn(service);
		PowerMockito.when(service.addNormal(Mockito.isA(CommInputVo.class),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyInt())).thenReturn(result);
		PowerMockito.when(service.addPromotion(Mockito.isA(CommInputVo.class),Mockito.anyLong(),Mockito.anyInt(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyMap())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("producttype", "normal");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("producttype", "normal");
		bizInfo2.put("provinceid", "12");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("producttype", "normal");
		bizInfo3.put("provinceid", "12");
		bizInfo3.put("pmid", "12");
		Map<String, String> bizInfo4 = new HashMap<String, String>();
		bizInfo4.put("producttype", "normal");
		bizInfo4.put("provinceid", "12");
		bizInfo4.put("pmid", "12");
		bizInfo4.put("promotionid", "12");
		Map<String, String> bizInfo5 = new HashMap<String, String>();
		bizInfo5.put("producttype", "normal");
		bizInfo5.put("provinceid", "12");
		bizInfo5.put("pmid", "12");
		bizInfo5.put("promotionid", "12");
		bizInfo5.put("merchantid", "12");
		Map<String, String> bizInfo6 = new HashMap<String, String>();
		bizInfo6.put("producttype", "normal");
		bizInfo6.put("provinceid", "12");
		bizInfo6.put("pmid", "12");
		bizInfo6.put("promotionid", "12");
		bizInfo6.put("merchantid", "12");
		bizInfo6.put("num", "12");
		Map<String, String> bizInfo7 = new HashMap<String, String>();
		bizInfo7.put("producttype", "normal");
		bizInfo7.put("provinceid", "12");
		bizInfo7.put("pmid", "12");
		bizInfo7.put("promotionid", "12");
		bizInfo7.put("merchantid", "12");
		bizInfo7.put("num", "12");
		Map<String, String> bizInfo8 = new HashMap<String, String>();
		bizInfo8.put("producttype", "lp");
		bizInfo8.put("provinceid", "12");
		bizInfo8.put("pmid", "12");
		bizInfo8.put("promotionid", "12");
		bizInfo8.put("merchantid", "12");
		bizInfo8.put("num", "12");
		this.mapsFrontDispatchService.addToCart(urlPath, true, bizInfo, content);
		this.mapsFrontDispatchService.addToCart(urlPath, true, bizInfo1, content);
		this.mapsFrontDispatchService.addToCart(urlPath, true, bizInfo2, content);
		this.mapsFrontDispatchService.addToCart(urlPath, true, bizInfo3, content);
		this.mapsFrontDispatchService.addToCart(urlPath, true, bizInfo4, content);
		this.mapsFrontDispatchService.addToCart(urlPath, true, bizInfo5, content);
		this.mapsFrontDispatchService.addToCart(urlPath, true, bizInfo6, content);
		this.mapsFrontDispatchService.addToCart(urlPath, true, bizInfo7, content);
		this.mapsFrontDispatchService.addToCart(urlPath, true, bizInfo8, content);
	}
	
	@Test
	public void testloadGrouponBrandVO(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		MapsFrontService service = PowerMockito.mock(MapsFrontService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		GrouponBrandVO re = new GrouponBrandVO();
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getMapsFrontClientService()).thenReturn(service);
		PowerMockito.when(service.loadGrouponBrandVO(Mockito.anyLong())).thenReturn(re);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("brandid", "12");
		this.mapsFrontDispatchService.loadGrouponBrandVO(urlPath, true, bizInfo, content);
	}
}
