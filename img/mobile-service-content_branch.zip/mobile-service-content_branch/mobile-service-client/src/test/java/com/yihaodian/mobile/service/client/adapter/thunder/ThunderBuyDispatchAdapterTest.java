package com.yihaodian.mobile.service.client.adapter.thunder;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.tag.IAppTagService;
import com.yihaodian.mobile.service.facade.business.thunder.ThunderBuyService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;


@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class ThunderBuyDispatchAdapterTest extends BaseTest{
	ThunderBuyDispatchAdapter thunderBuyDispatchAdapter = new ThunderBuyDispatchAdapter();
	
	@Test
	public void testgetThunderHomeBannerAndDes(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getThunderHomeBannerAndDes(Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("provinceid", "12");
		this.thunderBuyDispatchAdapter.getThunderHomeBannerAndDes(urlPath, true, bizInfo, content);
		this.thunderBuyDispatchAdapter.getThunderHomeBannerAndDes(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testgetThunderProvinceInfo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getThunderProvinceInfo(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("provincename", "12");
		bizInfo.put("cityname", "12");
		bizInfo.put("areaname", "12");
		bizInfo.put("streetname", "12");
		this.thunderBuyDispatchAdapter.getThunderProvinceInfo(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetProductsByCategoryIds(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getProductsByCategoryIds(Mockito.anyList(),Mockito.anyLong(),Mockito.isA(Integer.class),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("categoryids", "[12]");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("categoryids", "[12]");
		bizInfo2.put("provinceid", "12");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("categoryids", "[12]");
		bizInfo3.put("provinceid", "12");
		bizInfo3.put("size", "12");
		this.thunderBuyDispatchAdapter.getProductsByCategoryIds(urlPath, true, bizInfo, content);
		this.thunderBuyDispatchAdapter.getProductsByCategoryIds(urlPath, true, bizInfo1, content);
		this.thunderBuyDispatchAdapter.getProductsByCategoryIds(urlPath, true, bizInfo2, content);
		this.thunderBuyDispatchAdapter.getProductsByCategoryIds(urlPath, true, bizInfo3, content);
	}
	
	@Test
	public void testgetProductsByCategoryId(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getProductsByCategoryId(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("categoryid", "12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("categoryid", "12");
		bizInfo2.put("provinceid", "12");
		this.thunderBuyDispatchAdapter.getProductsByCategoryId(urlPath, true, bizInfo, content);
		this.thunderBuyDispatchAdapter.getProductsByCategoryId(urlPath, true, bizInfo1, content);
		this.thunderBuyDispatchAdapter.getProductsByCategoryId(urlPath, true, bizInfo2, content);
	}
	
	@Test
	public void testgetProductsByProvinceId(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getProductsByProvinceId(Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("provinceid", "12");
		this.thunderBuyDispatchAdapter.getProductsByProvinceId(urlPath, true, bizInfo, content);
		this.thunderBuyDispatchAdapter.getProductsByProvinceId(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testarrivalReminding(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.arrivalReminding(Mockito.isA(Long.class),Mockito.isA(Long.class),Mockito.isA(Long.class),Mockito.anyBoolean())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("provinceid", "12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("provinceid", "12");
		bizInfo2.put("pmid", "12");
		bizInfo2.put("isreminding", "1");
		this.thunderBuyDispatchAdapter.arrivalReminding(urlPath, true, bizInfo, content);
		this.thunderBuyDispatchAdapter.arrivalReminding(urlPath, true, bizInfo1, content);
		this.thunderBuyDispatchAdapter.arrivalReminding(urlPath, true, bizInfo2, content);
	}
	
	@Test
	public void testgetThunderCategory(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getThunderCategory(Mockito.isA(Long.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("provinceid", "12");
		this.thunderBuyDispatchAdapter.getThunderCategory(urlPath, true, bizInfo, content);
		this.thunderBuyDispatchAdapter.getThunderCategory(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testgetNativeThunderMerchantInfo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getNativeThunderMerchantInfo(Mockito.anyDouble(),Mockito.anyDouble(),Mockito.anyString(),Mockito.isA(Long.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("lng", "12.01");
		bizInfo.put("lat", "12.01");
		bizInfo.put("cellid", "12.01");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("currentpage", "12");
		bizInfo1.put("lng", "12.01");
		bizInfo1.put("lat", "12.01");
		bizInfo1.put("cellid", "12.01");
		this.thunderBuyDispatchAdapter.getNativeThunderMerchantInfo(urlPath, true, bizInfo, content);
		this.thunderBuyDispatchAdapter.getNativeThunderMerchantInfo(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testgetNativeThunderProvinceInfo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getNativeThunderProvinceInfo(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.isA(Long.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("provincename", "12");
		bizInfo.put("cityname", "12");
		bizInfo.put("areaname", "12");
		bizInfo.put("streetname", "12");
		this.thunderBuyDispatchAdapter.getNativeThunderProvinceInfo(urlPath, isLogined, bizInfo, content);
	}
	@Test
	public void testgetNativeThunderIndexInfo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getNativeThunderIndexInfo(Mockito.anyString(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("provinceid","12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("provinceid","12");
		bizInfo2.put("blockid","12");
		this.thunderBuyDispatchAdapter.getNativeThunderIndexInfo(urlPath, isLogined, bizInfo, content);
		this.thunderBuyDispatchAdapter.getNativeThunderIndexInfo(urlPath, isLogined, bizInfo1, content);
		this.thunderBuyDispatchAdapter.getNativeThunderIndexInfo(urlPath, isLogined, bizInfo2, content);
	}
	@Test
	public void testgetNativeThunderUserInfo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getNativeThunderUserInfo(Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.thunderBuyDispatchAdapter.getNativeThunderUserInfo(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetAddressListByKeyword(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "20", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ThunderBuyService service = PowerMockito.mock(ThunderBuyService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getThunderBuyClientService()).thenReturn(service);
		PowerMockito.when(service.getAddressListByKeyword(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("keywords", "12");
		bizInfo.put("location", "12");
		bizInfo.put("city", "12");
		this.thunderBuyDispatchAdapter.getAddressListByKeyword(urlPath, true, bizInfo, content);
	}
}
