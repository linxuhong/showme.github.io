package com.yihaodian.mobile.hedwig.client.impl.foodieBill;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.domain.business.dal.backend.FoodieOrderBill;
import com.yihaodian.mobile.service.facade.business.foodieBill.IFoodieBillService;

public class FoodieBillClientServiceImplTest {
	
	private FoodieBillClientServiceImpl foodieBillClientServiceImpl = new FoodieBillClientServiceImpl();
	
	@Mock
	private IFoodieBillService foodieBillHessianCall;

	@Before
	public void initMock() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(foodieBillClientServiceImpl, "foodieBillHessianCall", foodieBillHessianCall);
	}

	@Test
	public void testInsertOrUpdateOneFobill() {
		FoodieOrderBill one = new FoodieOrderBill();
		one.setRgstrTime(new Date());
		one.setAlctnAmt(56.12);
		one.setBackup("backend");
		one.setSkuNum(34L);
		one.setTop1CategLvl2Name("top1CategLvl2Name");
		foodieBillClientServiceImpl.insertOrUpdateOneFobill(one );
	}

	@Test
	public void testSelectFobillsByUserId() {
		foodieBillClientServiceImpl.selectFobillByUserId(23L);
	}

	@Test
	public void testSelectFobillByUserIds() {
		List<Long> userIds = new ArrayList<Long>();
		userIds.add(1L);
		userIds.add(11L);
		userIds.add(111L);
		
		foodieBillClientServiceImpl.selectFobillsByUserIds(userIds );
	}

	@Test
	public void testUpdateFobillByObj() {
		FoodieOrderBill one = new FoodieOrderBill();
		one.setRgstrTime(new Date());
		one.setAlctnAmt(56.12);
		one.setBackup("backend");
		one.setSkuNum(34L);
		one.setTop1CategLvl2Name("top1CategLvl2Name");
		foodieBillClientServiceImpl.updateFobillByObj(one);
	}

	@Test
	public void testDeleteFobillByUserId() {
		foodieBillClientServiceImpl.deleteFobillByUserId(34L);
	}

	@Test
	public void testDeleteFobillByUserIds() {
		List<Long> userIds = new ArrayList<Long>();
		userIds.add(1L);
		userIds.add(11L);
		userIds.add(111L);
		foodieBillClientServiceImpl.deleteFobillByUserIds(userIds);
	}

	@Test
	public void testSumFobillByObj() {
		FoodieOrderBill one = new FoodieOrderBill();
		one.setRgstrTime(new Date());
		one.setAlctnAmt(56.12);
		one.setBackup("backend");
		one.setSkuNum(34L);
		one.setTop1CategLvl2Name("top1CategLvl2Name");
		foodieBillClientServiceImpl.sumFobillByObj(one);
	}

	@Test
	public void testGetFoodieBillHessianCall() {
		foodieBillClientServiceImpl.getFoodieBillHessianCall();
	}

	@Test
	public void testSetFoodieBillHessianCall() {
		foodieBillClientServiceImpl.setFoodieBillHessianCall(foodieBillHessianCall);
	}

}
