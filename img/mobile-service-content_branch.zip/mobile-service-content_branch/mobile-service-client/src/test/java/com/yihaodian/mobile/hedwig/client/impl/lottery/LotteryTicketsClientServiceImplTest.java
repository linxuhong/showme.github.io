package com.yihaodian.mobile.hedwig.client.impl.lottery;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.lottery.spi.ILotteryTicketService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class LotteryTicketsClientServiceImplTest {
	private LotteryTicketsClientServiceImpl lotteryTicketsClientServiceImpl = new LotteryTicketsClientServiceImpl();
	
	@Mock
	private ILotteryTicketService lotteryTicketsHessianCall;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(lotteryTicketsClientServiceImpl, "lotteryTicketsHessianCall", lotteryTicketsHessianCall);
	}
	

	@Test
	public void testGetLotteryTicketUrlFor500StringStringInteger() {
		Integer type = 23;
		String traderName = "traderName";
		String userToken ="userToken";
		lotteryTicketsClientServiceImpl.getLotteryTicketUrlFor500(userToken, traderName, type);
	}

	@Test
	public void testGetLotteryTicketUrlFor500LongStringIntegerTrader() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android5.0");
		trader.setDeviceCode("nubia");
		trader.setLatitude(34.8);
		Integer type =23;
		String traderName = "taderName";
		Long userId = 23l;
		lotteryTicketsClientServiceImpl.getLotteryTicketUrlFor500(userId, traderName, type, trader);
	}
	

	@Test
	public void testGetLotteryTicketsHessianCall() {
		lotteryTicketsClientServiceImpl.getLotteryTicketsHessianCall();
	}

	@Test
	public void testSetLotteryTicketsHessianCall() {
		lotteryTicketsClientServiceImpl.setLotteryTicketsHessianCall(lotteryTicketsHessianCall);
	}

}
