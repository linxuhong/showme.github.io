package com.yihaodian.mobile.service.client.adapter.sharecoupon;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.domain.vo.business.share.GenerateUrlVO;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponDetailInputVO;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponFindInputVO;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponInputVO;
import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.HomeService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class ShareCouponServiceTest extends BaseTest{
	ShareCouponService shareCouponService = new ShareCouponService();
	@Test
	public void testGetReceiveCouponCount() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		IShareCouponService service = PowerMockito.mock(IShareCouponService.class);
		PowerMockito.when(CentralMobileServiceHandler.getShareCouponClientService()).thenReturn(service);
	    PowerMockito.when(service.getReceiveCouponCountWl2(Mockito.anyLong())).thenReturn(null);
	    shareCouponService.getReceiveCouponCount(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetShareCouponDetail() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		IShareCouponService service = PowerMockito.mock(IShareCouponService.class);
		PowerMockito.when(CentralMobileServiceHandler.getShareCouponClientService()).thenReturn(service).thenReturn(service).thenReturn(service).thenReturn(service);
	    PowerMockito.when(service.getShareCouponDetail(Mockito.any(ShareCouponDetailInputVO.class))).thenReturn(null).thenReturn(null).thenReturn(null).thenReturn(null);
	    shareCouponService.getShareCouponDetail(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("couponid", "1");
	    bizInfo.put("couponactivityid", "1");
	    shareCouponService.getShareCouponDetail(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("type", "1");
	    shareCouponService.getShareCouponDetail(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("userid", "1");
	    shareCouponService.getShareCouponDetail(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetShareCouponPage() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		IShareCouponService service = PowerMockito.mock(IShareCouponService.class);
		PowerMockito.when(CentralMobileServiceHandler.getShareCouponClientService()).thenReturn(service).thenReturn(service).thenReturn(service);
	    PowerMockito.when(service.getShareCouponPage(Mockito.any(ShareCouponFindInputVO.class))).thenReturn(null).thenReturn(null).thenReturn(null);
	    shareCouponService.getShareCouponPage(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("userId", "1");
	    PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
	    shareCouponService.getShareCouponPage(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("currentpage", "1");
	    bizInfo.put("pagesize", "1");
	    shareCouponService.getShareCouponPage(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("type", "1");
	    bizInfo.put("receiveuserid", "1");
	    shareCouponService.getShareCouponPage(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetShareCouponPageForWechat() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		IShareCouponService service = PowerMockito.mock(IShareCouponService.class);
		PowerMockito.when(CentralMobileServiceHandler.getShareCouponClientService()).thenReturn(service).thenReturn(service).thenReturn(service);
	    PowerMockito.when(service.getShareCouponPageForWechat(Mockito.any(ShareCouponFindInputVO.class))).thenReturn(null).thenReturn(null).thenReturn(null);
	    shareCouponService.getShareCouponPageForWechat(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("currentpage", "1");
	    bizInfo.put("pagesize", "1");
	    shareCouponService.getShareCouponPageForWechat(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("receiveuserid", "1");
	    bizInfo.put("type", "1");
	    shareCouponService.getShareCouponPageForWechat(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testShareCoupon() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		IShareCouponService service = PowerMockito.mock(IShareCouponService.class);
		PowerMockito.when(CentralMobileServiceHandler.getShareCouponClientService()).thenReturn(service).thenReturn(service).thenReturn(service).thenReturn(service).thenReturn(service).thenReturn(service);
	    PowerMockito.when(service.shareCoupon(Mockito.any(ShareCouponInputVO.class))).thenReturn(null).thenReturn(null).thenReturn(null).thenReturn(null).thenReturn(null).thenReturn(null);
	    shareCouponService.shareCoupon(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("couponactiveid", "1");
	    shareCouponService.shareCoupon(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("couponid", "1");
	    shareCouponService.shareCoupon(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("sharefrom", "1");
	    shareCouponService.shareCoupon(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("triggertype", "1");
	    bizInfo.put("receiveuserid", "1");
	    bizInfo.put("shareuserid", "1");
	    PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
	    shareCouponService.shareCoupon(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetShareCouponUrl() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		 PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		IShareCouponService service = PowerMockito.mock(IShareCouponService.class);
		PowerMockito.when(CentralMobileServiceHandler.getShareCouponClientService()).thenReturn(service).thenReturn(service).thenReturn(service);
	    PowerMockito.when(service.getShareCouponUrl(Mockito.any(GenerateUrlVO.class))).thenReturn(null).thenReturn(null).thenReturn(null);
	    shareCouponService.getShareCouponUrl(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("type", "1");
	    shareCouponService.getShareCouponUrl(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("couponactiveid", "1");
	    shareCouponService.getShareCouponUrl(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("couponid", "1");
	    shareCouponService.getShareCouponUrl(urlPath, isLogined, bizInfo, content);
	}

}
