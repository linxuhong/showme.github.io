package com.yihaodian.mobile.service.client.adapter.downloadpage;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.impl.downloadpage.DownloadPageClientService;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.downloadpage.spi.IDownloadPageService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class DownloadPageTest extends BaseTest{
	DownloadPage service = new DownloadPage();
	
	@Test
	public void testGetDownloadPageInfo() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		IDownloadPageService mock = PowerMockito.mock(DownloadPageClientService.class);
		PowerMockito.when(CentralMobileServiceHandler.getDownloadPageClientService()).thenReturn(mock);
		PowerMockito.doReturn(null).when(mock).getDownloadPageInfo(null, null);
		
		service.getDownloadPageInfo(urlPath, isLogined, bizInfo, content);
		
		bizInfo.put("pageurl", "http://");
		service.getDownloadPageInfo(urlPath, isLogined, bizInfo, content);
	}

}
