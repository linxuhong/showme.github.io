package com.yihaodian.mobile.hedwig.client.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.SeckillProductService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class SeckillProductClientServiceTest {
	
	private SeckillProductClientService SPClientService = new SeckillProductClientService();
	@Mock
	private SeckillProductService seckillHessiancall;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(SPClientService, "seckillHessiancall", seckillHessiancall);
	}

	@Test
	public void testPreSeckillProductStringLongStringLong() {
		Long productId = 34L;
		String promotionId = "dacu098";
		Long provinceId = 5L;
		String token = "priomtyion_token";
		SPClientService.preSeckillProduct(token, provinceId, promotionId, productId);
	}

	@Test
	public void testSeckillProductStringLongStringLong() {
		Long productId = 23L;
		String promotionId = "dachu887";
		Long provinceId = 3L;
		String token = "user_token";
		SPClientService.seckillProduct(token, provinceId, promotionId, productId);
	}

	@Test
	public void testGetSeckillProductList() {
		SPClientService.getSeckillProductList(4L, "dachu001");
	}

	@Test
	public void testCheckIfSecKill() {
		Long productId = 455L;
		Long provinceId = 5L;
		String promotionId = "dachu009";
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Androin5,0");
		trader.setDeviceCode("nubiaz9mini");
		
		SPClientService.checkIfSecKill(trader, promotionId, provinceId, productId);
	}

	@Test
	public void testCheckIfSecKillForList() {
		Long provinceId = 5L;
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Androin5,0");
		trader.setDeviceCode("nubiaz9mini");
		List<Long> productIdList = new ArrayList<Long>();
		productIdList.add(1L);
		productIdList.add(2L);
		productIdList.add(4L);
		List<String> promotionIdList = new ArrayList<String>();
		promotionIdList.add("daccu001");
		promotionIdList.add("daccu021");
		promotionIdList.add("daccu041");
		SPClientService.checkIfSecKillForList(trader, promotionIdList, productIdList, provinceId);
	}

	@Test
	public void testCheckSeckillCanBuyStringListOfStringListOfLong() {
		List<Long> productIdList = new ArrayList<Long>();
		productIdList.add(1L);
		productIdList.add(2L);
		productIdList.add(4L);
		List<String> promotionIdList = new ArrayList<String>();
		promotionIdList.add("daccu001");
		promotionIdList.add("daccu021");
		promotionIdList.add("daccu041");
		String token = "yhd_token";
		SPClientService.checkSeckillCanBuy(token, promotionIdList, productIdList);
	}

	@Test
	public void testGetSeckillHessiancall() {
		SPClientService.getSeckillHessiancall();
	}

	@Test
	public void testSetSeckillHessiancall() {
		SPClientService.setSeckillHessiancall(seckillHessiancall);
	}

	@Test
	public void testPreSeckillProductLongLongStringLong() {
		SPClientService.preSeckillProduct(34L, 4L, "dachu098", 456L);
	}

	@Test
	public void testSeckillProductLongLongStringLong() {
		SPClientService.seckillProduct(34L, 4L, "dachu098", 456L);
	}

	@Test
	public void testCheckSeckillCanBuyLongListOfStringListOfLongLong() {
		List<Long> productIdList = new ArrayList<Long>();
		productIdList.add(1L);
		productIdList.add(2L);
		productIdList.add(4L);
		List<String> promotionIdList = new ArrayList<String>();
		promotionIdList.add("daccu001");
		promotionIdList.add("daccu021");
		promotionIdList.add("daccu041");
		Long userId = 345L;
		SPClientService.checkSeckillCanBuy(userId, promotionIdList, productIdList, 4L);
	}

}
