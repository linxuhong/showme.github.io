package com.yihaodian.mobile.service.client.adapter.cut;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.cut.ICutService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;

import org.springframework.beans.factory.BeanFactory;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class CutDispatchServiceTest extends BaseTest {
	CutDispatchService cutDispatchService = new CutDispatchService();
	
	@Test
	public void testgetAllExclusivePriceColumns(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		PowerMockito.when(service.getAllExclusivePriceColumns(Mockito.anyLong(),Mockito.isA(ClientInfoVO.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.cutDispatchService.getAllExclusivePriceColumns(urlPath, true, bizInfo, content);
		this.cutDispatchService.getAllExclusivePriceColumns(urlPath, true, bizInfo, content);
		this.cutDispatchService.getAllExclusivePriceColumns(urlPath, true, bizInfo, content);
		this.cutDispatchService.getAllExclusivePriceColumns(urlPath, true, bizInfo, content);
	}
	@Test
	public void testGetExclusiveProductsByColumnIds(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		PowerMockito.when(service.getExclusiveProductsByColumnIds(Mockito.anyList(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("ids", "1,2,5");
		this.cutDispatchService.getExclusiveProductsByColumnIds(urlPath, true, bizInfo, content);
		this.cutDispatchService.getExclusiveProductsByColumnIds(urlPath, true, bizInfo, content);
		this.cutDispatchService.getExclusiveProductsByColumnIds(urlPath, true, bizInfo, content);
	}
	@Test
	public void testgetCutPriceTab(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		PowerMockito.when(service.getCutPriceTab(Mockito.isA(ClientInfoVO.class),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.cutDispatchService.getCutPriceTab(urlPath, true, bizInfo, content);
		this.cutDispatchService.getCutPriceTab(urlPath, true, bizInfo, content);
		this.cutDispatchService.getCutPriceTab(urlPath, true, bizInfo, content);
	}
	@Test
	public void testgetColumnAndActivity(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		PowerMockito.when(service.getColumnAndActivity(Mockito.isA(ClientInfoVO.class), Mockito.isA(Integer.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("type", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("type", "");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("type", "ab");
		this.cutDispatchService.getColumnAndActivity(urlPath, true, bizInfo, content);
		this.cutDispatchService.getColumnAndActivity(urlPath, true, bizInfo1, content);
		this.cutDispatchService.getColumnAndActivity(urlPath, true, bizInfo2, content);
	}
	
	@Test
	public void testgetSimilarProducts(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		PowerMockito.when(service.findSimilarProduct(Mockito.isA(Long.class),Mockito.isA(ClientInfoVO.class),Mockito.isA(Long.class),Mockito.isA(Long.class),Mockito.isA(Long.class),Mockito.isA(Integer.class),Mockito.isA(Long.class),Mockito.isA(Long.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("activityid", "ab");
		bizInfo1.put("productid", "11");
		bizInfo1.put("merchantid", "10");
		bizInfo1.put("pmid", "12");
		bizInfo1.put("number", "9");
		bizInfo1.put("lastid","8");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("activityid", "12");
		bizInfo2.put("productid", "ab");
		bizInfo2.put("merchantid", "10");
		bizInfo2.put("pmid", "12");
		bizInfo2.put("number", "9");
		bizInfo2.put("lastid","8");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("activityid", "12");
		bizInfo3.put("productid", "11");
		bizInfo3.put("merchantid", "ab");
		bizInfo3.put("pmid", "12");
		bizInfo3.put("number", "9");
		bizInfo3.put("lastid","8");
		Map<String, String> bizInfo4 = new HashMap<String, String>();
		bizInfo4.put("activityid", "12");
		bizInfo4.put("productid", "11");
		bizInfo4.put("merchantid", "10");
		bizInfo4.put("pmid", "ab");
		bizInfo4.put("number", "9");
		bizInfo4.put("lastid","8");
		Map<String, String> bizInfo5 = new HashMap<String, String>();
		bizInfo5.put("activityid", "12");
		bizInfo5.put("productid", "11");
		bizInfo5.put("merchantid", "10");
		bizInfo5.put("pmid", "12");
		bizInfo5.put("number", "ab");
		bizInfo5.put("lastid","8");
		Map<String, String> bizInfo6 = new HashMap<String, String>();
		bizInfo6.put("activityid", "12");
		bizInfo6.put("productid", "11");
		bizInfo6.put("merchantid", "10");
		bizInfo6.put("pmid", "12");
		bizInfo6.put("number", "9");
		bizInfo6.put("lastid","ab");
		Map<String, String> bizInfo7 = new HashMap<String, String>();
		bizInfo7.put("activityid", "12");
		bizInfo7.put("productid", "11");
		bizInfo7.put("merchantid", "10");
		bizInfo7.put("pmid", "12");
		bizInfo7.put("number", "9");
		bizInfo7.put("lastid","9");
		this.cutDispatchService.getSimilarProducts(urlPath, true, bizInfo1, content);
		this.cutDispatchService.getSimilarProducts(urlPath, true, bizInfo2, content);
		this.cutDispatchService.getSimilarProducts(urlPath, true, bizInfo3, content);
		this.cutDispatchService.getSimilarProducts(urlPath, true, bizInfo4, content);
		this.cutDispatchService.getSimilarProducts(urlPath, true, bizInfo5, content);
		this.cutDispatchService.getSimilarProducts(urlPath, true, bizInfo6, content);
		this.cutDispatchService.getSimilarProducts(urlPath, true, bizInfo7, content);
		
	}
	
	@Test
	public void testGetProductByActivityId(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		PowerMockito.when(service.getProductByActivityId(Mockito.isA(ClientInfoVO.class),Mockito.anyList())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("ids", "1,2,3");
		this.cutDispatchService.getProductByActivityId(urlPath, true, bizInfo, content);
		this.cutDispatchService.getProductByActivityId(urlPath, true, bizInfo, content);
		this.cutDispatchService.getProductByActivityId(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetCurrentProductList(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		HashMap<String, Object> map = new HashMap<String, Object>();
		PowerMockito.when(service.getCurrentProductList(Mockito.isA(ClientInfoVO.class))).thenReturn(map);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.cutDispatchService.getCurrentProductList(urlPath, true, bizInfo, content);
		this.cutDispatchService.getCurrentProductList(urlPath, true, bizInfo, content);
		this.cutDispatchService.getCurrentProductList(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetGroupProductListByLp(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		HashMap<String, Map> map = new HashMap<String, Map>();
		PowerMockito.when(service.getGroupProductListByLp(Mockito.isA(ClientInfoVO.class))).thenReturn(map);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.cutDispatchService.getGroupProductListByLp(urlPath, true, bizInfo, content);
		this.cutDispatchService.getGroupProductListByLp(urlPath, true, bizInfo, content);
		this.cutDispatchService.getGroupProductListByLp(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetYesterdayProductList(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		HashMap<String, Object> map = new HashMap<String, Object>();
		PowerMockito.when(service.getYesterdayProductList(Mockito.isA(ClientInfoVO.class), Mockito.anyLong())).thenReturn(map);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.cutDispatchService.getYesterdayProductList(urlPath, true, bizInfo, content);
		this.cutDispatchService.getYesterdayProductList(urlPath, true, bizInfo, content);
		this.cutDispatchService.getYesterdayProductList(urlPath, true, bizInfo, content);
	}
	@Test
	public void testgetProductReMindNum(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		HashMap<String, Object> map = new HashMap<String, Object>();
		PowerMockito.when(service.getProductReMindNum(Mockito.anyList())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("keys", "1,2,3");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		this.cutDispatchService.getProductReMindNum(urlPath, true, bizInfo, content);
		this.cutDispatchService.getProductReMindNum(urlPath, true, bizInfo1, content);
		this.cutDispatchService.getProductReMindNum(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testupdateProductReMindNum(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		HashMap<String, Object> map = new HashMap<String, Object>();
		PowerMockito.when(service.updateProductReMindNum(Mockito.anyString(),Mockito.anyInt())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("keys", "1,2,3");
		bizInfo.put("add", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("keys", "1,2,3");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("add", "10");
		this.cutDispatchService.updateProductReMindNum(urlPath, true, bizInfo, content);
		this.cutDispatchService.updateProductReMindNum(urlPath, true, bizInfo1, content);
		this.cutDispatchService.updateProductReMindNum(urlPath, true, bizInfo2, content);
	}
	
	@Test
	public void testgetBrandActivityDetailById(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		HashMap<String, Object> map = new HashMap<String, Object>();
		PowerMockito.when(service.getBrandActivityDetailById(Mockito.isA(ClientInfoVO.class),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("activityid", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		this.cutDispatchService.getBrandActivityDetailById(urlPath, true, bizInfo, content);
		this.cutDispatchService.getBrandActivityDetailById(urlPath, true, bizInfo1, content);
		this.cutDispatchService.getBrandActivityDetailById(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetExclusiveAd(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		HashMap<String, Object> map = new HashMap<String, Object>();
		PowerMockito.when(service.getExclusiveAd(Mockito.isA(ClientInfoVO.class),Mockito.isA(Integer.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.cutDispatchService.getExclusiveAd(urlPath, true, bizInfo, content);
		this.cutDispatchService.getExclusiveAd(urlPath, true, bizInfo, content);
		this.cutDispatchService.getExclusiveAd(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetTodayDuoshouPic(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId(null);
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ICutService service = PowerMockito.mock(ICutService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCutClientService()).thenReturn(service);
		HashMap<String, Object> map = new HashMap<String, Object>();
		PowerMockito.when(service.getTodayDuoshouPic(Mockito.isA(ClientInfoVO.class),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.cutDispatchService.getTodayDuoshouPic(urlPath, true, bizInfo, content);
		this.cutDispatchService.getTodayDuoshouPic(urlPath, true, bizInfo, content);
		this.cutDispatchService.getTodayDuoshouPic(urlPath, true, bizInfo, content);
	}
}
