package com.yihaodian.mobile.hedwig.client.WeChat.service.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.domain.business.dal.backend.WechatCoupon;
import com.yihaodian.mobile.service.domain.business.dal.backend.WechatCouponExample;
import com.yihaodian.mobile.service.domain.business.dal.backend.WechatCouponExample.Criteria;
import com.yihaodian.mobile.service.facade.business.wechat.WechatCouponService;

public class WechatCouponClientServiceImplTest {
	
	private WechatCouponClientServiceImpl WCClientServiceImpl = new WechatCouponClientServiceImpl();
	@Mock
	private WechatCouponService weChatCouponHessianCall;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(WCClientServiceImpl, "weChatCouponHessianCall", weChatCouponHessianCall);
	}

	@Test
	public void testSetWeChatCouponHessianCall() {
		WCClientServiceImpl.setWeChatCouponHessianCall(weChatCouponHessianCall);
	}

	@Test
	public void testGetCodesByCouponIds() {
		List<Long> couponIds = new ArrayList<Long>();
		couponIds.add(3L);
		couponIds.add(4L);
		couponIds.add(5L);
		WCClientServiceImpl.getCodesByCouponIds(couponIds , 2);
	}

	@Test
	public void testUpdateByCode() {
		WechatCoupon wechatCoupon = new WechatCoupon();
		wechatCoupon.setActiveId(34L);
		wechatCoupon.setOpenId("0384");
		wechatCoupon.setOrderId(34L);
		WCClientServiceImpl.updateByCode(wechatCoupon);
	}

	@Test
	public void testGetWechatCouponByCode() {
		WCClientServiceImpl.getWechatCouponByCode("dachuxiao");
	}

	@Test
	public void testGetByExample() {
		WechatCouponExample example = new WechatCouponExample();
		Criteria createCriteria = example.createCriteria();
		createCriteria.andActiveIdBetween(23L, 45L);
		WCClientServiceImpl.getByExample(example );
	}

	@Test
	public void testReceiveCoupon() {
		WCClientServiceImpl.receiveCoupon(45L, "code");
	}

	@Test
	public void testShareCoupon() {
		WCClientServiceImpl.shareCoupon(67L, 34L, "code");
	}

	@Test
	public void testDeleteCoupon() {
		WCClientServiceImpl.deleteCoupon(45L, "code");
	}

	@Test
	public void testLogErrorMsg() {
		WCClientServiceImpl.logErrorMsg(34L, "code", "erroeMgs", 4);
	}

	@Test
	public void testCheckWechatByOrderId() {
		WCClientServiceImpl.checkWechatByOrderId(45L);
	}

	@Test
	public void testCheckWechatByCouponNum() {
		List<String> couponNums = new ArrayList<String>();
		couponNums.add("mengniu");
		couponNums.add("yili");
		couponNums.add("sanlu");
		WCClientServiceImpl.checkWechatByCouponNum(couponNums );
	}

}
