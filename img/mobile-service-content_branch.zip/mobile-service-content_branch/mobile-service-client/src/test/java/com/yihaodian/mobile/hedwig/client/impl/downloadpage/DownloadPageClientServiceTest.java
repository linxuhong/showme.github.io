package com.yihaodian.mobile.hedwig.client.impl.downloadpage;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.downloadpage.spi.IDownloadPageService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class DownloadPageClientServiceTest {
	private DownloadPageClientService downloadPageClientService = new DownloadPageClientService();
	
	@Mock
	private IDownloadPageService downloadPageHessianCall;

	@Before
	public void initMock() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(downloadPageClientService, "downloadPageHessianCall", downloadPageHessianCall);
	}

	@Test
	public void testGetDownloadPageInfo() {
		String pageUrl="www.yhd.com/static/img/appdlown.png";
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.2.111");
		clientInfoVO.setClientSystem("Android5.0");
		
		downloadPageClientService.getDownloadPageInfo(clientInfoVO, pageUrl);
	}

	@Test
	public void testGetDownloadPageHessianCall() {
		String pageUrl="www.yhd.com/static/img/appdlown.png";
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.2.111");
		clientInfoVO.setClientSystem("Android5.0");
		downloadPageClientService.getDownloadPageInfo(clientInfoVO, pageUrl);
	}

	@Test
	public void testSetDownloadPageHessianCall() {
		downloadPageClientService.setDownloadPageHessianCall(downloadPageHessianCall);
	}

}
