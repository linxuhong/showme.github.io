package com.yihaodian.mobile.hedwig.client.service.alipay;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.alipay.spi.IAlipaySignService;

public class AlipaySignClientServiceTest {
	private AlipaySignClientService alipaySignClientService = new AlipaySignClientService();
	@Mock
	private IAlipaySignService alipaySignHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(alipaySignClientService, "alipaySignHessianCall", alipaySignHessianCall);
	}

	@Test
	public void testGetAlipaySignHessianCall() {
		alipaySignClientService.getAlipaySignHessianCall();
	}

	@Test
	public void testSetAlipaySignHessianCall() {
		alipaySignClientService.setAlipaySignHessianCall(alipaySignHessianCall);
	}

	@Test
	public void testGetAliPaySignature() {
		alipaySignClientService.getAliPaySignature("User_token", 45L, "traderName", "V1.0");
	}

	@Test
	public void testGetAliPaySignatureV2() {
		String traderName = "traderName";
		Long orderId = 456L;
		alipaySignClientService.getAliPaySignatureV2(34L, orderId, traderName);
	}

}
