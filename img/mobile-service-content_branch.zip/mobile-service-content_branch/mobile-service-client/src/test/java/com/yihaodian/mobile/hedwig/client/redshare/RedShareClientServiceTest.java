package com.yihaodian.mobile.hedwig.client.redshare;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.IRedShareService;

public class RedShareClientServiceTest {
	private RedShareClientService redShareClientService = new RedShareClientService();
	
	@Mock
	private IRedShareService redShareHessianCall;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(redShareClientService, "redShareHessianCall", redShareHessianCall);
	}

	@Test
	public void testGetRedShareHessianCall() {
		redShareClientService.getRedShareHessianCall();
	}

	@Test
	public void testSetRedShareHessianCall() {
		redShareClientService.setRedShareHessianCall(redShareHessianCall);
	}

	@Test
	public void testGetPromotionInfo() {
		redShareClientService.getPromotionInfo(45L);
	}

	@Test
	public void testGetShareInfo() {
		redShareClientService.getShareInfo(45L, 34L);
	}

	@Test
	public void testShareRed() {
		redShareClientService.shareRed(36L, 34L, 23);
	}

	@Test
	public void testGetUserInfo() {
		redShareClientService.getUserInfo(56L, 23L);
	}

	@Test
	public void testAccepctRed() {
		int type = 5;
		String redCipher = "redCipher";
		String openid = "openId";
		Long userId = 6L;
		Long activityId = 45L;
		redShareClientService.accepctRed(activityId, userId,
				openid, redCipher, type);
	}

	@Test
	public void testExchangeAward() {
		redShareClientService.exchangeAward(45L, 43L, 88L);
	}

	@Test
	public void testGetUserRedList() {
		redShareClientService.getUserRedList(45L, "redCipher");
	}

}
