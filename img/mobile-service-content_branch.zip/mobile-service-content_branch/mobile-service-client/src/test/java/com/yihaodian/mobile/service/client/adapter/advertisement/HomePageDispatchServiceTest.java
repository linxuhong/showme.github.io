package com.yihaodian.mobile.service.client.adapter.advertisement;


import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.AssertThrows;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.push.spi.HomePageService;
import com.yihaodian.mobile.service.client.adapter.advertisement.HomePageDispatchService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
import com.yihaodian.mobile2.server.context.RtnInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class HomePageDispatchServiceTest extends BaseTest{	
	HomePageDispatchService homePageDispatchService =new HomePageDispatchService();	
	
	
	@Test
	public void testGetMobileViewById() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.getMobileViewById(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong())).thenReturn(null);
		bizInfo.put("viewid", "123");
		RtnInfo rtInfo = homePageDispatchService.getMobileViewById(urlPath, isLogined, bizInfo, content);
		System.out.println(rtInfo.getData());		
	}
	
	
	
	@Test
	public void testGetBrandShopPromotion() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.getBrandShopPromotion(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn(null);
		RtnInfo rtInfo = homePageDispatchService.getBrandShopPromotion(urlPath, isLogined, bizInfo, content);
		System.out.println(rtInfo.getData());		
	}
	
	
	@Test
	public void testGetMobileIndexViewByType() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.getMobileIndexViewByType(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong())).thenReturn(null);
		homePageDispatchService.getMobileIndexViewByType(urlPath, isLogined, bizInfo, content);
	}
	@Test
	public void testGetCmsColumnDetail() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.getCmsColumnDetail(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);
		bizInfo.put("sorttype", "12");
		bizInfo.put("currentpage", "12");
		bizInfo.put("pagesize", "2");
		bizInfo.put("cmscolumnid", "2");
		homePageDispatchService.getCmsColumnDetail(urlPath, isLogined, bizInfo, content);
	}
	
	@Test
	public void testGetCommunityProductList() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.getCmsColumnDetail(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);
		bizInfo.put("sorttype", "12");
		bizInfo.put("currentpage", "12");
		bizInfo.put("pagesize", "2");
		bizInfo.put("cmscolumnid", "2");
		bizInfo.put("communityprovinceid", "2");
		homePageDispatchService.getCommunityProductList(urlPath, isLogined, bizInfo, content);
	}
	@Test
	public void testCheckCommunity() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.checkCommunity(Mockito.anyLong(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(null);
		bizInfo.put("provincename", "test");
		bizInfo.put("cityname", "ytest");
		bizInfo.put("areaname", "test");
		bizInfo.put("streetname", "test");
		bizInfo.put("communityprovinceid", "12");
		homePageDispatchService.checkCommunity(urlPath, isLogined, bizInfo, content);
	}
	
	@Test
	public void testGetCommunityView() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.getCommunityView(Mockito.any(Trader.class),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(null);
		bizInfo.put("provincename", "test");
		bizInfo.put("cityname", "ytest");
		bizInfo.put("areaname", "test");
		bizInfo.put("streetname", "test");
		bizInfo.put("", "");
		homePageDispatchService.getCommunityView(urlPath, isLogined, bizInfo, content);
	}
	
	
	
	@Test
	public void testGetMobileIndexViewForBI() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.getMobileIndexViewForBI(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn(null);
		homePageDispatchService.getMobileIndexViewForBI(urlPath, isLogined, bizInfo, content);
	}
	
	
	
	@Test
	public void testGetCalendarBuyProductList() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.getCalendarBuyProductList(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyString())).thenReturn(null);
		bizInfo.put("dateday", "2014-10-12");
		homePageDispatchService.getCalendarBuyProductList(urlPath, isLogined, bizInfo, content);
	}
	
	
	@Test
	public void testGetCalendarBuyDetail() {	
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		HomePageService homePageService = PowerMockito.mock(HomePageService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomePageClientService()).thenReturn(homePageService);
		PowerMockito.when(homePageService.getCalendarBuyDetail(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyString())).thenReturn(null);
		bizInfo.put("dateday", "12");
		homePageDispatchService.getCalendarBuyDetail(urlPath, isLogined, bizInfo, content);
	}
	
	

}
