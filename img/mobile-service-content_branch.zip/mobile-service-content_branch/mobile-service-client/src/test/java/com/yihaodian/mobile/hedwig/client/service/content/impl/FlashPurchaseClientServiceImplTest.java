package com.yihaodian.mobile.hedwig.client.service.content.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.content.spi.FlashPurchaseService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class FlashPurchaseClientServiceImplTest {
	private FlashPurchaseClientServiceImpl fpcserviceimpl = new FlashPurchaseClientServiceImpl();
	@Mock
	private FlashPurchaseService flashPurchaseHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(fpcserviceimpl, "flashPurchaseHessianCall", flashPurchaseHessianCall);
	}

	@Test
	public void testInviteesRegister() {
		String inviterName = "django";
		Integer type = 4;
		String tempToken = "yhd_token";
		String verifyCode = "checken";
		String password = "xixilala";
		String userName = "slave1";
		String email = "slave1@128.com";
		Trader trader = new Trader();
		trader.setClientAppVersion("V1.0");
		trader.setClientSystem("ios");
		trader.setDeviceCode("feixunp660");
		
		fpcserviceimpl.inviteesRegister(trader, email, userName, password, 
				verifyCode, tempToken, type, inviterName);
	}

	@Test
	public void testGetBrandCollectState() {
		
		fpcserviceimpl.getBrandCollectState("yhd_token", 34L);
	}

	@Test
	public void testAddFavoriteForBrand() {
		fpcserviceimpl.addFavoriteForBrand("yhd_token", 345L);
	}

	@Test
	public void testGetFavoriteBrandLists() {
		fpcserviceimpl.getFavoriteBrandLists("yhd_token", 5, 10);
	}

	@Test
	public void testRemoveFavoriteBrand() {
		fpcserviceimpl.removeFavoriteBrand("user_token", 33L);
	}

	@Test
	public void testGetFlashPurchaseHessianCall() {
		fpcserviceimpl.getFlashPurchaseHessianCall();
	}

	@Test
	public void testSetFlashPurchaseHessianCall() {
		fpcserviceimpl.setFlashPurchaseHessianCall(flashPurchaseHessianCall);
	}

}
