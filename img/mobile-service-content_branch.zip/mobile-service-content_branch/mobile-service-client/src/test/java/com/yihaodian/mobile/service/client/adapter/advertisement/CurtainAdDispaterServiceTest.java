package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.service.client.advertisement.service.impl.CategoryAdClientService;
import com.yihaodian.mobile.service.facade.business.advertisement.CurtainAdvertisementService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;


@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class CurtainAdDispaterServiceTest extends BaseTest{
	CurtainAdDispaterService curtainAdDispaterService = new CurtainAdDispaterService();
	
	@Test
	public void testgetCurtainAdvertisement(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		AdapterContext content1 = new AdapterContext();
		content1.setHasToken(true);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CurtainAdvertisementService service = PowerMockito.mock(CurtainAdvertisementService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCurtainADClientService()).thenReturn(service);
		PowerMockito.when(service.getCurtainAdvertisement(Mockito.isA(Trader.class),Mockito.anyString(),Mockito.isA(Integer.class),Mockito.anyLong(),Mockito.anyString())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.curtainAdDispaterService.getCurtainAdvertisement(urlPath, false, bizInfo, content1);
		this.curtainAdDispaterService.getCurtainAdvertisement(urlPath, false, bizInfo, content);
	}
	
	@Test
	public void testopenCurtainAdvertisement(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		AdapterContext content1 = new AdapterContext();
		content1.setHasToken(true);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CurtainAdvertisementService service = PowerMockito.mock(CurtainAdvertisementService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCurtainADClientService()).thenReturn(service);
		PowerMockito.when(service.openCurtainAdvertisement(Mockito.isA(Trader.class),Mockito.anyString(),Mockito.isA(Integer.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("devicetoken", "12");
		this.curtainAdDispaterService.openCurtainAdvertisement(urlPath, true, bizInfo, content);
	}
}
