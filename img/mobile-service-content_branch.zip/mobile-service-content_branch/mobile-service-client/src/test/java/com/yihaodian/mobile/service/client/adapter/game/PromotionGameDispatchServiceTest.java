package com.yihaodian.mobile.service.client.adapter.game;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.hedwig.push.spi.IPromotionGameService;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;


@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class PromotionGameDispatchServiceTest extends BaseTest{
	PromotionGameDispatchService promotionGameDispatchService = new PromotionGameDispatchService();
	
	@Test
	public void testgetGamePromotionInfo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IPromotionGameService service = PowerMockito.mock(IPromotionGameService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		ResultModel resultModel = new ResultModel();
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionGameService()).thenReturn(service);
		PowerMockito.when(service.getGamePromotionInfo(Mockito.anyLong(),Mockito.anyLong(),Mockito.isA(Integer.class))).thenReturn(resultModel);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("gameid", "12");
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		this.promotionGameDispatchService.getGamePromotionInfo(urlPath, false, bizInfo, content);
		this.promotionGameDispatchService.getGamePromotionInfo(urlPath, true, bizInfo1, content);
		this.promotionGameDispatchService.getGamePromotionInfo(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testdoShakingWithAwardPoolIds(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IPromotionGameService service = PowerMockito.mock(IPromotionGameService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		ResultModel resultModel = new ResultModel();
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionGameService()).thenReturn(service);
		PowerMockito.when(service.doShakingWithAwardPoolIds(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.isA(Integer.class))).thenReturn(resultModel);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("gameid", "12");
		bizInfo1.put("awardpoolids", "awardpoolids");
		this.promotionGameDispatchService.doShakingWithAwardPoolIds(urlPath, false, bizInfo, content);
		this.promotionGameDispatchService.doShakingWithAwardPoolIds(urlPath, true, bizInfo, content);
		this.promotionGameDispatchService.doShakingWithAwardPoolIds(urlPath, true, bizInfo1, content);
	}
	
	@Test
	public void testacceptAward(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IPromotionGameService service = PowerMockito.mock(IPromotionGameService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		ResultModel resultModel = new ResultModel();
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionGameService()).thenReturn(service);
		PowerMockito.when(service.acceptAward(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.isA(Integer.class),Mockito.isA(Integer.class),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(resultModel);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("gameid", "112");
		bizInfo1.put("isdiscard","12");
		Map<String, String> bizInfo2 = new HashMap<String, String>();
		bizInfo2.put("gameid", "12");
		bizInfo1.put("awardid", "112");
		Map<String, String> bizInfo3 = new HashMap<String, String>();
		bizInfo3.put("gameid", "12");
		bizInfo3.put("awardid", "112");
		bizInfo3.put("tokensession", "12");
		bizInfo3.put("sessionid", "112");
		bizInfo3.put("username","12");
		bizInfo3.put("address","12");
		bizInfo3.put("phone","12");
		this.promotionGameDispatchService.acceptAward(urlPath, false, bizInfo, content);
		this.promotionGameDispatchService.acceptAward(urlPath, true, bizInfo, content);
		this.promotionGameDispatchService.acceptAward(urlPath, true, bizInfo1, content);
		this.promotionGameDispatchService.acceptAward(urlPath, true, bizInfo2, content);
		this.promotionGameDispatchService.acceptAward(urlPath, true, bizInfo3, content);
	}
	@Test
	public void testgetAchievementList(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IPromotionGameService service = PowerMockito.mock(IPromotionGameService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		ResultModel resultModel = new ResultModel();
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionGameService()).thenReturn(service);
		PowerMockito.when(service.getAchievementList(Mockito.anyLong(),Mockito.anyLong(),Mockito.isA(Integer.class))).thenReturn(resultModel);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("gameid", "12");
		this.promotionGameDispatchService.getAchievementList(urlPath,false, bizInfo, content);
		this.promotionGameDispatchService.getAchievementList(urlPath,true, bizInfo, content);
		this.promotionGameDispatchService.getAchievementList(urlPath,true, bizInfo1, content);
	}
	
	@Test
	public void testgetUserAcceptAwardList(){
		RequestInfo rn1 = new RequestInfo(clientInfo, "12/v2", provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, "12/v3", null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, "12/v", "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		IPromotionGameService service = PowerMockito.mock(IPromotionGameService.class);
		Result result = PowerMockito.mock(Result.class);
		result.setResultDesc("12");
		result.setSuccess(false);
		ResultModel resultModel = new ResultModel();
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionGameService()).thenReturn(service);
		PowerMockito.when(service.getUserAcceptAwardList(Mockito.anyLong(),Mockito.anyLong())).thenReturn(resultModel);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		Map<String, String> bizInfo1 = new HashMap<String, String>();
		bizInfo1.put("gameid", "12");
		this.promotionGameDispatchService.getUserAcceptAwardList(urlPath,false, bizInfo, content);
		this.promotionGameDispatchService.getUserAcceptAwardList(urlPath,true, bizInfo, content);
		this.promotionGameDispatchService.getUserAcceptAwardList(urlPath,true, bizInfo1, content);
	}
	
}
