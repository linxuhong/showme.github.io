package com.yihaodian.mobile.service.client.adapter.advertisement;

import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MobileProfileService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.home.ShareContentVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
import com.yihaodian.mobile2.server.context.RtnInfo;
@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,GsonUtil.class})
public class MobileProfileDispaterServiceTest extends BaseTest{
	MobileProfileDispaterService mobileProfileDispaterService =new MobileProfileDispaterService();
   
	
	@Test
	public void testgetViewProfile(){
		bizInfo.put("categoryid", "12");
		bizInfo.put("linkid", "11");
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);	
		PowerMockito.when(mobileProfileService.getExportGoodsBrand(Mockito.any(Trader.class), Mockito.anyLong(),  Mockito.anyLong())).thenReturn("");
		RtnInfo r=mobileProfileDispaterService.getViewProfile(urlPath, isLogined, bizInfo,content);
		
	}
	
	
	@Test
	public void testGetExportGoodsBrand(){
		try {
			bizInfo.put("categoryid", "12");
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
			PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);	
			PowerMockito.when(mobileProfileService.getExportGoodsBrand(Mockito.any(Trader.class), Mockito.anyLong(),  Mockito.anyLong())).thenReturn("");
			RtnInfo r=mobileProfileDispaterService.getExportGoodsBrand(urlPath, isLogined, bizInfo,content);
		} catch (Exception e) {
			assertTrue(true);
		}
		
		
	}
	@Test
	public void testGetIndexProfile(){	
		bizInfo.put("categoryid", "12");
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);	
		PowerMockito.when(mobileProfileService.getIndexProfile(Mockito.any(Trader.class) , Mockito.anyLong())).thenReturn("");
		RtnInfo r=mobileProfileDispaterService.getIndexProfile(urlPath, isLogined, bizInfo, content);
	}
	
	@Test
	public void testgetExportGoodsView(){
		PowerMockito.mockStatic(GsonUtil.class);
		bizInfo.put("linkid","12");
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);	
		PowerMockito.when(mobileProfileService.getExportGoodsView(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong())).thenReturn("12");
		RtnInfo r = mobileProfileDispaterService.getExportGoodsView(urlPath, isLogined, bizInfo, content);
	}
 
	@Test
  public void testgetExportGoodsCategory(){
		bizInfo.put("linkid","12");
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);	
		PowerMockito.when(mobileProfileService.getExportGoodsCategory(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn("12");
		RtnInfo r = mobileProfileDispaterService.getExportGoodsCategory(urlPath, isLogined, bizInfo, content);
  }
	@Test
	public void testgetDailyOneProfile(){
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);
		PowerMockito.when(mobileProfileService.getDailyOneProfile(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn("12");
		RtnInfo r = mobileProfileDispaterService.getDailyOneProfile(urlPath, isLogined, bizInfo, content);
	}
	
	@Test
	public void testgetCalendarDetailProfile(){
		
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);
		PowerMockito.when(mobileProfileService.getCalendarDetailProfile(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyString())).thenReturn("12");
		bizInfo.put("date","20161129");
		RtnInfo r = mobileProfileDispaterService.getCalendarDetailProfile(urlPath, isLogined, bizInfo, content);
	}
	@Test
	public void testgetShareContent(){
		ShareContentVO result = new ShareContentVO();
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);
		PowerMockito.when(mobileProfileService.getCalendarDetailProfile(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyString())).thenReturn("12");
		bizInfo.put("viewid","20");
		PowerMockito.when(mobileProfileService.getShareContent(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn(result);
		RtnInfo r = mobileProfileDispaterService.getShareContent(urlPath, isLogined, bizInfo, content);
	}
	@Test
	public void testgetActivityRule(){
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);
		PowerMockito.when(mobileProfileService.getActivityRule(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn("12");
		RtnInfo r = mobileProfileDispaterService.getActivityRule(urlPath, isLogined, bizInfo, content);
	}
	
	@Test
	public void testgetCalendarProfile(){
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		MobileProfileService mobileProfileService = PowerMockito.mock(MobileProfileService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileProfileService()).thenReturn(mobileProfileService);
		PowerMockito.when(mobileProfileService.getActivityRule(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn("12");
		RtnInfo r = mobileProfileDispaterService.getCalendarProfile(urlPath, isLogined, bizInfo, content);
	}
}
