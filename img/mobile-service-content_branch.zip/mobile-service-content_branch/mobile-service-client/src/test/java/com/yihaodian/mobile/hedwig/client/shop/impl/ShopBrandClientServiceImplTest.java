package com.yihaodian.mobile.hedwig.client.shop.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.ShopBrandFacdeService;

public class ShopBrandClientServiceImplTest {
	ShopBrandClientServiceImpl shopBrandClientServiceImpl = new ShopBrandClientServiceImpl();
	@Mock
	ShopBrandFacdeService shopBrandHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(shopBrandClientServiceImpl, "shopBrandHessianCall", shopBrandHessianCall);
	}
	@Test
	public void test() {
		shopBrandClientServiceImpl.getBrandNameByChar(null);
		shopBrandClientServiceImpl.getShopInfos(null, 0, 0);

		shopBrandClientServiceImpl.setShopBrandHessianCall(shopBrandHessianCall);
	}

}
