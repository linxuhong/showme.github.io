package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.hedwig.core.service.spi.AlipayService;

public class AlipayClientServiceImplTest {
	AlipayClientServiceImpl alipayClientServiceImpl = new AlipayClientServiceImpl();
	@Mock
	AlipayService alipayHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(alipayClientServiceImpl, "alipayHessianCall", alipayHessianCall);
	}
	@Test
	public void test() {
		alipayClientServiceImpl.getAlipayGoodReceiver(123L);
		alipayClientServiceImpl.alipayLogin(null, null, null, null, null, null);
		alipayClientServiceImpl.getAlipayHessianCall();
		alipayClientServiceImpl.getAlipayPayInfo(123L);
		alipayClientServiceImpl.getshareMyOrderList(null, null, null, null, null);
		alipayClientServiceImpl.getsharemyOrderRule(null);
		alipayClientServiceImpl.sharetoMyOrder(null, null, null, null, null);
		alipayClientServiceImpl.setAlipayHessianCall(alipayHessianCall);

	}

}
