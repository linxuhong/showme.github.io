package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.hedwig.core.service.spi.ICouponService;

public class CouponClientServiceImplTest {
	CouponClientServiceImpl couponClientServiceImpl = new CouponClientServiceImpl();
	@Mock
	ICouponService mobileCouponHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(couponClientServiceImpl, "couponMobileHessianCall", mobileCouponHessianCall);	
	}
	@Test
	public void testSendNewguestCoupon() {
		couponClientServiceImpl.sendNewguestCoupon(123L);
	}

	@Test
	public void testOpensendCouponflag() {
		couponClientServiceImpl.opensendCouponflag(null, null);
	}

	@Test
	public void testFlashSaleUrl() {
		couponClientServiceImpl.flashSaleUrl(123L);
	}

	@Test
	public void testGetMerchantH5Url() {
		couponClientServiceImpl.getMerchantH5Url(null, null, null, null);
	}

	@Test
	public void testGetCouponHessianCall() {
		couponClientServiceImpl.getCouponHessianCall();
	}

	@Test
	public void testSetCouponHessianCall() {
		couponClientServiceImpl.setCouponHessianCall(mobileCouponHessianCall);
	}

}
