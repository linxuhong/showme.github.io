package com.yihaodian.mobile.service.client.adapter.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.service.rock.RockClientService;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.hedwig.core.service.spi.AlipayService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class AlipayDispatchServiceTest extends BaseTest{
	AlipayDispatchService alipayDispatchService = new AlipayDispatchService();
	@Test
	public void testGetsharemyOrderRule() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AlipayService alipayService = PowerMockito.mock(AlipayService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getAlipayService()).thenReturn(alipayService);
		PowerMockito.when(alipayService.getsharemyOrderRule(Mockito.any(Trader.class))).thenReturn(null);
		alipayDispatchService.getsharemyOrderRule(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testAlipayLogin() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AlipayService alipayService = PowerMockito.mock(AlipayService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getAlipayService()).thenReturn(alipayService);
		PowerMockito.when(alipayService.alipayLogin(Mockito.any(Trader.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyString())).thenReturn(null).thenReturn(null).thenReturn(null);
		alipayDispatchService.alipayLogin(urlPath, isLogined, bizInfo, content);
		bizInfo.put("authcode", "1");
		alipayDispatchService.alipayLogin(urlPath, isLogined, bizInfo, content);
		bizInfo.put("appid", "1");
		alipayDispatchService.alipayLogin(urlPath, isLogined, bizInfo, content);
		
	}

	@Test
	public void testGetAlipayGoodReceiver() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AlipayService alipayService = PowerMockito.mock(AlipayService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getAlipayService()).thenReturn(alipayService);
		PowerMockito.when(alipayService.getAlipayGoodReceiver(Mockito.anyLong())).thenReturn(null);
		alipayDispatchService.getAlipayGoodReceiver(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testSharetoMyOrder() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AlipayService alipayService = PowerMockito.mock(AlipayService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getAlipayService()).thenReturn(alipayService);
		PowerMockito.when(alipayService.sharetoMyOrder(Mockito.anyString(), Mockito.anyListOf(Long.class), Mockito.anyListOf(String.class), Mockito.anyString(), Mockito.anyString())).thenReturn(null).thenReturn(null);
		alipayDispatchService.sharetoMyOrder(urlPath, isLogined, bizInfo, content);
		bizInfo.put("imageurls", "1");
		bizInfo.put("myiconurl", "1");
		bizInfo.put("content", "1");
		alipayDispatchService.sharetoMyOrder(urlPath, isLogined, bizInfo, content);
	}

}
