package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.hedwig.core.service.spi.FeedbackService;

public class FeedbackClientServiceImplTest {
	FeedbackClientServiceImpl feedbackClientServiceImpl = new FeedbackClientServiceImpl();
	@Mock
	FeedbackService feedbackHessiancall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(feedbackClientServiceImpl, "feedbackHessiancall", feedbackHessiancall);
	}
	@Test
	public void test() {
		feedbackClientServiceImpl.addFeedback(null, null);
		feedbackClientServiceImpl.addFeedback(null, null);
		feedbackClientServiceImpl.getFeedbackHessiancall();
		feedbackClientServiceImpl.getFeedBackTypeInfoList(null);
	}

}
