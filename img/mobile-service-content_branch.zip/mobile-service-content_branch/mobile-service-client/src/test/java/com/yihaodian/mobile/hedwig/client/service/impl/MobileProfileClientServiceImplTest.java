package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.hedwig.core.service.spi.MobileProfileService;

public class MobileProfileClientServiceImplTest {
	MobileProfileClientServiceImpl mobileProfileClientServiceImpl = new MobileProfileClientServiceImpl();
	@Mock
	MobileProfileService mobileProfileHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(mobileProfileClientServiceImpl, "mobileProfileHessianCall", mobileProfileHessianCall);
	}
	@Test
	public void test() {
		mobileProfileClientServiceImpl.getActivityProductList(null, null, null, null, null, 0);
		mobileProfileClientServiceImpl.getActivityRule(null, null);
		mobileProfileClientServiceImpl.getCalendarDetailProfile(null, null, null);
		mobileProfileClientServiceImpl.getCalendarProfile(null, null);
		mobileProfileClientServiceImpl.getDailyOneProfile(null, null);
		mobileProfileClientServiceImpl.getExportGoodsBrand(null, null, null);
		mobileProfileClientServiceImpl.getExportGoodsCategory(null, null);
		mobileProfileClientServiceImpl.getExportGoodsView(null, null, null);
		mobileProfileClientServiceImpl.getIndexProfile(null, null);
		
		mobileProfileClientServiceImpl.getIndexProfileByType(null, null, null);
		mobileProfileClientServiceImpl.getMobileProfileHessianCall();
		mobileProfileClientServiceImpl.getShareContent(null, null);
		mobileProfileClientServiceImpl.getViewProfile(null, null, null);
		
	}

}
