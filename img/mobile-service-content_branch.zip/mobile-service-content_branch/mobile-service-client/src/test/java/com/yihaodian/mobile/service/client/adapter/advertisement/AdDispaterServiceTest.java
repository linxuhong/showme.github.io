package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.service.client.advertisement.service.impl.AdClientService;
import com.yihaodian.mobile.vo.ad.DataResource;
import com.yihaodian.mobile.vo.ad.MobAdResource;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class AdDispaterServiceTest extends BaseTest {
	AdDispaterService adDispaterService = new AdDispaterService();
	
	@Test
	public void testgetHotWords(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		AdClientService  adService = PowerMockito.mock(AdClientService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getAdClientService()).thenReturn(adService);
		MobAdResource<DataResource> mobAdResource = new MobAdResource<DataResource>();
		PowerMockito.when(adService.getHotWords(Mockito.isA(Integer.class),Mockito.isA(Integer.class),Mockito.anyString(),Mockito.isA(Trader.class),Mockito.anyString())).thenReturn(mobAdResource);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("pagetype", "12");
		bizInfo.put("seattype", "15");
		this.adDispaterService.getHotWords(urlPath, isLogined, bizInfo, content);
	}
	
	@Test
	public void testgetPerCenterAd(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		AdClientService  adService = PowerMockito.mock(AdClientService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getAdClientService()).thenReturn(adService);
		List<MobAdResource<DataResource>> list = new ArrayList<MobAdResource<DataResource>>();
		PowerMockito.when(adService.getActPushMessages(Mockito.isA(Integer.class),Mockito.isA(Integer.class),Mockito.anyString(),Mockito.anyString())).thenReturn(list);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("pagetype", "12");
		bizInfo.put("seattype", "15");
		this.adDispaterService.getPerCenterAd(urlPath, true, bizInfo, content);
	}
}
