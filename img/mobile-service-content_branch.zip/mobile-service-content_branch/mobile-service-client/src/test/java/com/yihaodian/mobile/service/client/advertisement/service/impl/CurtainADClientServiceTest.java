package com.yihaodian.mobile.service.client.advertisement.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.advertisement.CurtainAdvertisementService;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class CurtainADClientServiceTest {
	private CurtainADClientService CAClientService = new CurtainADClientService();
	@Mock
	private CurtainAdvertisementService curtainADHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(CAClientService, "curtainADHessianCall", curtainADHessianCall);
	}

	@Test
	public void testGetCurtainADHessianCall() {
		CAClientService.getCurtainADHessianCall();
	}

	@Test
	public void testSetCurtainADHessianCall() {
		CAClientService.setCurtainADHessianCall(curtainADHessianCall);
	}

	@Test
	public void testGetCurtainAdvertisement() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android5.0");
		trader.setDeviceCode("huaweip8");
		String interfaceVersion = "v2,0";
		CAClientService.getCurtainAdvertisement(trader, "huaweip8", 4, 45L, interfaceVersion );
	}

	@Test
	public void testOpenCurtainAdvertisement() {
		Trader trader = new Trader();
		trader.setClientAppVersion("v1.0");
		trader.setClientSystem("Android5.0");
		trader.setDeviceCode("huaweip8");
		CAClientService.openCurtainAdvertisement(trader, "huaweip8", 4);
	}

}
