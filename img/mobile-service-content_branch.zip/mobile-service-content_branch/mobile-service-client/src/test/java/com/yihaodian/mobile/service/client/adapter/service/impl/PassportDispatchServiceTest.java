package com.yihaodian.mobile.service.client.adapter.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.UserPassport;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class PassportDispatchServiceTest extends BaseTest{
	PassportDispatchService passportDispatchService = new PassportDispatchService();
	@Test
	public void testGetUserById() {
		
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		UserPassport userPassportService = PowerMockito.mock(UserPassport.class);
		PowerMockito.when(CentralMobileServiceHandler.getUserPassportService()).thenReturn(userPassportService).thenReturn(userPassportService);
	    PowerMockito.when(userPassportService.getUserById(Mockito.anyLong())).thenReturn(null).thenReturn(null);
	    passportDispatchService.getUserById(urlPath, isLogined, bizInfo, content);
	    try {
	    	PowerMockito.doThrow(new Exception()).when(userPassportService).getUserById(Mockito.anyLong());
		} catch (Exception e) {
			assertTrue(true);
		}
	    
	}

	@Test
	public void testUpdateUserById() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		UserPassport userPassportService = PowerMockito.mock(UserPassport.class);
		PowerMockito.when(CentralMobileServiceHandler.getUserPassportService()).thenReturn(userPassportService);
		PowerMockito.when(userPassportService.updateUserById(Mockito.anyLong())).thenReturn(null);
		passportDispatchService.updateUserById(urlPath, isLogined, bizInfo, content);
	}

}
