package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.service.client.advertisement.service.impl.CategoryAdClientService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;


@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class CategoryAdDispaterServiceTest extends BaseTest{
	CategoryAdDispaterService categoryAdDispaterService = new CategoryAdDispaterService();
	
	@Test
	public void testgetHotRecommendCateList(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CategoryAdClientService service = PowerMockito.mock(CategoryAdClientService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCategoryAdClientService()).thenReturn(service);
		PowerMockito.when(service.getHotRecommendCateList(Mockito.isA(Trader.class),Mockito.anyString(),Mockito.isA(Integer.class),Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("devicetoken", "12");
		bizInfo.put("categoryid", "15");
		
		this.categoryAdDispaterService.getHotRecommendCateList(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetMobReCateList(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn1);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("123");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CategoryAdClientService service = PowerMockito.mock(CategoryAdClientService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCategoryAdClientService()).thenReturn(service);
		PowerMockito.when(service.getMobReCateList(Mockito.anyString(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("id", "12");
	  this.categoryAdDispaterService.getMobReCateList(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetMobSubCategorysById(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		CategoryAdClientService service = PowerMockito.mock(CategoryAdClientService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getCategoryAdClientService()).thenReturn(service);
		PowerMockito.when(service.getMobSubCategorysById(Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("id", "12");
	}
}
