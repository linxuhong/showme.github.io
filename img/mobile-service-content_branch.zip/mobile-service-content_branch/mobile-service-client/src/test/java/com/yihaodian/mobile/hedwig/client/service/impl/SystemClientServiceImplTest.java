package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.system.SystemService;

public class SystemClientServiceImplTest {
	SystemClientServiceImpl systemClientServiceImpl= new SystemClientServiceImpl();
	@Mock
	SystemService systemServiceHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(systemClientServiceImpl, "systemServiceHessianCall", systemServiceHessianCall);
	}
	@Test
	public void test() {
		systemClientServiceImpl.registerLaunchInfo(null, null, null);
		systemClientServiceImpl.getAppFunctionSwitch(null);
		systemClientServiceImpl.getAppShowControl(null);
		systemClientServiceImpl.getClientApplicationDownloadUrl(null);
		systemClientServiceImpl.getProductQRcode(null, null, null, null);
		systemClientServiceImpl.getServerTimeStamp(null);
		systemClientServiceImpl.getStartupPicture(null, null, null,null);
		systemClientServiceImpl.getStartupPicVOList(null, null, null);
		systemClientServiceImpl.setSystemServiceHessianCall(systemServiceHessianCall);
		systemClientServiceImpl.getSystemServiceHessianCall();
	}

}
