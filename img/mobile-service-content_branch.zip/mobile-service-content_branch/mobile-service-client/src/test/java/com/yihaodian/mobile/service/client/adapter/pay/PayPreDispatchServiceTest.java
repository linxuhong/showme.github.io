package com.yihaodian.mobile.service.client.adapter.pay;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.pay.IPayPreService;
import com.yihaodian.mobile.service.facade.business.system.SystemService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class PayPreDispatchServiceTest extends BaseTest{
	PayPreDispatchService payPreDispatchService = new PayPreDispatchService();
	@Test
	public void testGetPayPreInfo() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		IPayPreService payPreService = PowerMockito.mock(IPayPreService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getPayPreService()).thenReturn(payPreService);
	    PowerMockito.when(payPreService.getPayPreInfo(Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
	    payPreDispatchService.getPayPreInfo(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("orderid", "1");
	    PowerMockito.when(payPreService.getPayPreInfo(Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
	    payPreDispatchService.getPayPreInfo(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testAutoSwitchGateWay() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		IPayPreService payPreService = PowerMockito.mock(IPayPreService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getPayPreService()).thenReturn(payPreService);
		PowerMockito.when(payPreService.autoSwitchGateWay(Mockito.anyLong(), Mockito.anyLong(), Mockito.any(ClientInfoVO.class), Mockito.anyInt())).thenReturn(null);
		bizInfo.put("orderid", "1");
		payPreDispatchService.autoSwitchGateWay(urlPath, isLogined, bizInfo, content);
	}

}
