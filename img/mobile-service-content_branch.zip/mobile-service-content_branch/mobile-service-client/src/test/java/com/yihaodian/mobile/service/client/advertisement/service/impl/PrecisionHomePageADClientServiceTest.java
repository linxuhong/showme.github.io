package com.yihaodian.mobile.service.client.advertisement.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.advertisement.IPrecisionHomePageService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class PrecisionHomePageADClientServiceTest {
	private PrecisionHomePageADClientService PHPAClientService = new PrecisionHomePageADClientService();
	
	@Mock
	private IPrecisionHomePageService precisionHomePageADHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(PHPAClientService, "precisionHomePageADHessianCall", precisionHomePageADHessianCall);
	}

	@Test
	public void testGetPrecisionHomePageADV4() {
		Long userId = 5L;
		Integer provinceId = 5;
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.3.89");
		clientInfoVO.setDeviceCode("iphone5");
		String interfaceVersion = "v4.0";
		String cityid = "liupanshui";
		PHPAClientService.getPrecisionHomePageADV4(clientInfoVO, provinceId, userId, interfaceVersion, cityid);
	}

	@Test
	public void testGetPrecisionHomePageProducts() {
		Long userId = 5L;
		Integer provinceId = 5;
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.3.89");
		clientInfoVO.setDeviceCode("iphone5");
		
		PHPAClientService.getPrecisionHomePageProducts(clientInfoVO, provinceId, userId, 4, 10);
	}

	@Test
	public void testSwitchToLocalUrl() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.3.89");
		clientInfoVO.setDeviceCode("iphone5");
		String url = "www.sina.com";
		String merchantName = "merchanName";
		Long merchantId = 45L;
		PHPAClientService.switchToLocalUrl(clientInfoVO, url, merchantName, merchantId);
	}

	@Test
	public void testGetHomePageproducts() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.3.89");
		clientInfoVO.setDeviceCode("iphone5");
		PHPAClientService.getHomePageproducts(clientInfoVO, 34, 45L, 6, 10);
	}

	@Test
	public void testGetGrouponBanner() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.3.89");
		clientInfoVO.setDeviceCode("iphone5");
		PHPAClientService.getGrouponBanner(clientInfoVO, 56, 34L, "v3.0", "viewCode");
	}

	@Test
	public void testGetPrecisionHomePageADHessianCall() {
		PHPAClientService.getPrecisionHomePageADHessianCall();
	}

	@Test
	public void testSetPrecisionHomePageADHessianCall() {
		PHPAClientService.setPrecisionHomePageADHessianCall(precisionHomePageADHessianCall);
	}

	@Test
	public void testGetHomePageproductsNew() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.3.89");
		clientInfoVO.setDeviceCode("iphone5");
		PHPAClientService.getHomePageproductsNew(clientInfoVO, 6, 45L, 6, 10);
	}
	
	@Test
	public void testGetPromoteSpecialTopic() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setTraderName("");
		clientInfoVO.setDeviceCode("ffffffff-8e65-04ea-8589-4fad0f36be26");
		PHPAClientService.getPromoteSpecialTopic(clientInfoVO, 1L, 1L, "10001");
	}

	@Test
	public void testDoushouProduct() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.3.89");
		clientInfoVO.setDeviceCode("iphone5");
		PHPAClientService.doushouProduct(clientInfoVO, 7);
	}

}
