package com.yihaodian.mobile.service.client.adapter.advertisement;

import java.util.HashMap;
import java.util.Map;

import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.Context;
import com.yihaodian.mobile2.server.context.RequestInfo.ClientInfo;

public class BaseTest {	
	protected String urlPath = "/mobileservice/isWeiDianHasDevice";
	protected String urlPath1 = "/mobileservice/v2";
	protected String provinceId = "1";
	protected boolean isLogined = true;
	protected static final String BASEURL="/mobileservice/";
	protected Map<String, String> bizInfo = new HashMap<String, String>();	
	protected ClientInfo clientInfo=new ClientInfo("3.1.6", "iossystemen", "4.1.2", "sfsdfsaasf3323aaf11212sf--asefasdf223", "36.062810", "113.82055","iossystemen", "10442025702", "1", "12", "119.97.231.227");
	protected ClientInfo clientInfo1=new ClientInfo("3.1.6", "android", "4.1.2", "sfsdfsaasf3323aaf11212sf--asefasdf223", "36.062810", "113.82055",null, "10442025702", "1", "12", "119.97.231.227");
	protected Context context=new Context(null, null, urlPath, null, true, null, null, null);
	
}
