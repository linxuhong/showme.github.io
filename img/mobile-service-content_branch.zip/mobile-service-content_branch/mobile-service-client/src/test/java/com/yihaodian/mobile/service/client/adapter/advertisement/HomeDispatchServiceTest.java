package com.yihaodian.mobile.service.client.adapter.advertisement;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.hedwig.core.service.spi.HomeService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class HomeDispatchServiceTest extends BaseTest{
	HomeDispatchService homeDispatchService = new HomeDispatchService();
	
	@Test
	public void testGetQualityAppList() {	
		try {
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
			HomeService homeService = PowerMockito.mock(HomeService.class);
			PowerMockito.when(CentralMobileServiceHandler.getHomeService()).thenReturn(homeService);
			PowerMockito.when(homeService.getQualityAppList(Mockito.any(Trader.class),Mockito.any(Integer.class),Mockito.any(Integer.class))).thenReturn(null);
			bizInfo.put("currentpage","1");
			bizInfo.put("pagesize","1");
			homeDispatchService.getQualityAppList(urlPath, isLogined, bizInfo, content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}

	@Test
	public void testGetHomeSelection() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		HomeService homeService = PowerMockito.mock(HomeService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomeService()).thenReturn(homeService);
		PowerMockito.when(homeService.getHomeSelection(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);		
		bizInfo.put("currentpage","1");
		bizInfo.put("pagesize","1");
		homeDispatchService.getHomeSelection(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetHomeHotElement() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		HomeService homeService = PowerMockito.mock(HomeService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomeService()).thenReturn(homeService);
		PowerMockito.when(homeService.getHomeHotElement(Mockito.any(Trader.class),Mockito.anyInt())).thenReturn(null);		
		bizInfo.put("currentpage","1");
		bizInfo.put("pagesize","1");
		homeDispatchService.getHomeHotElement(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetHomeModuleList() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		HomeService homeService = PowerMockito.mock(HomeService.class);
		PowerMockito.when(CentralMobileServiceHandler.getHomeService()).thenReturn(homeService);
		PowerMockito.when(homeService.getHomeModuleList(Mockito.any(Trader.class))).thenReturn(null);		
		bizInfo.put("currentpage","1");
		bizInfo.put("pagesize","1");
		Trader trader = new Trader();
		homeService.getHomeModuleList(trader );
	}

}
