package com.yihaodian.mobile.hedwig.client.impl.rock;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.IRockService;
import com.yihaodian.mobile.service.domain.business.dal.backend.RockAwardAccept;

public class RockClientServiceImplTest {
	
	private RockClientServiceImpl rockClientServiceImpl = new RockClientServiceImpl();
	
	@Mock
	private IRockService rockHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(rockClientServiceImpl, "rockHessianCall", rockHessianCall);
	}

	@Test
	public void testGetRockPromotionInfoStringStringInt() {
		int provinceId = 4;
		String userToken = "yhd_token";
		String activityId = "光棍节大促销";
		rockClientServiceImpl.getRockPromotionInfo(activityId, userToken, provinceId);
	}

	@Test
	public void testGetWinnersList() {
		String activityId = "光棍节大促销";
		rockClientServiceImpl.getWinnersList(activityId);
	}

	@Test
	public void testDoShakingStringStringIntStringStringInt() {
		int provinceId = 3;
		String deviceToken = "iphone_token";
		String traderName = "光棍节大促销";
		int isExplode = 4;
		String activityId ="1009";
		String userToken = "yhd_token";
		rockClientServiceImpl.doShaking(userToken, activityId, isExplode, 
				traderName, deviceToken, provinceId);
	}

	@Test
	public void testAcceptAwardStringStringStringIntIntIntStringString() {
		int provinceId = 3;
		String deviceToken = "iphone_token";
		String traderName = "光棍节大促销";
		String activityId ="1009";
		String userToken = "yhd_token";
		String awardId = "0099";
		int explodeSecIndex = 4;
		int isDiscard = 4;
		rockClientServiceImpl.acceptAward(userToken, activityId, awardId, explodeSecIndex,
				isDiscard, provinceId, traderName, deviceToken);
	}

	@Test
	public void testGetUsersForPush() {
		String step = "step";
		String startMin = "startmin";
		rockClientServiceImpl.getUsersForPush(startMin, step);
	}

	@Test
	public void testGetNewTimeStart() {
		String trrigerCount = "trrigerCount";
		String newSecIndex = "newSecIndex";
		rockClientServiceImpl.getNewTimeStart(newSecIndex, trrigerCount);
	}

	@Test
	public void testGetRockHessianCall() {
		rockClientServiceImpl.getRockHessianCall();
	}

	@Test
	public void testSetRockHessianCall() {
		rockClientServiceImpl.setRockHessianCall(rockHessianCall);
	}

	@Test
	public void testGetRockPromotionInfoStringStringLongInt() {
		int provinceId = 5;
		Long userId = 123L;
		String activityId = "activityId";
		String promotionType = "cousdown";
		rockClientServiceImpl.getRockPromotionInfo(promotionType, activityId, userId, provinceId);
	}

	@Test
	public void testDoShakingStringLongStringStringIntStringStringInt() {
		int provinceId = 4;
		String deviceToken = "deviceToken";
		String traderName = "tradername";
		int explodedSec =4;
		String activityId = "activityId";
		String userName = "django";
		Long userId = 34L;
		String promotionType = "promotionType";
		rockClientServiceImpl.doShaking(promotionType, userId, userName, activityId,
				explodedSec, traderName, deviceToken, provinceId);
	}

	@Test
	public void testGetRockPromotionInfoStringLongInt() {
		int provinceId = 4;
		String activityId = "activityId";
		String userToken = "userToken";
		rockClientServiceImpl.getRockPromotionInfo(activityId, userToken , provinceId);
	}

	@Test
	public void testDoShakingLongStringIntStringStringInt() {
		int provinceId = 4;
		String deviceToken = "deviceToken";
		String traderName = "tradername";
		String activityId = "activityId";
		Long userId = 34L;
		int isExplode = 5;
		rockClientServiceImpl.doShaking(userId, activityId, isExplode , 
				traderName, deviceToken, provinceId);
	}

	@Test
	public void testAcceptAwardLongStringStringIntIntIntStringString() {
		int provinceId = 4;
		String deviceToken = "deviceToken";
		String traderName = "tradername";
		String activityId = "activityId";
		Long userId = 34L;
		String awardId = "awardid";
		int explodeSecIndex = 4;
		int isDiscard = 5;
		rockClientServiceImpl.acceptAward(userId, activityId, awardId, explodeSecIndex, isDiscard,
				provinceId, traderName, deviceToken);
	}

	@Test
	public void testAcceptAwardStringLongStringStringIntIntIntStringStringStringRockAwardAccept() {
		int provinceId = 4;
		String deviceToken = "deviceToken";
		String traderName = "tradername";
		String activityId = "activityId";
		Long userId = 34L;
		String awardId = "awardid";
		int explodeSecIndex = 4;
		int isDiscard = 5;
		String promotionType = "promotionType";
		String ciphertext = "cipheretext";
		RockAwardAccept rockAwardAccept = new RockAwardAccept();
		rockAwardAccept.setAddress("上海");
		rockAwardAccept.setAwardId(776L);
		rockClientServiceImpl.acceptAward(promotionType, userId, activityId, awardId, explodeSecIndex, isDiscard, provinceId, 
				traderName, deviceToken, ciphertext, rockAwardAccept);
	}

	@Test
	public void testGetUserGiftBox() {
		rockClientServiceImpl.getUserGiftBox("activityId", 34L, 4);
	}

	@Test
	public void testSharePromotion() {
		rockClientServiceImpl.sharePromotion("activityId", 34L);
	}

	@Test
	public void testReturnAddress() {
		Long userId = 34L;
		String awardId = "400元大奖";
		String activityId = "促销大活动";
		rockClientServiceImpl.returnAddress(activityId, awardId, userId);
	}

}
