package com.yihaodian.mobile.service.client.adapter.integral;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.integral.IintergralWallService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,StringUtil.class})
public class IntergralWallDispatchServiceTest extends BaseTest{
	IntergralWallDispatchService intergralWallDispatchService = new IntergralWallDispatchService();
	
	@Test
	public void testRegisterIntergralWallInfo() {
		try {
			
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		
		PowerMockito.mockStatic(StringUtil.class);
		PowerMockito.when(StringUtil.isEmpty(Mockito.anyString())).thenReturn(false);
		IintergralWallService intergralWallService = PowerMockito.mock(IintergralWallService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PowerMockito.when(CentralMobileServiceHandler.getIntergralWallService()).thenReturn(intergralWallService);
	    PowerMockito.when(intergralWallService.registerIntergralWallInfo(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(null);
	    bizInfo.put("mac", "aeqer");
	    bizInfo.put("appid", "1");
	    bizInfo.put("idfa", "aeqer");
	    bizInfo.put("oem", "1");
	    intergralWallDispatchService.registerIntergralWallInfo(urlPath, isLogined, bizInfo, content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}

	@Test
	public void testActivatingIntergralWallInfo() {
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		
		PowerMockito.mockStatic(StringUtil.class);
		PowerMockito.when(StringUtil.isEmpty(Mockito.anyString())).thenReturn(false);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		IintergralWallService intergralWallService = PowerMockito.mock(IintergralWallService.class);
		PowerMockito.when(CentralMobileServiceHandler.getIntergralWallService()).thenReturn(intergralWallService);
	    PowerMockito.when(intergralWallService.activatingIntergralWallInfo((ClientInfoVO) Mockito.anyObject(), Mockito.anyString(), Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(null);
	    bizInfo.put("mac", "aeqer");
	    bizInfo.put("appid", "1");
	    bizInfo.put("idfa", "aeqer");
	    bizInfo.put("oem", "1");
	    intergralWallDispatchService.activatingIntergralWallInfo(urlPath, isLogined, bizInfo, content);
	
	}

}
