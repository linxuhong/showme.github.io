package com.yihaodian.mobile.hedwig.client.push.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.AppPushFacdeService;

public class AppPushClientServiceImplTest {
	AppPushClientServiceImpl appPushClientServiceImpl = new AppPushClientServiceImpl();
	@Mock
	AppPushFacdeService<String> appPushHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(appPushClientServiceImpl, "appPushHessianCall", appPushHessianCall);
	}
	@Test
	public void test() {
		appPushClientServiceImpl.insertAppPushInfo(null);
		appPushClientServiceImpl.insertAppPushInfoList(null);
		appPushClientServiceImpl.insertPushInfoForVUser(null, null, null, null, 0, null);
		appPushClientServiceImpl.isWeiDianHasDevice(null);
		appPushClientServiceImpl.isWeiDianHasDeviceForBatch(null);
		appPushClientServiceImpl.checkIfMobileUser(null);
		appPushClientServiceImpl.checkIfMobileUserForList(null);
		appPushClientServiceImpl.getAppPushHessianCall();
		appPushClientServiceImpl.getWeiDianDeviceToken(null);
		appPushClientServiceImpl.getWeiDianDeviceTokenForBatch(null);
		appPushClientServiceImpl.setAppPushHessianCall(appPushHessianCall);
	}

}
