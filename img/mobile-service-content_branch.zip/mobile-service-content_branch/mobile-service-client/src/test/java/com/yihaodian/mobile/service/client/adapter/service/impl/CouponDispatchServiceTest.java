package com.yihaodian.mobile.service.client.adapter.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.ICouponService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class CouponDispatchServiceTest extends BaseTest{
	CouponDispatchService couponDispatchService = new CouponDispatchService();
	@Test
	public void testSendNewguestCoupon() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ICouponService couponService = PowerMockito.mock(ICouponService.class);
		PowerMockito.when(CentralMobileServiceHandler.getCouponClientService()).thenReturn(couponService);
		PowerMockito.when(couponService.sendNewguestCoupon(Mockito.anyLong())).thenReturn(null);
		couponDispatchService.sendNewguestCoupon(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetMerchantH5Url() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ICouponService couponService = PowerMockito.mock(ICouponService.class);
		PowerMockito.when(CentralMobileServiceHandler.getCouponClientService()).thenReturn(couponService);
		PowerMockito.when(couponService.getMerchantH5Url(Mockito.any(Trader.class), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		bizInfo.put("brandid", "1");
		couponDispatchService.getMerchantH5Url(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testFlashSaleUrl() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ICouponService couponService = PowerMockito.mock(ICouponService.class);
		PowerMockito.when(CentralMobileServiceHandler.getCouponClientService()).thenReturn(couponService);
		PowerMockito.when(couponService.flashSaleUrl(Mockito.anyLong())).thenReturn(null);
		couponDispatchService.flashSaleUrl(urlPath, isLogined, bizInfo, content);
	}

}
