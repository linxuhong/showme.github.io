package com.yihaodian.mobile.service.client.adapter.advertisement;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.hedwig.core.service.spi.MobileProfileService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.ProductService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
import com.yihaodian.mobile2.server.context.RtnInfo;
@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class ProductDispatchServiceTest extends BaseTest{
	ProductDispatchService productDispatchService =new ProductDispatchService();
	@Test
	public void testGetHomeHotPointList(){
		try {
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			ProductService productService = PowerMockito.mock(ProductService.class);
			PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
			PowerMockito.when(productService.getHomeHotPointList(Mockito.any(Trader.class), Mockito.anyLong(),  Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);
			bizInfo.put("currentpage", "1");
			bizInfo.put("pagesize", "20");				
			RtnInfo r=productDispatchService.getHomeHotPointList(urlPath, isLogined, bizInfo, content);
		
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	@Test
	public void testGetAdvertisementList(){
		try {
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			ProductService productService = PowerMockito.mock(ProductService.class);
			PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
			PowerMockito.when(productService.getAdvertisementList(Mockito.any(Trader.class), Mockito.anyLong(),  Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);
			bizInfo.put("currentpage", "1");
			bizInfo.put("pagesize", "20");		
			bizInfo.put("productid", "123456");
			RtnInfo r=productDispatchService.getAdvertisementList(urlPath, isLogined, bizInfo, content);
		
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testGetPackageProducts(){
		try {
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			ProductService productService = PowerMockito.mock(ProductService.class);
			PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
			PowerMockito.when(productService.getPackageProducts(Mockito.any(Trader.class), Mockito.anyLong(),  Mockito.anyInt(),Mockito.anyInt(),Mockito.anyLong())).thenReturn(null);
			bizInfo.put("currentpage", "1");
			bizInfo.put("pagesize", "20");		
			bizInfo.put("productid", "123456");
			RtnInfo r=productDispatchService.getPackageProducts(urlPath, isLogined, bizInfo, content);

		} catch (Exception e) {
			assertTrue(true);
		}
	}
	@Test
	public void testGetUserInterestedProducts(){
		try {
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			ProductService productService = PowerMockito.mock(ProductService.class);
			PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
			PowerMockito.when(productService.getUserInterestedProducts(Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);
			bizInfo.put("currentpage", "1");
			bizInfo.put("pagesize", "20");		
			RtnInfo r=productDispatchService.getUserInterestedProducts(urlPath, isLogined, bizInfo, content);

		} catch (Exception e) {
			assertTrue(true);
		}
	}
   @Test
   public void testgetMoreInterestedProducts(){
	   RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		ProductService productService = PowerMockito.mock(ProductService.class);
		PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
		PowerMockito.when(productService.getMoreInterestedProducts(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.any(Integer.class),Mockito.any(Integer.class))).thenReturn(null);
		bizInfo.put("currentpage", "1");
		bizInfo.put("pagesize", "20");	
		bizInfo.put("productid","12");
		RtnInfo r=productDispatchService.getMoreInterestedProducts(urlPath, isLogined, bizInfo, content);
   }
   
   @Test
   public void testgetHotRandomProducts(){
	   RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		ProductService productService = PowerMockito.mock(ProductService.class);
		PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
	   PowerMockito.when(productService.getHotRandomProducts(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn(null);
	   RtnInfo r=productDispatchService.getHotRandomProducts(urlPath, isLogined, bizInfo, content);
   }
   @Test
   public void testgetYhbByCategoryId(){
	   bizInfo.put("currentpage", "1");
	   bizInfo.put("pagesize", "20");
	   bizInfo.put("categoryid", "3");
	   bizInfo.put("sitetype", "4");
	   bizInfo.put("mcsiteid", "5");
	   RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		ProductService productService = PowerMockito.mock(ProductService.class);
		PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
	   PowerMockito.when(productService.getYhbByCategoryId(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.any(Integer.class),Mockito.any(Integer.class))).thenReturn(null);
	   RtnInfo r=productDispatchService.getYhbByCategoryId(urlPath, isLogined, bizInfo, content);
   }
   @Test
   public void testgetPromotionProductPage(){
	   bizInfo.put("currentpage", "1");
	   bizInfo.put("pagesize", "20");
	   bizInfo.put("categoryid", "3");
	   bizInfo.put("sitetype", "4");
	   bizInfo.put("mcsiteid", "5");
	   RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		ProductService productService = PowerMockito.mock(ProductService.class);
		PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
		PowerMockito.when(productService.getPromotionProductPage(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong(),Mockito.any(Integer.class),Mockito.any(Integer.class))).thenReturn(null);
		RtnInfo r=productDispatchService.getPromotionProductPage(urlPath, isLogined, bizInfo, content);
   }
   
   @Test
   public void testgetHomeHotProductTop5List(){
	   RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		ProductService productService = PowerMockito.mock(ProductService.class);
		PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
		PowerMockito.when(productService.getHomeHotProductTop5List(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn(null);
		RtnInfo r=productDispatchService.getHomeHotProductTop5List(urlPath, isLogined, bizInfo, content);
	   
   }
   
   @Test
   public void testgetHotProductPageByCategoryId(){
	   bizInfo.put("currentpage", "1");
	   bizInfo.put("pagesize", "20");
	   bizInfo.put("categoryid", "3");
	   bizInfo.put("sitetype", "4");
	   bizInfo.put("mcsiteid", "5");
	   RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		ProductService productService = PowerMockito.mock(ProductService.class);
		PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
		PowerMockito.when(productService.getHotProductPageByCategoryId(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong(),Mockito.any(Integer.class),Mockito.any(Integer.class))).thenReturn(null);
		RtnInfo r=productDispatchService.getHotProductPageByCategoryId(urlPath, isLogined, bizInfo, content);
	  }
   @Test
   public void testgetHotProductByActivityID(){
	   bizInfo.put("currentpage", "1");
	   bizInfo.put("pagesize", "20");
	   bizInfo.put("categoryid", "3");
	   bizInfo.put("sitetype", "4");
	   bizInfo.put("mcsiteid", "5");
	   RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		ProductService productService = PowerMockito.mock(ProductService.class);
		PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
		PowerMockito.when(productService.getHotProductByActivityID(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong(),Mockito.any(Integer.class),Mockito.any(Integer.class))).thenReturn(null);
		RtnInfo r=productDispatchService.getHotProductByActivityID(urlPath, isLogined, bizInfo, content);
   }
   @Test
   public void testgetUserInterestedProductsCategorys(){
	   RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		ProductService productService = PowerMockito.mock(ProductService.class);
		PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
		PowerMockito.when(productService.getUserInterestedProductsCategorys(Mockito.any(Trader.class))).thenReturn(null);
		RtnInfo r=productDispatchService.getUserInterestedProductsCategorys(urlPath, isLogined, bizInfo, content);
   }
   @Test
   public void testgetHotProductCountByCategoryId(){
	   bizInfo.put("currentpage", "1");
	   bizInfo.put("pagesize", "20");
	   bizInfo.put("categoryid", "3");
	   bizInfo.put("sitetype", "4");
	   bizInfo.put("mcsiteid", "5");
	   RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		ProductService productService = PowerMockito.mock(ProductService.class);
		PowerMockito.when(CentralMobileServiceHandler.getProductService()).thenReturn(productService);	
		PowerMockito.when(productService.getHotProductCountByCategoryId(Mockito.any(Trader.class),Mockito.anyLong(),Mockito.anyLong())).thenReturn(null);
		RtnInfo r=productDispatchService.getHotProductCountByCategoryId(urlPath, isLogined, bizInfo, content);
   }
}
