package com.yihaodian.mobile.service.client.adapter.flashPurchase;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.system.SystemService;
import com.yihaodian.mobile.service.facade.content.spi.FlashPurchaseService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class FlashPurchaseDispatchServiceTest extends BaseTest {
	FlashPurchaseDispatchService flashPurchaseDispatchService = new FlashPurchaseDispatchService();
	@Test
	public void testGetBrandCollectState() {
		try {
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			FlashPurchaseService flashPurchaseService = PowerMockito.mock(FlashPurchaseService.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
  			PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			PowerMockito.when(CentralMobileServiceHandler.getFlashPurchaseService()).thenReturn(flashPurchaseService);			
			PowerMockito.when(flashPurchaseService.getBrandCollectState(Mockito.anyString(), Mockito.anyLong())).thenReturn(true);
			bizInfo.put("brandid", "12");
			flashPurchaseDispatchService.getBrandCollectState(urlPath, isLogined, bizInfo, content);
			
		} catch (Exception e) {
			assertTrue(true);
		}
	}

	@Test
	public void testGetFavoriteBrandLists() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		FlashPurchaseService flashPurchaseService = PowerMockito.mock(FlashPurchaseService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getFlashPurchaseService()).thenReturn(flashPurchaseService);			
		PowerMockito.when(flashPurchaseService.getFavoriteBrandLists(Mockito.anyString(), Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);
		bizInfo.put("currentpage", "12");
		bizInfo.put("pagesize", "12");
		flashPurchaseDispatchService.getFavoriteBrandLists(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testAddFavoriteForBrand() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		FlashPurchaseService flashPurchaseService = PowerMockito.mock(FlashPurchaseService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getFlashPurchaseService()).thenReturn(flashPurchaseService);			
		PowerMockito.when(flashPurchaseService.addFavoriteForBrand(Mockito.anyString(), Mockito.anyLong())).thenReturn(true);
		bizInfo.put("brandid", "12");
		flashPurchaseDispatchService.addFavoriteForBrand(urlPath, isLogined, bizInfo, content);
	
	}

}
