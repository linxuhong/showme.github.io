package com.yihaodian.mobile.hedwig.client.impl.product;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.product.spi.IProductSignService;

public class ProductSignClientServiceTest {
	
	private ProductSignClientService productSignClientService = new ProductSignClientService();
	@Mock
	private IProductSignService productSignHessianCall;
	@Before
	public void initMock() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(productSignClientService, "productSignHessianCall", productSignHessianCall);
	}

	@Test
	public void testGetInterestedProductsByUserStringStringStringLongLongLongLongInteger() {
		Integer productNum = 232334;
		Long merchantId = 23L;
		Long provinceId = 4L;
		Long pmId = 35L;
		Long productId = 344L;
		String clientAppVersion= "v1.0";
		String traderName = "大促销";
		String userToken = "userTocken";
		productSignClientService.
		getInterestedProductsByUser
		(userToken, traderName, clientAppVersion, productId,
				pmId, provinceId, merchantId, productNum);
	}

	@Test
	public void testGetProductSignHessianCall() {
		productSignClientService.getProductSignHessianCall();
	}

	@Test
	public void testSetProductSignHessianCall() {
		productSignClientService.setProductSignHessianCall(productSignHessianCall);
	}

	@Test
	public void testGetInterestedProductsByUserLongStringStringLongLongLongLongInteger() {
		Integer productNum = 232334;
		Long merchantId = 23L;
		Long provinceId = 4L;
		Long pmId = 35L;
		Long productId = 344L;
		String clientAppVersion= "v1.0";
		String traderName = "大促销";
		String userToken = "userTocken";
		String userId = "yhdlfe009";
		productSignClientService.getInterestedProductsByUser(userId , traderName, clientAppVersion, 
				productId, pmId, provinceId, merchantId, productNum);
	}

}
