package com.yihaodian.mobile.service.client.advertisement.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.advertisement.AdvertisementShareService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class AdvertisementShareClientServiceImplTest {
	private AdvertisementShareClientServiceImpl ASClientsevie = new AdvertisementShareClientServiceImpl();
	@Mock
	private AdvertisementShareService advertisementShareHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(ASClientsevie, "advertisementShareHessianCall", advertisementShareHessianCall);
	}

	@Test
	public void testGetShareInfoByCmsId() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.3.45");
		clientInfoVO.setDeviceCode("nubiaz9");
		ASClientsevie.getShareInfoByCmsId(clientInfoVO , 67L);
	}

	@Test
	public void testSetAdvertisementShareHessianCall() {
		ASClientsevie.setAdvertisementShareHessianCall(advertisementShareHessianCall);
	}

}
