package com.yihaodian.mobile.hedwig.client.redshare;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.IOrderRedService;

public class OrderRedClientServiceTest {
	
	private OrderRedClientService orderRedClientService = new OrderRedClientService();
	@Mock
	private IOrderRedService orderRedHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(orderRedClientService, "orderRedHessianCall", orderRedHessianCall);
	}

	@Test
	public void testSetOrderRedHessianCall() {
		orderRedClientService.setOrderRedHessianCall(orderRedHessianCall);
	}

	@Test
	public void testIsPromotionAvailable() {
		Long orderId = 23L;
		Long userId = 45L;
		orderRedClientService.isPromotionAvailable(userId, orderId);
	}

	@Test
	public void testGetPromotionDetail() {
		Long orderId = 23L;
		Long userId = 45L;
		orderRedClientService.getPromotionDetail(userId, orderId);
	}

	@Test
	public void testGetPromotionDescription() {
		Long promotionId = 34L;
		orderRedClientService.getPromotionDescription(promotionId );
	}

	@Test
	public void testShareOrderRed() {
		Long orderId = 23L;
		Long userId = 45L;
		orderRedClientService.shareOrderRed(userId, orderId);
	}

	@Test
	public void testOpenOrderRed() {
		orderRedClientService.openIndependentOrderRed(34L);
	}

	@Test
	public void testGetOrderRedByPhone() {
		String awardId = "o90sfs";
		Long userId = 34L;
		String phone = "nubia";
		String code = "lsdfjweo";
		orderRedClientService.getOrderRedByPhone(code, phone, userId, awardId);
	}

	@Test
	public void testSendSingleSMS() {
		String content = "content";
		String mobile = "iphone";
		orderRedClientService.sendSingleSMS(mobile, content);
	}

	@Test
	public void testOpenIndependentOrderRed() {
		Long promotionId = 45L;
		orderRedClientService.openIndependentOrderRed(promotionId );
	}

	@Test
	public void testGetIndependentOrderRedByPhone() {
		String awardId = "799大奖";
		Long userId = 45L;
		String phone = "nubia9mini";
		orderRedClientService.getIndependentOrderRedByPhone(phone, userId, awardId);
	}

}
