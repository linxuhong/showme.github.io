package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.hedwig.core.service.spi.MonkeyService;

public class MonkeyClientServiceImplTest {
	MonkeyClientServiceImpl monkeyClientServiceImpl = new MonkeyClientServiceImpl();
	@Mock
	MonkeyService monkeyHessiancall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(monkeyClientServiceImpl, "monkeyHessiancall", monkeyHessiancall);
	}
	@Test
	public void test() {
		monkeyClientServiceImpl.monkeyCheckMobileNumber(null, null);
		monkeyClientServiceImpl.monkeyGetExtratCouponResult(123L, null, null);
		monkeyClientServiceImpl.monkeyInsertAddress(123L, null, null, null);
		monkeyClientServiceImpl.monkeyGetCouponCheckCode(null, null);
		monkeyClientServiceImpl.getMonkeyHessiancall();
		monkeyClientServiceImpl.setMonkeyHessiancall(monkeyHessiancall);
	}

}
