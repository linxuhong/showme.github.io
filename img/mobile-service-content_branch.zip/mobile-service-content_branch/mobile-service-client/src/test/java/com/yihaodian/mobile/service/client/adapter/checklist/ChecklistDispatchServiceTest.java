package com.yihaodian.mobile.service.client.adapter.checklist;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.mobile.backend.checklist.vo.BatchSaveListVO;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.service.checklist.spi.ChecklistService;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.hedwig.core.service.spi.FeedbackService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class ChecklistDispatchServiceTest extends BaseTest{
	ChecklistDispatchService checklistDispatchService = new ChecklistDispatchService();
	
	@Test
	public void testgetUserAllLists(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.getUserAllLists(Mockito.anyLong(),Mockito.anyBoolean(),Mockito.anyBoolean(),Mockito.anyBoolean())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("includeitems", "12");
		bizInfo.put("includeauthusers", "15");
		bizInfo.put("isdoneonly", "20");
		this.checklistDispatchService.getUserAllLists(urlPath, false, bizInfo, content);
		this.checklistDispatchService.getUserAllLists(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetUserListDetail(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.getUserListDetail(Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "12");
		this.checklistDispatchService.getUserListDetail(urlPath, false, bizInfo, content);
		this.checklistDispatchService.getUserListDetail(urlPath, true, bizInfo, content);
	}
	@Test
	public void testCreateUserList(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("title", "用户标题");
		bizInfo.put("remindtime", "2017-01-03 14:34:25");
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.createUserList(Mockito.anyLong(), Mockito.anyString(), Mockito.any(Date.class))).thenReturn(result);
		checklistDispatchService.createUserList(urlPath, false, bizInfo, content);
		checklistDispatchService.createUserList(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testUpdateUserList(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "12");
		bizInfo.put("version", "4.3.0");
		bizInfo.put("oneclickdone", "1");
		bizInfo.put("title", "用户标题");
		bizInfo.put("remindtime", "2017-01-03 14:34:25");
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.updateUserList(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(),
				Mockito.any(Date.class), Mockito.anyBoolean(), Mockito.anyLong())).thenReturn(result);
		checklistDispatchService.updateUserList(urlPath, false, bizInfo, content);
		checklistDispatchService.updateUserList(urlPath, true, bizInfo, content);
		bizInfo.put("version", "4");
		checklistDispatchService.updateUserList(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testCreateListItem(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "");
		bizInfo.put("version", "4.3.0");
		bizInfo.put("memo", "1");
		bizInfo.put("externalurl", "http://m.yhd.com/charge/showAppH5GameHome.action");
		bizInfo.put("picurls", "['http://d6.yihaodianimg.com/TEST/M04/2D/49/CqGQP1eNl_aAaqsDAADegfn8EVs90700.jpg']");
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.createListItem(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(),
				Mockito.anyList(), Mockito.anyString())).thenReturn(result);
		checklistDispatchService.createListItem(urlPath, false, bizInfo, content);
		checklistDispatchService.createListItem(urlPath, true, bizInfo, content);
		bizInfo.put("listid", "4");
		checklistDispatchService.createListItem(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testUpdateListItem(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "");
		bizInfo.put("version", "4.3.0");
		
		bizInfo.put("itemid", "1");
		bizInfo.put("externalurl", "http://m.yhd.com/charge/showAppH5GameHome.action");
		bizInfo.put("picurls", "['http://d6.yihaodianimg.com/TEST/M04/2D/49/CqGQP1eNl_aAaqsDAADegfn8EVs90700.jpg']");
		bizInfo.put("picids2del", "[1,2,3]");
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.updateListItem(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyList(),Mockito.anyBoolean(),Mockito.anyBoolean(), Mockito.anyLong())).thenReturn(result);
		checklistDispatchService.updateListItem(urlPath, false, bizInfo, content);
		checklistDispatchService.updateListItem(urlPath, true, bizInfo, content);
		bizInfo.put("listid", "4");
		checklistDispatchService.updateListItem(urlPath, true, bizInfo, content);
		bizInfo.put("memo", "1");
		bizInfo.put("version", "1");
		
		checklistDispatchService.updateListItem(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testReorderListItem(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "");
		bizInfo.put("version", "4.3.0");
		
		bizInfo.put("itemid", "1");
		bizInfo.put("externalurl", "http://m.yhd.com/charge/showAppH5GameHome.action");
		bizInfo.put("picurls", "['http://d6.yihaodianimg.com/TEST/M04/2D/49/CqGQP1eNl_aAaqsDAADegfn8EVs90700.jpg']");
		bizInfo.put("move", "1");
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.reorderListItem(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyInt())).thenReturn(result);
		checklistDispatchService.reorderListItem(urlPath, false, bizInfo, content);
		checklistDispatchService.reorderListItem(urlPath, true, bizInfo, content);
		bizInfo.put("listid", "4");
		checklistDispatchService.reorderListItem(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testCopyListItems(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "");
		bizInfo.put("itemids", "[1]");
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.copyListItems(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong())).thenReturn(result);
		checklistDispatchService.copyListItems(urlPath, false, bizInfo, content);
		checklistDispatchService.copyListItems(urlPath, true, bizInfo, content);
		bizInfo.put("listid", "4");
		checklistDispatchService.copyListItems(urlPath, true, bizInfo, content);
	}
	
	
	@Test
	public void testAuthorizeUsersListRequest(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "");
		bizInfo.put("authusers", "[1,2,3]");
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.authorizeUsersListRequest(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyList())).thenReturn(result);
		checklistDispatchService.authorizeUsersListRequest(urlPath, false, bizInfo, content);
		checklistDispatchService.authorizeUsersListRequest(urlPath, true, bizInfo, content);
		bizInfo.put("listid", "4");
		checklistDispatchService.authorizeUsersListRequest(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testAuthorizeUserListResponse(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "");
		bizInfo.put("userid", "1");
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.authorizeUserListResponse(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyBoolean())).thenReturn(result);
		checklistDispatchService.authorizeUserListResponse(urlPath, false, bizInfo, content);
		checklistDispatchService.authorizeUserListResponse(urlPath, true, bizInfo, content);
		bizInfo.put("listid", "4");
		checklistDispatchService.authorizeUserListResponse(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testGetUserAuthorizeListPendingRequests(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "");
		bizInfo.put("userid", "1");
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.getUserAuthorizeListPendingRequests(Mockito.anyLong())).thenReturn(result);
		checklistDispatchService.getUserAuthorizeListPendingRequests(urlPath, false, bizInfo, content);
		checklistDispatchService.getUserAuthorizeListPendingRequests(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testDeleteUserList(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "");
		
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.deleteUserList(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		checklistDispatchService.deleteUserList(urlPath, false, bizInfo, content);
		bizInfo.put("version", "1");
		checklistDispatchService.deleteUserList(urlPath, true, bizInfo, content);
		bizInfo.put("listid", "23");
		checklistDispatchService.deleteUserList(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testDeleteListItem(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("listid", "");
		
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.deleteListItem(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(result);
		checklistDispatchService.deleteListItem(urlPath, false, bizInfo, content);
		bizInfo.put("listid", "23");
		checklistDispatchService.deleteListItem(urlPath, true, bizInfo, content);
		bizInfo.put("itemid", "23");
		checklistDispatchService.deleteListItem(urlPath, true, bizInfo, content);
		bizInfo.put("version", "1");
		checklistDispatchService.deleteListItem(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testBatchSaveItemList(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("").thenReturn("1");
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("offlinelist", "{list:null,items:[],'deletedItems':[]}");
		bizInfo.put("replacemode", "23");
		
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.batchSaveItemList(Mockito.anyLong(),Mockito.any(BatchSaveListVO.class),Mockito.anyBoolean())).thenReturn(result);
		checklistDispatchService.batchSaveItemList(urlPath, false, bizInfo, content);
		checklistDispatchService.batchSaveItemList(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testParseExternalUrl(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		RequestInfo requestInfo = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		requestInfo.setProvinceId("1");
		PowerMockito.when(content.getRequestInfo()).thenReturn(requestInfo);
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("externalurl", "");
		
		ChecklistService service = PowerMockito.mock(ChecklistService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getChecklistService()).thenReturn(service);
		PowerMockito.when(service.parseExternalUrl(Mockito.anyString(),Mockito.anyLong())).thenReturn(result);
		checklistDispatchService.parseExternalUrl(urlPath, false, bizInfo, content);
		bizInfo.put("externalurl", "http://m.yhd.com/charge/showAppH5GameHome.action");
		checklistDispatchService.parseExternalUrl(urlPath, true, bizInfo, content);
	}
	

	@Test
	public void testAddFeedbackForChecklist(){
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		RequestInfo requestInfo = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		requestInfo.setProvinceId("1");
		PowerMockito.when(content.getRequestInfo()).thenReturn(requestInfo);
		
		Map<String, String> bizInfo = new HashMap<String, String>();
		bizInfo.put("feedbackcontext", "");
		bizInfo.put("image1", "");
		bizInfo.put("image2", "");
		bizInfo.put("image3", "");
		bizInfo.put("info", "");
		
		FeedbackService service = PowerMockito.mock(FeedbackService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getFeedbackService()).thenReturn(service);
		PowerMockito.when(service.addFeedback(
				Mockito.anyLong(),
				Mockito.anyString(),Mockito.anyString(),Mockito.anyString()
				,Mockito.anyString(),Mockito.any(Trader.class),Mockito.anyString())).thenReturn(1);
		checklistDispatchService.addFeedbackForChecklist(urlPath, false, bizInfo, content);
		bizInfo.put("externalurl", "http://m.yhd.com/charge/showAppH5GameHome.action");
		checklistDispatchService.addFeedbackForChecklist(urlPath, true, bizInfo, content);
		bizInfo.put("feedbackcontext", "feedback");
		checklistDispatchService.addFeedbackForChecklist(urlPath, true, bizInfo, content);
	}
}
