package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.hedwig.core.service.spi.PromotionService;

public class PromotionClientServiceImplTest {
	PromotionClientServiceImpl promotionClientServiceImpl = new PromotionClientServiceImpl();
	@Mock
	PromotionService promotionHessiancall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(promotionClientServiceImpl, "promotionHessiancall", promotionHessiancall);
	}
	@Test
	public void test() {
		promotionClientServiceImpl.addCouponByActivityId(null, null);
		promotionClientServiceImpl.addStorageBox(null, null, null, null, null, null);
		promotionClientServiceImpl.checkResult(null, null, null);
		//promotionClientServiceImpl.checkRockResult(null, null, null, null, null);
		promotionClientServiceImpl.createRockGame(null);
		promotionClientServiceImpl.createRockGameFlow(null, null);
		promotionClientServiceImpl.isCanInviteeUser(null, null);
		promotionClientServiceImpl.processGameFlow(null, null);
		promotionClientServiceImpl.getAdvertisingPromotionVOByType(null, null, null, null, null);
		promotionClientServiceImpl.getAwardsResults(null);
		promotionClientServiceImpl.getCmsAdvertisingPromotion(null, null, null);
		promotionClientServiceImpl.getCmsColumnByColumnById(null, null, null, null, null, null, null);
		promotionClientServiceImpl.getCmsColumnList(null, null, null, null, null, null);
		promotionClientServiceImpl.getCmsColumnListV2(null, null, null, null, null, null);
		promotionClientServiceImpl.getCmsColumnList(null, null, null, null, null, null, null);
		promotionClientServiceImpl.getCmsPageList(null, null, null, null, null);
		promotionClientServiceImpl.getHomeHotPointListNew(null, null, null, null);
		promotionClientServiceImpl.getHotPointNewVOById(null, null, null);
		promotionClientServiceImpl.getRockResultV3(null, null, null, null);
		promotionClientServiceImpl.getRockResultV3(null, null, null);
		promotionClientServiceImpl.getRockResultV2(null, null);
		promotionClientServiceImpl.getRockResult(null, null, null, null);
		promotionClientServiceImpl.getRockProductList(null, null, null, null);
		promotionClientServiceImpl.getRockGameProductVO(null);
		promotionClientServiceImpl.getRockGameByToken(null, null);
		promotionClientServiceImpl.getPromotionHessiancall();
		promotionClientServiceImpl.getPromotionByTopicID(null, null);
		promotionClientServiceImpl.getPresentsByToken(null);
		promotionClientServiceImpl.getMyStorageBoxList(null, null, null, null);
		promotionClientServiceImpl.setPromotionHessiancall(promotionHessiancall);
	}

}
