package com.yihaodian.mobile.service.client.adapter.seckill;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.SeckillProductService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class SeckillDispatchServiceTest extends BaseTest {
	SeckillDispatchService seckillDispatchService =new SeckillDispatchService();
	@Test
	public void testCheckIfSecKill() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		SeckillProductService seckillProductService = PowerMockito.mock(SeckillProductService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getSeckillClientService()).thenReturn(seckillProductService);
		PowerMockito.when(seckillProductService.checkIfSecKill(Mockito.any(Trader.class), Mockito.anyString(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		bizInfo.put("productid", "1");
		bizInfo.put("promotionid", "1");
		seckillDispatchService.checkIfSecKill(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testSeckillProduct() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		SeckillProductService seckillProductService = PowerMockito.mock(SeckillProductService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getSeckillClientService()).thenReturn(seckillProductService);
		PowerMockito.when(seckillProductService.seckillProduct(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
		bizInfo.put("productid", "1");
		bizInfo.put("promotionid", "1");
		seckillDispatchService.seckillProduct(urlPath, isLogined, bizInfo, content);

	}

	@Test
	public void testPreSeckillProduct() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		SeckillProductService seckillProductService = PowerMockito.mock(SeckillProductService.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(CentralMobileServiceHandler.getSeckillClientService()).thenReturn(seckillProductService);
		PowerMockito.when(seckillProductService.preSeckillProduct(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
		bizInfo.put("productid", "1");
		bizInfo.put("promotionid", "1");
		bizInfo.put("", "1");
		seckillDispatchService.preSeckillProduct(urlPath, isLogined, bizInfo, content);
	
	}

	@Test
	public void testCheckSeckillCanBuy() {
		try {	
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			SeckillProductService seckillProductService = PowerMockito.mock(SeckillProductService.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			PowerMockito.when(CentralMobileServiceHandler.getSeckillClientService()).thenReturn(seckillProductService);
			PowerMockito.when(seckillProductService.checkSeckillCanBuy(Mockito.anyString(),Mockito.anyListOf(String.class), Mockito.anyListOf(Long.class))).thenReturn(null);
			bizInfo.put("promotionidlist", "[1]");
			seckillDispatchService.checkSeckillCanBuy(urlPath, isLogined, bizInfo, content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}

}
