package com.yihaodian.mobile.service.client.adapter.mobilecoupon;


import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.AssertThrows;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.coupon.IMobileCouponFacadeService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class MobileCouponDispatchServiceTest extends BaseTest {
	MobileCouponDispatchService mobileCouponDispatchService = new MobileCouponDispatchService();
	@Test
	public void testCheckCouppnVerfyCode() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		IMobileCouponFacadeService service = PowerMockito.mock(IMobileCouponFacadeService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileCouponClientService()).thenReturn(service);
		PowerMockito.when(service.checkCouppnVerfyCode(Mockito.any(Trader.class), Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		mobileCouponDispatchService.checkCouppnVerfyCode(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetCouponActivityVOByPromotionId() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		IMobileCouponFacadeService service = PowerMockito.mock(IMobileCouponFacadeService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMobileCouponClientService()).thenReturn(service);
        PowerMockito.when(service.getCouponActivityVOByPromotionId(Mockito.any(Trader.class), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
        bizInfo.put("type", "1");
        bizInfo.put("promotionid", "1");
        bizInfo.put("currentpage", "1");
        bizInfo.put("pagesize", "1");
        mobileCouponDispatchService.getCouponActivityVOByPromotionId(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testReceiveCouponByActivityId() {
		try {
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
			PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
			IMobileCouponFacadeService service = PowerMockito.mock(IMobileCouponFacadeService.class);
			PowerMockito.when(CentralMobileServiceHandler.getMobileCouponClientService()).thenReturn(service);
			PowerMockito.when(service.receiveCouponByActivityId(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(), Mockito.any(Trader.class)));
			bizInfo.put("couponactivityid", "1");
	        bizInfo.put("entryactiveid", "1");
			mobileCouponDispatchService.receiveCouponByActivityId(urlPath, isLogined, bizInfo, content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}

}
