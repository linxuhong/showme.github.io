package com.yihaodian.mobile.service.client.adapter.user;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;
import com.yihaodian.mobile.service.user.spi.UserFacadeService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class UserDispatchServiceTest extends BaseTest{
	UserDispatchService userDispatchService = new UserDispatchService();
	@Test
	public void testInsertAppErrorLog() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");	
		UserFacadeService userFacadeService = PowerMockito.mock(UserFacadeService.class);
		PowerMockito.when(CentralMobileServiceHandler.getUserClientService()).thenReturn(userFacadeService);
	    PowerMockito.when(userFacadeService.insertAppErrorLog(Mockito.any(Trader.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
	    userDispatchService.insertAppErrorLog(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testEnableDeviceForPushMsg() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		UserFacadeService userFacadeService = PowerMockito.mock(UserFacadeService.class);
		PowerMockito.when(CentralMobileServiceHandler.getUserClientService()).thenReturn(userFacadeService);
	    PowerMockito.when(userFacadeService.enableDeviceForPushMsg(Mockito.any(Trader.class), Mockito.anyString(), Mockito.anyBoolean(), Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);
	   bizInfo.put("isopen", "1");
	   bizInfo.put("starthour", "1");
	   bizInfo.put("endhour", "1");
	    userDispatchService.enableDeviceForPushMsg(urlPath, isLogined, bizInfo, content);
	}

}
