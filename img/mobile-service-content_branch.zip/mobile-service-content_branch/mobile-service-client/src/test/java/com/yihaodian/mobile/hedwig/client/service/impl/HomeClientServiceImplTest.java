package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.hedwig.core.service.spi.HomeService;

public class HomeClientServiceImplTest {
	HomeClientServiceImpl homeClientServiceImpl = new HomeClientServiceImpl();
	@Mock
	HomeService homeHessiancall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(homeClientServiceImpl, "homeHessiancall", homeHessiancall);
	}
	@Test
	public void test() {
		homeClientServiceImpl.getHomeHessiancall();
		homeClientServiceImpl.getHomeHotElement(null, 0);
		homeClientServiceImpl.getHomeModuleList(null);
		homeClientServiceImpl.getHomeSelection(null, null, null, null);
		homeClientServiceImpl.getQualityAppList(null, null, null);
		homeClientServiceImpl.setHomeHessiancall(homeHessiancall);
	}

}
