package com.yihaodian.mobile.hedwig.client.service.user.impl;


import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.user.spi.UserFacadeService;

public class UserClientServiceTest {
	UserClientService userClientService = new UserClientService();
	@Mock
	UserFacadeService userHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(userClientService, "userHessianCall", userHessianCall);
	}
	@Test
	public void test() {
		userClientService.enableDeviceForPushMsg(null, null, null, null, null);
		userClientService.getUserHessianCall();
		userClientService.setUserHessianCall(userHessianCall);
	}

}
