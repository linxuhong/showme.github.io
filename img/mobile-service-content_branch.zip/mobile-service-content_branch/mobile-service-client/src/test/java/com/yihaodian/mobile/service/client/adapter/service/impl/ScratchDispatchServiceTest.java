package com.yihaodian.mobile.service.client.adapter.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.content.spi.ScratchService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.PromotionService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class ScratchDispatchServiceTest extends BaseTest{
	ScratchDispatchService scratchDispatchService = new ScratchDispatchService();
	@Test
	public void testGetRebatesNotification() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ScratchService scratchService = PowerMockito.mock(ScratchService.class);
		PowerMockito.when(CentralMobileServiceHandler.getScratchService()).thenReturn(scratchService);
		PowerMockito.when(scratchService.getRebatesNotification(Mockito.anyLong())).thenReturn(null);
		scratchDispatchService.getRebatesNotification(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("orderidandsitetype", "1");
	    scratchDispatchService.getRebatesNotification(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetScratchInfoListForOrderList() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ScratchService scratchService = PowerMockito.mock(ScratchService.class);
		PowerMockito.when(CentralMobileServiceHandler.getScratchService()).thenReturn(scratchService);
		PowerMockito.when(scratchService.getScratchInfoListForOrderList(Mockito.anyLong(), Mockito.anyListOf(String.class), Mockito.any(Trader.class))).thenReturn(null);
		scratchDispatchService.getScratchInfoListForOrderList(urlPath, isLogined, bizInfo, content);
		//bizInfo.put("orderidandsitetype", "1");
		scratchDispatchService.getScratchInfoListForOrderList(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetScratchInfoListForOrderListNoCilentInfo() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ScratchService scratchService = PowerMockito.mock(ScratchService.class);
		PowerMockito.when(CentralMobileServiceHandler.getScratchService()).thenReturn(scratchService);
		PowerMockito.when(scratchService.getScratchInfoListForOrderList(Mockito.anyLong(),Mockito.any(ClientInfoVO.class), Mockito.anyListOf(String.class), Mockito.any(Trader.class))).thenReturn(null);
		scratchDispatchService.getScratchInfoListForOrderListNoCilentInfo(urlPath, isLogined, bizInfo, content);
		bizInfo.put("orderid", "1");
		scratchDispatchService.getScratchInfoListForOrderListNoCilentInfo(urlPath, isLogined, bizInfo, content);
		bizInfo.put("sitetype", "1");
		scratchDispatchService.getScratchInfoListForOrderListNoCilentInfo(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetScratchAvailable() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ScratchService scratchService = PowerMockito.mock(ScratchService.class);
		PowerMockito.when(CentralMobileServiceHandler.getScratchService()).thenReturn(scratchService);
		PowerMockito.when(scratchService.getScratchAvailable(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyInt(), Mockito.any(Trader.class))).thenReturn(null);
		scratchDispatchService.getScratchAvailable(urlPath, isLogined, bizInfo, content);
	
	}

	@Test
	public void testCancelScratchReuslt() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ScratchService scratchService = PowerMockito.mock(ScratchService.class);
		PowerMockito.when(CentralMobileServiceHandler.getScratchService()).thenReturn(scratchService);
		PowerMockito.when(scratchService.cancelScratchReuslt(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyInt())).thenReturn(null);
		scratchDispatchService.cancelScratchReuslt(urlPath, isLogined, bizInfo, content);
		bizInfo.put("orderid", "1");
		scratchDispatchService.cancelScratchReuslt(urlPath, isLogined, bizInfo, content);
		bizInfo.put("sitetype", "1");
		scratchDispatchService.cancelScratchReuslt(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetScratchDetailByOrderId() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ScratchService scratchService = PowerMockito.mock(ScratchService.class);
		PowerMockito.when(CentralMobileServiceHandler.getScratchService()).thenReturn(scratchService);
	}

	@Test
	public void testGetScratchReuslt() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ScratchService scratchService = PowerMockito.mock(ScratchService.class);
		PowerMockito.when(CentralMobileServiceHandler.getScratchService()).thenReturn(scratchService);
		PowerMockito.when(scratchService.getScratchReuslt(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString(), Mockito.any(Trader.class))).thenReturn(null);
		scratchDispatchService.getScratchReuslt(urlPath, isLogined, bizInfo, content);
		bizInfo.put("orderid", "1");
		scratchDispatchService.getScratchReuslt(urlPath, isLogined, bizInfo, content);
		bizInfo.put("sitetype", "1");
		scratchDispatchService.getScratchReuslt(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetUserScratchResultDetailList() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		ScratchService scratchService = PowerMockito.mock(ScratchService.class);
		PowerMockito.when(CentralMobileServiceHandler.getScratchService()).thenReturn(scratchService);
		PowerMockito.when(scratchService.getUserScratchResultDetailList(Mockito.any(Trader.class))).thenReturn(null);
		scratchDispatchService.getUserScratchResultDetailList(urlPath, isLogined, bizInfo, content);
	}

}
