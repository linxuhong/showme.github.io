package com.yihaodian.mobile.hedwig.client.service.newuser;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.newuser.NewUserCouponService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class NewUserCouponClientServiceTest {
	private NewUserCouponClientService NCClientService = new NewUserCouponClientService();
	
	@Mock
	private NewUserCouponService newUserCouponHessianCall;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(NCClientService, "newUserCouponHessianCall", newUserCouponHessianCall);
	}

	@Test
	public void testGetNewUserCouponInfo() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v2.0");
		clientInfoVO.setClientip("192.168.4.109");
		clientInfoVO.setClientSystem("Android5.0");
		clientInfoVO.setDeviceCode("nubia9");
		NCClientService.getNewUserCouponInfo(clientInfoVO , 45L);
		
	}

	@Test
	public void testGetUserCoupon() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v2.0");
		clientInfoVO.setClientip("192.168.4.109");
		clientInfoVO.setClientSystem("Android5.0");
		clientInfoVO.setDeviceCode("nubia9");
		NCClientService.getUserCoupon(clientInfoVO, 23L, 345L);
	}

	@Test
	public void testGetNewUserCouponHessianCall() {
		NCClientService.getNewUserCouponHessianCall();
	}

	@Test
	public void testSetNewUserCouponHessianCall() {
		NCClientService.setNewUserCouponHessianCall(newUserCouponHessianCall);
	}

}
