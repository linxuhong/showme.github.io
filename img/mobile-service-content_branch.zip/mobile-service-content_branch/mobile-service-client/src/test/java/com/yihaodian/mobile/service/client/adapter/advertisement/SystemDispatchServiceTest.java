package com.yihaodian.mobile.service.client.adapter.advertisement;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.facade.business.system.SystemService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class SystemDispatchServiceTest extends BaseTest{
	SystemDispatchService systemDispatchService = new SystemDispatchService();




	@Test
	public void testGetClientApplicationDownloadUrl() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		SystemService systemService = PowerMockito.mock(SystemService.class);
		PowerMockito.when(CentralMobileServiceHandler.getSystemService()).thenReturn(systemService);
		PowerMockito.when(systemService.getClientApplicationDownloadUrl(Mockito.any(Trader.class))).thenReturn(null);
	    systemDispatchService.getClientApplicationDownloadUrl(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetAppFunctionSwitch() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		SystemService systemService = PowerMockito.mock(SystemService.class);
		PowerMockito.when(CentralMobileServiceHandler.getSystemService()).thenReturn(systemService);
	    PowerMockito.when(systemService.getAppFunctionSwitch(Mockito.any(Trader.class))).thenReturn(null);
	    systemDispatchService.getAppFunctionSwitch(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testRegisterLaunchInfo() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		SystemService systemService = PowerMockito.mock(SystemService.class);
		PowerMockito.when(CentralMobileServiceHandler.getSystemService()).thenReturn(systemService);
	    PowerMockito.when(systemService.registerLaunchInfo(Mockito.any(Trader.class), Mockito.anyString(),Mockito.anyString(), Mockito.anyString())).thenReturn(null);
	    bizInfo.put("phoneno", "142324124");
	    systemDispatchService.registerLaunchInfo(urlPath, isLogined, bizInfo, content);	  
	}

}
