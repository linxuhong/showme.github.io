package com.yihaodian.mobile.service.client.adapter.appconfig;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.BeanFactory;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.enums.BaseResultCode;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.appconfig.AppConfigService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;


@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class,SpringBeanProxy.class,BeanFactory.class})
@SuppressStaticInitializationFor({"com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler","com.yihaodian.mobile.hedwig.client.util.SpringBeanProxy"})
public class AppConfigDispatchServiceTest extends BaseTest{
	AppConfigDispatchService appConfigDispatchService = new AppConfigDispatchService();
	
	@Test
	public void testgetAppTab(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		AppConfigService service = PowerMockito.mock(AppConfigService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getAppConfigClientService()).thenReturn(service);
		PowerMockito.when(service.getAppTab(Mockito.isA(Trader.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.appConfigDispatchService.getAppTab(urlPath, true, bizInfo, content);
	}
	@Test
	public void testgetDefaultHit(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		AppConfigService service = PowerMockito.mock(AppConfigService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getAppConfigClientService()).thenReturn(service);
		PowerMockito.when(service.getDefaultHit(Mockito.isA(Trader.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.appConfigDispatchService.getDefaultHit(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetDefaultHitForPad(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		AppConfigService service = PowerMockito.mock(AppConfigService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getAppConfigClientService()).thenReturn(service);
		PowerMockito.when(service.getDefaultHit(Mockito.isA(Trader.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.appConfigDispatchService.getDefaultHitForPad(urlPath, true, bizInfo, content);
	}
	
	@Test
	public void testgetAppRefInfo(){
		RequestInfo rn1 = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		RequestInfo rn2 = new RequestInfo(clientInfo, urlPath, null, bizInfo);
		RequestInfo rn3 = new RequestInfo(clientInfo, urlPath, "ab", bizInfo);
		rn1.setProvinceId("20");
		rn2.setProvinceId("10");
		rn3.setProvinceId("ad");
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		rn1.setClientInfo(clientInfo);
		rn2.setClientInfo(clientInfo);
		rn3.setClientInfo(clientInfo);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn2).thenReturn(rn3).thenReturn(rn1);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.mockStatic(SpringBeanProxy.class);
		PowerMockito.mockStatic(BeanFactory.class);
		AppConfigService service = PowerMockito.mock(AppConfigService.class);
		Result result = PowerMockito.mock(Result.class);
		BaseResultCode baseResultCode = PowerMockito.mock(BaseResultCode.class);
		PowerMockito.when(CentralMobileServiceHandler.getAppConfigClientService()).thenReturn(service);
		PowerMockito.when(service.getDefaultHit(Mockito.isA(Trader.class))).thenReturn(result);
		PowerMockito.when(result.getBaseResultCode()).thenReturn(baseResultCode);
		PowerMockito.when(baseResultCode.getCode()).thenReturn("33");
		PowerMockito.when(baseResultCode.getMsg()).thenReturn("33");
		PowerMockito.when(baseResultCode.getDetail()).thenReturn("33");
		this.appConfigDispatchService.getAppRefInfo(urlPath, true, bizInfo, content);
	}
}
