package com.yihaodian.mobile.service.client.adapter.advertisement;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.hedwig.push.spi.HomePageService;
import com.yihaodian.mobile.service.client.adapter.service.impl.ScratchDispatchService;
import com.yihaodian.mobile.service.facade.content.spi.ScratchService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
import com.yihaodian.mobile2.server.context.RtnInfo;
@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class ScratchDispatchServiceTest extends BaseTest{
	ScratchDispatchService scratchDispatchService =new ScratchDispatchService();
	@Test
	public void testGetScratchInfoListForOrderList(){
		try {
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			ScratchService scratchService = PowerMockito.mock(ScratchService.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mock(CentralMobileServiceHandler.class);
			PowerMockito.when(CentralMobileServiceHandler.getScratchService()).thenReturn(scratchService);
			RtnInfo r=scratchDispatchService.getScratchInfoListForOrderList(urlPath, isLogined, bizInfo, context);
		} catch (Exception e) {
			assertTrue(true);
		}
		
	}
	

}
