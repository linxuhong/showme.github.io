package com.yihaodian.mobile.hedwig.client.WeChat.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.WeChatFacdeService;

public class WeChatClientServiceImplTest {
	WeChatClientServiceImpl weChatClientServiceImpl = new WeChatClientServiceImpl();
	@Mock
	WeChatFacdeService<String> weChatHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(weChatClientServiceImpl, "weChatHessianCall", weChatHessianCall);
	}
	@Test
	public void test() {
		weChatClientServiceImpl.getWeChatProductVODetail(null, null);
		weChatClientServiceImpl.setWeChatHessianCall(weChatHessianCall);
	}

}
