package com.yihaodian.mobile.service.client.adapter.lottery;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.system.SystemService;
import com.yihaodian.mobile.service.facade.lottery.spi.ILotteryTicketService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class LotteryTicketsTest extends BaseTest{
	LotteryTickets lotteryTickets = new LotteryTickets();
	@Test
	public void testGetLotteryTicketUrlFor500() {
		try {
			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			ILotteryTicketService lotteryTicketsClientService = PowerMockito.mock(ILotteryTicketService.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			PowerMockito.when(CentralMobileServiceHandler.getLotteryTicketsClientService()).thenReturn(lotteryTicketsClientService);
			PowerMockito.when(lotteryTicketsClientService.getLotteryTicketUrlFor500(Mockito.anyLong(), Mockito.anyString(), Mockito.anyInt(), Mockito.any(Trader.class))).thenReturn(null);
			lotteryTickets.getLotteryTicketUrlFor500(urlPath, isLogined, bizInfo, content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
		

}
