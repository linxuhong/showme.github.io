package com.yihaodian.mobile.hedwig.client.update;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.UpdateAwardService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class UpdateAwardClientServiceImplTest {
	
	private UpdateAwardClientServiceImpl UAClientServiceImpl = new UpdateAwardClientServiceImpl();
	@Mock
	private UpdateAwardService updateAwardHessianCall;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(UAClientServiceImpl, "updateAwardHessianCall", updateAwardHessianCall);
	}

	@Test
	public void testSetUpdateAwardHessianCall() {
		UAClientServiceImpl.setUpdateAwardHessianCall(updateAwardHessianCall);
		
	}

	@Test
	public void testGetUpdateAwardOrder() {
		
		UAClientServiceImpl.getUpdateAwardOrder("光棍节大出血" , "v3.0", "yhd_tocken");
	}

	@Test
	public void testCreateMessageForUpdateAward() {
		ClientInfoVO clientInfo = new ClientInfoVO();
		clientInfo.setClientAppVersion("v1.0");
		clientInfo.setClientip("192.168.45.22");
		clientInfo.setClientSystem("Andorid4.0");
		clientInfo.setDeviceCode("iphone");
		UAClientServiceImpl.createMessageForUpdateAward(clientInfo , 45L);
	}

}
