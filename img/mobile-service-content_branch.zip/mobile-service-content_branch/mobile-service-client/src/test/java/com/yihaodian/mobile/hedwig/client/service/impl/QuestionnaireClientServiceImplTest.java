package com.yihaodian.mobile.hedwig.client.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.questionnaire.QuestionnaireService;

public class QuestionnaireClientServiceImplTest {
	QuestionnaireClientServiceImpl questionnaireClientServiceImpl = new QuestionnaireClientServiceImpl();
	@Mock
	QuestionnaireService questionnaireHessianCall;
	@Before
	public void initMocks(){
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(questionnaireClientServiceImpl, "questionnaireHessianCall", questionnaireHessianCall);
	}
	@Test
	public void test() {
		questionnaireClientServiceImpl.getQuestionnaireHessianCall();
		questionnaireClientServiceImpl.getQuestionnaireSwitch(null, 123L, null);
		questionnaireClientServiceImpl.setQuestionnaireHessianCall(questionnaireHessianCall);
		questionnaireClientServiceImpl.skipQuestionnaire(null,123L);
	}

}
