package com.yihaodian.mobile.hedwig.client.impl.dailybuy;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.IDailyBuyService;

public class DailyBuyClientServiceTest {
	
	private  DailyBuyClientService  dailyBuyClientService =new DailyBuyClientService();
	
	@Mock
	private IDailyBuyService dailyBuyHessianCall;

	@Before
	public void initMock() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(dailyBuyClientService, "dailyBuyHessianCall", dailyBuyHessianCall);
	}

	@Test
	public void testSetDailyBuyHessianCall() {
		dailyBuyClientService.setDailyBuyHessianCall(dailyBuyHessianCall);
	
	}

	@Test
	public void testPraiseTopic() {
		Long userId = 23L;
		String topicId = "YHD00989";
		String praise = "how much";
		dailyBuyClientService.praiseTopic(userId, praise, topicId);
		}

	@Test
	public void testGetCategory() {
		dailyBuyClientService.getCategory();
	}

	@Test
	public void testGetTopicByCategoryId() {
		Long userId = 23L;
		dailyBuyClientService.getTopicByAllCategory(userId );
	}

	@Test
	public void testGetTopicById() {
	
	
		Long userId = 23L;
		Long topicId = 123L;
		dailyBuyClientService.getTopicById( 1L, topicId, userId);
	}

	@Test
	public void testGetTopicByAllCategory() {
		dailyBuyClientService.getTopicByAllCategory(23L);
		}

}
