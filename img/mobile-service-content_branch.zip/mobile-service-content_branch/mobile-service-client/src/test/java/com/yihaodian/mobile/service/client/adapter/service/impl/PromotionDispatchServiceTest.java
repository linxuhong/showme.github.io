package com.yihaodian.mobile.service.client.adapter.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.sharecoupon.spi.IShareCouponService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.PromotionService;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class PromotionDispatchServiceTest extends BaseTest{
	PromotionDispatchService promotionDispatchService = new PromotionDispatchService();
	
	@Test
	public void testAddCouponByActivityId() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService).thenReturn(promotionService);
		PowerMockito.when(promotionService.addCouponByActivityId(Mockito.anyLong(), Mockito.anyLong(), Mockito.any(Trader.class))).thenReturn(null).thenReturn(null);
		promotionDispatchService.addCouponByActivityId(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("activityid", "1");
	    promotionDispatchService.addCouponByActivityId(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetCmsColumnByColumnById() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService).thenReturn(promotionService).thenReturn(promotionService);
		PowerMockito.when(promotionService.getCmsColumnByColumnById(Mockito.any(Trader.class), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null).thenReturn(null).thenReturn(null);
		promotionDispatchService.getCmsColumnByColumnById(urlPath, isLogined, bizInfo, content);
		bizInfo.put("cmscolumnid", "1");
		promotionDispatchService.getCmsColumnByColumnById(urlPath, isLogined, bizInfo, content);
		bizInfo.put("cmscolumnid", "1");
		bizInfo.put("type", "1");
		bizInfo.put("cmstype", "1");
		bizInfo.put("currentpage", "1");
		bizInfo.put("pagesize", "1");
		promotionDispatchService.getCmsColumnByColumnById(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetCmsColumnListWithCMSType() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService).thenReturn(promotionService).thenReturn(promotionService).thenReturn(promotionService).thenReturn(promotionService);
		PowerMockito.when(promotionService.getCmsColumnList(Mockito.any(Trader.class), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null).thenReturn(null).thenReturn(null).thenReturn(null).thenReturn(null).thenReturn(null);
		promotionDispatchService.getCmsColumnListWithCMSType(urlPath, isLogined, bizInfo, content);
		bizInfo.put("cmspageid", "1");
		promotionDispatchService.getCmsColumnListWithCMSType(urlPath, isLogined, bizInfo, content);
		bizInfo.put("type", "1");
		promotionDispatchService.getCmsColumnListWithCMSType(urlPath, isLogined, bizInfo, content);
		bizInfo.put("cmstype", "1");
		promotionDispatchService.getCmsColumnListWithCMSType(urlPath, isLogined, bizInfo, content);
		bizInfo.put("currentpage", "1");
		promotionDispatchService.getCmsColumnListWithCMSType(urlPath, isLogined, bizInfo, content);
		bizInfo.put("pagesize", "1");
		promotionDispatchService.getCmsColumnListWithCMSType(urlPath, isLogined, bizInfo, content);
	
	}

	@Test
	public void testGetCmsColumnList() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService).thenReturn(promotionService).thenReturn(promotionService);
		PowerMockito.when(promotionService.getCmsColumnList(Mockito.any(Trader.class), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null).thenReturn(null).thenReturn(null);
		promotionDispatchService.getCmsColumnList(urlPath, isLogined, bizInfo, content);
		bizInfo.put("cmspageid", "1");
		promotionDispatchService.getCmsColumnList(urlPath, isLogined, bizInfo, content);
		bizInfo.put("type", "1");
		promotionDispatchService.getCmsColumnList(urlPath, isLogined, bizInfo, content);
		bizInfo.put("currentpage", "1");
		promotionDispatchService.getCmsColumnList(urlPath, isLogined, bizInfo, content);
		bizInfo.put("pagesize", "1");
		promotionDispatchService.getCmsColumnList(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetCmsPageList() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getCmsPageList(Mockito.any(Trader.class), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
		promotionDispatchService.getCmsPageList(urlPath, isLogined, bizInfo, content);
		bizInfo.put("activityid", "1");
		promotionDispatchService.getCmsPageList(urlPath, isLogined, bizInfo, content);
		bizInfo.put("pagesize", "1");
		bizInfo.put("currentpage", "1");
		promotionDispatchService.getCmsPageList(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testAddStorageBox() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.addStorageBoxV2(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		promotionDispatchService.addStorageBox(urlPath, isLogined, bizInfo, content);
		bizInfo.put("productid", "1");
		promotionDispatchService.addStorageBox(urlPath, isLogined, bizInfo, content);
		bizInfo.put("promotionid", "1");
		bizInfo.put("couponnumber", "1");
		promotionDispatchService.addStorageBox(urlPath, isLogined, bizInfo, content);
		bizInfo.put("type", "1");
		bizInfo.put("couponactiveid", "1");
		promotionDispatchService.addStorageBox(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetRockResultV3NotLogined() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService).thenReturn(promotionService);
		PowerMockito.when(promotionService.getRockResultV3(Mockito.any(Trader.class), Mockito.anyLong(), Mockito.anyDouble(),Mockito.anyDouble())).thenReturn(null).thenReturn(null);
		promotionDispatchService.getRockResultV3NotLogined(urlPath, isLogined, bizInfo, content);
		bizInfo.put("lng", "1");
		bizInfo.put("lat", "1");
		promotionDispatchService.getRockResultV3NotLogined(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetRockResultV3WithToken() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getRockResultV3(Mockito.anyLong(), Mockito.anyDouble(),Mockito.anyDouble(), Mockito.any(Trader.class), Mockito.anyLong(), Mockito.anyString())).thenReturn(null);
		promotionDispatchService.getRockResultV3WithToken(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetMyStorageBoxList() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getMyStorageBoxList(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
		promotionDispatchService.getMyStorageBoxList(urlPath, isLogined, bizInfo, content);
		bizInfo.put("type", "1");
		promotionDispatchService.getMyStorageBoxList(urlPath, isLogined, bizInfo, content);
		bizInfo.put("currentpage", "1");
		promotionDispatchService.getMyStorageBoxList(urlPath, isLogined, bizInfo, content);
		bizInfo.put("pagesize", "1");
		promotionDispatchService.getMyStorageBoxList(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetPromotionByTopicID() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getPromotionByTopicID(Mockito.any(Trader.class),Mockito.anyLong())).thenReturn(null);
		promotionDispatchService.getPromotionByTopicID(urlPath, isLogined, bizInfo, content);
		bizInfo.put("id", "1");
		promotionDispatchService.getPromotionByTopicID(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetPresentsByToken() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getPresentsByToken(Mockito.anyString())).thenReturn(null);
		promotionDispatchService.getPresentsByToken(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testCheckResult() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.checkResult( Mockito.any(Trader.class),Mockito.anyLong(), Mockito.anyString())).thenReturn(null);
		promotionDispatchService.checkResult(urlPath, isLogined, bizInfo, content);
		bizInfo.put("rockgameflowid", "1");
		promotionDispatchService.checkResult(urlPath, isLogined, bizInfo, content);
		bizInfo.put("resultcode", "1");
		promotionDispatchService.checkResult(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testProcessGameFlow() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.processGameFlow(Mockito.anyString(), Mockito.anyLong()));
		promotionDispatchService.processGameFlow(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetAwardsResults() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getAwardsResults(Mockito.any(Trader.class))).thenReturn(null);
		promotionDispatchService.getAwardsResults(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testUpdateStroageBoxProductType() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.updateStroageBoxProductType(Mockito.anyLong(), Mockito.anyListOf(String.class), Mockito.anyListOf(Long.class), Mockito.anyInt())).thenReturn(null);
		promotionDispatchService.updateStroageBoxProductType(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetRockResultV2() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getRockResultV2(Mockito.any(Trader.class), Mockito.anyLong())).thenReturn(null);
		promotionDispatchService.getRockResultV2(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetRockResultV2WithToken() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getRockResultV2(Mockito.anyLong(), Mockito.anyDouble(),Mockito.anyDouble(), Mockito.any(Trader.class), Mockito.anyLong(), Mockito.anyString())).thenReturn(null);
		promotionDispatchService.getRockResultV2WithToken(urlPath, isLogined, bizInfo, content);
		bizInfo.put("lng", "1");
		bizInfo.put("lat", "1");
		promotionDispatchService.getRockResultV2WithToken(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetHotPointNewVOById() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getHotPointNewVOById(Mockito.any(Trader.class),Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		bizInfo.put("hotpointnewvoid", "1");
		promotionDispatchService.getHotPointNewVOById(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetAdvertisingPromotionVOByType() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getAdvertisingPromotionVOByType(Mockito.any(Trader.class),Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
		promotionDispatchService.getAdvertisingPromotionVOByType(urlPath, isLogined, bizInfo, content);
		bizInfo.put("type", "1");
		promotionDispatchService.getAdvertisingPromotionVOByType(urlPath, isLogined, bizInfo, content);
		bizInfo.put("currentpage", "1");
		promotionDispatchService.getAdvertisingPromotionVOByType(urlPath, isLogined, bizInfo, content);
		bizInfo.put("pagesize", "1");
		promotionDispatchService.getAdvertisingPromotionVOByType(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testCreateRockGame() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
	
		PowerMockito.when(promotionService.createRockGame( Mockito.anyString())).thenReturn(null);
		promotionDispatchService.createRockGame(urlPath, isLogined, bizInfo, content);
		}

	@Test
	public void testGetRockGameProductVO() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getRockGameProductVO(Mockito.anyLong())).thenReturn(null);
		promotionDispatchService.getRockGameProductVO(urlPath, isLogined, bizInfo, content);
		}

	@Test
	public void testGetHomeHotPointListNew() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
	
		PowerMockito.when(promotionService.getHomeHotPointListNew(Mockito.any(Trader.class),Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
		promotionDispatchService.getHomeHotPointListNew(urlPath, isLogined, bizInfo, content);
		}

	@Test
	public void testGetCmsAdvertisingPromotion() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getCmsAdvertisingPromotion(Mockito.any(Trader.class),Mockito.anyLong(), Mockito.anyString())).thenReturn(null);
		promotionDispatchService.getCmsAdvertisingPromotion(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetRockGameByToken() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getRockGameByToken( Mockito.anyString(), Mockito.anyInt())).thenReturn(null);
		promotionDispatchService.getRockGameByToken(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testCheckRockResult() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.checkRockResult( Mockito.anyString(), Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt(), Mockito.anyLong())).thenReturn(null);
		promotionDispatchService.checkRockResult(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetRockProductList() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.getRockProductList(Mockito.any(Trader.class),Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
		promotionDispatchService.getRockProductList(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("currentpage", "1");
	    promotionDispatchService.getRockProductList(urlPath, isLogined, bizInfo, content);
	    bizInfo.put("pagesize", "1");
	    promotionDispatchService.getRockProductList(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testRockRock() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.when(content.getRequestIp()).thenReturn("1.1.1.1");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.rockRock(Mockito.any(Trader.class),Mockito.anyLong(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyDouble(),  Mockito.anyDouble(),  Mockito.anyLong())).thenReturn(null);
		promotionDispatchService.rockRock(urlPath, isLogined, bizInfo, content);
		bizInfo.put("promotionid", "1");
		promotionDispatchService.rockRock(urlPath, isLogined, bizInfo, content);
		bizInfo.put("productid", "1");
		promotionDispatchService.rockRock(urlPath, isLogined, bizInfo, content);
		bizInfo.put("lng", "1");
		promotionDispatchService.rockRock(urlPath, isLogined, bizInfo, content);
		bizInfo.put("lat", "1");
		promotionDispatchService.rockRock(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testIsCanInviteeUser() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("1341234");
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);		
		PromotionService promotionService = PowerMockito.mock(PromotionService.class);
		PowerMockito.when(CentralMobileServiceHandler.getPromotionService()).thenReturn(promotionService);
		PowerMockito.when(promotionService.isCanInviteeUser(Mockito.any(Trader.class),Mockito.anyString())).thenReturn(null);
		promotionDispatchService.isCanInviteeUser(urlPath, isLogined, bizInfo, content);
	}

}
