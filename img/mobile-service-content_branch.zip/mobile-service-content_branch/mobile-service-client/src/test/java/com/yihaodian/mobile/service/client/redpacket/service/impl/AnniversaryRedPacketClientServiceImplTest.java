package com.yihaodian.mobile.service.client.redpacket.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.redpacket.IAnniversaryRedPacketService;
import com.yihaodian.mobile.vo.ClientInfoVO;

public class AnniversaryRedPacketClientServiceImplTest {
	private AnniversaryRedPacketClientServiceImpl ARPClientImpl = new AnniversaryRedPacketClientServiceImpl();
	
	@Mock
	private IAnniversaryRedPacketService anniversaryRedPacketHessianCall;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(ARPClientImpl, "anniversaryRedPacketHessianCall", anniversaryRedPacketHessianCall);
	}

	@Test
	public void testCheckActivityEffective() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.4.33");
		clientInfoVO.setDeviceCode("huaweihonnor7");
		ARPClientImpl.checkActivityEffective(clientInfoVO );
	}

	@Test
	public void testGetRedPacketResult() {
		ClientInfoVO clientInfoVO = new ClientInfoVO();
		clientInfoVO.setClientAppVersion("v1.0");
		clientInfoVO.setClientip("192.168.4.33");
		clientInfoVO.setDeviceCode("huaweihonnor7");
		ARPClientImpl.getRedPacketResult(clientInfoVO);
	}

	@Test
	public void testSetAnniversaryRedPacketHessianCall() {
		ARPClientImpl.setAnniversaryRedPacketHessianCall(anniversaryRedPacketHessianCall);
	}

}
