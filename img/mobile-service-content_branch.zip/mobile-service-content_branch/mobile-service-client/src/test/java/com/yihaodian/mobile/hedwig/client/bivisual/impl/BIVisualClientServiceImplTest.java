package com.yihaodian.mobile.hedwig.client.bivisual.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.hedwig.push.spi.BIVisualFacdeService;

public class BIVisualClientServiceImplTest {
	private BIVisualClientServiceImpl bIVisualClientServiceImpl = new BIVisualClientServiceImpl();
	
	@Mock
	private BIVisualFacdeService biVisualHessianCall;

	@Before
	public void initMock() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(bIVisualClientServiceImpl, "biVisualHessianCall", biVisualHessianCall);
		
	}

	@Test
	public void testSetBiVisualHessianCall() {
		bIVisualClientServiceImpl.setBiVisualHessianCall(biVisualHessianCall);
	}

	@Test
	public void testGetBIVisualInfos() {
		bIVisualClientServiceImpl.getBIVisualInfos();
	}

}
