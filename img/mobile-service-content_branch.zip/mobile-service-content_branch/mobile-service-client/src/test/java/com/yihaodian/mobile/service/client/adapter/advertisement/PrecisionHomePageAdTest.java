package com.yihaodian.mobile.service.client.adapter.advertisement;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.facade.business.advertisement.IPrecisionHomePageService;
import com.yihaodian.mobile.service.hedwig.core.service.spi.HomeService;
import com.yihaodian.mobile.vo.ClientInfoVO;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class PrecisionHomePageAdTest extends BaseTest {
	PrecisionHomePageAd precisionHomePageAd = new PrecisionHomePageAd();


	@Test
	public void testGetPrecisionHomePageProducts() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("12");

			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.getPrecisionHomePageProducts(
							Mockito.any(ClientInfoVO.class), Mockito.anyInt(),
							Mockito.anyLong(), Mockito.anyInt(),
							Mockito.anyInt())).thenReturn(result);
			bizInfo.put("currentpage", "1");
			bizInfo.put("pagesize", "1");
			precisionHomePageAd.getPrecisionHomePageProducts(urlPath,
					isLogined, bizInfo, content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}

	@Test
	public void testSwitchToLocalUrl() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			bizInfo.put("url", "1");
			bizInfo.put("merchantname", "1");
			bizInfo.put("merchantid", "1");
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.switchToLocalUrl(
							Mockito.any(ClientInfoVO.class),
							Mockito.anyString(), Mockito.anyString(),
							Mockito.anyLong())).thenReturn(result);
			precisionHomePageAd.switchToLocalUrl(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testDoushouProduct() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("1");
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.doushouProduct(
							Mockito.any(ClientInfoVO.class),
							Mockito.anyInt(), Mockito.anyLong())).thenReturn(result);
			precisionHomePageAd.doushouProduct(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testGetHomeRecommendProducts() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("1");
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.getHomeRecommendProducts(
							Mockito.any(ClientInfoVO.class),
							Mockito.anyInt(), Mockito.anyLong())).thenReturn(result);
			precisionHomePageAd.getHomeRecommendProducts(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testGetAnnouncements() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			bizInfo.put("url", "1");
			bizInfo.put("merchantname", "1");
			bizInfo.put("merchantid", "1");
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.getAnnouncements(
							Mockito.any(ClientInfoVO.class),
							Mockito.anyString(), Mockito.anyString(),
							Mockito.anyString(),Mockito.anyLong())).thenReturn(result);
			precisionHomePageAd.getAnnouncements(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testGetPrecisionHomePageADV3() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("1");
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			bizInfo.put("cityid", "1");
			bizInfo.put("interfaceversion", "10");
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.getPrecisionHomePageADV4(
							Mockito.any(ClientInfoVO.class),
							Mockito.anyInt(), Mockito.anyLong(), Mockito.anyString(),Mockito.anyString())).thenReturn(result);
			precisionHomePageAd.getPrecisionHomePageADV3(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testGetHomePageProduct() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("1");
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			bizInfo.put("currentpage", "1");
			bizInfo.put("pagesize", "10");
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.getHomePageproducts(
							Mockito.any(ClientInfoVO.class),
							Mockito.anyInt(), Mockito.anyLong(), Mockito.anyInt(),Mockito.anyInt())).thenReturn(result);
			precisionHomePageAd.getHomePageProduct(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testGetHomePageGuessUlikeProducts() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("1");
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			bizInfo.put("productids", "1");
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.getHomePageGuessUlikeProducts(
							Mockito.any(ClientInfoVO.class),
							Mockito.anyInt(), Mockito.anyLong(), Mockito.anyString())).thenReturn(result);
			precisionHomePageAd.getHomePageGuessUlikeProducts(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testGetHomePageColumnProducts() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getCurrentUserId()).thenReturn("1");
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.getHomePageColumnProducts(
							Mockito.any(ClientInfoVO.class),
							Mockito.anyInt(), Mockito.anyLong())).thenReturn(result);
			precisionHomePageAd.getHomePageColumnProducts(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testGetPromoteSpecialTopic() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			bizInfo.put("cityid", "1");
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			PowerMockito.when(
					iPrecisionHomePageService.getPromoteSpecialTopic(
							Mockito.any(ClientInfoVO.class),
							Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString())).thenReturn(result);
			precisionHomePageAd.getPromoteSpecialTopic(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}

	@Test
	public void testGetActivityTimeV2() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			bizInfo.put("url", "1");
			bizInfo.put("merchantname", "1");
			bizInfo.put("merchantid", "1");
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			List<Long> times = new ArrayList<Long>();
			PowerMockito.when(
					iPrecisionHomePageService.getActivityTimeV2(
							Mockito.anyString())).thenReturn(times );
			precisionHomePageAd.getActivityTimeV2(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testGetActivityTime() {
		try {

			RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId,
					bizInfo);
			PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
			AdapterContext content = PowerMockito.mock(AdapterContext.class);
			PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
			PowerMockito.mockStatic(CentralMobileServiceHandler.class);
			IPrecisionHomePageService iPrecisionHomePageService = PowerMockito
					.mock(IPrecisionHomePageService.class);
			PowerMockito.when(
					CentralMobileServiceHandler
							.getPrecisionHomePageADClientService()).thenReturn(
					iPrecisionHomePageService);
			Result result = PowerMockito.mock(Result.class);
			PowerMockito.when(result.getDefaultModel()).thenReturn(null);
			Long time = 1L;
			PowerMockito.when(
					iPrecisionHomePageService.getActivityTime(
							Mockito.anyString())).thenReturn(time  );
			precisionHomePageAd.getActivityTime(urlPath, isLogined, bizInfo,
					content);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
}
