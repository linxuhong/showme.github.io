package com.yihaodian.mobile.service.client.adapter.message;

import static org.junit.Assert.*;

import java.lang.reflect.Method;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.hedwig.client.handler.CentralMobileServiceHandler;
import com.yihaodian.mobile.hedwig.client.util.CentralMobileClientSpringBeanProxy;
import com.yihaodian.mobile.service.client.adapter.advertisement.BaseTest;
import com.yihaodian.mobile.service.facade.business.message.MessageCenterService;
import com.yihaodian.mobile2.server.context.AdapterContext;
import com.yihaodian.mobile2.server.context.RequestInfo;
@RunWith(PowerMockRunner.class)
@PrepareForTest({CentralMobileServiceHandler.class,CentralMobileClientSpringBeanProxy.class})
public class MessageCenterDispatchServiceTest extends BaseTest{
	MessageCenterDispatchService messageCenterDispatchService = new MessageCenterDispatchService();
	@Test
	public void testGetNoReadCountWithUserId() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		PowerMockito.mockStatic(CentralMobileClientSpringBeanProxy.class);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.getNoReadCountWithUserId(Mockito.anyString(), Mockito.anyInt())).thenReturn(null);
	    bizInfo.put("isread", "1");
	    messageCenterDispatchService.getNoReadCountWithUserId(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetFMessTypeSubStatus() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.getFMessTypeSubStatus(Mockito.anyLong())).thenReturn(null);
	    messageCenterDispatchService.getFMessTypeSubStatus(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetMessagesWithMSrc() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.getMessagesWithMSrc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
	   bizInfo.put("size", "1");
	   bizInfo.put("startindex", "1");
	   bizInfo.put("platform", "1");
	   bizInfo.put("messagetype", "1");
	    messageCenterDispatchService.getMessagesWithMSrc(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testUpdateMessageISRead() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.updateMessageISRead(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
	    bizInfo.put("messageid", "1");
	    messageCenterDispatchService.updateMessageISRead(urlPath, isLogined, bizInfo, content);
	
	}

	@Test
	public void testDeleteMultiMesssage() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.deleteMultiMesssage(Mockito.anyLong(), Mockito.anyListOf(Long.class))).thenReturn(null);
	    bizInfo.put("messageids", "1");
	    messageCenterDispatchService.deleteMultiMesssage(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testDeleteSingleMesssage() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.deleteSingleMesssage(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
	    PowerMockito.when(messageCenterService.deleteSingleMesssage(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
	    bizInfo.put("messageid", "1");
	    messageCenterDispatchService.deleteMultiMesssage(urlPath, isLogined, bizInfo, content);
	    messageCenterDispatchService.deleteSingleMesssage(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testUpdateMessageISReadWithMessT() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.updateMessageISReadWithMessT(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
	    bizInfo.put("messagetype", "1");
	    messageCenterDispatchService.updateMessageISReadWithMessT(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetMessagesWithUserId() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.getMessagesWithUserId(Mockito.anyLong(), Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);
	    bizInfo.put("startindex", "1");
	    bizInfo.put("size", "1");
	    messageCenterDispatchService.getMessagesWithUserId(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetNoReadMessageF() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.getNoReadMessageF(Mockito.anyLong())).thenReturn(null);
	    messageCenterDispatchService.getNoReadMessageF(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testUpdateSubStatusWithFiType() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.updateUnSubStatusWithFiType(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
	    bizInfo.put("firstcatetype", "1");
	    messageCenterDispatchService.updateSubStatusWithFiType(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testUpdateUnSubStatusWithFiType() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.updateUnSubStatusWithFiType(Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
	    bizInfo.put("firstcatetype", "1");
	    messageCenterDispatchService.updateUnSubStatusWithFiType(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testDeleteMesssaageWithMType() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.deleteMesssaageWithMType(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
	    bizInfo.put("messagetype", "1");
	    messageCenterDispatchService.deleteMesssaageWithMType(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testGetMessageCatelogByParent() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.getMessageCatelogByParent()).thenReturn(null);
	    messageCenterDispatchService.getMessageCatelogByParent(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testIsUserSubscribeBatch() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.isUserSubscribeBatch(Mockito.anyLong(), Mockito.anyListOf(Long.class))).thenReturn(null);
	    bizInfo.put("cateids", "");
	    messageCenterDispatchService.isUserSubscribeBatch(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testSubscribeMessage() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.subscribeMessage(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
	    bizInfo.put("cateid", "1");
	    messageCenterDispatchService.subscribeMessage(urlPath, isLogined, bizInfo, content);
	}

	@Test
	public void testUnsubscribeMessage() {
		RequestInfo rn = new RequestInfo(clientInfo, urlPath, provinceId, bizInfo);
		AdapterContext content = PowerMockito.mock(AdapterContext.class);
		PowerMockito.when(content.getRequestInfo()).thenReturn(rn);
		PowerMockito.mockStatic(CentralMobileServiceHandler.class);	
		PowerMockito.when(content.getCurrentUserId()).thenReturn("12");
		MessageCenterService messageCenterService = PowerMockito.mock(MessageCenterService.class);
		PowerMockito.when(CentralMobileServiceHandler.getMessageCenterService()).thenReturn(messageCenterService);
	    PowerMockito.when(messageCenterService.unsubscribeMessage(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
	    bizInfo.put("cateid", "1");
	    messageCenterDispatchService.unsubscribeMessage(urlPath, isLogined, bizInfo, content);
		try {
			PowerMockito.doThrow( new Exception("")).when(messageCenterService, "unsubscribeMessage");
		} catch (Exception e) {
			assertTrue(true);
		}
	}
}
