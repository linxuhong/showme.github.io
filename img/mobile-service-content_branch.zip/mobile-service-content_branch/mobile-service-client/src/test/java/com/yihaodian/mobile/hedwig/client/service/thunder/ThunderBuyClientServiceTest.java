package com.yihaodian.mobile.hedwig.client.service.thunder;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.yihaodian.mobile.service.facade.business.thunder.ThunderBuyService;
import com.yihaodian.mobile.vo.thunder.MobileProductVO;

public class ThunderBuyClientServiceTest {
	private ThunderBuyClientService TBClientService = new ThunderBuyClientService();
	@Mock
	private ThunderBuyService thunderBuyHessianCall;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(TBClientService, "thunderBuyHessianCall", thunderBuyHessianCall);
	}

	@Test
	public void testGetThunderBuyHessianCall() {
		TBClientService.getThunderBuyHessianCall();
	}

	@Test
	public void testSetThunderBuyHessianCall() {
		TBClientService.setThunderBuyHessianCall(thunderBuyHessianCall);
		}

	@Test
	public void testGetThunderHomeBannerAndDes() {
		TBClientService.getThunderHomeBannerAndDes(4L);
	}

	@Test
	public void testGetThunderProvinceInfo() {
		TBClientService.getThunderProvinceInfo("贵州", "六盘水", "盘县", "鱼朵");
	}

	@Test
	public void testArrivalReminding() {
		TBClientService.arrivalReminding(3L, 45L, 33L, true);
	}

	@Test
	public void testGetThunderCategory() {
		TBClientService.getThunderCategory(6L);
	}

	@Test
	public void testGetProductsByCategoryIds() {
		List<Long> categoryIds = new ArrayList<Long>();
		categoryIds.add(3L);
		categoryIds.add(4L);
		categoryIds.add(5L);
		categoryIds.add(6L);
		TBClientService.getProductsByCategoryIds(categoryIds , 4L, 55, 876L);
	}

	@Test
	public void testGetProductsByCategoryId() {
		TBClientService.getProductsByCategoryId(4L, 6L, 678L);
	}

	@Test
	public void testValidateThunderOrder() {
		List<MobileProductVO> productIds = new ArrayList<MobileProductVO>();
		MobileProductVO e = new MobileProductVO();
		e.setActivitypoint(345);
		e.setAddCartUrl("www.sina.com/img/pic.png");
		e.setAddType(5);
		productIds.add(e );
		TBClientService.validateThunderOrder(45L, 5L, 456.87, productIds );
	}

}
