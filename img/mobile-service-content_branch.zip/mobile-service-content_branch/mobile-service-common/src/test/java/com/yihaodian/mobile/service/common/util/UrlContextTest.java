package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

public class UrlContextTest {
	private UrlContext urlContext = new UrlContext();
	@Test
	public void testGetUrlIntent() {
		String url = "www.baidu.com";
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("11", "11");
		map.put("22", "22");
		map.put("33", "33");
		urlContext.getUrlIntent(url, map);
	}

	@Test
	public void testGetTrackUrlBD() {
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("11", "11");
		map.put("22", "22");
		urlContext.getTrackUrlBD(map);
	}
}
