package com.yihaodian.mobile.service.common.util.my;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyyhdMobileDesEncrypterVirtualUtilTest {

	@Test
	public void testGetDesDecryptVirtualCode() {
		MyyhdMobileDesEncrypterVirtualUtil.getDesDecryptVirtualCode("012345678901234567890123");
	}

}
