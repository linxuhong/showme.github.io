//package com.yihaodian.mobile.service.common.util.service;
//
//import static org.junit.Assert.*;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Mockito;
//import org.powermock.api.mockito.PowerMockito;
//import org.powermock.core.classloader.annotations.PrepareForTest;
//import org.powermock.modules.junit4.PowerMockRunner;
//
//import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
//import com.yihaodian.mobile.service.common.util.AliPayUtil;
//@RunWith(PowerMockRunner.class)
//@PrepareForTest(YccGlobalPropertyConfigurer.class)
//public class ConfigTest {
//
//	@Test
//	public void testGetProperties() {
//		PowerMockito.mockStatic(YccGlobalPropertyConfigurer.class);
//		PowerMockito.when(YccGlobalPropertyConfigurer.loadConfigString(Mockito.anyString(), Mockito.anyString())).thenReturn("12343232");
//		Config config = new Config();
//		config.getProperties();
//		config.get("a");
//		config.get("", "1");
//		config.getBool("1");
//		config.getBool("1", true);
//		config.getDouble("a");
//		config.getDouble("a", 1.1);
//		config.getFloat("q");
//		config.getFloat("a", 1f);
//		config.getInt("q");
//		config.getInt("a", 1);
//		config.getLong("a");
//		config.getLong("a", 1l);
//		config.getProperties();
//	}
//
//
//}
