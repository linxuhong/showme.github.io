package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;

public class YihaodianDataSourceTest {
	YihaodianDataSource yihaodianDataSource = new YihaodianDataSource();
	@Test
	public void testGetConnection() {
	/*	try {
			yihaodianDataSource.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}


}
