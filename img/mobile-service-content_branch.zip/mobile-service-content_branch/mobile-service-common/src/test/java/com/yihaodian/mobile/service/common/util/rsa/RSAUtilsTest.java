package com.yihaodian.mobile.service.common.util.rsa;

import org.junit.Test;

public class RSAUtilsTest {

	@Test
	public void testGenKeyPair() {
		
		try {
			RSAUtils.genKeyPair();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
