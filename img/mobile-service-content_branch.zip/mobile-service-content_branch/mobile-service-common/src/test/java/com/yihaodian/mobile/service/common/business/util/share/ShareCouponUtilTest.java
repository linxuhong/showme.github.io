package com.yihaodian.mobile.service.common.business.util.share;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.yihaodian.front.user.common.model.EndUser;
import com.yihaodian.mobile.service.domain.business.dal.MobileCouponShare;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponDO;
import com.yihaodian.promotion.coupon.domain.UserCouponInfoVo;
import com.yihaodian.promotion.coupon.outputVo.CouponActivityOutputVo;
import com.yihaodian.promotion.coupon.outputVo.couponShare.ShareCouponVo;

public class ShareCouponUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testCouponActivityOutputVoToShareCouponDO() {
		MobileCouponShare mobileCouponShare = new MobileCouponShare();
		
		CouponActivityOutputVo couponActivityOutputVo = new CouponActivityOutputVo();
		couponActivityOutputVo.setActiveId(1223L);
		couponActivityOutputVo.setActiveName("大甩卖");
		couponActivityOutputVo.setActiveType(3);
		couponActivityOutputVo.setActivityBeginDate(new Date());
		ShareCouponUtil.couponActivityOutputVoToShareCouponDO(couponActivityOutputVo, mobileCouponShare);
	}

	@Test
	public void testShareCouponVoToShareCouponDO() {
		
		MobileCouponShare mobileCouponShare = new MobileCouponShare();
		ShareCouponVo shareCouponVo=new ShareCouponVo();
		shareCouponVo.setCanShareCode(123);
		CouponActivityOutputVo couponActivityOutputVo = new CouponActivityOutputVo();
		couponActivityOutputVo.setActiveId(1223L);
		couponActivityOutputVo.setActiveName("大甩卖");
		couponActivityOutputVo.setActiveType(3);
		couponActivityOutputVo.setActivityBeginDate(new Date());
		shareCouponVo.setCouponActivityOutputVo(couponActivityOutputVo);
		shareCouponVo.setShareType(2);
		UserCouponInfoVo userCouponInfoVo = new UserCouponInfoVo();
		userCouponInfoVo.setActiveId(344L);
		
		shareCouponVo.setUserCouponInfoVo(userCouponInfoVo );
		ShareCouponUtil.shareCouponVoToShareCouponDO(shareCouponVo, mobileCouponShare);
	}

	@Test
	public void testMobileCouponShareToShareCouponDO() {
		int type = 0;
		Map<Long, ShareCouponVo> couponInfoMap = new HashMap<Long, ShareCouponVo>();
		ShareCouponVo shareCouponVo=new ShareCouponVo();
		shareCouponVo.setCanShareCode(123);
		couponInfoMap.put(12L, shareCouponVo);
		Map<Long, EndUser> sharedUserInfoMap = new HashMap<Long, EndUser>();
		EndUser value = new EndUser();
		value.setBackOperatorId(23L);
		value.setId(34L);
		sharedUserInfoMap.put(23L, value );
		Map<Long, EndUser> receiveUserInfoMap = new HashMap<Long, EndUser>();
		receiveUserInfoMap.put(22L, value);
		Map<Long, Integer> vipCouponMap = new HashMap<Long, Integer>();
		vipCouponMap.put(12L, 34);
		Map<Long, CouponActivityOutputVo> activityInfoMap = new HashMap<Long, CouponActivityOutputVo>();
		CouponActivityOutputVo couponActivityOutputVo = new CouponActivityOutputVo();
		couponActivityOutputVo.setActiveId(1223L);
		couponActivityOutputVo.setActiveName("大甩卖");
		couponActivityOutputVo.setActiveType(3);
		couponActivityOutputVo.setActivityBeginDate(new Date());
		activityInfoMap.put(34L, couponActivityOutputVo);
		MobileCouponShare mobileCouponShare = new MobileCouponShare();
		
		ShareCouponUtil.mobileCouponShareToShareCouponDO(mobileCouponShare, activityInfoMap, vipCouponMap, receiveUserInfoMap, sharedUserInfoMap, couponInfoMap, type);
	}



	

}
