package com.yihaodian.mobile.service.common.util.service;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yihaodian.mobile.service.common.util.service.AppADConstants.AD_LAYOUT;

public class AppADConstantsTest {

	@Test
	public void test() {
		AD_LAYOUT ad_layout = AppADConstants.AD_LAYOUT.BRAND;
		AD_LAYOUT ad_layout1 = AppADConstants.AD_LAYOUT.BRAND_LIST;
				AD_LAYOUT ad_layout2 = AppADConstants.AD_LAYOUT.BRAND_SHOP;
				AD_LAYOUT ad_layout3 = AppADConstants.AD_LAYOUT.CATEGORY;
				AD_LAYOUT ad_layout4 = AppADConstants.AD_LAYOUT.CMS_MAX;
				AD_LAYOUT ad_layout5 = AppADConstants.AD_LAYOUT.CMS_NATIVE;
				AD_LAYOUT ad_layout6 = AppADConstants.AD_LAYOUT.COUPON_LIST;
				AD_LAYOUT ad_layout7 = AppADConstants.AD_LAYOUT.DECREASE_UNDER_CONDITION;
				AD_LAYOUT ad_layout8 = AppADConstants.AD_LAYOUT.DISCOUNT_UNDER_CONDITION;
				AD_LAYOUT ad_layout9 = AppADConstants.AD_LAYOUT.FUNCTION;
				AD_LAYOUT ad_layout0 = AppADConstants.AD_LAYOUT.GIFT_UNDER_CONDITION;
				AD_LAYOUT ad_layout11 = AppADConstants.AD_LAYOUT.GROUPON;
				AD_LAYOUT ad_layout12 = AppADConstants.AD_LAYOUT.GROUPON_BRAND;
				AD_LAYOUT ad_layout13 = AppADConstants.AD_LAYOUT.GROUPON_CATEGORY;
				AD_LAYOUT ad_layout14 = AppADConstants.AD_LAYOUT.GROUPON_CHANNEL;
				AD_LAYOUT ad_layout15 = AppADConstants.AD_LAYOUT.GROUPON_LABEL;
				AD_LAYOUT ad_layout16 = AppADConstants.AD_LAYOUT.H5_CMS;
				AD_LAYOUT ad_layout17 = AppADConstants.AD_LAYOUT.IMPORT_GOODS_INDEX;
						AD_LAYOUT ad_layout18 = AppADConstants.AD_LAYOUT.MALLSHOP;
						AD_LAYOUT ad_layout19 = AppADConstants.AD_LAYOUT.MOBILE_CHARGE_INDEX;
						AD_LAYOUT ad_layout20 = AppADConstants.AD_LAYOUT.N2N_ACTIVITY;
						AD_LAYOUT ad_layout21 = AppADConstants.AD_LAYOUT.NO_USE;
						AD_LAYOUT ad_layout22 = AppADConstants.AD_LAYOUT.NO_USE2;
						AD_LAYOUT ad_layout23 = AppADConstants.AD_LAYOUT.NO_USE3;
						AD_LAYOUT ad_layout24 = AppADConstants.AD_LAYOUT.NOLINK_AD;
						AD_LAYOUT ad_layout25 = AppADConstants.AD_LAYOUT.OUTLINK_AD;
						AD_LAYOUT ad_layout26 = AppADConstants.AD_LAYOUT.PC_CMS;
						AD_LAYOUT ad_layout27 = AppADConstants.AD_LAYOUT.PROMOTION_LD_PRODUCTS;
						AD_LAYOUT ad_layout28 = AppADConstants.AD_LAYOUT.SEARCH;
				
	}

}
