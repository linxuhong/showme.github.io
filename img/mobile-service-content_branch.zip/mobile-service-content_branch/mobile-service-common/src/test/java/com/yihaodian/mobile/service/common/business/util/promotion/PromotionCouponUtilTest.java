package com.yihaodian.mobile.service.common.business.util.promotion;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.yihaodian.promotion.coupon.outputVo.CouponActivityOutputVo;
import com.yihaodian.promotion.coupon.outputVo.couponShare.ShareCouponVo;

public class PromotionCouponUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testGetSharableCouponList() {
		
		 PromotionCouponUtil.getSharableCouponList(23L, 34L);
	
	}

	@Test
	public void testQuerySimpleCouponActiveInfoMapByActiveIdList() {
		List<Long> activeIdList = new ArrayList<Long>();
		activeIdList.add(23L);
		activeIdList.add(34L);
		PromotionCouponUtil.querySimpleCouponActiveInfoMapByActiveIdList(activeIdList);
	}

	@Test
	public void testComposeCouponUseExplain() {
		CouponActivityOutputVo couponActivityOutputVo = new CouponActivityOutputVo();
		couponActivityOutputVo.setActiveId(34L);
		couponActivityOutputVo.setActiveName("大厨");
		PromotionCouponUtil.composeCouponUseExplain(couponActivityOutputVo);
	}

	@Test
	public void testQueryCouponActiveInfoForShare() {
		PromotionCouponUtil.queryCouponActiveInfoForShare(34L, 45L);
	}

	@Test
	public void testQueryCouponActiveInfoForShareList() {
		
		List<Long> couponIdList = new ArrayList<Long>();
		couponIdList.add(23L);
		couponIdList.add(34L);
		PromotionCouponUtil.queryCouponActiveInfoForShareList(34L, couponIdList);
	}

	@Test
	public void testGetCouponActivityDesc() {
		CouponActivityOutputVo couponActivityInputInfoVo = new CouponActivityOutputVo();
		couponActivityInputInfoVo.setActiveId(23L);
		couponActivityInputInfoVo.setActiveName("最后三天");
		couponActivityInputInfoVo.setActiveType(3);
		couponActivityInputInfoVo.setActivityBeginDate(new Date());
		
		couponActivityInputInfoVo.setUsedType(6);
		couponActivityInputInfoVo.setActivityDesc("haohaoaho");
		BigDecimal deductAmount = new BigDecimal(23);
		couponActivityInputInfoVo.setDeductAmount(deductAmount );
		PromotionCouponUtil.getCouponActivityDesc(couponActivityInputInfoVo );
	}

}
