package com.yihaodian.mobile.service.common.business.util.check;

import org.junit.Test;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
public class BaseParamCheckUtilTest {

	@Test
	public void testHeaderVOCheck() {
		Result result = new ResultModel();
		//case1
		BaseParamCheckUtil baseParamCheckUtil = new BaseParamCheckUtil();
		result = baseParamCheckUtil.headerVOCheck(null);
	}

}
