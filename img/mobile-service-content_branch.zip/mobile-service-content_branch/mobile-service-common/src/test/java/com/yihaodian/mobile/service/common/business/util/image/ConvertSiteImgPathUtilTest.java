package com.yihaodian.mobile.service.common.business.util.image;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.front.global.util.UrlPrefix;
@RunWith(PowerMockRunner.class)
@PrepareForTest(UrlPrefix.class)
public class ConvertSiteImgPathUtilTest {

	@Test
	public void testMatchHeguiImgUrl() {
	    //case1
		ConvertSiteImgPathUtil.matchHeguiImgUrl(null);
		//case2
		PowerMockito.mockStatic(UrlPrefix.class);
		Map<String,String> map = new HashMap<String,String>();
		map.put("centralYhdDomain", "http://yihaodian.com");
		//PowerMockito.when((UrlPrefix.getValues().get("mallImgDomain"))).thenReturn(map.get("centralYhdDomain"));
		/*
		 * String cannot be returned by getValues() getValues() should return Map
		   org.mockito.exceptions.misusing.WrongTypeOfReturnValue:
		   String cannot be returned by getValues()
		    getValues() should return Map
		 */
		PowerMockito.when(UrlPrefix.getValues()).thenReturn(map);
		
		ConvertSiteImgPathUtil.matchHeguiImgUrl("http://yihaodian.com");
		Map<String,String> map1 = new HashMap<String,String>();
		map1.put("centralImgDomain", "http://yihaodian.com");
		PowerMockito.when((UrlPrefix.getValues().get("centralImgDomain"))).thenReturn(map1.get("centralYhdDomain"));
//		ConvertSiteImgPathUtil.matchHeguiImgUrl("yiaodian.com");
	}

}
