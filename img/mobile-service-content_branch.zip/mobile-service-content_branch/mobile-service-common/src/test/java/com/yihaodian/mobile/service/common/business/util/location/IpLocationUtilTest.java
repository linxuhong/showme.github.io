package com.yihaodian.mobile.service.common.business.util.location;

import static org.junit.Assert.*;

import org.junit.Test;

public class IpLocationUtilTest {

	@Test
	public void testGetIpVOByIp() {
		IpLocationUtil.getIpVOByIp("168.0.1.1");
	}
}
