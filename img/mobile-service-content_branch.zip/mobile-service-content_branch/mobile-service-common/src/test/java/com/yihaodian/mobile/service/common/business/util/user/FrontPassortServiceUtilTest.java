package com.yihaodian.mobile.service.common.business.util.user;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.yihaodian.mobile.vo.bussiness.Trader;

public class FrontPassortServiceUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testGetTrader() {
		FrontPassortServiceUtil.getTrader("test1");
		
	}

	@Test
	public void testCheckVerifyCode() {
		String sessionId = "sessionId";
		String code = "userCode";
		FrontPassortServiceUtil.checkVerifyCode(code, sessionId);
	}

	@Test
	public void testGetVerifyCodeUrl() {
		Trader trader = new Trader();
		trader.setInterfaceVersion("V1.0");
		trader.setClientAppVersion("Android5.0");
		trader.setClientSystem("Android");
		FrontPassortServiceUtil.getVerifyCodeUrl(trader );
	}

	@Test
	public void testMain() {
		String[] args = {"test1","test2","teset3"};
		FrontPassortServiceUtil.main(args );
	}

}
