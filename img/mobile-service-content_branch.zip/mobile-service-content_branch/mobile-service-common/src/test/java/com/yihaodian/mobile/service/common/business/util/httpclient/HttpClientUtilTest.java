package com.yihaodian.mobile.service.common.business.util.httpclient;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
public class HttpClientUtilTest {

	@Test
	public void testHttpClientPost() {
		//case1
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("1", "1");
		HttpClientUtil.httpClientPost("http://yihaodian.com", parameters, null);
	}

}
