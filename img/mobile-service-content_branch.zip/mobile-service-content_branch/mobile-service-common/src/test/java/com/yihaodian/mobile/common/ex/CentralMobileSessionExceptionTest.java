package com.yihaodian.mobile.common.ex;

import static org.junit.Assert.*;

import org.junit.Test;

public class CentralMobileSessionExceptionTest {
	private CentralMobileSessionException centralMobileSessionException = new CentralMobileSessionException(null);
	@Test
	public void testCentralMobileSessionException() {
		String message = "message ";
		centralMobileSessionException = new CentralMobileSessionException(message);
	}

	@Test
	public void testGetMessage() {
		centralMobileSessionException.getMessage();
	}

}
