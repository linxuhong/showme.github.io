package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class XSSEncoderTest {

	@Test
	public void testXssEncode() {
		XSSEncoder.xssEncode(null);
		XSSEncoder.xssEncode("sd");
	}

}
