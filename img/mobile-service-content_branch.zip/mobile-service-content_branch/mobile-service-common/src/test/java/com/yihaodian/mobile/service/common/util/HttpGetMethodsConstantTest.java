package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

import com.yihaodian.mobile.service.common.util.HttpGetMethodsConstant.ParamTypeEnum;

public class HttpGetMethodsConstantTest {

	@Test
	public void test() {
		ParamTypeEnum paramTypeEnum = HttpGetMethodsConstant.ParamTypeEnum.Integer;
		ParamTypeEnum paramTypeEnum1 = HttpGetMethodsConstant.ParamTypeEnum.Long;
		ParamTypeEnum paramTypeEnum2 = HttpGetMethodsConstant.ParamTypeEnum.None;
		ParamTypeEnum paramTypeEnum3 = HttpGetMethodsConstant.ParamTypeEnum.String;
		HttpGetMethodsConstant.methodMap = new HashMap();
		HttpGetMethodsConstant httpGetMethodsConstant = new HttpGetMethodsConstant();
		
	}

}
