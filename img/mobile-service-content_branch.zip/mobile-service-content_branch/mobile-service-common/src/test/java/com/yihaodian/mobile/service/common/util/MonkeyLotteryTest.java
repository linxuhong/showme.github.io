package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class MonkeyLotteryTest {

	@Test
	public void testGetLotteryResult() {
		//case1
		MonkeyLottery.getLotteryResult(0);
		//case2
		MonkeyLottery.getLotteryResult(101);
		//case3
		MonkeyLottery.getLotteryResult(70);
		//case4
		MonkeyLottery.getLotteryResult(-1);
	}

	@Test
	public void testGetRandCount() {
		MonkeyLottery.getRandCount(0);
		MonkeyLottery.getRandCount(12.54);
	}

	@Test
	public void testGetNextMondayTimeInM() {
		MonkeyLottery.getNextMondayTimeInM();
	}

	@Test
	public void testGetNextDayTimeInM() {
		MonkeyLottery.getNextDayTimeInM();
	}

	@Test
	public void testMain() {
		MonkeyLottery.main(null);
	}

}
