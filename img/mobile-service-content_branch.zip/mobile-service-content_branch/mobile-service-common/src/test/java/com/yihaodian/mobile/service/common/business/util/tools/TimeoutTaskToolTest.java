package com.yihaodian.mobile.service.common.business.util.tools;

import static org.junit.Assert.*;

import java.util.concurrent.Callable;

import org.junit.Test;

public class TimeoutTaskToolTest {

	@Test
	public void testExecuteTimeoutTaskCallableOfTLong() {
		//case1
		TimeoutTaskTool.executeTimeoutTask(new Callable<String>() {
			@Override
			public String call() throws Exception {
				return "test";
			}
		}, -1);
		//case2
		TimeoutTaskTool.executeTimeoutTask(new Callable<String>() {
			@Override
			public String call() throws Exception {
				return "test";
			}
		}, 1);
	}

	@Test
	public void testExecuteTimeoutTaskCallableOfTLongObject() {
		// case1
		TimeoutTaskTool.executeTimeoutTask(new Callable<String>() {
			@Override
			public String call() throws Exception {
				return "test";
			}
		}, -1, null);
		// case2
		TimeoutTaskTool.executeTimeoutTask(new Callable<String>() {
			@Override
			public String call() throws Exception {
				return "test";
			}
		}, 1, null);
	}

}
