package com.yihaodian.front.i.util.img;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.front.global.util.UrlPrefix;
@RunWith(PowerMockRunner.class)
@PrepareForTest(UrlPrefix.class)
public class ConvertSiteImgPathUtilTest {

	@Test	
	public void testMatchHeguiImgUrl() {
		//case1
		ConvertSiteImgPathUtil convertSiteImgPathUtil = new ConvertSiteImgPathUtil();
		convertSiteImgPathUtil.matchHeguiImgUrl(null);
		PowerMock.mockStatic(UrlPrefix.class);//Mock静态方法
		String url = "http://d6.yihaodianimg.com/N00/M08/7A/0E/CgMBmVOxHUeAaknDAAGxomURfZY75200.jpg";
		Map<String,String> result = new HashMap<String,String>() ;
		result.put("mallImgDomain", url);
		EasyMock.expect(UrlPrefix.getValues()).andReturn(result);//录制Mock对象的静态方法  
		Map<String,String> result2 = new HashMap<String,String>() ;
		result2.put("centralImgDomain", url);
		EasyMock.expect(UrlPrefix.getValues()).andReturn(result2);
	    PowerMock.replayAll();//重放Mock对象       
	//	 PowerMock.verifyAll(); 
	    //case2
		ConvertSiteImgPathUtil.matchHeguiImgUrl(url);
	
	
	}

}
