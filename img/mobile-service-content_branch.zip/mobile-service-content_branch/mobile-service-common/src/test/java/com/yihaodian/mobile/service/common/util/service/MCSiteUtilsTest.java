package com.yihaodian.mobile.service.common.util.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class MCSiteUtilsTest {

	@Test
	public void testGetMCSiteId() {
		MCSiteUtils.getMCSiteId();
	}

}
