package com.yihaodian.mobile.service.common.util;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.mobile.service.common.util.service.MemcachedProxy;
@RunWith(PowerMockRunner.class)
@PrepareForTest(MemcachedProxy.class)
public class UserLoginUtilTest {
	@Test
	public void testCheckIfNeedVerificationCode() {
		PowerMockito.mockStatic(MemcachedProxy.class);
    	MemcachedProxy me = PowerMockito.mock(MemcachedProxy.class);
    	PowerMockito.when(MemcachedProxy.getInstance()).thenReturn(me);
    	Map<String, Object> map = new HashMap<String, Object>();
    	map.put("firstLoginTimeKey", 1);
    	map.put("secondLoginTimeKey", 2);
    	map.put("thirdLoginTimeKey", 3);
		PowerMockito.when(me.get(Mockito.anyString())).thenReturn(map);
		UserLoginUtil userLoginUtil =new UserLoginUtil();
		userLoginUtil.checkIfNeedVerificationCode("zhangwei");
		
	}

}
