package com.yihaodian.mobile.service.common.business.util.scalper;

import static org.junit.Assert.*;
import static org.powermock.api.mockito.PowerMockito.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yhd.platform.merchant.manager.center.api.interfaces.risk.UserRiskLevelService;
import com.yhd.platform.merchant.manager.center.api.model.risk.UserRiskLevelDto;
import com.yhd.platform.merchant.manager.center.api.model.risk.UserRiskLevelResult;
import com.yhd.platform.merchant.manager.center.api.model.risk.UserRiskLevelVo;
import com.yihaodian.common.util.SpringBeanFactory;

@RunWith(PowerMockRunner.class)
@PrepareForTest(SpringBeanFactory.class)
public class ScalperUtilTest {
	
	private static UserRiskLevelService userRiskLevelService;
	private UserRiskLevelResult<UserRiskLevelVo> value=new UserRiskLevelResult<UserRiskLevelVo>();
	private UserRiskLevelVo result = new UserRiskLevelVo();
	@BeforeClass
	public static void setUpBeforeClass(){
		mockStatic(SpringBeanFactory.class);
		userRiskLevelService = mock(UserRiskLevelService.class);
		when(SpringBeanFactory.getBean("userRiskLevelService")).thenReturn(userRiskLevelService);
	}
	
	@Before
	public void setUp(){
		value.setResultCode(UserRiskLevelResult.SUCCESS);
		result.setClusterLevel(0);
		result.setLimitActionLevel(0);
		result.setUserRiskLevel(0);
		value.setResult(result);
		when(userRiskLevelService.getScalperRiskLevel(Mockito.any(UserRiskLevelDto.class))).thenReturn(value);
	}
	@Test
	public void testGetScalperRiskLevelLongInteger() {
		assertFalse(ScalperUtil.getScalperRiskLevel(1l, 1));
		result.setUserRiskLevel(1);
		assertTrue(ScalperUtil.getScalperRiskLevel(1l, 1));
	}

	@Test
	public void testGetScalperRiskLevelLongIntegerInteger() {
		assertFalse(ScalperUtil.getScalperRiskLevel(1l, 1,2));
		result.setUserRiskLevel(0);
		assertFalse(ScalperUtil.getScalperRiskLevel(1l, 1,2));
		result.setUserRiskLevel(2);
		assertFalse(ScalperUtil.getScalperRiskLevel(1l, 1,2));
		result.setUserRiskLevel(3);
		assertTrue(ScalperUtil.getScalperRiskLevel(1l, 1,2));
	}

}
