package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class Base64Test {

	@Test
	public void testEncode() {
		//case1
		Base64.encode(null);
		//case2
		Base64.encode(new byte[]{82, 71, -8, -103, -36, -127, -13, -78, 42, -92, 47, 99, 31, 27, 116, -73, 76, -23, -99, -114, 69, -45, 39, -91, 64, -29, 87, 111, -119, 20, 29, -16, -114, 17, -56, 96, -38, 80, -123, 23, 80, -128, -71, 53, -118, -86, -78, 24, -5, 35, -88, -2, -5, -28, -23, 99, 36, -37, 98, -75, 23, 3, -15, -44, -87, 118, 89});
	}

	@Test
	public void testDecode() {
		Base64.decode(null);
		Base64.decode("8271-8-103-36-127-13");
	}

}
