package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.junit.Test;

public class XmlHttpConnectionTest {

	@Test
	public void testXmlHttpConnectionStringInt() {
		InputStream stream = new ByteArrayInputStream("ok".getBytes());;
		XmlHttpConnection xmlHttpConnection = new XmlHttpConnection("http://yihaodian", 0) ;
		XmlHttpConnection xmlHttpConnection2 = new XmlHttpConnection("http://yihaodian", "1") ;
		xmlHttpConnection2.sendMsg("asdf");
		xmlHttpConnection2.getErrCode();
		xmlHttpConnection2.getErrMsg();
		xmlHttpConnection2.getRecvMsg();
		xmlHttpConnection2.getReMeg();
	}
}
