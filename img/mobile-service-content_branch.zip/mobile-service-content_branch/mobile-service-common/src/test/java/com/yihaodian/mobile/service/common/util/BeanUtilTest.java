package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.beans.PropertyDescriptor;

import org.apache.commons.beanutils.PropertyUtils;
import org.easymock.EasyMock;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

public class BeanUtilTest {

	@Test
	public void testCopyPropertiesObjectObject() {
		
	}

	@Test
	public void testCopyPropertiesObjectObjectBoolean() {
		//case1
		BeanUtil.copyProperties("name", "src", true);
		//case2
	}

	@Test
	public void testExtractLShortName() {
		BeanUtil.extractLShortName(String.class);
	}

	@Test
	public void testGetNotNullStrString() {
		BeanUtil.getNotNullStr("dsf");
	}

	@Test
	public void testGetNotNullStrObject() {
		BeanUtil.getNotNullStr(2);
	}

	@Test
	public void testGetRandomString() {
		BeanUtil.getRandomString();
	}

	@Test
	public void testGetRandomStringInt() {
		BeanUtil.getRandomString(12);
	}

}
