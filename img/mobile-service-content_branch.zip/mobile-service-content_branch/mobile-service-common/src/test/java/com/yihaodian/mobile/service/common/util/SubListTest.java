package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class SubListTest {

	@Test
	public void testSubList() {
		SubList subList = new SubList();
		List<String> list = new ArrayList<String>();
		list.add("1");
		list.add("2");
		list.add("2");
		subList.subList(list ,1,2);
		
	}

}
