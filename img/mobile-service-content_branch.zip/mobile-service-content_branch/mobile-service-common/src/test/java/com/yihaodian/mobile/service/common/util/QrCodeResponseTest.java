package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class QrCodeResponseTest {
	QrCodeResponse qrCodeResponse =  new QrCodeResponse();
	@Test
	public void testGetMessage() {
		qrCodeResponse.getMessage();
		qrCodeResponse.getResultCode();
		qrCodeResponse.setMessage("ok");
		qrCodeResponse.setResultCode("23849");
		
	}

}
