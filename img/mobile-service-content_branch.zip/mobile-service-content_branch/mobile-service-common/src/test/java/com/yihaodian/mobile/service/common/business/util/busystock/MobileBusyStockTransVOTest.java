package com.yihaodian.mobile.service.common.business.util.busystock;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yihaodian.front.busystock.vo.BSPromotionProductVo;
import com.yihaodian.mobile.vo.product.ProductVO;

public class MobileBusyStockTransVOTest {

	@Test
	public void testSetBusyStockInfoByBsProductVOBSProductVoDiaryProductVO() {
		BSPromotionProductVo bspVo = new BSPromotionProductVo();
		bspVo.setPmId(2L);
		bspVo.setMerchantId(2L);
		ProductVO productVO = new ProductVO();
		MobileBusyStockTransVO.setBusyStockInfoByBsProductVO(bspVo, productVO);
	}

	@Test
	public void testSetBusyStockInfoByBsProductVOBSPromotionProductVoDiaryProductVO() {
		BSPromotionProductVo bspVo = new BSPromotionProductVo();
		bspVo.setPmId(2L);
		bspVo.setMerchantId(2L);
		ProductVO productVO = new ProductVO();
		MobileBusyStockTransVO.setBusyStockInfoByBsProductVOV2(bspVo,productVO);
	}

}
