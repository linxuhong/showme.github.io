package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Test;

public class QRUtilTest {

	@Test
	public void testProcessSingleProductQRCode() {
		//QRUtil.processSingleProductQRCode(1L, 1L, 1L, 120, 20);
		QRUtil.processCMSActivityQRCode(1L, 20, 20);
		QRUtil.processCouponQRCode(1L, 20, 20);
		QRUtil.getQRBySourceContent("sdg", 2, 3);
		QRUtil.generateQRImageFile("http://yihaodian.com", 12, 12);
		//QRUtil.processSingleProductQRCode(1l, 1l, 1l, 20, 40);
		QRUtil.commonQRCodeGenerate(1l, 1l, 1, 2, 1);
		QRUtil.commonQRCodeGenerate(1l, 1l, 2, 2, 1);
		QRUtil.commonQRCodeGenerate(1l, 1l, 3, 2, 1);
		QRUtil.commonQRCodeGenerate(1l, 1l, 4, 2, 1);
		QRUtil.commonQRCodeGenerate(1l, 1l, 5, 2, 1);
		QRUtil.commonQRCodeGenerate(1l, 1l, 7, 2, 1);
		QRUtil.commonQRCodeGenerate(1l, 1l, 8, 2, 1);
		QRUtil.commonQRCodeGenerate(1l, 1l, 9, 2, 1);
		QRUtil.commonQRCodeGenerate(1l, 1l, 10,2, 1);
		//QRUtil.uploadFile("yihaodian", null);
	}

}
