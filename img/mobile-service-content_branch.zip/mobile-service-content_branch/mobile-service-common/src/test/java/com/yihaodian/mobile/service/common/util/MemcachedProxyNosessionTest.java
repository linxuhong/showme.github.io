package com.yihaodian.mobile.service.common.util;


import org.junit.Test;
public class MemcachedProxyNosessionTest {
	MemcachedProxyNosession memcachedProxyNosession = new MemcachedProxyNosession();
	@Test
	public void testGetInstance() {
		MemcachedProxyNosession.getInstance();
	}

	@Test
	public void testGet() {
		memcachedProxyNosession.get("1");
	}

	@Test
	public void testPutStringObject() {
		memcachedProxyNosession.put("ok", "yihaodianok");
	}

	@Test
	public void testPutStringObjectInt() {
		memcachedProxyNosession.put("ok2", "yihaodianok2", 2);
	}

	@Test
	public void testRemove() {
		memcachedProxyNosession.remove("ok");
	}

	@Test
	public void testGetDateAfter() {
		memcachedProxyNosession.getDateAfter(3);
	}

}
