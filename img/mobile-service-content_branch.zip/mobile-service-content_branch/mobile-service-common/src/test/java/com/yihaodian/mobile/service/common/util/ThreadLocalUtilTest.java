package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yihaodian.front.sso.common.vo.SsoUser;
import com.yihaodian.mobile.vo.bussiness.Trader;

public class ThreadLocalUtilTest {

	@Test
	public void testSetUser() {
		SsoUser user = new SsoUser();
		user.setId(1l);
		ThreadLocalUtil.setUser(user);
		ThreadLocalUtil.getUser();
		ThreadLocalUtil.removeUser();
		Trader trader = new Trader();
		trader.setUserToken("im");
		ThreadLocalUtil.setTrader(trader );
		ThreadLocalUtil.getTrader();
		ThreadLocalUtil.removeTrader();
		ThreadLocalUtil.setPromotionLevelVoListFlag(true);
		ThreadLocalUtil.getPromotionLevelVoListFlag();
	}

}
