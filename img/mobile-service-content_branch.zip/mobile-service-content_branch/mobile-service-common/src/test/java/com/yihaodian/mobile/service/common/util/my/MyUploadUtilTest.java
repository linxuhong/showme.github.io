package com.yihaodian.mobile.service.common.util.my;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Test;

public class MyUploadUtilTest {

	@Test
	public void testDelFile() {
		String filename = "android";
		File file = new File(filename);
		MyUploadUtil.delFile(file);
	}
}
