package com.yihaodian.mobile.common.ex;

import static org.junit.Assert.*;

import org.easymock.EasyMock;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.front.global.util.UrlPrefix;

@RunWith(PowerMockRunner.class)
@PrepareForTest(CentralMobileParamsException.class)
public class CentralMobileParamsExceptionTest {
	String message = "no exception";
	CentralMobileParamsException centralMobileParamsException;
	@Test
	public void testCentralMobileParamsException() {

		centralMobileParamsException = new CentralMobileParamsException(message);
	}

	@Test
	public void testGetMessage() {
		centralMobileParamsException = new CentralMobileParamsException(null);
		centralMobileParamsException.getMessage();
	}

}
