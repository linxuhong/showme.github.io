package com.yihaodian.mobile.common.ex;

import static org.junit.Assert.*;

import org.junit.Test;

public class CentralMobileRuntimeExceptionTest {
	private CentralMobileRuntimeException centralMobileRuntimeException = new CentralMobileRuntimeException(null);
	@Test
	public void testCentralMobileRuntimeException() {
		String message = "no exception";
		centralMobileRuntimeException = new CentralMobileRuntimeException(message);
	}

	@Test
	public void testGetMessage() {
		centralMobileRuntimeException.getMessage();
		
	}

}
