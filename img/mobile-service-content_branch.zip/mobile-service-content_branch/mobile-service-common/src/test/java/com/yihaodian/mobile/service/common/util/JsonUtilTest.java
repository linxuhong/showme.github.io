package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.util.HashMap;

import net.sf.json.processors.JsonValueProcessor;

import org.junit.Test;

import com.yihaodian.mobile.service.common.util.JsonUtil.NullValueProcesser;

public class JsonUtilTest {

	@Test
	public void testGetJsonArray() {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("one", "ok");
		JsonUtil.getJsonArray(map);
		new JsonUtil.NullValueProcesser().processArrayValue(null, null);
		new JsonUtil.NullValueProcesser().processArrayValue("ok", null);
		new JsonUtil.NullValueProcesser().processObjectValue(null, null, null);
		new JsonUtil.NullValueProcesser().processObjectValue(null, map, null);
		JsonUtil.objectToJson(map);
	}

}
