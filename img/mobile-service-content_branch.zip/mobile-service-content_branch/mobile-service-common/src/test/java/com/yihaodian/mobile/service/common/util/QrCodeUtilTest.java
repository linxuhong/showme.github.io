package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class QrCodeUtilTest {
	QrCodeUtil qrCodeUtil = new QrCodeUtil();
	@Test
	public void testGetQrCodeText() {
		qrCodeUtil.setQrCodeText("235djf");
		qrCodeUtil.getQrCodeText();
		qrCodeUtil.setProductId("ok3");
		qrCodeUtil.getProductId();
		qrCodeUtil.setTrackingId("SD");
		qrCodeUtil.setImageSize("800");
		qrCodeUtil.getImageSize();
		QrCodeUtil.getHostUrl();
	}

}
