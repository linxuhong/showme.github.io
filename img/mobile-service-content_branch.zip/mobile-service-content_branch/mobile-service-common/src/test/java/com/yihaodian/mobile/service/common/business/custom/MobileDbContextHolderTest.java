package com.yihaodian.mobile.service.common.business.custom;

import static org.junit.Assert.*;

import org.junit.Test;

public class MobileDbContextHolderTest {

	@Test
	public void testSetDbType() {
		MobileDbContextHolder.setDbType("yihaodian");
	}

	@Test
	public void testGetDbType() {
		MobileDbContextHolder.getDbType();
	}

	@Test
	public void testClearDbType() {
		MobileDbContextHolder.clearDbType();
	}

}
