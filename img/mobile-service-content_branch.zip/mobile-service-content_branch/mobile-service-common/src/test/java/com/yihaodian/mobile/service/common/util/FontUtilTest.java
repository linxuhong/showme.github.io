package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.awt.Font;
import java.io.File;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
@RunWith(PowerMockRunner.class)
public class FontUtilTest {
	@Test
	@PrepareForTest({FontUtil.class})
	public void testGenerateCheckCodeImage() {
		try {
			/*File value = new File("");
			PowerMockito.mockStatic(YccGlobalPropertyConfigurer.class);
			PowerMockito.when(YccGlobalPropertyConfigurer.getFile(Mockito.anyString())).thenReturn(value );
			PowerMockito.mockStatic(Font.class);
			Font font = PowerMockito.mock(Font.class);
			PowerMockito.when(Font.createFont(Mockito.anyInt(), Mockito.any(File.class))).thenReturn(font);*/
			
			PowerMockito.mockStatic(FontUtil.class);
			Object[] obj = new Object[2];
			PowerMockito.when(FontUtil.generateCheckCodeImage()).thenReturn(obj);
		} catch (Exception e) {
			assertTrue(true);
		}
	}
}
