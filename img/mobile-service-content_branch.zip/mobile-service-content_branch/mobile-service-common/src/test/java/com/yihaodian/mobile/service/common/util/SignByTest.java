package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.junit.Test;

public class SignByTest {

	@Test
	public void testCreateSign() {
		/*String str = "dfgdsfg";
		SignBy.createSign("origin", "alias", "123",new ByteArrayInputStream(str.getBytes()));
		byte [] bstr = {1};
		SignBy.BASE64encode(bstr);*/
	}
}
