package com.yihaodian.mobile.service.common.business.custom;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.front.global.util.UrlPrefix;
@RunWith(PowerMockRunner.class)
//@PrepareForTest(MobileDynmicDataSource.class)
public class MobileDynmicDataSourceTest {
	MobileDynmicDataSource mobileDynmicDataSource = new MobileDynmicDataSource();
	@Test
	@PrepareForTest(MobileDbContextHolder.class)
	public void testDetermineCurrentLookupKey() {
		mobileDynmicDataSource.determineCurrentLookupKey();
	}

}
