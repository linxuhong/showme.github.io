package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class TokenFactoryTest {

	@Test
	public void testGetUserToken() {
		TokenFactory.getUserToken();
	}

}
