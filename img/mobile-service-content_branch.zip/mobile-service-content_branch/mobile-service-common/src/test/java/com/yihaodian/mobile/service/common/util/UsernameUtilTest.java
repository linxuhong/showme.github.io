package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class UsernameUtilTest {

	@Test
	public void testChangeUserNametoHidden() {
		UsernameUtil.changeUserNametoHidden(null);
		UsernameUtil.changeUserNametoHidden("yihaodian");
		UsernameUtil.changeUserNametoHidden("zxq@yihaodian.com");
	}

}
