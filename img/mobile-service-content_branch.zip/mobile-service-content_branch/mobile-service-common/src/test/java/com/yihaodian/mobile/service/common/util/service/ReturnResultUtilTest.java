package com.yihaodian.mobile.service.common.util.service;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yihaodian.mobile.vo.cart.AddOrDeletePromotionResult;
import com.yihaodian.mobile.vo.cart.AddProductResult;
import com.yihaodian.mobile.vo.cart.ExistOptionalResult;
import com.yihaodian.mobile.vo.cart.UpadtePromotionResult;
import com.yihaodian.mobile.vo.cart.UpdateCartResult;
import com.yihaodian.mobile.vo.coupon.AddCouponByActivityIdResult;
import com.yihaodian.mobile.vo.coupon.CouponVerifyActiveCodeResult;
import com.yihaodian.mobile.vo.coupon.ReceiveResult;
import com.yihaodian.mobile.vo.groupon.GrouponOrderSubmitResult;
import com.yihaodian.mobile.vo.groupon.GrouponOrderVO;
import com.yihaodian.mobile.vo.miracle.MiracleRegisterResult;
import com.yihaodian.mobile.vo.order.CheckSmsResult;
import com.yihaodian.mobile.vo.order.CouponDeleteResult;
import com.yihaodian.mobile.vo.order.CouponGetCheckCodeResult;
import com.yihaodian.mobile.vo.order.CouponSaveResult;
import com.yihaodian.mobile.vo.order.CouponVerifyCheckCodeResult;
import com.yihaodian.mobile.vo.order.CreateOrderResult;
import com.yihaodian.mobile.vo.order.SaveGateWayToOrderResult;
import com.yihaodian.mobile.vo.order.SaveGoodReceiverResult;
import com.yihaodian.mobile.vo.order.SavePayByAccountResult;
import com.yihaodian.mobile.vo.order.SendValidCodeResult;
import com.yihaodian.mobile.vo.order.SubmitOrderResult;
import com.yihaodian.mobile.vo.promotion.AddStorageBoxResult;
import com.yihaodian.mobile.vo.promotion.AwardsResult;
import com.yihaodian.mobile.vo.promotion.InviteeResult;
import com.yihaodian.mobile.vo.promotion.SeckillCanBuyResult;
import com.yihaodian.mobile.vo.promotion.UpdateStroageBoxResult;
import com.yihaodian.mobile.vo.user.BindMobileResult;
import com.yihaodian.mobile.vo.user.CheckUserNameResult;
import com.yihaodian.mobile.vo.user.CheckValidCodeForPhoneRegisterResult;
import com.yihaodian.mobile.vo.user.CheckValidCodeResult;
import com.yihaodian.mobile.vo.user.LoginResult;
import com.yihaodian.mobile.vo.user.PushMappingResult;
import com.yihaodian.mobile.vo.user.RegisterQijiResult;
import com.yihaodian.mobile.vo.user.RegisterResult;
import com.yihaodian.mobile.vo.user.SendBindValidateCodeResult;
import com.yihaodian.mobile.vo.user.SendValidCodeForPhoneRegisterResult;
import com.yihaodian.mobile.vo.user.UpdatePasswordResult;
import com.yihaodian.mobile.vo.user.UpdateUserAgreeAuthResult;

public class ReturnResultUtilTest {

	@Test
	public void testFormatReturnObject() {
		AddOrDeletePromotionResult addOrDeletePromotionResult = new AddOrDeletePromotionResult();
		addOrDeletePromotionResult.setErrorInfo("error");
		addOrDeletePromotionResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(addOrDeletePromotionResult, "getSearchKeyWord");
		addOrDeletePromotionResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(addOrDeletePromotionResult, "getSearchKeyWord");
		addOrDeletePromotionResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(addOrDeletePromotionResult, "getSearchKeyWord");
		
		AddProductResult addProductResult = new AddProductResult();
		addProductResult.setErrorInfo("error");
		addProductResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(addProductResult, "getSearchKeyWord");
		addProductResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(addProductResult, "getSearchKeyWord");
		addProductResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(addProductResult, "getSearchKeyWord");
		
		ExistOptionalResult existOptionalResult = new ExistOptionalResult();
		existOptionalResult.setErrorInfo("error");
		existOptionalResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(existOptionalResult, "getSearchKeyWord");
		existOptionalResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(existOptionalResult, "getSearchKeyWord");
		existOptionalResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(existOptionalResult, "getSearchKeyWord");
		
		UpadtePromotionResult upadtePromotionResult = new UpadtePromotionResult();
		upadtePromotionResult.setErrorInfo("error");
		upadtePromotionResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(upadtePromotionResult, "getSearchKeyWord");
		upadtePromotionResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(upadtePromotionResult, "getSearchKeyWord");
		upadtePromotionResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(upadtePromotionResult, "getSearchKeyWord");
		
		UpdateCartResult updateCartResult = new UpdateCartResult();
		updateCartResult.setErrorInfo("error");
		updateCartResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(updateCartResult, "getSearchKeyWord");
		updateCartResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(updateCartResult, "getSearchKeyWord");
		updateCartResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(updateCartResult, "getSearchKeyWord");
		
		AddCouponByActivityIdResult addCouponByActivityIdResult = new AddCouponByActivityIdResult();
		addCouponByActivityIdResult.setErrorInfo("error");
		addCouponByActivityIdResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(addCouponByActivityIdResult, "getSearchKeyWord");
		addCouponByActivityIdResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(addCouponByActivityIdResult, "getSearchKeyWord");
		addCouponByActivityIdResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(addCouponByActivityIdResult, "getSearchKeyWord");
		
		CouponVerifyActiveCodeResult couponVerifyActiveCodeResult = new CouponVerifyActiveCodeResult();
		couponVerifyActiveCodeResult.setErrorInfo("error");
		couponVerifyActiveCodeResult.setSuccessed(true);
		ReturnResultUtil.formatReturnObject(couponVerifyActiveCodeResult, "getSearchKeyWord");
		couponVerifyActiveCodeResult.setSuccessed(false);
		ReturnResultUtil.formatReturnObject(couponVerifyActiveCodeResult, "getSearchKeyWord");
		
		ReceiveResult receiveResult = new ReceiveResult();
		receiveResult.setResultInfo("error");
		receiveResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(receiveResult, "getSearchKeyWord");
		receiveResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(receiveResult, "getSearchKeyWord");
		receiveResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(receiveResult, "getSearchKeyWord");
		
		GrouponOrderSubmitResult grouponOrderSubmitResult = new GrouponOrderSubmitResult();
		grouponOrderSubmitResult.setErrorInfo("error");
		grouponOrderSubmitResult.setHasError(true);
		ReturnResultUtil.formatReturnObject(grouponOrderSubmitResult, "getSearchKeyWord");
		grouponOrderSubmitResult.setHasError(false);
		ReturnResultUtil.formatReturnObject(grouponOrderSubmitResult, "getSearchKeyWord");
		
		GrouponOrderVO grouponOrderVO = new GrouponOrderVO();
		grouponOrderVO.setErrorInfo("error");
		grouponOrderVO.setHasError(true);
		ReturnResultUtil.formatReturnObject(grouponOrderVO, "getSearchKeyWord");
		grouponOrderVO.setHasError(false);
		ReturnResultUtil.formatReturnObject(grouponOrderVO, "getSearchKeyWord");
		
		MiracleRegisterResult miracleRegisterResult = new MiracleRegisterResult();
		miracleRegisterResult.setResultInfo("error");
		miracleRegisterResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(miracleRegisterResult, "getSearchKeyWord");
		miracleRegisterResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(miracleRegisterResult, "getSearchKeyWord");
		miracleRegisterResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(miracleRegisterResult, "getSearchKeyWord");
		
		CheckSmsResult checkSmsResult = new CheckSmsResult();
		checkSmsResult.setErrorInfo("error");
		checkSmsResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(checkSmsResult, "getSearchKeyWord");
		checkSmsResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(checkSmsResult, "getSearchKeyWord");
		checkSmsResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(checkSmsResult, "getSearchKeyWord");
		
		CouponDeleteResult couponDeleteResult = new CouponDeleteResult();
		couponDeleteResult.setErrorInfo("error");
		couponDeleteResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(couponDeleteResult, "getSearchKeyWord");
		couponDeleteResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(couponDeleteResult, "getSearchKeyWord");
		couponDeleteResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(couponDeleteResult, "getSearchKeyWord");
		
		CouponGetCheckCodeResult couponGetCheckCodeResult = new CouponGetCheckCodeResult();
		couponGetCheckCodeResult.setErrorInfo("error");
		couponGetCheckCodeResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(couponGetCheckCodeResult, "getSearchKeyWord");
		couponGetCheckCodeResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(couponGetCheckCodeResult, "getSearchKeyWord");
		couponGetCheckCodeResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(couponGetCheckCodeResult, "getSearchKeyWord");
		
		CouponSaveResult couponSaveResult = new CouponSaveResult();
		couponSaveResult.setErrorInfo("error");
		couponSaveResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(couponSaveResult, "getSearchKeyWord");
		
		CouponVerifyCheckCodeResult couponVerifyCheckCodeResult = new CouponVerifyCheckCodeResult();
		couponVerifyCheckCodeResult.setErrorInfo("error");
		couponVerifyCheckCodeResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(couponVerifyCheckCodeResult, "getSearchKeyWord");
		
		CreateOrderResult createOrderResult = new CreateOrderResult();
		createOrderResult.setErrorInfo("error");
		createOrderResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(createOrderResult, "getSearchKeyWord");
		createOrderResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(createOrderResult, "getSearchKeyWord");
		createOrderResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(createOrderResult, "getSearchKeyWord");
		
		SaveGateWayToOrderResult saveGateWayToOrderResult = new SaveGateWayToOrderResult();
		saveGateWayToOrderResult.setErrorInfo("error");
		saveGateWayToOrderResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(saveGateWayToOrderResult, "getSearchKeyWord");
		
		SaveGoodReceiverResult saveGoodReceiverResult = new SaveGoodReceiverResult();
		saveGoodReceiverResult.setErrorInfo("error");
		saveGoodReceiverResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(saveGoodReceiverResult, "getSearchKeyWord");
		saveGoodReceiverResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(saveGoodReceiverResult, "getSearchKeyWord");
		saveGoodReceiverResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(saveGoodReceiverResult, "getSearchKeyWord");
		
		SavePayByAccountResult savePayByAccountResult = new SavePayByAccountResult();
		savePayByAccountResult.setErrorInfo("error");
		savePayByAccountResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(savePayByAccountResult, "getSearchKeyWord");
		
		SendValidCodeResult sendValidCodeResult = new SendValidCodeResult();
		sendValidCodeResult.setErrorInfo("error");
		sendValidCodeResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(sendValidCodeResult, "getSearchKeyWord");
		
		SubmitOrderResult submitOrderResult = new SubmitOrderResult();
		submitOrderResult.setErrorInfo("error");
		submitOrderResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(submitOrderResult, "getSearchKeyWord");
		
		AddStorageBoxResult addStorageBoxResult = new AddStorageBoxResult();
		addStorageBoxResult.setErrorInfo("error");
		addStorageBoxResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(addStorageBoxResult, "getSearchKeyWord");
		
		AwardsResult awardsResult = new AwardsResult();
		awardsResult.setErrorInfo("error");
		awardsResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(awardsResult, "getSearchKeyWord");
		
		InviteeResult inviteeResult = new InviteeResult();
		inviteeResult.setErrorInfo("error");
		inviteeResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(inviteeResult, "getSearchKeyWord");
		
		SeckillCanBuyResult seckillCanBuyResult = new SeckillCanBuyResult();
		seckillCanBuyResult.setResultInfo("error");
		seckillCanBuyResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(seckillCanBuyResult, "getSearchKeyWord");
		
		UpdateStroageBoxResult updateStroageBoxResult = new UpdateStroageBoxResult();
		updateStroageBoxResult.setErrorInfo("error");
		updateStroageBoxResult.setErrorCode("1");
		ReturnResultUtil.formatReturnObject(updateStroageBoxResult, "getSearchKeyWord");
		updateStroageBoxResult.setErrorCode("0");
		ReturnResultUtil.formatReturnObject(updateStroageBoxResult, "getSearchKeyWord");
		updateStroageBoxResult.setErrorCode("-1");
		ReturnResultUtil.formatReturnObject(updateStroageBoxResult, "getSearchKeyWord");
		
		BindMobileResult bindMobileResult = new BindMobileResult();
		bindMobileResult.setErrorInfo("error");
		bindMobileResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(bindMobileResult, "getSearchKeyWord");
		
		CheckUserNameResult checkUserNameResult = new CheckUserNameResult();
		checkUserNameResult.setErrorInfo("error");
		checkUserNameResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(checkUserNameResult, "getSearchKeyWord");
		
		CheckValidCodeForPhoneRegisterResult checkValidCodeForPhoneRegisterResult = new CheckValidCodeForPhoneRegisterResult();
		checkValidCodeForPhoneRegisterResult.setErrorInfo("error");
		checkValidCodeForPhoneRegisterResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(checkValidCodeForPhoneRegisterResult, "getSearchKeyWord");
		
		CheckValidCodeResult checkValidCodeResult = new CheckValidCodeResult();
		checkValidCodeResult.setErrorInfo("error");
		checkValidCodeResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(checkValidCodeResult, "getSearchKeyWord");
		
		LoginResult loginResult = new LoginResult();
		loginResult.setErrorInfo("error");
		loginResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(loginResult, "getSearchKeyWord");
		loginResult.setResultCode(0);
		ReturnResultUtil.formatReturnObject(loginResult, "getSearchKeyWord");
		loginResult.setResultCode(-1);
		ReturnResultUtil.formatReturnObject(loginResult, "getSearchKeyWord");
		
		PushMappingResult pushMappingResult = new PushMappingResult();
		pushMappingResult.setErrorInfo("error");
		pushMappingResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(pushMappingResult, "getSearchKeyWord");
		
		RegisterQijiResult registerQijiResult = new RegisterQijiResult();
		registerQijiResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(registerQijiResult, "getSearchKeyWord");
		
		RegisterResult registerResult = new RegisterResult();
		registerResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(registerResult, "getSearchKeyWord");
		
		SendBindValidateCodeResult sendBindValidateCodeResult = new SendBindValidateCodeResult();
		sendBindValidateCodeResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(sendBindValidateCodeResult, "getSearchKeyWord");
		
		SendValidCodeForPhoneRegisterResult sendValidCodeForPhoneRegisterResult = new SendValidCodeForPhoneRegisterResult();
		sendValidCodeForPhoneRegisterResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(sendValidCodeForPhoneRegisterResult, "getSearchKeyWord");
		
		com.yihaodian.mobile.vo.user.SendValidCodeResult sendValidCodeResult1 = new com.yihaodian.mobile.vo.user.SendValidCodeResult();
		sendValidCodeResult1.setResultCode(1);
		ReturnResultUtil.formatReturnObject(sendValidCodeResult1, "getSearchKeyWord");
		
		UpdatePasswordResult updatePasswordResult = new UpdatePasswordResult();
		updatePasswordResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(updatePasswordResult, "getSearchKeyWord");
		
		UpdateUserAgreeAuthResult updateUserAgreeAuthResult = new UpdateUserAgreeAuthResult();
		updateUserAgreeAuthResult.setResultCode(1);
		ReturnResultUtil.formatReturnObject(updateUserAgreeAuthResult, "getSearchKeyWord");
		
		ReturnResultUtil.formatReturnObject(new Integer(1), "getUnreadMessageCount");
		
		ReturnResultUtil.formatReturnObject(new Long(1), "saveGateWayToGrouponOrder");
		
		ReturnResultUtil.formatReturnObject("", "saveGateWayToGrouponOrder");
	}

	@Test
	public void testFormatReturnErr() {
		ReturnResultUtil.formatReturnErr("saveGateWayToGrouponOrder", "");
	}

}
