package com.yihaodian.mobile.service.common.business.util.gson;


import org.junit.Test;
public class GsonUtilTest {
	GsonUtil gsonUtil = new GsonUtil();
	@Test
	public void testPaseToObject() {
		
		gsonUtil.paseToObject(null, null);
	}

	@Test
	public void testIsNumeric() {
		String str = "123";
		gsonUtil.isNumeric(str);
		gsonUtil.isNumeric(" ");
	}

}
