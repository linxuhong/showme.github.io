package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class PicturePipleUtilTest {

	@Test
	public void testGetPictureUrlStringString() {
		//PicturePipleUtil.getGrouponPictureUrl("sadf.jpg",23);
		PicturePipleUtil.getPictureUrl("sadf.jpg","1024");
		PicturePipleUtil.getGrouponPictureUrl("yihaodiansdf.jpg", "http://yihaodian.jpg", "680");
		PicturePipleUtil.getPictureUrl("sadf.jpg","1024",1l);
	}

}
