package com.yihaodian.front.i.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class ConstantTest {

	@Test
	public void testGetDefaultPicURL() {
		Constant constant = new Constant();
		constant.getDefaultPicURL();
	}

}
