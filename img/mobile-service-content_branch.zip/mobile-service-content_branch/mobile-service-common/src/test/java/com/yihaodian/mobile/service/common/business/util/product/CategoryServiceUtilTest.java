package com.yihaodian.mobile.service.common.business.util.product;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.newheight.common.model.PmsHedwigProduct;

public class CategoryServiceUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testQueryLowerlayerCategoryTreeById() {
	CategoryServiceUtil.queryLowerlayerCategoryTreeById(34L);
	}

	@Test
	public void testQuerySubMcsiteCategorysById() {
		CategoryServiceUtil.querySubMcsiteCategorysById(34L);
	}

	@Test
	public void testQueryLowerlayerCategoryTreeByIdList() {
		List<Long> categoryIdList = new ArrayList<Long>();
		categoryIdList.add(34L);
		categoryIdList.add(35L);
		categoryIdList.add(36L);
		CategoryServiceUtil.queryLowerlayerCategoryTreeByIdList(categoryIdList );
	}


}
