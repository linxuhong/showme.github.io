package com.yihaodian.mobile.common.ex;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
@RunWith(PowerMockRunner.class)
@PrepareForTest(RuntimeExceptionThreadVO.class)
public class RuntimeExceptionThreadVOTest {

	@Test
	public void testGetMessage() {
		PowerMock.mockStatic(RuntimeExceptionThreadVO.class);
		RuntimeExceptionThreadVO.getMessage();
		 
	}

	@Test
	public void testSetMessage() {
		PowerMock.mockStatic(RuntimeExceptionThreadVO.class);
		RuntimeExceptionThreadVO.setMessage("ok");
	}

	@Test
	public void testClearMessage() {
		PowerMock.mockStatic(RuntimeExceptionThreadVO.class);
		RuntimeExceptionThreadVO.clearMessage();
	}

}
