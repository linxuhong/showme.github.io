package com.yihaodian.mobile.service.common.util.service;

import org.junit.Test;

public class VersionUtilTest {

	@Test
	public void testCompare() {
		VersionUtil.compare(null, null);
		VersionUtil.compare("sdfhgsdf", null);
		VersionUtil.compare("as", "dfgsj");
	}

	@Test
	public void testBefore() {
		String versionSrc = "1.2.1";
		String versionDest = "2.1.1";
		VersionUtil.before(versionSrc, versionDest);
	}

	@Test
	public void testAfter() {
		String versionSrc = "1.2.1";
		String versionDest = "2.1.1";
		VersionUtil.after(versionDest, versionSrc);
	}

	@Test
	public void testEqualsStringString() {
		String versionSrc = "1.2.1";
		String versionDest = "2.1.1";
		VersionUtil.equals(versionSrc, versionDest);
	}

}
