//package com.yihaodian.mobile.service.common.util;
//
//import static org.junit.Assert.*;
//
//import java.awt.Font;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.powermock.api.mockito.PowerMockito;
//import org.powermock.core.classloader.annotations.PrepareForTest;
//import org.powermock.modules.junit4.PowerMockRunner;
//
//import com.yihaodian.common.mercury.model.McSite;
//import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
//@RunWith(PowerMockRunner.class)
//@PrepareForTest({YccGlobalPropertyConfigurer.class})
//public class MobileCommonUtilTest {
//
//	@Test
//	public void testGetCurrSiteId() {
//		PowerMockito.mockStatic(McSiteConfigFactory.class);
//		PowerMockito.mockStatic(YccGlobalPropertyConfigurer.class);
//		PowerMockito.when(YccGlobalPropertyConfigurer.getPropertyByKey(Mockito.anyString(),Mockito.anyString())).thenReturn("2");
//		McSiteConfigFactory value = PowerMockito.mock(McSiteConfigFactory.class);
//		PowerMockito.when(McSiteConfigFactory.getInstance()).thenReturn(value );
//		McSite value1 = new McSite();
//		value1.setId(1);
//		PowerMockito.when(value.getCurrentSite()).thenReturn(value1 );
//		MobileCommonUtil u = new MobileCommonUtil();
//		u.getCurrSiteId();
//	}
//
//}
