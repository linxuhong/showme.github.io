package com.yihaodian.mobile.service.common.business.util.user;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yihaodian.myyhdservice.interfaces.enums.point.PointSendSourceType;

public class UserPointServiceUtilTest {

	@Test
	public void testUpdateUserPoint() {
		UserPointServiceUtil.updateUserPoint(2, 5, 5L, 2, 12L);
	}

	@Test
	public void testPointSendByUserId() {
		PointSendSourceType sourceType = PointSendSourceType.INTEGRAL_SHAKE_SOURCE;
		UserPointServiceUtil.pointSendByUserId(5L, 5, sourceType);
	}

}
