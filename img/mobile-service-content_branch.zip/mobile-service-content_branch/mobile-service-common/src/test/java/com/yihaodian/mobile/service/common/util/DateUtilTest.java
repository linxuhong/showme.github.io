package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class DateUtilTest {
	Date date = new Date();
	@Test
	public void testParseDateToString() {
		
		DateUtil.parseDateToString(date);
	}

	@Test
	public void testGetWeekDay() {
		DateUtil.getWeekDay(date);
	}

	@Test
	public void testGetDayFormat() {
		DateUtil.getDayFormat(date, "yyyy-MM-dd HH:mm:ss");
	}

	@Test
	public void testGetDate() {
		DateUtil.getDate("2012-12-12 45:34:23", "yyyy-MM-dd");
	}

	@Test
	public void testDaysBetween() {
		DateUtil.daysBetween("2012-12-12", "2012-12-17");
	}

	@Test
	public void testGetTodayZeroTime() {
		DateUtil.getTodayZeroTime();
	}

	@Test
	public void testGetCalendayBuyDiffHour() {
		DateUtil.getCalendayBuyDiffHour("2012-12-12 45:34:23");
	}

	@Test
	public void testGetDesignationDate() {
		DateUtil.getDesignationDate(date, 1);
	}

	@Test
	public void testCompareDate() {
		DateUtil.compareDate("2012-12-12", "2012-12-13", "yyyy-MM-dd");
	}

	@Test
	public void testCompareWithNow() {
		DateUtil.compareWithNow("2012-12-12", "yyyy-MM-dd");
	}

}
