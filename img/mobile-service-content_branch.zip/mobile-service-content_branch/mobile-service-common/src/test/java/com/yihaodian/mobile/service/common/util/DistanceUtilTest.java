package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class DistanceUtilTest {

	@Test
	public void testDistanceByLBS() {
		DistanceUtil.distanceByLBS(12.1, 1.3, 1.4, 1.45);
	}

	@Test
	public void testMain() {
		DistanceUtil.main(null);
	}

}
