package com.yihaodian.mobile.service.common.business.cache;

import java.util.Properties;

import org.junit.Test;

import com.ibatis.sqlmap.engine.cache.CacheModel;

public class EhCacheControllerTest {
	private EhCacheController ehCacheController = new EhCacheController();
	private CacheModel cacheModel = new CacheModel();
	
	@Test
	public void testFinalize() {
		ehCacheController.finalize();
	}

	@Test
	public void testFlush() {
		ehCacheController.configure(new Properties());
		cacheModel.setId("rock_promotion.cache1");
		ehCacheController.flush(cacheModel);
	}

	@Test
	public void testGetObject() {
		ehCacheController.configure(new Properties());
		//case1
		cacheModel.setId("rock_promotion.cache1");
		ehCacheController.getObject(cacheModel, "key1");
		//case2
		cacheModel.setId("idtest");
		ehCacheController.getObject(cacheModel, "key1");
		//case3
		cacheModel.setId("rock_promotion.cache1");
		ehCacheController.putObject(cacheModel, "key1", "value1");
//		ehCacheController.getObject(cacheModel, "key1");
	}

	@Test
	public void testPutObject() {
		ehCacheController.configure(new Properties());
		cacheModel.setId("rock_promotion.cache1");
		ehCacheController.putObject(cacheModel, "key1", "value1");
	}

	@Test
	public void testRemoveObject() {
		ehCacheController.configure(new Properties());
		cacheModel.setId("rock_promotion.cache1");
		ehCacheController.removeObject(cacheModel, "key1");
	}

	@Test
	public void testConfigure() {
		Properties properties = new Properties();
		//case1
		ehCacheController.configure(properties);
		//case2
		properties.setProperty(EhCacheController.CONFIG_LOCATION, EhCacheController.DEFAULT_CONFIG_LOCATION);
		ehCacheController.configure(properties);
	}

}
