package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;

public class MathUtilTest {
	BigDecimal big1 = new BigDecimal(23);
	BigDecimal big2 = new BigDecimal(2);
	@Test
	public void testRoundDouble() {
		MathUtil.roundDouble(12.3, 2);
	}

	@Test
	public void testAddDay() {
		MathUtil.addDay(new Date(), 3);
	}

	@Test
	public void testSubtract() {
		MathUtil.subtract(big1, big2);
	}

	@Test
	public void testMultiply() {
		MathUtil.multiply(big1, big2);
	}

	@Test
	public void testAdd() {
		MathUtil.add(big1, big2);
	}

	@Test
	public void testGetPercent() {
		MathUtil.getPercent(12.3, 12.4);
	}

	@Test
	public void testFormatDate() {
		MathUtil.format(new Date());
	}

	@Test
	public void testFormatDateString() {
		MathUtil.format(new Date(), "yyyy-mm-dd");
	}

	@Test
	public void testFormatPrice() {
		MathUtil.formatPrice(12.34);
	}

	@Test
	public void testMain() {
		MathUtil.main(null);
	}

}
