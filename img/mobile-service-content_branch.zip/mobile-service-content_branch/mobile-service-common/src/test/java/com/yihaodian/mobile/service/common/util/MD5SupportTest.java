package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class MD5SupportTest {

	@Test
	public void testMD5String() {
		MD5Support.MD5("yihaodian");
	}

	@Test
	public void testMD5StringString() {
		MD5Support.MD5("wuhanyihaodian", "UTF-8");
	}

}
