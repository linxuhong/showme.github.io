package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;

import org.junit.Test;

public class StringUtilTest {

	@Test
	public void testIsNotEmptyString() {
		//case1
		StringUtil.isEmpty(null);
		//case2
		StringUtil.isEmpty("sd");
	}

	@Test
	public void testIsEmpty() {
		StringUtil.isNotEmpty(null);
		StringUtil.isNotEmpty("s");
	}

	@Test
	public void testIsNotEmptyObject() {
		StringUtil.isNotEmpty(null);
		StringUtil.isNotEmpty(1);
	}

	@Test
	public void testClearWidth() {
		StringUtil.clearWidth("a");
		StringUtil.clearWidth(null);
		StringUtil.clearWidth("asdfg");
	}

	@Test
	public void testNotNull() {
		StringUtil.notNull(null);
		StringUtil.notNull("dsf");
	}

	@Test
	public void testSubstring() {
		StringUtil.substring("adad", 1, "ad");
		StringUtil.substring(null, 0, null);
	}

	@Test
	public void testDataCompress() {
		byte [] b = {1,2};
		StringUtil.dataCompress(b);
	}

	@Test
	public void testDataDecompressByteArray() {
		byte [] b = {1,2};
		StringUtil.dataDecompress(b);
	}

	@Test
	public void testDataDecompressInputStreamInt() {
	StringUtil.dataDecompress(new ByteArrayInputStream("d2".getBytes()),2);
	}

	@Test
	public void testGetTimeOutData() {
		StringUtil.getTimeOutData("1");
	}

}
