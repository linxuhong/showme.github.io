package com.yihaodian.mobile.common.ex;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
@RunWith(PowerMockRunner.class)
public class PushDataExceptionTest {

	private PushDataException pushDataException;
	@Test
	public void testPushDataException() {
		pushDataException = new PushDataException();
	}

	@Test
	public void testPushDataExceptionString() {
		pushDataException = new PushDataException("date message");
	}

	@Test
    @PrepareForTest(Throwable.class)
	public void testPushDataExceptionStringThrowable() {
		Throwable cause = PowerMock.createMock(Throwable.class);
		pushDataException = new PushDataException("date message",cause);
	}

	@Test
	@PrepareForTest(Throwable.class)
	public void testPushDataExceptionThrowable() {
		Throwable cause = PowerMock.createMock(Throwable.class);
		pushDataException = new PushDataException(cause);
	}

}
