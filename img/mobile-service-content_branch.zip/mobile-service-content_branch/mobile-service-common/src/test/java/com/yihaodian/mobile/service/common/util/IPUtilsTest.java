package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class IPUtilsTest {

	@Test
	public void testInitFinished() {
		IPUtils.addIpInfo("127.0.0.1");
		IPUtils.addIpInfo("127.0.0.3");
		IPUtils.addIpInfo("192.168.1.*");
		IPUtils.addIpInfo("192.168.*.*");
		IPUtils.addIpInfo("192.167.*.*");
		IPUtils.initFinished();
		IPUtils.main(null);
		System.out.println(IPUtils.findIpInfo("127.0.0.1"));
		System.out.println(IPUtils.findIpInfo("127.0.0.2"));
		System.out.println(IPUtils.findIpInfo("127.0.0.3"));
		System.out.println(IPUtils.findIpInfo("192.168.1.1"));
		System.out.println(IPUtils.findIpInfo("192.168.2.1"));
		System.out.println(IPUtils.findIpInfo("192.167.2.1"));
		System.out.println(IPUtils.findIpInfo("192.166.2.1"));
	}

}
