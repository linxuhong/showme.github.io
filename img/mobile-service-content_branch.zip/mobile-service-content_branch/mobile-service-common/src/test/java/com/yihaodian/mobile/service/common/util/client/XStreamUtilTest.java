package com.yihaodian.mobile.service.common.util.client;

import static org.junit.Assert.*;

import org.junit.Test;

public class XStreamUtilTest {

	@Test
	public void testObjectToXml() {
		XStreamUtil.objectToXml("fff");
	}

/*	@Test
	public void testXmlToObject() {
		String xml = "<?xml version='1.0' encoding='ISO-8859-1'?>"
				+ "<resources><resource><id>0001</id>"
				+ "<lrc><name>0712.lrc</name><size>22538</size></lrc>"
				+ "</resource><resource><id>0002</id>"
				+ "<lrc><name>0906.lrc</name><size>22933</size></lrc>"
				+ "</resource><resources>";
		XStreamUtil.xmlToObject(xml);
	}*/
}
