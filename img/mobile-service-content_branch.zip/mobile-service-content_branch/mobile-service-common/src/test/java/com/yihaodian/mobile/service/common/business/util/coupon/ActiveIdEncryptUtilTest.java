//package com.yihaodian.mobile.service.common.business.util.coupon;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.powermock.api.mockito.PowerMockito;
//import org.powermock.core.classloader.annotations.PrepareForTest;
//import org.powermock.modules.junit4.PowerMockRunner;
//
//import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
//@RunWith(PowerMockRunner.class)
//@PrepareForTest(YccGlobalPropertyConfigurer.class)
//public class ActiveIdEncryptUtilTest {
//	ActiveIdEncryptUtil activeIdEncryptUtil;
//	@Before
//	public void initMocks(){
//		MockitoAnnotations.initMocks(this);
//	}
//	@Test
//	public void testEntryActiveId() {
//		PowerMockito.mockStatic(YccGlobalPropertyConfigurer.class);
//		PowerMockito.when(YccGlobalPropertyConfigurer.getPropertyByKey(Mockito.anyString(), Mockito.anyString())).thenReturn("1");
//		activeIdEncryptUtil = new ActiveIdEncryptUtil();
//		activeIdEncryptUtil.entryActiveId(1l);
//	}
//
//}
