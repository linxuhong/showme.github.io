package com.yihaodian.mobile.service.common.util.encrypt;

import static org.junit.Assert.*;

import org.junit.Test;

public class DESPlusTest {

	@Test
	public void testByteArr2HexStr() {
		try
		{
			byte []b = {1,-2};
			String test = "3267362";
			// DESPlus des = new DESPlus();//默认密钥
			DESPlus des = new DESPlus();// 自定义密钥
			DESPlus des2 = new DESPlus("sd");
			System.out.println( "加密前的字符：" + test );
			System.out.println( "加密后的字符：" + des.encrypt( test ) );
			System.out.println( "解密后的字符：" + des.decrypt( des.encrypt( test ) ) );
			des.main(null);
		}
		catch( Exception e )
		{
			// handle exception
			e.printStackTrace();
		}
	}

}
