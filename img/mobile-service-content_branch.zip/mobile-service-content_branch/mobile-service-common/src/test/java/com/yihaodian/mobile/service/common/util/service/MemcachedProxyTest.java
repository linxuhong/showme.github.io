package com.yihaodian.mobile.service.common.util.service;


import org.junit.Test;
public class MemcachedProxyTest{

	@Test
	public void testGetInstance(){
		 String methodName  = "";
		String traderName = "androidSystem";
		String interfaceVersion = "1.3.2";
		Long provinceId = 1l;
		String date = "2012-03-04 23:23:4";
		Long viewId = 1l;
		MemcachedProxy.createKey(methodName, traderName, interfaceVersion, provinceId, date, viewId);
		String oldkey = "1";
		//case1
		MemcachedProxy.getGoodKey(oldkey);
		//case2
		MemcachedProxy.getGoodKey(" qweq  ");
		//case3
		MemcachedProxy.getGoodKey("3 w sf s s f s d f dd s f s f s d    s s f s f s d    s d f f d s f s f s d   sf  sfs  s df s f   s f sdf  ");
	}

}
