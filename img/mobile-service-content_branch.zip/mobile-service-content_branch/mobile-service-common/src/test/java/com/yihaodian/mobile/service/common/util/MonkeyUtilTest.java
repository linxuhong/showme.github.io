package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.yihaodian.mobile.vo.monkey.MobileCentralMonkeyStore;


public class MonkeyUtilTest {

	@Test
	public void testDistanceByLBS() {
		MonkeyUtil.distanceByLBS(12.1, 1.3, 1.4, 1.5);
	}

	@Test
	public void testGetMonkeyStoreVOListSort() {
		List<MobileCentralMonkeyStore> monkyeStroeList = new ArrayList<MobileCentralMonkeyStore>();;
		MobileCentralMonkeyStore mobileCentralMonkeyStore = new MobileCentralMonkeyStore();
		mobileCentralMonkeyStore.setGearthlatitude(12.3);
		mobileCentralMonkeyStore.setGearthlongitude(12.4);
		mobileCentralMonkeyStore.setGmaplatitude(12.5);
		mobileCentralMonkeyStore.setGmaplongitude(34.5);
		monkyeStroeList.add(mobileCentralMonkeyStore);
		MonkeyUtil.getMonkeyStoreVOListSort(null, 1.3, 1.4);
		
	}

}
