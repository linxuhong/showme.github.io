package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yihaodian.mobile.vo.bussiness.Trader;

public class TraderUtilTest {

	@Test
	public void testTransTrader() {
		Trader trader = new Trader();
		trader.setTraderName("iosSystem");
		TraderUtil.transTrader(null , 1);
		TraderUtil.transTrader(trader , 1);
		trader.setTraderName("androidSystem");
		TraderUtil.transTrader(trader,1);
		TraderUtil.transTraderForIos7(trader);
		trader.setTraderName("23");
		TraderUtil.transTraderForIos7(trader);
	}

}
