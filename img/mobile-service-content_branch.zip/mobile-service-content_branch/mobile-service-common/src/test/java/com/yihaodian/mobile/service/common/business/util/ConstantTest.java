package com.yihaodian.mobile.service.common.business.util;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.yihaodian.front.global.util.UrlPrefix;

public class ConstantTest {

	@Test
	public void testGetDefaultPicURL() {
	 
		String url = Constant.getDefaultPicURL();
	}

}
