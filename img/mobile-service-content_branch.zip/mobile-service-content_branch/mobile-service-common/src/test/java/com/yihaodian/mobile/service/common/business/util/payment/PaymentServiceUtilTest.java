package com.yihaodian.mobile.service.common.business.util.payment;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PaymentServiceUtilTest {
	
	

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testGetPayGatewayById() {
		PaymentServiceUtil.getPayGatewayById(34L);
	}

}
