package com.yihaodian.mobile.service.common.util.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.yihaodian.front.busystock.vo.BSProductVo;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.groupon.GrouponVO;
import com.yihaodian.mobile.vo.home.ViewVO;
import com.yihaodian.mobile.vo.product.ProductVO;

public class UtilsTest {

	@Test
	public void testSubList() {
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(2);
		list.add(2);
		Utils.subList(list, 0, 1);
		
	}

	@Test
	public void testSubPage() {
		Page<String> page = null;
		Utils.subPage(null, 0, 1);
		page = new Page<String>();
		page.setPageSize(4);
		Utils.subPage(page, 0, 1);
	}

	@Test
	public void testGetProductIdListByJsonArray1() {
		JsonArray productIdArray = new JsonArray();
		Map<Long,ProductVO> productVOMap = new HashMap<Long,ProductVO>();
		ProductVO productVO = new ProductVO();
		productVO.setBrandName("d");
		productVOMap.put(1l, productVO);
		Utils.getProductIdListByJsonArray(productIdArray, productVOMap);
	}

	@Test
	public void testTransferLongListFromJsonArray() {
		Utils.transferLongListFromJsonArray(null);
		
	}

	@Test
	public void testGetProductIdListByJsonArrayJsonArrayMapOfLongProductVO() {
		ProductVO productVO = new ProductVO();
		productVO.setBrandName("sdf");
		Trader trader = new Trader();
		trader.setTraderName("sd");
		Integer saleProductLimit = 1;
		BSProductVo bspVo = new BSProductVo();
		bspVo.getPromoteType();	
		Utils.getProductStockNumber(trader, bspVo, productVO, saleProductLimit);
	}

	@Test
	public void testGetProductIdListByJsonArrayJsonArrayMapOfLongProductVOInt() {
		JsonArray productIdArray = new JsonArray ();
		ProductVO productVO = new ProductVO();
		productVO.setEnName("ok");
		Map<Long,ProductVO> productVOMap = new HashMap<Long,ProductVO>();
		productVOMap.put(1l,productVO);
		Utils.getProductIdListByJsonArray(productIdArray, productVOMap, 2);
	}
	@Test
	public void testCalculateDiscount() {
		Utils.calculateDiscount(0, 1);
	}

	@Test
	public void testCalculateSub() {
		Utils.calculateSub(1.3, 1.4);
	}

	@Test
	public void testGetJsonStringAttribute() {
		Utils.getJsonIntegerAttribute(null, null);
		JsonObject obj = new JsonObject();
		obj.addProperty("1", true);
		Utils.getJsonIntegerAttribute(obj, null);
	}

	@Test
	public void testGetJsonIntegerAttribute() {
		Utils.getJsonStringAttribute(null, null);
		JsonObject obj = new JsonObject();
		obj.addProperty("1", true);
		Utils.getJsonStringAttribute(obj, null);
	}

	@Test
	public void testMergeProductVOProductVO() {
		GrouponVO grouponVO = new GrouponVO();
		GrouponVO grouponVO1 = new GrouponVO();
		Utils.merge(grouponVO, grouponVO1);
	}

	@Test
	public void testMergeGrouponVOGrouponVO() {
		ProductVO productVO = new ProductVO();
		ProductVO productVO1 = new ProductVO();
		Utils.merge(productVO, productVO1 );
	}

	@Test
	public void testGetProductStockNumber() {
		int saleProductLimit = 2;
		BSProductVo bspVo = new BSProductVo();
		Trader trader = new Trader();
		ProductVO productVO = new ProductVO();
		Utils.getProductStockNumber(trader, bspVo, productVO, saleProductLimit);
	}

	@Test
	public void testTransVirtualFunctionType() {
		ViewVO viewVo = new ViewVO();
		viewVo.setName("ok");
		Utils.transVirtualFunctionType(viewVo);
	}

}
