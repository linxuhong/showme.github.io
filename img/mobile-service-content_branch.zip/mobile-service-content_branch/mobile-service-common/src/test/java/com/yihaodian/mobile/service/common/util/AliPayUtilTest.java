package com.yihaodian.mobile.service.common.util;

import static org.junit.Assert.*;

import java.io.UnsupportedEncodingException;
import java.security.KeyFactory;
import java.security.spec.PKCS8EncodedKeySpec;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
@RunWith(PowerMockRunner.class)
@PrepareForTest(AliPayUtil.class)
public class AliPayUtilTest {

	@Test
	public void testSign() {
		
	}

	@Test
	public void testResponse() {
		try {
			//case1
			AliPayUtil.response(null, null, null, null, null, null, null, null, null);
			//case2
			AliPayUtil.response(null, null, null, null, null, null, null, null, "test");
			//case3 
			//AliPayUtil.response("1", "seller", null, null, null, null, null, null, "test");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetOrderInfo() {
		AliPayUtil.getOrderInfo("", null, null, null, null, null, null);
	}

	@Test
	public void testGetSignType() {
		AliPayUtil.getSignType();
	}

}
