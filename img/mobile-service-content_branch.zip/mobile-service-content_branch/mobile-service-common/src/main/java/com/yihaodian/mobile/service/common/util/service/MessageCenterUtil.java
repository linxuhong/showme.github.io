package com.yihaodian.mobile.service.common.util.service;

import com.newheight.hessianService.service.messageCenter.MessageCenterNewManager;
import com.newheight.support.EdmServiceContainer;

public class MessageCenterUtil {
	
	public static void updateMessagesISRead(Long userId, Long messageId) {
		MessageCenterNewManager messageCenterNewManager = EdmServiceContainer.getInstance().getService(MessageCenterNewManager.class);
		messageCenterNewManager.updateMessageISRead(userId, messageId);
	}

	public static void deleteSingleMesssage(Long userId, Long messageId) {
		MessageCenterNewManager messageCenterNewManager = EdmServiceContainer.getInstance().getService(MessageCenterNewManager.class);
		messageCenterNewManager.deleteSingleMesssage(userId, messageId);
	}
}
