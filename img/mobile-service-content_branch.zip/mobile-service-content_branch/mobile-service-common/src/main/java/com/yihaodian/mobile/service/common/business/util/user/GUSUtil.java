package com.yihaodian.mobile.service.common.business.util.user;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Maps;
import com.yihaodian.common.util.SpringBeanFactory;
import com.yihaodian.front.user.client.service.EndUserService;
import com.yihaodian.front.user.client.util.UserServiceClient;
import com.yihaodian.front.user.common.enums.McSiteEnum;
import com.yihaodian.front.user.common.model.EndUser;
import com.yihaodian.front.user.common.model.EndUserInfo;
import com.yihaodian.front.user.common.vo.UserServiceResult;

public class GUSUtil {
    private static EndUserService endUserService;
    
    private static Logger logger= LoggerFactory.getLogger(GUSUtil.class);
    
    static{
    	endUserService = UserServiceClient.getEndUserService();
    			/*(EndUserService) SpringBeanFactory.getBean("endUserService")*/;
    }
    
    public static EndUserInfo getUserInfoByGus(Long userId){
    	UserServiceResult<EndUserInfo> userInfoResult = endUserService.getUserInfoById(userId,McSiteEnum.YIHAODIAN);
    	EndUserInfo endUserInfo= userInfoResult.getValueObj();
    	return endUserInfo;
    }
    
    public static EndUser getUserByGus(Long userId){
    	UserServiceResult<EndUser> userResult = endUserService.getUserById(userId,McSiteEnum.YIHAODIAN);
    	EndUser endUser= userResult.getValueObj();
    	return endUser;
    }
    
    public static EndUser getUserByGus(Long userId, McSiteEnum site) {
    	UserServiceResult<EndUser> userResult = endUserService.getUserById(userId, site);
    	EndUser endUser= userResult.getValueObj();
    	return endUser;
    }
    

    public static EndUser getMyyhdUserById(Long userId) {
    	UserServiceResult<EndUser> result = endUserService.getUserWithUserInfoById(userId, McSiteEnum.YIHAODIAN);
    	if(result!=null&&result.getCode().equals(UserServiceResult.SUCCESS)){
    		EndUser user = result.getValueObj();
    		if (user != null && user.getEndUserInfo() != null && user.getEndUserInfo().getEndUserPrePic() != null) {
    			user.setEndUserPic(user.getEndUserInfo().getEndUserPrePic());
    		}
    		return result.getValueObj();
    	}
    	return null;
    }

    public static Map<Long, EndUser> getMyyhdUserByIds(List<Long> userIds) {
    	Map<Long, EndUser> result = Maps.newHashMap();
    	UserServiceResult<List<EndUser>> userResult = endUserService.getUsersWithUserInfoByIds(userIds, McSiteEnum.YIHAODIAN);
    	if(userResult!=null&&userResult.getCode().equals(UserServiceResult.SUCCESS)){
    		if (userResult.getValueObj() != null) {
    			for (EndUser user : userResult.getValueObj()) {
    				if (user != null) {
	    				if (user.getEndUserInfo() != null && user.getEndUserInfo().getEndUserPrePic() != null) {
	    					user.setEndUserPic(user.getEndUserInfo().getEndUserPrePic());
	    				}
	    				result.put(user.getId(), user);
    				}
    			}
    		}
    	}
    	return result;
    }

    public static Integer getUserCountByNameOrEmailOrValidPhone(String phoneNumber){
    	UserServiceResult<Integer> getUserCountByNameOrEmailOrValidPhoneResult = endUserService.getUserCountByNameOrEmailOrValidPhone(phoneNumber, McSiteEnum.YIHAODIAN);
    	return getUserCountByNameOrEmailOrValidPhoneResult.getValueObj();
    }
    
    /**
     * 批量查询用户信息
     * @param userIdList
     * @return
     */
    public static Map<Long,EndUser> getUserList(List<Long> userIdList){
    	try {
    		UserServiceResult<List<EndUser>> userResult= endUserService.getUsersByIds(userIdList,McSiteEnum.YIHAODIAN);
    		if(userResult!=null&&userResult.getCode().equals(UserServiceResult.SUCCESS)){
    			return endUserListToMap(userResult.getValueObj());
    		}
			
		} catch (Exception e) {
			logger.error("getUserList has error ", e);
		}
    	return null;
    }
    
    private static  Map<Long,EndUser>  endUserListToMap(List<EndUser> endUserList){
    	Map<Long,EndUser> map = new HashMap<Long, EndUser>();
    	if(endUserList!=null&&endUserList.size()>0){
    		for(EndUser endUser : endUserList){
    			map.put(endUser.getId(), endUser);
    		}
    		return map;
    	}
    	return null;
    }
    
    public static String getUserGUIDById(Long userId){
        try {
            UserServiceResult<String> userResult = endUserService.getUserGUIDById(userId);
            if(userResult!=null&&userResult.getCode().equals(UserServiceResult.SUCCESS)){
                String guid = userResult.getValueObj();
                return guid;
            }
        } catch (Exception e) {
            logger.error("getUserGUIDById has error ", e);
        }
        return null;
    }
    
    public static EndUser getSamUserById(Long userId){
        UserServiceResult<EndUser> userResult = endUserService.getUserById(userId,McSiteEnum.SAMCLUB);
        EndUser endUser= userResult.getValueObj();
        return endUser;
    }
    
    
}
