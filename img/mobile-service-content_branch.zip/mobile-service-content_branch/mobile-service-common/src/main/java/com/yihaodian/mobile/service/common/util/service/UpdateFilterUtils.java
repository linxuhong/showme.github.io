package com.yihaodian.mobile.service.common.util.service;

import java.util.ArrayList;
import java.util.List;

import com.yihaodian.mobile.service.common.util.MobileCommonUtil;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.constant.CommonKey;


/**  
 * @ClassName: UpdateFilterUtils 
 * @Desc: 作为拦截升级接口的控制工具
 * @author guoyang
 * @date 2013-5-4 上午11:56:31
 * @version V1.0  
 */
public class UpdateFilterUtils {

	static List<String> methods = new ArrayList<String>();
	static{
		methods.add("getCashPromotionList");
		methods.add("getPromotionGiftList");
//		methods.add("getRedemptionList");
		methods.add("delProduct");
		methods.add("addProduct");
//		methods.add("updateCartItemQuantity");
//		methods.add("addPromotionProduct");
		methods.add("delPromotionProduct");
		methods.add("updatePromotionProductQuantity");
		methods.add("addProductV2");
		methods.add("addPromotionProductV2");
		methods.add("updateCartItemQuantityV2");
		methods.add("updatePromotionProductQuantityV2");
		methods.add("updateGiftProducts");
		methods.add("updateCartPromotion");
		methods.add("delProducts");
//		methods.add("addOptional");
//		methods.add("deleteOptional");
//		methods.add("isExistOptionalInCart");
		methods.add("updateOptional");
	}
	
	/** 提示消息 */
	static String getMessage(){
		return "expired interface,please update to the new’s。旧接口暂不支持，请升级到新接口";
	}
	
	/** 提示消息 */
	static String getTempMessage(){
		return getMessage();
//		return "for the time being, nonsupport versions lower than 1.2.4。版本升级阶段，低于1.2.4的版本暂不支持测试";
	}
	
	
	/**
	 * @Title: filte
	 * @author guoyang
	 * @Description: 
	 * @date 2013-5-4
	 */
	public static void filte(String token) {
//		if(compareVersion(token)){
//			throw new CentralMobileRuntimeException(getMessage());
//		}else{
//			throw new CentralMobileRuntimeException(getTempMessage());
//		}
	}
	
	/*private static boolean compareVersion(String token){
		MemcachedProxy me = MemcachedProxy.getInstance();
		Trader trader = MobileCommonUtil.getTrader(me, token);
		return VersionUtil.compare(CommonKey.INTERFACE_VERSION_1_2_5, trader.getInterfaceVersion()) >= 0;
	}*/

	/**
	 * @Title: filter
	 * @author guoyang
	 * @Description: 
	 * @date 2013-5-4
	 * @param object
	 * @param methodName
	 */
	public static void filte(Object token, String methodName) {
//		if(methods.contains(methodName)){
//			if(token.getClass().equals(String.class)){
//				filte((String)token);
//			}
//		}
	}
}
