package com.yihaodian.mobile.service.common.util;


public interface ActionConstants {
    String ORDER_UNSATISFIEDPRODUCT_KEY = "session.unsatisfiedProdcts";
    String ORDER_UNSATISFIEDPRODUCT_STOCK_KEY = "session.unsatisfiedProdctStock";
    String POSITIONLIST_SESSION_KEY = "session.positionList";
    String ORDER_SESSION_KEY = "session.order";
    String USER_SESSION_KEY = "session.user";
    String PRODUCT_SUPPLIER_LIST = "session.supplierList";
    String CART_INFO_COOKIE_KEY = "cart_info";
    String CART_NUM_COOKIE_KEY = "cart_num";
    String CART_UUID_COOKIE_KEY = "cart_cookie_uuid";
    String SHOPPING_CART_KEY = "session.shoppingCart";    
    String INDEX_USER_INFO_SESSION_KEY = "session.indexUserInfo";
    String CATEGORY_MENU_KEY = "menuCategory";
    String LEFT_FLOAT_MENU_DATA_KEY = "leftFloatMenuData";//网站左边浮动菜单数据key add by hikin yao 2010-10-29 
    String HOT_KEYWORDS_KEY = "hotKeywords";
    String PARAMETER_SEPARATOR = ":||:";
    String ENCODING_UTF_8 = "UTF-8";
    String LATEST_ORDER = "lastest_order";
    String USER_REBATE = "user_rebate";
    String GIFT_MAPPER = "giftMapper";
    String GIFT_MAPPER_KEY = "giftMapperKey";
    String GIFT_MAPPER_BLANCE = "giftMapperBlance";
    int STOCK_STATUS_NO_STOCK = 1;
    int STOCK_STATUS_NOT_ENOUGH = 2;
    long ACTIVITY_DAILY_PRODUCT_ID = -1;//每日一款
    long ACTIVITY_TIANYA_GIFT_ID = -5;//天涯
    long ACTIVITY_ID_SINA_ACTIVITY = -6;//新浪
    long ACTIVITY_ID_INVITE_GIFT = -2;
    long ACTIVITY_PINGAN_WEEKLY_PRODUCT_ID = -10;//平安每周一款
    long ACTIVITY_ID_NIGHT_MARKET = -15;//夜市
    long ACTIVITY_ID_TENCENT_SPECIAL_PRODUCT = -16;//QQ一元疯抢
    long ACTIVITY_ID_SERVICE_CHANNEL_GIFT = -17;//服务频道免费赠品
    long ACTIVITY_ID_SECKILL_ACTIVITY = -18; //秒杀
    long ACTIVITY_EPP_ACTIVITY = -55;//epp
    String KEY_USER_PRESENT_ID = "userPresentID";
    long DELIVERY_METHOD_SUPPORT_ALL = 0L;
    String DAILY_SPECIAL_KEY = "dspObject";
    String SECKILL_SPECIAL_KEY = "secKillObject";
    String SECKILLResult_SPECIAL_KEY = "seckillResultObject";
    String NEW_USER_FLAG_KEY = "rule_engine_new_user_";
    int ORDER_LOCKED=9;//编辑订单 锁定状态
    final static String IS_COD_SHOW = "isCodShow";
    // 用户购物车key
    static String USER_CART_KEY = "user.cart";
    // 用户购物车，是否需要加载cookie中商品key，NRFC（needRestoreFromCookie）
    static String USER_CART_NRFC_KEY = "user.cart.NRFC";
    // 用户购物车，是否需要加载cookie中商品key，NRFC（needRestoreFromCookie）
    static String NRFC_NO_NEED = "no_need";
    //session购物车key
    static String SESSION_CART_KEY ="session.cart";
    // 生成order时的购物车key
    static String ORDER_CART_KEY = "order.cart";
    // 敏感产品检查结果
    static String ORDER_SENSITIVE_CHECK_RESULT_KEY = "order.scResult";
    // order的用户前次选择的配送发送key
    static String ORDER_DELIVERY_KEY = "order.delivery";

    final static String VALID_CODE_VALUE_OF_SESSION = "validvalidCodeValueOfSession";
    final static String VALID_CODE_VALUE_OF_PAGE = "validvalidCodeValueOfPage";
    final static String VALID_CODE_CACHE_KEY = "valid_code_cache_key";
    
    String IPHONE4_CONTRACT_PRODUCT_CART = "session.iphone4ContractProductCart" ; //iphone4合约机套餐
}
