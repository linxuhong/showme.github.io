package com.yihaodian.mobile.service.common.util;

import java.io.File;
import java.io.FileNotFoundException;


import net.glxn.qrgen.QRCode;
import net.glxn.qrgen.image.ImageType;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.yihaodian.mobile.service.common.util.encrypt.DESPlus;
import com.yihaodian.mobile.service.domain.util.WebsiteUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class QRUtil.
 */
public class QRUtil {
	
	/**
	 * Process single product qr code.
	 *
	 * @param productId the product id
	 * @param promotionId the promotion id
	 * @param merchantId the merchant id
	 * @param width the width
	 * @param height the height
	 * @return the string
	 */
	public static String processSingleProductQRCode(long productId,long promotionId,long merchantId,int width,int height){
		String url="";
		String fileName="singleProduct";
		width=250;
		height=250;
		return uploadFile(fileName,generateQRImageFile(url,width,height));
	}
	
	/**
	 * 生成CMS活动二维码图片.
	 *
	 * @param cmsId the cms id
	 * @param width the width
	 * @param height the height
	 * @return 服务器二维码图片的url
	 */
	public static String processCMSActivityQRCode(long cmsId,int width,int height){
		StringBuffer sb=new StringBuffer();
		if(cmsId>0){
			sb.append(WebsiteUtil.getWebsiteUrl());
			sb.append("/mw/product/").append(cmsId).append("/1/");
		}else {
			sb.append(WebsiteUtil.getWebsiteUrl());
			sb.append("/");
		}
		//生成临时文件
		File file=generateQRImageFile(sb.toString(),width,height);
		String result=uploadFile(file.getAbsolutePath(),file);
		//删除临时文件
		if(file.exists()){			
			file.delete();
		}
		return result;
	}
	
	/**
	 * 生成促销搜索活动的二维码图片.
	 *
	 * @param productId the product id
	 * @param level the level
	 * @param langdingpageId the langdingpage id
	 * @param width the width
	 * @param height the height
	 * @return 服务器二维码图片的url
	 */
	public static String processPromotionQRCode(long productId,long level,long langdingpageId,int width,int height){
		StringBuffer sb=new StringBuffer();
		if(productId>0){
			sb.append(WebsiteUtil.getWebsiteUrl());
			sb.append("/mw/product/").append(productId).append("/1/").append(langdingpageId).append("_0_langdingpage");
		}else {
			sb.append(WebsiteUtil.getWebsiteUrl());
			sb.append("/");
		}
		//生成临时文件
		File file=generateQRImageFile(sb.toString(),width,height);
		String result=uploadFile(file.getAbsolutePath(),file);
		//删除临时文件
		if(file.exists()){			
			file.delete();
		}
		return result;
	}
	
	/**
	 * 生成抵购劵二维码图片.
	 *
	 * @param couponId the coupon id
	 * @param width the width
	 * @param height the height
	 * @return 服务器二维码图片的url
	 */
	public static String processCouponQRCode(long couponId,int width,int height){
		StringBuffer sb=new StringBuffer();
		if(couponId>0){
			sb.append(WebsiteUtil.getWebsiteUrl());
			sb.append("/mw/embed/").append(9).append("/").append(couponId);
		}else {
			sb.append(WebsiteUtil.getWebsiteUrl());
			sb.append("/");
		}
		//生成临时文件
		File file=generateQRImageFile(sb.toString(),width,height);
		String result=uploadFile(file.getAbsolutePath(),file);
		//删除临时文件
		if(file.exists()){			
			file.delete();
		}
		return result;
	}

	/**
	 * 公用接口生成二维码.
	 *
	 * @param param1 the param1
	 * @param param2 the param2
	 * @param type the type
	 * @param width the width
	 * @param height the height
	 * @return 服务器二维码图片的url
	 */
	public static String commonQRCodeGenerate(long param1,long param2,int type,int width,int height){
        StringBuffer sb=new StringBuffer();
		switch(type){
			case 1:
				sb.append(WebsiteUtil.getWebsiteUrl());
				sb.append("/mw/product/").append(param1).append("/1/").append(param2).append("_0_langdingpage");
				break;
			case 2:
				sb.append(WebsiteUtil.get1mallUrl());
				sb.append("/mw/product/").append(param1).append("/1/").append(param2).append("_0_langdingpage");
				break;
			case 3:
				sb.append(WebsiteUtil.get1mallUrl());
				sb.append("/mw/groupdetail/").append(param1).append("/").append(param2);
				break;
			case 4:
				sb.append(WebsiteUtil.getWebsiteUrl());
				sb.append("/mw/groupdetail/").append(param1).append("/").append(param2);
				break;
			case 5:
				sb.append(WebsiteUtil.getWebsiteUrl());
				sb.append("/mw/embed/").append(param1).append("/").append(param2);
				break;
			case 6:
			case 7:
				sb.append(WebsiteUtil.getWebsiteUrl());
				sb.append("/mw/promotionprolist/").append(param1).append("/").append(param2).append("/1/1");
				break;
			case 8:
				sb.append(WebsiteUtil.getWebsiteUrl());
				sb.append("/mw/optionalprolist/").append(param1).append("/").append(param2).append("/1");
				break;
			case 9:
				sb.append(WebsiteUtil.getWebsiteUrl());
				sb.append("/mw/product/").append(param1).append("/1/");
				break;
			case 10:
                sb.append(WebsiteUtil.getWebsiteUrl());
                sb.append("/mw/store/").append(param1).append("/").append(param2).append("?tracker_u=").append(WebsiteUtil.getUnionKey());
                break;
			default:
		}
		//生成临时文件
		File file=generateQRImageFile(sb.toString(),width,height);
		String result=uploadFile(file.getAbsolutePath(),file);
		//删除临时文件
		if(file.exists()){			
			file.delete();
		}
		return result;
	}
	
	/**
	 * 根据入参文本内容，生成二维码.
	 *
	 * @param sourceContent 二维码内容（如：http://...）
	 * @param width 二维码宽带
	 * @param height 二维码高度
	 * @return the QR by source content
	 */
	public static String getQRBySourceContent(String sourceContent, Integer width, Integer height){
		if(width == null || width == 0){
			width = 250;
		}
		
		if(height == null || height == 0){
			height = 250;
		}
		
		File file=generateQRImageFile(sourceContent, width, height);
		String result=uploadFile(file.getAbsolutePath(),file);
		//删除临时文件
		if(file.exists()){			
			file.delete();
		}
		return result;
	}
	
	/**
	 * Generate qr image file.
	 *
	 * @param url the url
	 * @param width the width
	 * @param height the height
	 * @return the file
	 */
	public static File generateQRImageFile(String url,int width,int height) {
		return QRCode.from(url).withSize(width, height).to(ImageType.PNG).file();
	}

	/**
	 * Upload file.
	 *
	 * @param name the name
	 * @param file the file
	 * @return the string
	 */
	public static String uploadFile(String name, File file) {
		String result = "";
		int creatorId = 1;
		DESPlus jsonKey = null;
		DESPlus defaultKey = null;
		JSONObject jo = new JSONObject();
		String returnurl = "";
		// post
		String postUrl = "http://upload.yihaodian.com/upload/UploadAction";
		HttpClient client = new HttpClient();
		// 设置相关参数
		client.getHttpConnectionManager().getParams().setConnectionTimeout(
				20000);
		client.getHttpConnectionManager().getParams().setSoTimeout(20000);

		PostMethod method = null;
		try {
			jsonKey = new DESPlus(String.valueOf(creatorId));
			defaultKey = new DESPlus();
			JSONArray ja = new JSONArray();

			JSONObject jo1 = new JSONObject();
			jo1.put("action", "upload");

			jo1.put("name", name);
			jo1.put("creator_id", "9527");
			jo1.put("resource_type", "3");
			jo1.put("resource_id", "9527");
			jo1.put("pic_type", "4");
			jo1.put("mc_site_id", "1");
			jo1.put("auth_server", "backend");
			jo1.put("session", "21169fgjsdsdahf@!@#$7479L");

			JSONArray jb = new JSONArray();
			JSONObject job1 = new JSONObject();
			job1.put("img_scale", "99");
			job1.put("img_wm", "0");

			JSONObject job2 = new JSONObject();
			job2.put("img_scale", "0");
			job2.put("img_wm", "0");
			jb.put(job1);
			jb.put(job2);

			jo1.put("img_series", jb);

			ja.put(jo1);

			jo.put("items", ja);
			// 提交url
			String joString = java.net.URLEncoder
					.encode(jo.toString(), "UTF-8");
			method = new PostMethod(postUrl);
			Part[] parts = {
					new StringPart("upload_request", jsonKey.encrypt(joString)),
					new StringPart("creator_id", defaultKey.encrypt(String
							.valueOf(creatorId))), new FilePart(name, file) };
			method.setRequestEntity(new MultipartRequestEntity(parts, method
					.getParams()));

			int statusCode = client.executeMethod(method);
			if (HttpStatus.SC_OK == statusCode) {// sc_ok=200
				String returnInfo = method.getResponseBodyAsString();
				if (returnInfo != null && !returnInfo.equalsIgnoreCase("")) {
					JSONObject rjo = new JSONObject(returnInfo);
					JSONArray items = rjo.getJSONArray("upload_response");
					for (int i = 0; i < items.length(); i++) {
						JSONObject to = (JSONObject) items.get(i);
						result = to.getString("result");
						if ("success".equals(result)) {
							if (!to.has("details")) {
								if (to.has("backup_url")) {
									System.out.println(to
											.getString("backup_url"));
									returnurl = to.getString("backup_url");
								}
							} else {
								JSONArray details = to.getJSONArray("details");
								for (int j = 0; j < details.length(); j++) {
									JSONObject detail = (JSONObject) details
											.get(j);
									System.out.println(detail.getString("url"));
									returnurl = detail.getString("url");
								}
							}
						} else {
							if (result.startsWith("error-")) {
								System.out.println(result);
							}
							break;
						}
					}
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (method != null) {
				method.releaseConnection();
			}
		}

		return returnurl;
	}
}
