package com.yihaodian.mobile.service.common.util;

import java.util.List;
import com.yihaodian.front.sso.common.vo.SsoUser;
import com.yihaodian.mobile.vo.bussiness.Trader;

// TODO: Auto-generated Javadoc
/**
 * 主要用于减少对Memcached Server缓存服务器的访问次数.
 *
 * @author oumingzhi
 * @date 20121206
 */
public class ThreadLocalUtil {

	/** The user thread local. */
	private static ThreadLocal<SsoUser> userThreadLocal = new ThreadLocal<SsoUser>();
	
	/** The trader thread local. */
	private static ThreadLocal<Trader> traderThreadLocal = new ThreadLocal<Trader>();
	
	//促销等级开关与对象值
	/** The cart promotion level vo list flag thread local. */
	private static ThreadLocal<Boolean> cartPromotionLevelVOListFlagThreadLocal = new ThreadLocal<Boolean>();
	
	
    /**
     * Sets the user.
     *
     * @param user the new user
     */
    public  static void setUser(SsoUser user){
    	userThreadLocal.set(user);
    }
    
    /**
     * Gets the user.
     *
     * @return the user
     */
    public  static SsoUser getUser(){
    	return userThreadLocal.get();
    }
    
    /**
     * Removes the user.
     */
    public  static void removeUser(){
    	userThreadLocal.remove();
    }
    
    /**
     * Sets the trader.
     *
     * @param trader the new trader
     */
    public  static void setTrader(Trader trader){
    	traderThreadLocal.set(trader);
    }
    
    /**
     * Gets the trader.
     *
     * @return the trader
     */
    public  static Trader getTrader(){
    	return traderThreadLocal.get();
    }

    /**
     * Removes the trader.
     */
    public  static void removeTrader(){
    	traderThreadLocal.remove();
    }
    
    /**
     * Sets the promotion level vo list flag.
     *
     * @param value the new promotion level vo list flag
     */
    public  static void setPromotionLevelVoListFlag(Boolean value){
    	cartPromotionLevelVOListFlagThreadLocal.set(value);
    }
    
    /**
     * Gets the promotion level vo list flag.
     *
     * @return the promotion level vo list flag
     */
    public  static Boolean getPromotionLevelVoListFlag(){
    	return cartPromotionLevelVOListFlagThreadLocal.get();
    }

    /**
     * Removes the promotion level vo list flag.
     */
    public  static void removePromotionLevelVoListFlag(){
    	cartPromotionLevelVOListFlagThreadLocal.remove();
    }
}
