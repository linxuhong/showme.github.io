package com.yihaodian.mobile.service.common.util.service;

public class VersionUtil {
	
	/**
	 *  比较版本号<br/>
	 * if versionSrc &lt versionDest return 1 <br/>
	 * if versionSrc = versionDest return 0 <br/>
	 * if versionSrc &gt versionDest return -1
	 * 
	 * @param versionSrc 原版本号
	 * @param versionDest 目标版本号
	 */
	public static int compare(String versionSrc,String versionDest)
	{
		if(versionSrc == null && versionDest ==null){
			return 0;
		}else if(versionSrc == null){
			return 1;
		}else if(versionDest == null){
			return -1;
		}
		
		String [] src = versionSrc.split("\\.");
		String [] dest = versionDest.split("\\.");
		for(int i=0;i<src.length;i++)
		{
			if(i == dest.length)
				return -1;
			try{
				int s = Integer.parseInt(src[i]);
				int d = Integer.parseInt(dest[i]);
				if(d > s)
					return 1;
				if(d < s)
					return -1;
			}catch(Exception e)
			{
				return 0;
			}
		}
		if(src.length == dest.length)
			return 0;
		return 1;
	}
	
	 /**
     *  比较版本号<br/>
     * if versionSrc &lt versionDest return true <br/>
     * 
     * @param versionSrc 原版本号
     * @param versionDest 目标版本号
     */
	public static boolean before(String versionSrc, String versionDest) {
	    return compare(versionSrc, versionDest) == 1;
	}

    /**
    *  比较版本号<br/>
    * if versionSrc &gt versionDest return true <br/>
    * 
    * @param versionSrc 原版本号
    * @param versionDest 目标版本号
    */	
    public static boolean after(String versionSrc, String versionDest) {
        return compare(versionSrc, versionDest) == -1;
    }
    
    /**
    *  比较版本号<br/>
    * if versionSrc == versionDest return true <br/>
    * 
    * @param versionSrc 原版本号
    * @param versionDest 目标版本号
    */    
    public static boolean equals(String versionSrc, String versionDest) {
        return compare(versionSrc, versionDest) == 0;
    }
}
