package com.yihaodian.mobile.service.common.business.custom;


import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;


public class MobileDynmicDataSource extends AbstractRoutingDataSource {
    private static final Logger logger = Logger.getLogger(MobileDynmicDataSource.class);
    @Override
    protected Object determineCurrentLookupKey() {
        
        logger.debug("dbtype="+MobileDbContextHolder.getDbType());
        
        return MobileDbContextHolder.getDbType();
        
    }

    
    public static void main(String[] args) {
       Date date = new Date(1397468460078L);
       System.out.println(date);
    }
    
}
