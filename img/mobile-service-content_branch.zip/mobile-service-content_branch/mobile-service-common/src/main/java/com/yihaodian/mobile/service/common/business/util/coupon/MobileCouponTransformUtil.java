package com.yihaodian.mobile.service.common.business.util.coupon;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.mobile.service.common.business.util.promotion.PromotionCouponUtil;
import com.yihaodian.mobile.service.domain.vo.business.coupon.MobileCouponDO;
import com.yihaodian.promotion.coupon.outputVo.CouponActivityOutputVo;

/**
 * 掌上抵用券转换类
 * @author zhangwei5
 * @version $Id: MobileCouponTransformUtil.java, v 0.1 2014年7月30日 下午1:40:54 zhangwei5 Exp $
 */
public class MobileCouponTransformUtil {

    private static Logger logger = LoggerFactory.getLogger(MobileCouponTransformUtil.class);
    
    /**
     * 爱分享实体转换为mobileCouponDo
     * @param shareCouponVo
     * @param mobileCouponDO
     */
    public static void couponActivityOutputVoToMobileCouponDO(CouponActivityOutputVo activityCouponVo,MobileCouponDO mobileCouponDO){
        try {
            //抵用券活动ID
            mobileCouponDO.setCouponActiveId(activityCouponVo.getActiveId());
            //面额
            mobileCouponDO.setCouponAmount(activityCouponVo.getDeductAmount().doubleValue());
            //描述
            mobileCouponDO.setDescription(PromotionCouponUtil.getCouponActivityDesc(activityCouponVo));
            //规则
            mobileCouponDO.setRuleDescription(PromotionCouponUtil.composeCouponUseExplain(activityCouponVo));
            //名称
            mobileCouponDO.setTitle(activityCouponVo.getActiveName());
        } catch (Exception e) {
            logger.error("shareCouponVoToMobileCouponDO has error ", e);
        }
    }
}
