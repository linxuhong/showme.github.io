package com.yihaodian.mobile.service.common.business.util.payment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.common.util.SpringBeanFactory;
import com.yihaodian.payment.onlinepayment.model.PayGateway;
import com.yihaodian.payment.onlinepayment.service.PayGatewayService;

/**
 * 支付网关服务
 * @author zhangwei5
 *
 */
public class PaymentServiceUtil {

	/**
	 * 根据网关Id查询网关信息
	 * @param gateWayId
	 * @return
	 */
	public static PayGateway getPayGatewayById(Long gateWayId){
		return null;
	}

}
