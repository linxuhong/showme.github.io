package com.yihaodian.mobile.service.common.util;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;

public class YihaodianDataSource extends BasicDataSource {
	private static Logger logger = Logger.getLogger(YihaodianDataSource.class);

	@Override
	public Connection getConnection() throws SQLException {
		Connection conn = super.getConnection();
		System.out.println(conn);
		if (conn.toString().indexOf("UserName=PURCHASE") != -1) {
			System.out.println(conn);
			throw new SQLException("use Purchase Ds ERROR!");
		}
		return conn;
	}

	@Override
	public Connection getConnection(String user, String pass)
			throws SQLException {
		Connection conn = super.getConnection(user, pass);
		System.out.println(conn);
		if (conn.toString().indexOf("UserName=PURCHASE") != -1) {
			System.out.println(conn);
			throw new SQLException("use Purchase Ds ERROR!");
		}
		return conn;
	}
}
