package com.yihaodian.mobile.service.common.util.service;

import java.util.Calendar;
import java.util.Date;

import com.yihaodian.mobile.service.common.util.MobileCommonUtil;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.constant.CommonKey;


/**  
 * @ClassName: TimeFixUtils 
 * @Desc: 修正时间工具类
 * @author guoyang
 * @date 2013-5-17 上午10:46:54
 * @version V1.0  
 */
public class TimeFixUtils {
	
	/**
	 * @Title: fixTime
	 * @author guoyang
	 * @Description: 修改正时间 
	 * 版本小于 1.2.5				
	 * ANDOID加14小时，IOS 加8小时
	 * @date 2013-5-17
	 * @param trader
	 * @param time
	 * @return
	 */
	public static Date fixTime(Trader trader,Date time){
		return fixTime(trader, time, CommonKey.YI_HAODIAN_SITE_TYPE);
	}
	
	/**
	 * @Title: fixTime
	 * @author guoyang
	 * @Description: 修改正时间 
	 * 版本小于 1.2.5				
	 * ANDOID加14小时，IOS 加8小时
	 * @date 2013-5-17
	 * @param trader
	 * @param time
	 * @return
	 */
	public static Date fixTime(Trader trader,Date time, Integer siteType){
		//商城不处理
		if(trader == null || siteType ==2 ){
			return time;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);
		// 版本 小于 1.2.4
		if(VersionUtil.compare(CommonKey.INTERFACE_VERSION_1_2_4, trader.getInterfaceVersion()) < 0
				&& CommonKey.TRADER_NAME_ANDROID.equalsIgnoreCase(trader.getTraderName())){
			// android 加14小时
			calendar.add(Calendar.HOUR_OF_DAY, 14);
		}else if(VersionUtil.compare(CommonKey.INTERFACE_VERSION_1_2_5, trader.getInterfaceVersion()) < 0 
				&& (CommonKey.TRADER_NAME_IPHONE.equalsIgnoreCase(trader.getTraderName())
				     || CommonKey.TRADER_NAME_IPAD.equalsIgnoreCase(trader.getTraderName()))){
			// IOS 加 8小时
			calendar.add(Calendar.HOUR_OF_DAY, 8);
		}
		return calendar.getTime();
	}

	public static Date fixGrouponTime(Trader trader,Date time){
        if (trader == null) {
            return time;
        }
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);
		// 版本 小于 1.2.4
		if(VersionUtil.compare(CommonKey.INTERFACE_VERSION_1_2_4, trader.getInterfaceVersion()) < 0
				&& CommonKey.TRADER_NAME_ANDROID.equalsIgnoreCase(trader.getTraderName())){
			// android 加14小时
			calendar.add(Calendar.HOUR_OF_DAY, 14);
		}else if(VersionUtil.compare(CommonKey.INTERFACE_VERSION_1_2_5, trader.getInterfaceVersion()) < 0 
				&& (CommonKey.TRADER_NAME_IPHONE.equalsIgnoreCase(trader.getTraderName())
				     || CommonKey.TRADER_NAME_IPAD.equalsIgnoreCase(trader.getTraderName()))){
			// IOS 加 8小时
			calendar.add(Calendar.HOUR_OF_DAY, 8);
		}else if(trader.getClientAppVersion() !=null && VersionUtil.compare("2.3.8", trader.getClientAppVersion()) == 0 
				&& VersionUtil.compare(CommonKey.INTERFACE_VERSION_1_2_5, trader.getInterfaceVersion()) == 0 
				&& CommonKey.TRADER_NAME_IPHONE.equalsIgnoreCase(trader.getTraderName())){
			// IOS 加 8小时
			calendar.add(Calendar.HOUR_OF_DAY, 8);
		}
		return calendar.getTime();
	}
	
	/**
	 * @Title: fixTime
	 * @author guoyang
	 * @Description: 修改正时间 
	 * 版本小于 1.2.5				
	 * ANDOID加14小时，IOS 加8小时
	 * @date 2013-5-17
	 * @param token
	 * @param createTime
	 * @return
	 */
	public static Date fixTime(String token, Date time) {
		Trader trader = null;
		if(token!=null){
			trader = MobileCommonUtil.getTrader(token);
		}
		return fixTime(trader, time);
	}
	
	public static Date fixGrouponTime(String token, Date time) {
		Trader trader = null;
		if(token!=null){
			trader = MobileCommonUtil.getTrader(token);
		}
		return fixGrouponTime(trader, time);
	}
}
