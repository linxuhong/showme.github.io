package com.yihaodian.mobile.service.common.business.util.product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.yhd.pss.spi.baseinfo.service.QueryProductRemoteService;
import com.yhd.pss.spi.baseinfo.vo.ProductBaseVo;
import com.yhd.pss.spi.baseinfo.vo.ProductCategoryMcSiteVo;
import com.yhd.pss.spi.baseinfo.vo.ProductPicVo;
import com.yhd.pss.spi.baseinfo.vo.ProductVo;
import com.yhd.pss.spi.baseinfo.vo.input.ProductCodesRequest;
import com.yhd.pss.spi.baseinfo.vo.input.QueryBaseProductWithProductPicByProdIdsRequest;
import com.yhd.pss.spi.baseinfo.vo.input.QueryProductByIdRequest;
import com.yhd.pss.spi.baseinfo.vo.input.QueryProductByIdsRequest;
import com.yhd.pss.spi.baseinfo.vo.input.QueryProductPicByIdRequest;
import com.yhd.pss.spi.baseinfo.vo.input.QueryProductRequest;
import com.yhd.pss.spi.common.vo.HandleResult;
import com.yhd.pss.spi.common.vo.Response;
import com.yhd.pss.spi.map.vo.CoordinateInfoVo;
import com.yhd.pss.spi.map.vo.MapBlock;
import com.yhd.pss.spi.map.vo.input.QueryAddressResolveRequest;
import com.yhd.pss.spi.merchant.o2o.input.QueryAddressListByKeyWordRequest;
import com.yhd.pss.spi.merchant.o2o.vo.AddressListVo;
import com.yhd.pss.spi.merchant.service.QueryMerchantMapConfigRemoteService;
import com.yhd.pss.spi.merchant.service.QueryMerchantRemoteService;
import com.yhd.pss.spi.merchant.vo.FullFieldsMerchant;
import com.yhd.pss.spi.merchant.vo.Merchant;
import com.yhd.pss.spi.merchant.vo.MerchantIdAndNameAndStoreStatusVo;
import com.yhd.pss.spi.merchant.vo.input.QueryBaseMerchantByIdRequest;
import com.yhd.pss.spi.merchant.vo.input.QueryByPagingCoordinatesRequest;
import com.yhd.pss.spi.merchant.vo.input.QueryByPagingMerchantIdAndCoordinatesAndCellIdRequest;
import com.yhd.pss.spi.merchant.vo.input.QueryMerchantByIdRequest;
import com.yhd.pss.spi.o2o.vo.CoordinatesVo;
import com.yhd.pss.spi.pminfo.service.QueryPmInfoRemoteService;
import com.yhd.pss.spi.pminfo.service.QueryRecommendProductRemoteService;
import com.yhd.pss.spi.pminfo.vo.RecommendProductVo;
import com.yhd.pss.spi.pminfo.vo.SimplePmInfo;
import com.yhd.pss.spi.pminfo.vo.SimplePmInfoWithSimpleMerchantArea;
import com.yhd.pss.spi.pminfo.vo.input.ProductIdAndProvinceIdRequest;
import com.yhd.pss.spi.pminfo.vo.input.QueryRecommendProductRequest;
import com.yhd.shareservice.exceptions.HedwigException;
import com.yihaodian.mobile.common.ex.CentralMobileParamsException;
import com.yihaodian.mobile.common.ex.CentralMobileRuntimeException;
import com.yihaodian.mobile.service.common.util.service.MemcachedProxy;
import com.yihaodian.mobile.vo.constant.CommonKey;
import com.yihaodian.pss.client.PssClient;
import com.yihaodian.pss.client.PssClientConfiguration;

/**
 * 商品服务
 * @author zhangwei5
 * @version $Id: ProductServiceUtil.java, v 0.1 2014-4-11 上午9:48:17 zhangwei5 Exp $
 */
public class ProductServiceUtil {

    private static Logger logger = LoggerFactory.getLogger(ProductServiceUtil.class);
    
    private static QueryProductRemoteService queryProductRemoteService = null;
    
    private static QueryPmInfoRemoteService queryPmInfoRemoteService = null;
    
    private static QueryMerchantRemoteService queryMerchantRemoteService = null;
    
    private static QueryMerchantMapConfigRemoteService queryMerchantMapConfigRemoteService = null;
    
    private static QueryRecommendProductRemoteService queryRecommendProductRemoteService = null;
    
    static {
        queryProductRemoteService = PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getQueryProductRemoteService();
        queryPmInfoRemoteService= PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getQueryPmInfoRemoteService();
        queryMerchantRemoteService= PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getQueryMerchantRemoteService();
        queryMerchantMapConfigRemoteService = PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getQueryMerchantMapConfigRemoteService();
        queryRecommendProductRemoteService = PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getQueryRecommendProductRemoteService();
    }
    
    /**
     * 根据productId和provinceId获取PmInfo
     * @param productId
     * @param provinceId
     * @return
     */
    public static SimplePmInfo queryBasePmInfoByProductIdAndProvinceId(Long productId, Long provinceId) {
    	try{
    		if(productId == null || provinceId==null ){
    			return null;
    		}
    		ProductIdAndProvinceIdRequest request = new ProductIdAndProvinceIdRequest();
    		request.setProvinceId(provinceId);
    		request.setProductId(productId);
    		Response<List<SimplePmInfoWithSimpleMerchantArea>> response = queryPmInfoRemoteService.querySPminfoWithSMerchantAreaByPIdProvinceId(request);
    		if(response!=null && response.getResult()!=null){
    			List<SimplePmInfoWithSimpleMerchantArea> list = response.getResult();
    			if(CollectionUtils.isNotEmpty(list)){
    				return list.get(0).getSimplePmInfo();
    			}
    		}
    	}catch(Exception e){
    		logger.error("queryBasePmInfoByProductIdAndProvinceId has error", e);
    	}
    	return null;
    }
    
    /**
     * 根据productId和provinceId获取PmInfo
     * @param productId
     * @param provinceId
     * @return
     */
    public static List<SimplePmInfo> queryBasePmInfoListByProductIdAndProvinceId(Long productId, Long provinceId) {
    	List<SimplePmInfo> pmList = new ArrayList<SimplePmInfo>();
    	try{
    		if(productId == null || provinceId==null ){
    			return pmList;
    		}
    		ProductIdAndProvinceIdRequest request = new ProductIdAndProvinceIdRequest();
    		request.setProvinceId(provinceId);
    		request.setProductId(productId);
    		Response<List<SimplePmInfoWithSimpleMerchantArea>> response = queryPmInfoRemoteService.querySPminfoWithSMerchantAreaByPIdProvinceId(request);
    		if(response!=null && response.getResult()!=null){
    			List<SimplePmInfoWithSimpleMerchantArea> list = response.getResult();
    			if(CollectionUtils.isNotEmpty(list)){
    				for(SimplePmInfoWithSimpleMerchantArea sp: list){
    					pmList.add(sp.getSimplePmInfo());
    				}
    			}
    		}
    	}catch(Exception e){
    		logger.error("queryBasePmInfoByProductIdAndProvinceId has error", e);
    	}
    	return pmList;
    }
    
    /**
     * 查询商品基本信息
     * @param productId
     * @return
     */
    public static ProductCategoryMcSiteVo queryBaseProductById(Long productId){
        try {
        	if(productId == null){
        		return null ;
        	}
            String key = new StringBuffer("queryBaseProductById").append(productId).toString();
            MemcachedProxy me = MemcachedProxy.getInstance();
            Object obj = me.get(key);
            if(obj!=null){
                return (ProductCategoryMcSiteVo) obj;
            }
            QueryProductByIdRequest request = new QueryProductByIdRequest();
            request.setProductId(productId);
            Response<ProductCategoryMcSiteVo> productCategoryMcSiteVoResponse = queryProductRemoteService.queryProductWithPicByProdId(request);
            if(productCategoryMcSiteVoResponse!=null&&productCategoryMcSiteVoResponse.isSuccess()){
                ProductCategoryMcSiteVo productCategoryMcSiteVo = productCategoryMcSiteVoResponse.getResult();
                if(productCategoryMcSiteVo!=null){
                    me.put(key, productCategoryMcSiteVo, CommonKey.MEMCACHE_INVALID_TIME_ONE_HOUR);
                }
                return productCategoryMcSiteVo;
            }
        } catch (Exception e) {
            logger.error("queryBaseProductById has error ", e);
        }
        return null;
    }
    
    /**
     * 批量查询商品基本信息
     * @param productIds
     * @return
     */
    public static Map<Long ,ProductCategoryMcSiteVo> queryBaseProductByIds(List<Long> productIds){
        try {
        	if(CollectionUtils.isEmpty(productIds)){
        		return new HashMap<Long, ProductCategoryMcSiteVo>() ;
        	}
            QueryBaseProductWithProductPicByProdIdsRequest request = new QueryBaseProductWithProductPicByProdIdsRequest();
            request.setProductIds(productIds);
            request.setMcsiteid(1L);
            Response<List<ProductCategoryMcSiteVo>> productCategoryMcSiteVoListResponse = queryProductRemoteService.queryBaseProductWithProductPicByProdIds(request);
            if(productCategoryMcSiteVoListResponse!=null&&productCategoryMcSiteVoListResponse.isSuccess()){
                List<ProductCategoryMcSiteVo> productCategoryMcSiteVoList = productCategoryMcSiteVoListResponse.getResult();
                Map<Long, ProductCategoryMcSiteVo> productCategoryMcSiteVoMap = productCategoryMcSiteVoListToMap(productCategoryMcSiteVoList);
                return productCategoryMcSiteVoMap;
            }
        } catch (Exception e) {
            logger.error("queryBaseProductByIds has error ", e);
        }
        return new HashMap<Long, ProductCategoryMcSiteVo>();
    }
    
    /**
     * 批量查询商品信息
     * @param productCodes 产品编码查询
     * @return
     */
    public static List<ProductVo> queryProductByCodes(List<String> productCodes){
        try {
        	if(CollectionUtils.isEmpty(productCodes)){
        		return new ArrayList<ProductVo>() ;
        	}
            QueryProductRequest request = new QueryProductRequest();
            request.setProductCodesIn(productCodes);
            Response<List<ProductVo>> response = queryProductRemoteService.queryProduct(request);
            if(response!=null){
                List<ProductVo> product = response.getResult();
                if(product!=null&&product.size()>0){
                    List<Long> productIds = new ArrayList<Long>();
                    for(ProductVo productVo : product){
                        productIds.add(productVo.getId());
                    }
                    //设置商品图片
                    Map<Long, String> map = queryProductPicByIds(productIds);
                    for( ProductVo productVo : product){
                        if(map!=null&&map.get(productVo.getId())!=null){
                            productVo.setDefaultPictureUrl(map.get(productVo.getId()));
                        }
                    }
                    
                }
                return product;
            }
        } catch (Exception e) {
            logger.error("queryProductByCodes has error ", e);
        }
        return new ArrayList<ProductVo>();
    }
    
    
    
    /**
     * 批量查询商品信息 返回Map
     * @param productIds 商品Id
     * @return
     */
    public static Map<Long,ProductVo> queryProductMapByIds(List<Long> productIds){
        try {
        	if(CollectionUtils.isEmpty(productIds)){
        		return new HashMap<Long,ProductVo>();
        	}
        	String key=  "queryProductMapByIds_"+productIds.toString() ; 
        	MemcachedProxy me = MemcachedProxy.getInstance() ;
        	Map<Long, ProductVo> productMap =(Map<Long, ProductVo>) me.get(key)  ;
        	if(productMap != null){
        		return productMap ;
        	}
        	productMap = new HashMap<Long, ProductVo>();
            QueryProductByIdsRequest request = new QueryProductByIdsRequest();            
            List<List<Long>> ids = Lists.partition(productIds, 100);
            for(List<Long> id: ids){            	
            	request.setProductIds(id);
            	Response<List<ProductVo>> response = queryProductRemoteService.queryProductByIds(request);
            	if(response!=null&&response.isSuccess()){
            		List<ProductVo> productList = response.getResult();
            		//设置商品图片
            		Map<Long, String> map = queryProductPicByIds(productIds);
            		for( ProductVo productVo : productList){
            			if(map!=null && map.get(productVo.getId())!=null){
            				productVo.setDefaultPictureUrl(map.get(productVo.getId()));
            			}
            		}
            		productMap .putAll(productVoListToMap(productList));
            	}
            }
            if(productMap.size() > 0){
            	me.put(key, productMap,CommonKey.MEMCACHE_INVALID_TIME_MINUTE_10);                
            }
            return productMap;            
        } catch (Exception e) {
            logger.error("queryProductByIds has error productIds:"+productIds.toString(), e);
        }
        return new HashMap<Long, ProductVo>();
    }
    /**
     * 批量查询商品信息  返回List
     * @param productIds 商品Id
     * @return
     */
    public static List<ProductVo> queryProductByIds(List<Long> productIds){
        try {
        	if(CollectionUtils.isEmpty(productIds)){
        		return new ArrayList<ProductVo>();
        	}
            QueryProductByIdsRequest request = new QueryProductByIdsRequest();
            request.setProductIds(productIds);
            Response<List<ProductVo>> response = queryProductRemoteService.queryProductByIds(request);
            if(response!=null&&response.isSuccess()){
                List<ProductVo> productList = response.getResult();
                //设置商品图片
                Map<Long, String> map = queryProductPicByIds(productIds);
                for( ProductVo productVo : productList){
                    if(map!=null&&map.get(productVo.getId())!=null){
                        productVo.setDefaultPictureUrl(map.get(productVo.getId()));
                    }
                }
                return productList;
            }
        } catch (Exception e) {
            logger.error("queryProductByIds has error ", e);
        }
        return new ArrayList<ProductVo>();
    }
    
    /**
     * 查询单个商品详细信息
     * @param productId 商品Id
     * @return
     */
    public static ProductVo queryProductById(Long productId){
        try {
        	if(productId == null){
        		return null ;
        	}
            String key = new StringBuffer("queryProductById").append(productId).toString();
            MemcachedProxy me = MemcachedProxy.getInstance();
            Object obj = me.get(key);
            if(obj!=null){
                return (ProductVo) obj;
            }
            QueryProductByIdRequest  request = new QueryProductByIdRequest();
            request.setProductId(productId);
            Response<ProductVo> response = queryProductRemoteService.queryProductById(request);
            if(response!=null&&response.isSuccess()&&response.getResult()!=null){  
                ProductVo productVo = response.getResult();
                //获取图片
                List<Long> prodcutIds = new ArrayList<Long>();
                prodcutIds.add(productId);
                Map<Long, String> map = queryProductPicByIds(prodcutIds);
                if(map!=null&&map.get(productId)!=null){
                    productVo.setDefaultPictureUrl(map.get(productId));
                }
                me.put(key, productVo, CommonKey.MEMCACHE_INVALID_TIME_ONE_HOUR);
                return productVo;
            }
        } catch (Exception e) {
            logger.error("queryProductByCodes has error ", e);
        }
        return null;
    }
    
    /**
     * 查询主品图片
     * @param productId
     * @return
     */
    public static ProductPicVo queryProductSerialMainPicByProductIds(Long productId){
        try {
            String key = new StringBuffer("queryProductSerialMainPicByProductIds").append(productId).toString();
            MemcachedProxy me = MemcachedProxy.getInstance();
            Object obj = me.get(key);
            if(obj!=null){
                return (ProductPicVo) obj;
            }
            QueryProductByIdsRequest request = new QueryProductByIdsRequest();
            List<Long> productIds = new ArrayList<Long>();
            productIds.add(productId);
            request.setProductIds(productIds);
            Response<List<ProductPicVo>> productPicVoReponse = queryProductRemoteService.queryProductSerialMainPicByProductIds(request);
            if(productPicVoReponse!=null&&productPicVoReponse.isSuccess()&&productPicVoReponse.getResult()!=null&&productPicVoReponse.getResult().size()>0){
                ProductPicVo productPicVo = productPicVoReponse.getResult().get(0);
                me.put(key, productPicVo, CommonKey.MEMCACHE_INVALID_TIME_ONE_HOUR);
                return productPicVo;
            }
        } catch (Exception e) {
            logger.error("queryProductSerialMainPicByProductIds has error",e);
        }
        return null;
    }
    
    /**
     * 查询商品图片
     * @param productIds
     */
    public static Map<Long,String>  queryProductPicByIds(List<Long> productIds){
    	Map<Long, String> map = new HashMap<Long, String>();
        try {
        	if(CollectionUtils.isEmpty(productIds)){
        		return map;
        	}        	
            QueryProductPicByIdRequest request = new QueryProductPicByIdRequest();
            //设置取默认图片
            request.setIsDefault(1);
            List<List<Long>> ids = Lists.partition(productIds, 100);
            for(List<Long> id:ids){
            	request.setProductIds(id);
            	Response<List<ProductPicVo>> response = queryProductRemoteService.queryProductPicByIds(request);            	
            	if(response!=null && response.isSuccess() && CollectionUtils.isNotEmpty(response.getResult())){
            		List<ProductPicVo> productPicVoList = response.getResult();            		
            		for(ProductPicVo productPicVo : productPicVoList){
            			map.put(productPicVo.getProductId(), productPicVo.getPicUrl());
            		}                 
            	}
            }            
        } catch (Exception e) {
            logger.error("queryProductPicByIds has error",e);
        }
        return map;
    }
    
    
    /**
     * 批量查询商品信息
     * @param productCodes 产品编码查询
     * @return
     */
    public static Map<String , Long> queryProductByCodesForMap(List<String> productCodes){
        try {
        	if(CollectionUtils.isEmpty(productCodes)){
        		 return new HashMap<String, Long>();
        	}
            ProductCodesRequest request = new ProductCodesRequest();
            request.setProductCodes(productCodes);
            Response<List<ProductBaseVo>> response = queryProductRemoteService.queryProductBaseByProductCodes(request);
            if(response!=null){
                List<ProductBaseVo> product = response.getResult();
                if(product!=null&&product.size()>0){
                    Map<String , Long> productMap = new HashMap<String, Long>();
                    for(ProductBaseVo productVo : product){
                        productMap.put(productVo.getProductCode(), productVo.getId());
                    }
                    return productMap; 
                }
            }
        } catch (Exception e) {
            logger.error("queryProductByCodes has error ", e);
        }
        return new HashMap<String, Long>();
    }

    private static Map<Long , ProductCategoryMcSiteVo> productCategoryMcSiteVoListToMap(List<ProductCategoryMcSiteVo> productList){
        if(productList!=null&&productList.size()>0){
            Map<Long , ProductCategoryMcSiteVo> map = new HashMap<Long, ProductCategoryMcSiteVo>();
            for(ProductCategoryMcSiteVo product: productList){
                map.put(product.getId(), product);
            }
            return map;
        }
        return new HashMap<Long, ProductCategoryMcSiteVo>();
    }
    
    
    private static Map<Long , ProductVo> productVoListToMap(List<ProductVo> productList){
        if(productList!=null&&productList.size()>0){
            Map<Long , ProductVo> map = new HashMap<Long, ProductVo>();
            for(ProductVo product: productList){
                map.put(product.getId(), product);
            }
            return map;
        }
        return new HashMap<Long, ProductVo>();
    }
    
    /**
     * 根据merchantId查询集团商家id
     * @param merchantId
     * @return
     */
    public static Merchant queryBaseMerchantById(Long merchantId){
        try {
        	if(merchantId == null ){
        		 return new Merchant();
        	}
        	QueryBaseMerchantByIdRequest request = new QueryBaseMerchantByIdRequest();
            request.setMerchantId(merchantId);
            Response<Merchant> response = queryMerchantRemoteService.queryBaseMerchantById(request);
            if(response!=null){
                return response.getResult(); 
            }
        } catch (Exception e) {
            logger.error("queryBaseMerchantById has error ", e);
        }
        return new Merchant();
    }
    
   /**
    * 商家ID+经纬度 ，取该地址下的区域信息 
    * @param merchantId  商家ID
    * @param lng         经度
    * @param lat         纬度
    * @return
    */
    public static MapBlock queryO2OModelBlockByMerchantIdAndCoordinates(Long merchantId,Double lng,Double lat){
    	try {
    		if(null == merchantId || null == lng || null == lat){
    			return null;
    		}
    		QueryByPagingMerchantIdAndCoordinatesAndCellIdRequest request = new QueryByPagingMerchantIdAndCoordinatesAndCellIdRequest();
    		request.setMerchantId(merchantId);
    		CoordinatesVo coordinates = new CoordinatesVo();
    		coordinates.setLat(lat);
    		coordinates.setLng(lng);
    		request.setCoordinates(coordinates);
    		Response<HandleResult <List<MapBlock>>> rps = queryMerchantMapConfigRemoteService.queryO2OModelBlockByMerchantIdAndCoordinatesAndCellId(request);
    		if(null != rps && rps.getResult().getHandleStatus()){
    			List<MapBlock> blockList = rps.getResult().getResult();
    			if(CollectionUtils.isNotEmpty(blockList)){
    				return blockList.get(0);
    			}
    		}
		} catch (HedwigException e) {
			 logger.error("queryO2OModelBlockByMerchantIdAndCoordinates has HedwigException ", e);
		}
    	return null;
    }
    
    /**
     * cell_id获取该地址下的区域信息
     * @param cellId
     * @return
     */
    public static MapBlock queryO2OModelBlockByCellId(String cellId){
    	try {
    		if(null == cellId){
    			return null;
    		}
    		QueryByPagingMerchantIdAndCoordinatesAndCellIdRequest request = new QueryByPagingMerchantIdAndCoordinatesAndCellIdRequest();
    		CoordinatesVo coordinates = new CoordinatesVo();
    		coordinates.setCellId(cellId);
    		request.setCoordinates(coordinates);
    		Response<HandleResult <List<MapBlock>>> rps = queryMerchantMapConfigRemoteService.queryO2OModelBlockByMerchantIdAndCoordinatesAndCellId(request);
    		if(null != rps && rps.getResult().getHandleStatus()){
    			List<MapBlock> blockList = rps.getResult().getResult();
    			if(CollectionUtils.isNotEmpty(blockList)){
    				return blockList.get(0);
    			}
    		}
		} catch (HedwigException e) {
			 logger.error("queryO2OModelBlockByCellId has HedwigException ", e);
		}
    	return null;
    }
    
	/**
	 * 通过详细地址查经纬度
	 * @param address
	 * @param coordinate
	 * @return
	 */
    public static CoordinateInfoVo queryCoordinateByAddress(String address){
    	try {
    		if(null == address){
    			return null;
    		}
    		QueryAddressResolveRequest request = new QueryAddressResolveRequest();
    		request.setAddress(address);
    		Response<CoordinateInfoVo> rps = queryMerchantMapConfigRemoteService.queryCoordinateByAddress(request);
    		if(null != rps && null != rps.getResult()){
    			return rps.getResult();
    		}
		} catch (HedwigException e) {
			 logger.error("queryCoordinateByAddress has HedwigException ", e);
		}
    	return null;
    }
    
    /**
     * 根据经纬度返回该地址下的商家列表
     * @param lng
     * @param lat
     * @param cellId
     * @param currentPage 	目前页面
     * @param pageSize 		页面大小
     * @return
     */
    public static List<MerchantIdAndNameAndStoreStatusVo> queryPagingMerchantByPoint(Double lng, Double lat, String cellId, Long currentPage, Long pageSize) {
    	if (lng==null || lat==null) {
    		throw new CentralMobileParamsException("lng or lat is null");
    	}
    	
    	QueryByPagingCoordinatesRequest request = new QueryByPagingCoordinatesRequest();
    	CoordinatesVo coordinates = new CoordinatesVo();
    	coordinates.setLat(lat);
    	coordinates.setLng(lng);
    	coordinates.setCellId(cellId);
    	request.setCoordinates(coordinates);
    	request.setCurrentPage(currentPage);
    	request.setPageSize(pageSize);
    	try {
			Response<HandleResult<List<MerchantIdAndNameAndStoreStatusVo>>> response = queryMerchantMapConfigRemoteService.queryPagingMerchantByPoint(request);
    		if(null != response && response.getResult().getHandleStatus()){
    			return response.getResult().getResult();
    		}
    	} catch (HedwigException e) {
			logger.error("queryPagingMerchantByPoint has HedwigException ", e);
		}
    	
    	throw new CentralMobileRuntimeException("No result calling queryMerchantMapConfigRemoteService.queryPagingMerchantByPoint");
    }
    
    public static List<AddressListVo> queryAddressListByKeyWord(String keywords, String location, String city) {
    	
    	if (keywords==null) {
    		throw new CentralMobileParamsException("keywords is null");
    	}
    	
    	QueryAddressListByKeyWordRequest request = new QueryAddressListByKeyWordRequest();
    	request.setKeyWords(keywords);
    	request.setLocation(location);
    	request.setCity(city);
    	try {
			Response<List<AddressListVo>> response = queryMerchantMapConfigRemoteService.queryAddressListByKeyWord(request);
			if(null != response && response.isSuccess()){
    			return response.getResult();
    		}
		} catch (HedwigException e) {
			logger.error("queryAddressListByKeyWord has HedwigException ", e);
		}
    	
    	throw new CentralMobileRuntimeException("No result calling queryMerchantMapConfigRemoteService.queryAddressListByKeyWord");
    }
    
    public static FullFieldsMerchant queryMerchantById(Long merchantId) throws HedwigException{
    	try {
    		QueryMerchantByIdRequest request = new QueryMerchantByIdRequest();
        	request.setMerchantId(merchantId);
        	Response<FullFieldsMerchant> rps = queryMerchantRemoteService.queryMerchantById(request);
        	if(null != rps && null != rps.getResult()){
        		return rps.getResult();
        	}
    	}catch (HedwigException e) {
			logger.error("queryMerchantById has HedwigException ", e);
		}
    	return null;
    }
    
    public static List<RecommendProductVo> getRecommendProductByMerchantIdsAndProvinceId(List<Long> merchantIds, Long provinceId) {
    	List<RecommendProductVo> result = Lists.newArrayList();
    	try {
    		List<List<Long>> idsList = Lists.partition(merchantIds, 10);
    		for (List<Long> mIds: idsList) {
    			QueryRecommendProductRequest request = new QueryRecommendProductRequest();
    			request.setMerchantIds(mIds);
    			request.setProvinceId(provinceId);
    			logger.error("Before calling getRecommendProductByMerchantIdsAndProvinceId time millis:"+System.currentTimeMillis());
    			Response<List<RecommendProductVo>> response = queryRecommendProductRemoteService.getRecommendProductByMerchantIdsAndProvinceId(request);
    			logger.error("After calling getRecommendProductByMerchantIdsAndProvinceId time millis:"+System.currentTimeMillis());
    			if (response!=null && response.getResult()!=null) {
    				result.addAll(response.getResult());
    			}
    		}
		} catch (HedwigException e) {
			logger.error("HedwigException in getRecommendProductByMerchantIdsAndProvinceId", e);
		} catch (Exception e) {
			logger.error("Exception in getRecommendProductByMerchantIdsAndProvinceId", e);
		}
    	
    	return result;
    }
}
