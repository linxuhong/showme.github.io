package com.yihaodian.mobile.service.common.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class MathUtil.
 */
public class MathUtil {
    
    /**
     * Round double.
     *
     * @param val the val
     * @param precision the precision
     * @return the double
     */
    public static Double roundDouble(double val, int precision) {
        Double ret = null;
        try {
            double factor = Math.pow(10, precision);
            ret = Math.floor(val * factor + 0.5) / factor;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ret;
    }
    
    /**
     * Adds the day.
     *
     * @param date the date
     * @param amount the amount
     * @return the date
     */
    public static Date addDay (Date date, int amount) {
    	Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	calendar.add(Calendar.DAY_OF_MONTH, amount);
    	return calendar.getTime();
    }
    
    /**
     * Subtract.
     *
     * @param base the base
     * @param subtrahends the subtrahends
     * @return the big decimal
     */
    public static BigDecimal subtract(BigDecimal base, BigDecimal ... subtrahends) {
    	for (BigDecimal subtrahend : subtrahends) {
    		base = base.subtract(subtrahend);
    	}
    	return base;
    }
    
    /**
     * Multiply.
     *
     * @param base the base
     * @param multiplicands the multiplicands
     * @return the big decimal
     */
    public static BigDecimal multiply(BigDecimal base, BigDecimal ... multiplicands) {
    	for (BigDecimal multiplicand : multiplicands) {
    		base = base.multiply(multiplicand);
    	}
    	return base;
    }
    
    /**
     * Adds the.
     *
     * @param base the base
     * @param augends the augends
     * @return the big decimal
     */
    public static BigDecimal add(BigDecimal base, BigDecimal ... augends) {
    	for (BigDecimal augend : augends) {
    		base = base.add(augend);
    	}
    	return base;
    }
    
    /**
     * Gets the percent.
     *
     * @param x the x
     * @param total the total
     * @return the percent
     */
    public static Double getPercent(double x, double total) {
    	String result = "";
    	double tempReuslt = x/total;
    	NumberFormat numFormat = NumberFormat.getInstance();
    	numFormat.setMinimumFractionDigits(4);
    	result= numFormat.format(tempReuslt);
    	return new Double(result);
    }

	/**
	 * Format.
	 *
	 * @param date the date
	 * @return the string
	 */
	public static String format(Date date) {
		return format(date, "yyyy-MM-dd HH:mm:ss");
	}
	
	/**
	 * Format.
	 *
	 * @param date the date
	 * @param pattern the pattern
	 * @return the string
	 */
	public static String format(Date date, String pattern) {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(date);
	}
	
	/**
	 * 对金额做截取，如果小数点后面都为0则只返回整数部分.
	 *
	 * @param price the price
	 * @return the string
	 */
	public static String formatPrice(Double price){
		int integerPartPrice = (int) Math.floor(price);
		if((price-integerPartPrice)>0){
			return price+"";
		}
		return integerPartPrice+"";
	}
	
	public static Double parseDouble(String str){
		Double value = null;
		try{
			if(null != str){
				value = Double.parseDouble(str);
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return value;
	}
    
    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
//    	BigDecimal big1 = new BigDecimal(2.0);
//    	BigDecimal big2 = new BigDecimal(3.0);
//    	BigDecimal big3 = new BigDecimal(5.0);
//    	BigDecimal result;
//    	result = add(big1, big2, big3);
//    	System.out.println(result.doubleValue());
//    	result = subtract(big1, big2, big3);
//    	System.out.println(result.doubleValue());
//    	result = multiply(big1, big2, big3);
//    	System.out.println(result.doubleValue());
    	System.out.println(formatPrice(10.0));
    }
}
