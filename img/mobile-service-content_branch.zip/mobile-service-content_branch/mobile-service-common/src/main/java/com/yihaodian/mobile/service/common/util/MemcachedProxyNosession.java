package com.yihaodian.mobile.service.common.util;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;


import com.yihaodian.common.vo.Constant;
import com.yihaodian.common.vo.ConstantCustom;
import com.yihaodian.mobile.service.common.util.service.MemcachedProxy;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.danga.MemCached.MemCachedClient;
import com.danga.MemCached.SockIOPool;

// TODO: Auto-generated Javadoc
/**
 * The Class MemcachedProxyNosession.
 *
 * @author weip
 * @time Mar 14, 2008 1:07:46 PM
 */
public class MemcachedProxyNosession {
	
	/** The sys logger. */
	protected static Log sysLogger = LogFactory.getLog("sysLogger");

	/** The instance. */
	private static MemcachedProxyNosession instance;

	/** The Constant defaultExpiryMinutes. */
	private static final int defaultExpiryMinutes = 60 * 12;   //缺省保存12小时
	
	/** The Constant SocketTimeout. */
	private static final int SocketTimeout = 1000 * 3;    
	
	/** The Constant socketConnectTO. */
	private static final int socketConnectTO = 1000 * 3;
	
	/** The Constant initConn. */
	private static final int initConn = 50;
	
	/** The Constant mainSleep. */
	private static final int mainSleep = 30*1000;
	
	/** The Constant minConn. */
	private static final int minConn = 50;
	
	/** The Constant maxConn. */
	private static final int maxConn = 500;
	
	/** The Constant poolname. */
	private static final String poolname = "nosession";
	
	/** The mc. */
	private static MemCachedClient MC = new MemCachedClient(poolname);

	/**
	 * Gets the single instance of MemcachedProxyNosession.
	 *
	 * @return single instance of MemcachedProxyNosession
	 */
	public static MemcachedProxyNosession getInstance() {
		if(null == instance) {
			instance = new MemcachedProxyNosession();
		}
		return instance;
	}

	/**
	 * Inits the.
	 */
	public void init() {
		
		String servers ="";
		
		if(System.getProperty("central.config.path") == null){
			
			servers = Constant.getMemcachedsNoSession();
			
		}else{
			
			servers = ConstantCustom.getMemcachedsNoSession();
		}		
		
		String[] serverlist = servers.split(",");
		SockIOPool pool = SockIOPool.getInstance(poolname);
		pool.setServers(serverlist);
		pool.setInitConn(initConn);
		pool.setMinConn(minConn);
		pool.setMaxConn(maxConn);
		pool.setMaintSleep(mainSleep);
		pool.setNagle(false);
		pool.setFailover(true);
		pool.setSocketTO(SocketTimeout);             
		pool.setSocketConnectTO(socketConnectTO);
		
		pool.setHashingAlg(SockIOPool.CONSISTENT_HASH);
		// pool.setAliveCheck( true );
		// pool.setFailback(true);
		pool.initialize();
	}

	/**
	 * Close.
	 */
	public void close() {
		SockIOPool pool = SockIOPool.getInstance(poolname);
		pool.shutDown();
	}

	/**
	 * Gets the.
	 *
	 * @param key the key
	 * @return the object
	 */
	public Object get(String key) {
		
		MemCachedClient mc = MC;
		
		//mc.setPoolName(poolname);
		
		mc.setCompressEnable(true);
		
		Object obj = mc.get(MemcachedProxy.getGoodKey(key));
//		sysLogger.info("Try get an object from memcached with key : " + key
//				+ ", got object: " + obj);
		return obj;
	}

	/**
	 * 榛樿杩囨湡鏃堕棿涓轰竴澶�.
	 *
	 * @param key the key
	 * @param value the value
	 */
	public void put(String key, Object value) {
		this.put(key, value, defaultExpiryMinutes);
	}

	/**
	 * Put.
	 *
	 * @param key the key
	 * @param value the value
	 * @param expirMins the expir mins
	 */
	public void put(String key, Object value, int expirMins) {
		if(value!=null) {
			MemCachedClient mc = MC;
			//mc.setPoolName(poolname);
			mc.setCompressEnable(true);
			if (expirMins > 0){
			    BigDecimal bigExpirMins = new BigDecimal(1000*60*expirMins);
			    mc.set(MemcachedProxy.getGoodKey(key), value, new Date(bigExpirMins.longValue()));  
			}else{
			    //-------限期错误，强制30分失效---------------
			    mc.set(MemcachedProxy.getGoodKey(key), value,new Date(1000*60*30));   
			}
		} else {
			try {
				throw new Exception("Memcache value is null error! The key is :"+key);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Removes the.
	 *
	 * @param key the key
	 */
	public void remove(String key) {
		MemCachedClient mc = MC;
		//mc.setPoolName(poolname);
		mc.delete(MemcachedProxy.getGoodKey(key));
	}

	/**
	 * Gets the date after.
	 *
	 * @param mins the mins
	 * @return the date after
	 */
	public Date getDateAfter(int mins) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, mins);
		return cal.getTime();
	}

}
