package com.yihaodian.mobile.common.ex;

public class ServiceIntegrationException extends RuntimeException {
	
	private ServiceNameEnum serviceName;

	/**
	 * 
	 */
	private static final long serialVersionUID = 6912643702418097355L;
	
	public ServiceIntegrationException(String msg) {
		super(msg);
	}
	
	public ServiceIntegrationException(ServiceNameEnum serviceName, String msg) {
		super(msg);
		this.serviceName = serviceName;
	}
	
	public ServiceIntegrationException(String msg, Throwable throwable) {
		super(msg, throwable);
	}
	
	public ServiceIntegrationException(ServiceNameEnum serviceName, String msg, Throwable throwable) {
		super(msg, throwable);
		this.serviceName = serviceName;
	}

	public ServiceNameEnum getServiceName() {
		return serviceName;
	}
	
	public static enum ServiceNameEnum {
		GeneralPromoSearchClientService, RemoteCartService;
	}

}
