package com.yihaodian.front.i.util;

public class Constant {
	/**
	 * 兼容老的central
	 * @return
	 */
     public static String getDefaultPicURL(){
    	 return "";
     }
}
