package com.yihaodian.mobile.service.common.util.service;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.yihaodian.mobile.vo.cart.AddOrDeletePromotionResult;
import com.yihaodian.mobile.vo.cart.AddProductResult;
import com.yihaodian.mobile.vo.cart.ExistOptionalResult;
import com.yihaodian.mobile.vo.cart.UpadtePromotionResult;
import com.yihaodian.mobile.vo.cart.UpdateCartResult;
import com.yihaodian.mobile.vo.coupon.AddCouponByActivityIdResult;
import com.yihaodian.mobile.vo.coupon.CouponVerifyActiveCodeResult;
import com.yihaodian.mobile.vo.coupon.ReceiveResult;
import com.yihaodian.mobile.vo.groupon.GrouponOrderSubmitResult;
import com.yihaodian.mobile.vo.groupon.GrouponOrderVO;
import com.yihaodian.mobile.vo.miracle.MiracleRegisterResult;
import com.yihaodian.mobile.vo.order.CheckSmsResult;
import com.yihaodian.mobile.vo.order.CouponDeleteResult;
import com.yihaodian.mobile.vo.order.CouponGetCheckCodeResult;
import com.yihaodian.mobile.vo.order.CouponSaveResult;
import com.yihaodian.mobile.vo.order.CouponVerifyCheckCodeResult;
import com.yihaodian.mobile.vo.order.CreateOrderResult;
import com.yihaodian.mobile.vo.order.SaveGateWayToOrderResult;
import com.yihaodian.mobile.vo.order.SaveGoodReceiverResult;
import com.yihaodian.mobile.vo.order.SavePayByAccountResult;
import com.yihaodian.mobile.vo.order.SendValidCodeResult;
import com.yihaodian.mobile.vo.order.SubmitOrderResult;
import com.yihaodian.mobile.vo.promotion.AddStorageBoxResult;
import com.yihaodian.mobile.vo.promotion.AwardsResult;
import com.yihaodian.mobile.vo.promotion.InviteeResult;
import com.yihaodian.mobile.vo.promotion.SeckillCanBuyResult;
import com.yihaodian.mobile.vo.promotion.UpdateStroageBoxResult;
import com.yihaodian.mobile.vo.user.BindMobileResult;
import com.yihaodian.mobile.vo.user.CheckUserNameResult;
import com.yihaodian.mobile.vo.user.CheckValidCodeForPhoneRegisterResult;
import com.yihaodian.mobile.vo.user.CheckValidCodeResult;
import com.yihaodian.mobile.vo.user.LoginResult;
import com.yihaodian.mobile.vo.user.PushMappingResult;
import com.yihaodian.mobile.vo.user.RegisterQijiResult;
import com.yihaodian.mobile.vo.user.RegisterResult;
import com.yihaodian.mobile.vo.user.SendBindValidateCodeResult;
import com.yihaodian.mobile.vo.user.SendValidCodeForPhoneRegisterResult;
import com.yihaodian.mobile.vo.user.UpdatePasswordResult;
import com.yihaodian.mobile.vo.user.UpdateUserAgreeAuthResult;


public class ReturnResultUtil {
	private static Map<String, String> businessCodeMap;
	private static final String BUSINESS_SEARCH = "001";
	private static final String BUSINESS_SHOPPING = "002";
	private static final String BUSINESS_DETAIL = "003";
	private static final String BUSINESS_WL = "004";
	private static final String BUSINESS_MYYHD = "005";
	private static final String BUSINESS_GROUPON = "006";
	private static final String BUSINESS_PASSPORT = "007";
	public static final String ERROR_PARAMS = "0001";
	public static final String ERROR_SECURITY = "0002";
	public static final String ERROR_BUSINESS = "0003";
	public static final String ERROR_NETWORK = "0004";
	public static final String ERROR_DATA = "0005";
	public static final String ERROR_SYSTEM = "0006";
	public static final String ERROR_OTHER = "0007";
	
	static {
		businessCodeMap = new HashMap<String, String>();
		businessCodeMap.put("getSearchKeyWord", BUSINESS_SEARCH);
		businessCodeMap.put("getSearchKeyword", BUSINESS_SEARCH);
		businessCodeMap.put("searchProduct", BUSINESS_SEARCH);
		businessCodeMap.put("searchByNetNote", BUSINESS_SEARCH);
		businessCodeMap.put("searchProductForList", BUSINESS_SEARCH);
		businessCodeMap.put("getProductByBarcode", BUSINESS_SEARCH);
		businessCodeMap.put("getRelateProductByBarcode", BUSINESS_SEARCH);
		businessCodeMap.put("getHotSearchKeywords", BUSINESS_SEARCH);
		businessCodeMap.put("getPromotionDetailPageVO", BUSINESS_SEARCH);
		businessCodeMap.put("searchCategorysOnly", BUSINESS_SEARCH);
		businessCodeMap.put("searchAttributesOnly", BUSINESS_SEARCH);
		businessCodeMap.put("searchProductsOnly", BUSINESS_SEARCH);
		businessCodeMap.put("getAutoCompleteKeyword", BUSINESS_SEARCH);
		
		businessCodeMap.put("getSessionCart", BUSINESS_SHOPPING);
		businessCodeMap.put("addProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("addProducts", BUSINESS_SHOPPING);
		businessCodeMap.put("delProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("delAllProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("updateCartItemQuantity", BUSINESS_SHOPPING);
		businessCodeMap.put("updateGiftProducts", BUSINESS_SHOPPING);
		businessCodeMap.put("addProductV2", BUSINESS_SHOPPING);
		businessCodeMap.put("addProductsV2", BUSINESS_SHOPPING);
		businessCodeMap.put("updateCartItemQuantityV2", BUSINESS_SHOPPING);
		businessCodeMap.put("delProducts", BUSINESS_SHOPPING);
		businessCodeMap.put("updateCartPromotion", BUSINESS_SHOPPING);
		businessCodeMap.put("addOptional", BUSINESS_SHOPPING);
		businessCodeMap.put("isExistOptionalInCart", BUSINESS_SHOPPING);
		businessCodeMap.put("updateOptional", BUSINESS_SHOPPING);
		businessCodeMap.put("deleteOptional", BUSINESS_SHOPPING);
		businessCodeMap.put("countSessionCart", BUSINESS_SHOPPING);
		businessCodeMap.put("getGiftList", BUSINESS_SHOPPING);
		businessCodeMap.put("getCashList", BUSINESS_SHOPPING);
		businessCodeMap.put("getRedemptionList", BUSINESS_SHOPPING);
		businessCodeMap.put("addNormalProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("addLandingpageProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("addLandingpageProducts", BUSINESS_SHOPPING);
		businessCodeMap.put("addNormalProducts", BUSINESS_SHOPPING);
		businessCodeMap.put("addPromotionProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("addOptionalProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("updateNormalProductQuantity", BUSINESS_SHOPPING);
		businessCodeMap.put("updateLandingpageProductQuantity", BUSINESS_SHOPPING);
		businessCodeMap.put("deleteOptionalProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("deleteNormalProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("deletePromotionProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("deleteLandingpageProduct", BUSINESS_SHOPPING);
		businessCodeMap.put("deleteProducts", BUSINESS_SHOPPING);
		businessCodeMap.put("getUnmetPromotionList", BUSINESS_SHOPPING);
		businessCodeMap.put("createSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("createSessionOrderV2", BUSINESS_SHOPPING);
		businessCodeMap.put("getSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("removeSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("submitOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("submitOrderEx", BUSINESS_SHOPPING);
		businessCodeMap.put("saveGoodReceiverToSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("saveGoodReceiverToSessionOrderV2", BUSINESS_SHOPPING);
		businessCodeMap.put("saveCouponToSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("saveInvoiceToSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("savePaymentToSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("getPaymentMethodsForSessionOrderV2", BUSINESS_SHOPPING);
		businessCodeMap.put("getPaymentMethodsForSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("needSmsCheck", BUSINESS_SHOPPING);
		businessCodeMap.put("sendValidCodeToUserBindMobile", BUSINESS_SHOPPING);
		businessCodeMap.put("checkSms", BUSINESS_SHOPPING);
		businessCodeMap.put("savePayByAccount", BUSINESS_SHOPPING);
		businessCodeMap.put("saveCouponToSessionOrderV2", BUSINESS_SHOPPING);
		businessCodeMap.put("deleteCouponFromSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("getCouponListForSessionOrder", BUSINESS_SHOPPING);
		businessCodeMap.put("getCouponCheckCode", BUSINESS_SHOPPING);
		businessCodeMap.put("verifyCouponCheckCode", BUSINESS_SHOPPING);
		businessCodeMap.put("submitOrderV2", BUSINESS_SHOPPING);
		businessCodeMap.put("getDeliveryInfoList", BUSINESS_SHOPPING);
		businessCodeMap.put("getPromotionGiftList", BUSINESS_SHOPPING);
		businessCodeMap.put("getMobilePromotion", BUSINESS_SHOPPING);
		businessCodeMap.put("getCashPromotionList", BUSINESS_SHOPPING);
		businessCodeMap.put("getRedemptionPromotionList", BUSINESS_SHOPPING);
		businessCodeMap.put("updateCartProductUnlogin", BUSINESS_SHOPPING);
		businessCodeMap.put("getBankVOList", BUSINESS_SHOPPING);
		businessCodeMap.put("getBankVOByID", BUSINESS_SHOPPING);
		
		businessCodeMap.put("getProductDetail", BUSINESS_DETAIL);
		businessCodeMap.put("getProductDetails", BUSINESS_DETAIL);
		businessCodeMap.put("getProductDetailDescription", BUSINESS_DETAIL);
		businessCodeMap.put("getProductDetailDescriptionV2", BUSINESS_DETAIL);
		businessCodeMap.put("getProductDetailComment", BUSINESS_DETAIL);
		businessCodeMap.put("getProductByBarcode", BUSINESS_DETAIL);
		businessCodeMap.put("getProductExperience", BUSINESS_DETAIL);
		businessCodeMap.put("getExperienceRateByPIdMId", BUSINESS_DETAIL);
		businessCodeMap.put("getCategoryByRootCategoryId", BUSINESS_DETAIL);
		businessCodeMap.put("getCategoryByRootCategoryId", BUSINESS_DETAIL);
		businessCodeMap.put("getMallCategoryByRootCategoryId", BUSINESS_DETAIL);
		businessCodeMap.put("getBrandByCategoryId", BUSINESS_DETAIL);
		businessCodeMap.put("getNavigationCategoryByRootCategoryId", BUSINESS_DETAIL);
		
		businessCodeMap.put("addFeedback", BUSINESS_WL);
		businessCodeMap.put("getHomeSelection", BUSINESS_WL);
		businessCodeMap.put("getHomeHotElement", BUSINESS_WL);
		businessCodeMap.put("getHomeModuleList", BUSINESS_WL);
		businessCodeMap.put("getQualityAppList", BUSINESS_WL);
		businessCodeMap.put("getCouponActivityDetailDescription", BUSINESS_WL);
		businessCodeMap.put("receiveCouponByActivityId", BUSINESS_WL);
		businessCodeMap.put("getCouponActivityVOByPromotionId", BUSINESS_WL);
		businessCodeMap.put("monkeyGetExtratCouponResult", BUSINESS_WL);
		businessCodeMap.put("monkeyGetCouponCheckCode", BUSINESS_WL);
		businessCodeMap.put("monkeyVerifyCouponCheckCode", BUSINESS_WL);
		businessCodeMap.put("monkeyCheckMobileNumber", BUSINESS_WL);
		businessCodeMap.put("monkeyInsertAddress", BUSINESS_WL);
		businessCodeMap.put("CUPSignature", BUSINESS_WL);
		businessCodeMap.put("aliPaySignature", BUSINESS_WL);
		businessCodeMap.put("aliPaySignatureV2", BUSINESS_WL);
		businessCodeMap.put("getHomeHotProductTop5List", BUSINESS_WL);
		businessCodeMap.put("getHomeHotPointList", BUSINESS_WL);
		businessCodeMap.put("getHotProductByActivityID", BUSINESS_WL);
		businessCodeMap.put("getPromotionProductPage", BUSINESS_WL);
		businessCodeMap.put("getHotProductPageByCategoryId", BUSINESS_WL);
		businessCodeMap.put("getHotProductCountByCategoryId", BUSINESS_WL);
		businessCodeMap.put("getHotRandomProducts", BUSINESS_WL);
		businessCodeMap.put("getAdvertisementList", BUSINESS_WL);
		businessCodeMap.put("getUserInterestedProducts", BUSINESS_WL);
		businessCodeMap.put("getMoreInterestedProducts", BUSINESS_WL);
		businessCodeMap.put("getUserBehavior", BUSINESS_WL);
		businessCodeMap.put("getUserInterestedProductsCategorys", BUSINESS_WL);
		businessCodeMap.put("getPromotionByTopicID", BUSINESS_WL);
		businessCodeMap.put("getRockProductList", BUSINESS_WL);
		businessCodeMap.put("rockRock", BUSINESS_WL);
		businessCodeMap.put("getRockResult", BUSINESS_WL);
		businessCodeMap.put("getHomeHotPointListNew", BUSINESS_WL);
		businessCodeMap.put("getCmsPageList", BUSINESS_WL);
		businessCodeMap.put("getCmsColumnList", BUSINESS_WL);
		businessCodeMap.put("getCmsColumnListV2", BUSINESS_WL);
		businessCodeMap.put("getCmsColumnByColumnById", BUSINESS_WL);
		businessCodeMap.put("getHotPointNewVOById", BUSINESS_WL);
		businessCodeMap.put("getCmsAdvertisingPromotion", BUSINESS_WL);
		businessCodeMap.put("createRockGame", BUSINESS_WL);
		businessCodeMap.put("getRockGameByToken", BUSINESS_WL);
		businessCodeMap.put("getPresentsByToken", BUSINESS_WL);
		businessCodeMap.put("createRockGameFlow", BUSINESS_WL);
		businessCodeMap.put("processGameFlow", BUSINESS_WL);
		businessCodeMap.put("getRockGameProductVO", BUSINESS_WL);
		businessCodeMap.put("checkResult", BUSINESS_WL);
		businessCodeMap.put("getRockResultV2", BUSINESS_WL);
		businessCodeMap.put("getRockResultV3", BUSINESS_WL);
		businessCodeMap.put("getAwardsResults", BUSINESS_WL);
		businessCodeMap.put("getMyStorageBoxList", BUSINESS_WL);
		businessCodeMap.put("addStorageBox", BUSINESS_WL);
		businessCodeMap.put("checkRockResult", BUSINESS_WL);
		businessCodeMap.put("isCanInviteeUser", BUSINESS_WL);
		businessCodeMap.put("addCouponByActivityId", BUSINESS_WL);
		businessCodeMap.put("getAdvertisingPromotionVOByType", BUSINESS_WL);
		businessCodeMap.put("updateStroageBoxProductType", BUSINESS_WL);
		businessCodeMap.put("updateStroageBoxProductForDelAll", BUSINESS_WL);
		businessCodeMap.put("pushCouponMsg", BUSINESS_WL);
		businessCodeMap.put("preSeckillProduct", BUSINESS_WL);
		businessCodeMap.put("seckillProduct", BUSINESS_WL);
		businessCodeMap.put("getSeckillProductList", BUSINESS_WL);
		businessCodeMap.put("checkIfSecKill", BUSINESS_WL);
		businessCodeMap.put("checkIfSecKillForList", BUSINESS_WL);
		businessCodeMap.put("checkSeckillCanBuy", BUSINESS_WL);
		businessCodeMap.put("getServerTimeStamp", BUSINESS_WL);
		businessCodeMap.put("getClientApplicationDownloadUrl", BUSINESS_WL);
		businessCodeMap.put("registerLaunchInfo", BUSINESS_WL);
		businessCodeMap.put("getProductQRcode", BUSINESS_WL);
		businessCodeMap.put("doTracking", BUSINESS_WL);
		businessCodeMap.put("getStartupPicVOList", BUSINESS_WL);
		businessCodeMap.put("insertAppErrorLog", BUSINESS_WL);
		businessCodeMap.put("enableDeviceForPushMsg", BUSINESS_WL);
		businessCodeMap.put("getCouponActivityDetailDescription", BUSINESS_WL);
		businessCodeMap.put("receiveCouponByActivityId", BUSINESS_WL);
		businessCodeMap.put("getCouponActivityVOByPromotionId", BUSINESS_WL);
		businessCodeMap.put("getHomePagePromotionList", BUSINESS_WL);
		businessCodeMap.put("getHomeBannerPage", BUSINESS_WL);
		businessCodeMap.put("getHomeFloorList", BUSINESS_WL);
		businessCodeMap.put("getBottomPage", BUSINESS_WL);
		businessCodeMap.put("getCalendarBuyList", BUSINESS_WL);
		businessCodeMap.put("getCalendarBuyDetail", BUSINESS_WL);
		businessCodeMap.put("getCalendarBuyProduct", BUSINESS_WL);
		businessCodeMap.put("getCmsPromotionVO", BUSINESS_WL);
		businessCodeMap.put("getBrandFlagshipPromotion", BUSINESS_WL);
		businessCodeMap.put("getCmsColumnDetail", BUSINESS_WL);
		businessCodeMap.put("getDailyTimeVO", BUSINESS_WL);
		businessCodeMap.put("getPromotionSortAttributes", BUSINESS_WL);
		businessCodeMap.put("getLiteCmsPromotion", BUSINESS_WL);
		businessCodeMap.put("getIndexProfile", BUSINESS_WL);
		businessCodeMap.put("getCalendarProfile", BUSINESS_WL);
		businessCodeMap.put("getCalendarDetailProfile", BUSINESS_WL);
		businessCodeMap.put("getViewProfile", BUSINESS_WL);
		businessCodeMap.put("getDailyOneProfile", BUSINESS_WL);
		businessCodeMap.put("getActivityProductList", BUSINESS_WL);
		businessCodeMap.put("miracleAutoRegister", BUSINESS_WL);
		businessCodeMap.put("getPackageProducts", BUSINESS_WL);
		businessCodeMap.put("getYhbByCategoryId", BUSINESS_WL);
		businessCodeMap.put("getYhbPageByCategoryId", BUSINESS_WL);
		businessCodeMap.put("pushActivityMsg", BUSINESS_WL);
		businessCodeMap.put("pushOrderPayInfoMsg", BUSINESS_WL);
		businessCodeMap.put("pushOrderDeliveryInfoMsg", BUSINESS_WL);
		
		businessCodeMap.put("getAllProvince", BUSINESS_MYYHD);
		businessCodeMap.put("getCityByProvinceId", BUSINESS_MYYHD);
		businessCodeMap.put("getCountyByCityId", BUSINESS_MYYHD);
		businessCodeMap.put("getGoodReceiverListByToken", BUSINESS_MYYHD);
		businessCodeMap.put("updateGoodReceiverByToken", BUSINESS_MYYHD);
		businessCodeMap.put("insertGoodReceiverByToken", BUSINESS_MYYHD);
		businessCodeMap.put("deleteGoodReceiverByToken", BUSINESS_MYYHD);
		businessCodeMap.put("getMyFavoriteList", BUSINESS_MYYHD);
		businessCodeMap.put("addFavorite", BUSINESS_MYYHD);
		businessCodeMap.put("delFavorite", BUSINESS_MYYHD);
		businessCodeMap.put("getUnreadMessageCount", BUSINESS_MYYHD);
		businessCodeMap.put("getMessageList", BUSINESS_MYYHD);
		businessCodeMap.put("getMessageDetailById", BUSINESS_MYYHD);
		businessCodeMap.put("deleteMessageById", BUSINESS_MYYHD);
		businessCodeMap.put("getMyOrderListByToken", BUSINESS_MYYHD);
		businessCodeMap.put("getMyOrderListByTokenEx", BUSINESS_MYYHD);
		businessCodeMap.put("getOrderDetailByOrderId", BUSINESS_MYYHD);
		businessCodeMap.put("getOrderDetailByOrderIdEx", BUSINESS_MYYHD);
		businessCodeMap.put("cancelOrder", BUSINESS_MYYHD);
		businessCodeMap.put("rebuyOrder", BUSINESS_MYYHD);
		businessCodeMap.put("getOrderStatusHeader", BUSINESS_MYYHD);
		businessCodeMap.put("getOrderStatusTrack", BUSINESS_MYYHD);
		businessCodeMap.put("getMyOrderCount", BUSINESS_MYYHD);
		businessCodeMap.put("updateOrderFinish", BUSINESS_MYYHD);
		businessCodeMap.put("saveGateWayToOrder", BUSINESS_MYYHD);
		businessCodeMap.put("getLogisticByToken", BUSINESS_MYYHD);
		businessCodeMap.put("getBoughtProductList", BUSINESS_MYYHD);
		businessCodeMap.put("getMyYihaodianSessionUser", BUSINESS_MYYHD);
		businessCodeMap.put("getSessionUser", BUSINESS_MYYHD);
		businessCodeMap.put("changeProvince", BUSINESS_MYYHD);
		businessCodeMap.put("getUserAcountLogList", BUSINESS_MYYHD);
		businessCodeMap.put("isBindMobile", BUSINESS_MYYHD);
		businessCodeMap.put("sendValidateCodeForBindMobile", BUSINESS_MYYHD);
		businessCodeMap.put("bindMobileValidate", BUSINESS_MYYHD);
		businessCodeMap.put("getUserAccout", BUSINESS_MYYHD);
		businessCodeMap.put("getMyCouponList", BUSINESS_MYYHD);
		businessCodeMap.put("verifyCouponActiveCode", BUSINESS_MYYHD);
		businessCodeMap.put("getUserPointLogList", BUSINESS_MYYHD);
		businessCodeMap.put("submitNewNickname", BUSINESS_MYYHD);
		businessCodeMap.put("submitUserPhoto", BUSINESS_MYYHD);
		businessCodeMap.put("getAddedVoucherInfo", BUSINESS_MYYHD);
		businessCodeMap.put("submitReturnForm", BUSINESS_MYYHD);
		businessCodeMap.put("getReturnProgessListByOrderId", BUSINESS_MYYHD);
		businessCodeMap.put("getIsCanReturnByOrderId", BUSINESS_MYYHD);
		businessCodeMap.put("getProductReturnInfo", BUSINESS_MYYHD);
		businessCodeMap.put("getReturnReasonAndType", BUSINESS_MYYHD);
		businessCodeMap.put("getReturnInventory", BUSINESS_MYYHD);
		businessCodeMap.put("uploadPicForReturn", BUSINESS_MYYHD);
		
		businessCodeMap.put("getCurrentGrouponList", BUSINESS_GROUPON);
		businessCodeMap.put("getGrouponCategoryList", BUSINESS_GROUPON);
		businessCodeMap.put("getGrouponDetail", BUSINESS_GROUPON);
		businessCodeMap.put("getGrouponAreaList", BUSINESS_GROUPON);
		businessCodeMap.put("createGrouponOrder", BUSINESS_GROUPON);
		businessCodeMap.put("submitGrouponOrder", BUSINESS_GROUPON);
		businessCodeMap.put("getMyGrouponList", BUSINESS_GROUPON);
		businessCodeMap.put("getMyGrouponOrder", BUSINESS_GROUPON);
		businessCodeMap.put("getGrouponAreaIdByProvinceId", BUSINESS_GROUPON);
		businessCodeMap.put("saveGateWayToGrouponOrder", BUSINESS_GROUPON);
		businessCodeMap.put("getCurrentGrouponList", BUSINESS_GROUPON);
		businessCodeMap.put("getGroupOnSortAttribute", BUSINESS_GROUPON);
		
		businessCodeMap.put("login", BUSINESS_PASSPORT);
		businessCodeMap.put("loginV2", BUSINESS_PASSPORT);
		businessCodeMap.put("loginV3", BUSINESS_PASSPORT);
		businessCodeMap.put("getVerifyCodeUrl", BUSINESS_PASSPORT);
		businessCodeMap.put("register", BUSINESS_PASSPORT);
		businessCodeMap.put("registerV2", BUSINESS_PASSPORT);
		businessCodeMap.put("registerV3", BUSINESS_PASSPORT);
		businessCodeMap.put("modifyPassword", BUSINESS_PASSPORT);
		businessCodeMap.put("findPasswordByEmail", BUSINESS_PASSPORT);
		businessCodeMap.put("logout", BUSINESS_PASSPORT);
		businessCodeMap.put("unionLogin", BUSINESS_PASSPORT);
		businessCodeMap.put("getUserSitetypeAndAuth", BUSINESS_PASSPORT);
		businessCodeMap.put("updateUserAgreeAuth", BUSINESS_PASSPORT);
		businessCodeMap.put("checkUserName", BUSINESS_PASSPORT);
		businessCodeMap.put("sendValidCodeForPhoneRegister", BUSINESS_PASSPORT);
		businessCodeMap.put("checkValidCodeForPhoneRegister", BUSINESS_PASSPORT);
		businessCodeMap.put("registerForQiji", BUSINESS_PASSPORT);
		businessCodeMap.put("loginV4", BUSINESS_PASSPORT);
		businessCodeMap.put("sendValidCodeForUpdatePassword", BUSINESS_PASSPORT);
		businessCodeMap.put("checkValidCodeForUpdatePassword", BUSINESS_PASSPORT);
		businessCodeMap.put("updatePassword", BUSINESS_PASSPORT);
	}
	
	public static String formatReturnObject(Object returnObject, String methodName) {
		if (returnObject instanceof AddOrDeletePromotionResult) {
			AddOrDeletePromotionResult returnObj = (AddOrDeletePromotionResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof AddProductResult) {
			AddProductResult returnObj = (AddProductResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof ExistOptionalResult) {
			ExistOptionalResult returnObj = (ExistOptionalResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof UpadtePromotionResult) {
			UpadtePromotionResult returnObj = (UpadtePromotionResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof UpdateCartResult) {
			UpdateCartResult returnObj = (UpdateCartResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof AddCouponByActivityIdResult) {
			AddCouponByActivityIdResult returnObj = (AddCouponByActivityIdResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof CouponVerifyActiveCodeResult) {
			CouponVerifyActiveCodeResult returnObj = (CouponVerifyActiveCodeResult) returnObject;
			if (returnObj.getSuccessed()) {
				return formatJsonData("0", "", returnObj);
			} else {
				return formatJsonData(getRtnCode(methodName, ERROR_OTHER), returnObj.getErrorInfo(), "");
			}
		} else if (returnObject instanceof ReceiveResult) {
			ReceiveResult returnObj = (ReceiveResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getResultInfo(), returnObject, methodName);
		} else if (returnObject instanceof GrouponOrderSubmitResult) {
			GrouponOrderSubmitResult returnObj = (GrouponOrderSubmitResult) returnObject;
			if (!returnObj.isHasError()) {
				return formatJsonData("0", "", returnObj);
			} else {
				return formatJsonData(getRtnCode(methodName, ERROR_OTHER), returnObj.getErrorInfo(), "");
			}
		} else if (returnObject instanceof GrouponOrderVO) {
			GrouponOrderVO returnObj = (GrouponOrderVO) returnObject;
			if (!returnObj.getHasError()) {
				return formatJsonData("0", "", returnObj);
			} else {
				return formatJsonData(getRtnCode(methodName, ERROR_OTHER), returnObj.getErrorInfo(), "");
			}
		} else if (returnObject instanceof MiracleRegisterResult) {
			MiracleRegisterResult returnObj = (MiracleRegisterResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getResultInfo(), returnObject, methodName);
		} else if (returnObject instanceof CheckSmsResult) {
			CheckSmsResult returnObj = (CheckSmsResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof CouponDeleteResult) {
			CouponDeleteResult returnObj = (CouponDeleteResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof CouponGetCheckCodeResult) {
			CouponGetCheckCodeResult returnObj = (CouponGetCheckCodeResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof CouponSaveResult) {
			CouponSaveResult returnObj = (CouponSaveResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof CouponVerifyCheckCodeResult) {
			CouponVerifyCheckCodeResult returnObj = (CouponVerifyCheckCodeResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof CreateOrderResult) {
			CreateOrderResult returnObj = (CreateOrderResult) returnObject;
			if (returnObj.getResultCode() == 1) {
				return formatJsonData("0", "", returnObj);
			} else if (returnObj.getResultCode() == 0){
				return formatJsonData(getRtnCode(methodName, ERROR_OTHER), returnObj.getErrorInfo(), "");
			} else {
				return formatJsonData(returnObj.getResultCode().toString(), returnObj.getErrorInfo(), returnObj);
			}
		} else if (returnObject instanceof SaveGateWayToOrderResult) {
			SaveGateWayToOrderResult returnObj = (SaveGateWayToOrderResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof SaveGoodReceiverResult) {
			SaveGoodReceiverResult returnObj = (SaveGoodReceiverResult) returnObject;
			if (returnObj.getResultCode() == 1) {
				return formatJsonData("0", "", returnObj);
			} else if (returnObj.getResultCode() == 0){
				return formatJsonData(getRtnCode(methodName, ERROR_OTHER), returnObj.getErrorInfo(), "");
			} else {
				return formatJsonData(returnObj.getResultCode().toString(), returnObj.getErrorInfo(), returnObj);
			}
		} else if (returnObject instanceof SavePayByAccountResult) {
			SavePayByAccountResult returnObj = (SavePayByAccountResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof SendValidCodeResult) {
			SendValidCodeResult returnObj = (SendValidCodeResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof SubmitOrderResult) {
			SubmitOrderResult returnObj = (SubmitOrderResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof AddStorageBoxResult) {
			AddStorageBoxResult returnObj = (AddStorageBoxResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof AwardsResult) {
			AwardsResult returnObj = (AwardsResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof InviteeResult) {
			InviteeResult returnObj = (InviteeResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof SeckillCanBuyResult) {
			SeckillCanBuyResult returnObj = (SeckillCanBuyResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getResultInfo(), returnObject, methodName);
		} else if (returnObject instanceof UpdateStroageBoxResult) {
			UpdateStroageBoxResult returnObj = (UpdateStroageBoxResult) returnObject;
			if ("1".equals(returnObj.getErrorCode())) {
				return formatJsonData("0", "", returnObject);
			} else if ("0".equals(returnObj.getErrorCode())) {
				return formatJsonData(getRtnCode(methodName, ERROR_OTHER), returnObj.getErrorInfo(), "");
			} else {
				return formatJsonData(returnObj.getErrorCode(), returnObj.getErrorInfo(), "");
			}
		} else if (returnObject instanceof BindMobileResult) {
			BindMobileResult returnObj = (BindMobileResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof CheckUserNameResult) {
			CheckUserNameResult returnObj = (CheckUserNameResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof CheckValidCodeForPhoneRegisterResult) {
			CheckValidCodeForPhoneRegisterResult returnObj = (CheckValidCodeForPhoneRegisterResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof CheckValidCodeResult) {
			CheckValidCodeResult returnObj = (CheckValidCodeResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof LoginResult) {
			LoginResult returnObj = (LoginResult) returnObject;
			if (returnObj.getResultCode().intValue() == 1) {
				return formatJsonData("0", "", returnObject);
			} else if (returnObj.getResultCode().intValue() == 0) {
				return formatJsonData(getRtnCode(methodName, ERROR_OTHER), returnObj.getErrorInfo(), "");
			} else {
				return formatJsonData(returnObj.getResultCode()+"", returnObj.getErrorInfo(), returnObject);
			}
		} else if (returnObject instanceof PushMappingResult) {
			PushMappingResult returnObj = (PushMappingResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof RegisterQijiResult) {
			RegisterQijiResult returnObj = (RegisterQijiResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getInfo(), returnObject, methodName);
		} else if (returnObject instanceof RegisterResult) {
			RegisterResult returnObj = (RegisterResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof SendBindValidateCodeResult) {
			SendBindValidateCodeResult returnObj = (SendBindValidateCodeResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof SendValidCodeForPhoneRegisterResult) {
			SendValidCodeForPhoneRegisterResult returnObj = (SendValidCodeForPhoneRegisterResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof com.yihaodian.mobile.vo.user.SendValidCodeResult) {
			com.yihaodian.mobile.vo.user.SendValidCodeResult returnObj = (com.yihaodian.mobile.vo.user.SendValidCodeResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof UpdatePasswordResult) {
			UpdatePasswordResult returnObj = (UpdatePasswordResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof UpdateUserAgreeAuthResult) {
			UpdateUserAgreeAuthResult returnObj = (UpdateUserAgreeAuthResult) returnObject;
			return processResult(returnObj.getResultCode(), returnObj.getErrorInfo(), returnObject, methodName);
		} else if (returnObject instanceof Integer) {
			if ("getUnreadMessageCount".equals(methodName)
					|| "getUserSitetypeAndAuth".equals(methodName)) {
				return formatJsonData("0", "", returnObject);
			}
			return processResult(returnObject+"", methodName);
		} else if (returnObject instanceof Long) {
			if ("saveGateWayToGrouponOrder".equals(methodName)) {
				return processResult(returnObject+"", methodName);
			}
			return formatJsonData("0", "", returnObject);
		} else {
			return formatJsonData("0", "", returnObject);
		}
	}
	
	public static String formatReturnErr(String methodName, String errorType) {
		return formatJsonData(getRtnCode(methodName, errorType), "", "");
	}
	
	private static String processResult(int resultCode, String errorInfo, Object returnObject, String methodName) {
		if (resultCode == 1) {
			return formatJsonData("0", "", returnObject);
		} else if (resultCode == 0){
			return formatJsonData(getRtnCode(methodName, ERROR_OTHER), errorInfo, "");
		} else {
			return formatJsonData(resultCode+"", errorInfo, "");
		}
	}
	
	private static String processResult(String result, String methodName) {
		if ("1".equals(result)) {
			return formatJsonData("0", "", "");
		} else if ("0".equals(result)){
			return formatJsonData(getRtnCode(methodName, ERROR_OTHER), "", "");
		} else {
			return formatJsonData(result, "", "");
		}
	}
	
	private static String formatJsonData(String rtnCode, String rtnMsg, Object returnObject) {
		StringBuffer returnString = new StringBuffer();
		returnString.append("{\"rtn_code\":\"").append(rtnCode).append(
				"\",\"rtn_msg\":\"").append(rtnMsg).append("\",\"data\":")
				.append(JSON.toJSONString(returnObject)).append("}");
		return returnString.toString();
	}
	
	private static String getRtnCode(String methodName, String errorType) {
		return businessCodeMap.get(methodName) + "0000" + errorType;
	}
}
