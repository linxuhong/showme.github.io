package com.yihaodian.mobile.service.common.business.util.user;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yhd.api.common.client.RecommenderClientService;
import com.yhd.model.Pair;
import com.yhd.model.RequestParameter;
import com.yhd.model.UserAppreciateCollectionResult;
import com.yhd.model.UserAppreciateType;
import com.yhd.model.UserProfileType;
import com.yhd.userProfile.explicity.UserExplicityProfile;
import com.yihaodian.front.user.common.model.EndUser;
import com.yihaodian.mobile.service.domain.vo.business.user.questionnaire.QuestionnaireUserVO;
import com.yihaodian.trial.client.common.TrialServiceHandler;
import com.yihaodian.trial.client.service.baobao.TrialBaoBaoClientService;
import com.yihaodian.trial.common.basic.TrialReturn;

/**
 * 
 * @author zhangwei5
 * @version $Id: UserExplicityServiceUtil.java, v 0.1 2014年7月22日 下午2:14:29 zhangwei5 Exp $
 */
public class UserExplicityProfileServiceUtil {

    private static Logger logger = LoggerFactory.getLogger(UserExplicityProfileServiceUtil.class);
    
    /**
     * 投放人群类型 1:新客 2：丽人 3：辣妈 4：男人 5:全部
     */
    
    /**
     * 查询用户问卷信息
     * @param userId
     * @return
     */
    public static QuestionnaireUserVO getQuestionnaireInfo(Long userId){
        
        QuestionnaireUserVO questionnaireUserVO = new QuestionnaireUserVO();
        try {
            //首先得到性别信息
            EndUser user = GUSUtil.getUserByGus(userId);
            if(user!=null){
                questionnaireUserVO.setEndUserSex(user.getEndUserSex());
                //得到宝宝中心信息
                questionnaireUserVO.setHasBabyInfo(getBabyInfo(userId));
            }
            
        } catch (Exception e) {
            logger.error("getQuestionnaireInfo has error ", e);
        }
        return questionnaireUserVO;
    }
    
    /**
     * 查询用户类型，优先通过问卷信息判断，用户信息没有则通过精准化服务查询
     * @param userId
     * @return
     */
    public static Integer checkUserExplicityProfile(Long userId){
        try {
            QuestionnaireUserVO userQuInfo= getQuestionnaireInfo(userId);
            if(userQuInfo!=null&&userQuInfo.getEndUserSex()!=null){
                //有宝宝且为女性则返回辣妈
                if(userQuInfo.getHasBabyInfo()!=null&&(userQuInfo.getHasBabyInfo()==0||userQuInfo.getHasBabyInfo()==1)){
                    if(userQuInfo.getEndUserSex()==1){
                        return 3;   
                    }else{
                        return 4;
                    }
                }else{
                    if(userQuInfo.getEndUserSex()==1){
                        return 2;   
                    }else{
                        return 4;
                    } 
                }
            }else{
                //如果问卷信息不全则调用精准化服务查询用户类型
                return getUserUserExplicityProfile(userQuInfo.getUserId());
            }
        } catch (Exception e) {
            logger.error("checkUserExplicity has error ", e);
        }
        //默认返回新客
        return 1;
    }
    
    private static Integer getUserUserExplicityProfile(Long userId){
        try {
            UserExplicityProfile userExplicityProfile = RecommenderClientService.getUserExplicityProfile();

            RequestParameter requestParameter = new RequestParameter();
            requestParameter.setUserId(userId);//用户Id（可选）
            requestParameter.setUserAppreciateType(UserAppreciateType.USER_TAG);
            requestParameter.setUserProfileType(UserProfileType.BASE);
            UserAppreciateCollectionResult result = userExplicityProfile.getTopUserAppreciate(requestParameter);
            if(result.getUserAppreciateResult()!=null&&result.getUserAppreciateResult().getUserTagList()!=null){
                List<Pair<String, String>> list = result.getUserAppreciateResult().getUserTagList();
                for (Pair<String, String> pair : list) {
                    String userProperty = pair.getFirst();//用户属性
                    String propertyValue = pair.getSecond(); //属性值
                    if(userProperty.equals("younglady")&&propertyValue.equals("1")){
                        //丽人
                        return 2;
                    }else if(userProperty.equals("mumgroup")&&propertyValue.equals("1")){
                        //辣妈
                        return 3;   
                    }else if(userProperty.equals("genders")&&propertyValue.equals("1")){
                        return 4;   

                    }
                }

            }

        } catch (Exception e) {
            logger.error("getUserUserExplicityProfile has error ", e);
        }
        //默认返回新客
        return 1;
    }
    
    /**
     * 查询用户是否填写了宝宝信息数据
     * @param userId
     * @return -1-未填写;1-已填写
     */
    public static Integer getBabyInfo(Long userId){
        try {
            TrialBaoBaoClientService baobaoservice = TrialServiceHandler.getTrialBaoBaoClientService();
            TrialReturn<Integer> r = baobaoservice.getHasBabyInfoByUserId(userId);
            if(r!=null&&r.getStatus() == 0){
                Integer b= r.getOut();
                return b;
            }
        } catch (Exception e) {
            logger.error("getBabyInfo has error ", e);
        }
        return -1;
    }
}
