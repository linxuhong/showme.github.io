/**
 * 
 */
package com.yihaodian.mobile.service.common.util.my;

import java.io.File;
import java.io.FileNotFoundException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import com.yihaodian.front.global.util.UrlPrefix;
import com.yihaodian.mobile.service.common.util.encrypt.DESPlus;

/**
 * @author weile
 * 
 */
public class MyUploadUtil {
	/**
	 * 图片上传postUrl
	 */
	public final static String UPLOAD_POST_URL = "uploadPostUrl";
	/**
	 * 投诉图片资源类型
	 */
	public final static String RESOURCE_TYPE = "16";
	/**
	 * 头像上传图片资源类型
	 */
	public final static String EDIT_RESOURCE_TYPE = "36";
	/**
	 * 试用中心免费试用上传图片资源类型
	 */
	public final static String TRIAL_RESOURCE_TYPE = "26";
	/**
	 * 投诉图片类型
	 */
	public final static String PIC_TYPE = "16";
	/**
	 * 头像上传图片类型
	 */
	public final static String EDIT_PIC_TYPE = "36";
	/**
	 * 试用中心免费试用上传图片类型
	 */
	public final static String TRIAL_PIC_TYPE = "26";
	/**
	 * 图片空间显示套图类型5为60*60图片
	 */
	public final static String PIC_DISPLAY_TYPE = "5";

	/** 图片空间定义的退换货资源类型 */
	public final static String RETURN_RESOURCE_TYPE = "19";

	/** 图片空间定义的退换货图片类型 */
	public final static String RETURN_PIC_TYPE = "15";

	/**
	 * 节能补贴图片上传图片资源类型
	 * */
	public final static String ENERGY_RESOURCE_TYPE = "32";
	/**
	 * 节能补贴图片上传图片类型
	 * */
	public final static String Energy_PIC_TYPE = "32";
	

	

	/**
	 * 
	 * @Title: uploadFile
	 * @Description: 架构组提供的例子
	 * @param @param file
	 * @param @param filename
	 * @param @param resourceType
	 * @param @param picType
	 * @param @param resourceId
	 * @param @return 设定文件
	 * @author kevin.wang
	 * @return boolean 返回类型
	 * @throws
	 */
	public static String uploadFile(File file, String filename, String resourceType, String picType, String resourceId, Long userId) {
		String userPic = null;
		Long creatorId = userId;
		DESPlus jsonKey = null;
		DESPlus defaultKey = null;
		JSONObject jo = new JSONObject();
		try {
			jsonKey = new DESPlus(String.valueOf(creatorId));
			defaultKey = new DESPlus();
			JSONArray ja = new JSONArray();
			JSONObject jo1 = new JSONObject();
			jo1.put("action", "upload");
			jo1.put("backup", "0");
			jo1.put("name", filename);
			jo1.put("position", "1");
			jo1.put("creator_id", creatorId);
			jo1.put("resource_type", resourceType);
			jo1.put("resource_id", resourceId);
			jo1.put("pic_type", picType);
			jo1.put("mc_site_id", 1);
			jo1.put("auth_server", "backend");
			jo1.put("session", "21169fgjsdsdahf@!@#$7479L");
			JSONArray jb = new JSONArray();
			JSONObject job1 = new JSONObject();
			job1.put("img_scale", "0");
			job1.put("img_wm", "0");
			job1.put("is_major", "1");
			jb.put(job1);
			jo1.put("img_series", jb);
			ja.put(jo1);
			jo.put("items", ja);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		// post
		String postUrl = (String) UrlPrefix.getValues().get(MyUploadUtil.UPLOAD_POST_URL);

		HttpClient client = new HttpClient();
		// 设置相关参数
		client.getHttpConnectionManager().getParams().setConnectionTimeout(20000);
		client.getHttpConnectionManager().getParams().setSoTimeout(20000);

		PostMethod method = null;
		try {
			// 提交url
			String joString = java.net.URLEncoder.encode(jo.toString(), "UTF-8");
			method = new PostMethod(postUrl);
			Part[] parts = { new StringPart("upload_request", jsonKey.encrypt(joString)), new StringPart("creator_id", defaultKey.encrypt(String.valueOf(creatorId))),
					new FilePart(file.getName(), file) };
			method.setRequestEntity(new MultipartRequestEntity(parts, method.getParams()));
			int statusCode = client.executeMethod(method);
			if (HttpStatus.SC_OK == statusCode) {// sc_ok=200
				String returnInfo = method.getResponseBodyAsString();
				if (returnInfo != null && !returnInfo.equalsIgnoreCase("")) {
					JSONObject rjo = new JSONObject(returnInfo);
					JSONArray items = rjo.getJSONArray("upload_response");
					for (int i = 0; i < items.length(); i++) {
						JSONObject to = (JSONObject) items.get(i);
						String result = to.getString("result");
						if ("success".equals(result)) {
							JSONArray details = to.getJSONArray("details");
							JSONObject detail = (JSONObject) details.get(0);
							userPic = detail.getString("url");
						} else {
							break;
						}
					}
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (method != null) {
				method.releaseConnection();
			}
		}
		return userPic;

	}
	
	/**
	 * 删除服务器上的临时保存的问题
	 * 
	 * @param file
	 * @return
	 */
	public static boolean delFile(File file) {
		if (file.exists() && file.isFile()) {
			return file.delete();
		}
		return false;
	}

}
