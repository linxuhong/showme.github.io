package com.yihaodian.mobile.service.common.business.util.promotion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.mobile.service.common.util.MathUtil;
import com.yihaodian.promotion.basic.PromotionReturn;
import com.yihaodian.promotion.client.coupon.handler.CouponServiceHandler;
import com.yihaodian.promotion.client.coupon.service.CouponActivityClientService;
import com.yihaodian.promotion.client.coupon.service.CouponClientService;
import com.yihaodian.promotion.constants.ResultStatusConstants;
import com.yihaodian.promotion.coupon.inputVo.CouponActivityInputVo;
import com.yihaodian.promotion.coupon.inputVo.QueryCouponActiveInfoForShareInputVo;
import com.yihaodian.promotion.coupon.inputVo.QueryShareCouponInputVo;
import com.yihaodian.promotion.coupon.outputVo.CouponActivityOutputVo;
import com.yihaodian.promotion.coupon.outputVo.couponShare.ShareCouponVo;

/**
 * 促销服务--抵用券
 * @author zhangwei5
 * @version $Id: PromotionCouponUtil.java, v 0.1 2014-2-19 下午6:08:55 zhangwei5 Exp $
 */
public class PromotionCouponUtil {
	
	private final static Logger logger = LoggerFactory.getLogger(PromotionCouponUtil.class);

	/**
	 * 抵用券service
	 */
	private static CouponClientService couponClientService;
	private static CouponActivityClientService couponActivityClientService;
	static {
		couponClientService = CouponServiceHandler.getCouponClientService () ;
		couponActivityClientService = CouponServiceHandler.getCouponActivityClientService();
	}
	
	/**
	 * 查询可分享券列表
	 * @param userId 分享着用户id
	 * @param receiveUserId 被分享者用户Id 可为空
	 */
	public static List<ShareCouponVo> getSharableCouponList(Long userId , Long receiveUserId){
		try {
			QueryShareCouponInputVo queryShareCouponInputVo = new QueryShareCouponInputVo();
			queryShareCouponInputVo.setShareUserId(userId);
			if(receiveUserId!=null&&receiveUserId>0){
				queryShareCouponInputVo.setReceiveUserId(receiveUserId);
			}
			//查询得到可分享券列表
			PromotionReturn<List<ShareCouponVo>> result = couponClientService.queryAllValidShareCouponLst(queryShareCouponInputVo);
			
			List<ShareCouponVo> shareCouponVoLst = null;
			
			if(ResultStatusConstants.SUCCESS.equals(result.getStatus())){
				shareCouponVoLst = result.getOut();
			}else{
				//接口查询失败
				logger.error(result.getMessage());
			}
			
			if(CollectionUtils.isNotEmpty(shareCouponVoLst)){
				return shareCouponVoLst;
			}

		} catch (Exception e) {
			logger.error("getSharableCouponList has error ", e);
		}
		return null;
	}
	
	/**
	 * 批量查询抵用券活动信息
	 * @param activeIdList
	 */
	public static Map<Long, CouponActivityOutputVo> querySimpleCouponActiveInfoMapByActiveIdList(
			List<Long> activeIdList) {
		try {
			if (activeIdList != null && activeIdList.size() > 0) {
				Map<Long, CouponActivityOutputVo> resultMap = new HashMap<Long, CouponActivityOutputVo>();
    			//如果长度大于10，则循环获取
    			int count = activeIdList.size()%10==0 ? (activeIdList.size())/10 : (activeIdList.size()/10+1);
    			for(int i=0;i<count;i++){
    				int start = i*10;
    				int end = i==(count-1)? activeIdList.size() : (i+1)*10;
    				List<Long> subList = activeIdList.subList(start, end);
    				// 批量添加activeId
    				List<CouponActivityInputVo> couponActivityInputVoList = new ArrayList<CouponActivityInputVo>();
    				for (Long activeId : subList) {
    					CouponActivityInputVo activeInput = new CouponActivityInputVo(
    							activeId);
    					couponActivityInputVoList.add(activeInput);
    				}
    				// 查询得到抵用券活动详情
    				PromotionReturn<Map<Long, CouponActivityOutputVo>> couponActivityInfoMapRT = couponActivityClientService
    						.querySimpleCouponActiveInfoMapByActiveIdList(couponActivityInputVoList);
    				if (couponActivityInfoMapRT != null
    						&& ResultStatusConstants.SUCCESS
    						.equals(couponActivityInfoMapRT.getStatus())) { 
    					//查询成功
    					Map<Long, CouponActivityOutputVo> output = couponActivityInfoMapRT.getOut(); // 获得业务数据对象
    					resultMap.putAll(output);
    				}else{
    					//查询失败打印错误数据
    					String message = "couponActivityInfoMapRT is null";
    					if(couponActivityInfoMapRT != null){
    						message = couponActivityInfoMapRT.getMessage(); // 获得失败信息
    					}
    					logger.error(message);
    				}
    			}
    		    return resultMap;
			}
		} catch (Exception e) {
			logger.error(" querySimpleCouponActiveInfoMapByActiveIdList has error ", e);
		}
		return null;
	}
	
	/**
     * 
     * @param useScope
     * 适用范围 1：自营，2：商城
     * @param couponType 
     * 抵用券类型 0-全场 1-产品（普通、名品特卖、团购）2-分类 3-品牌 4分类+品牌 5 排除分类 6 免邮券
     * @param merchantId
     * 商家ID -1：商城平台券，!=-1:商城商家券
     * @param mallType
     * 特卖类型 0-普通; 1-名品特卖; 2-团购
     * @param isUsedForMobile
     * 是否手机专享 0-否; 1-是
     * @param isGroupPurchase
     * 是否支持本商家团购商品 0-否; 1-是
     * @return
     */
    public static String composeCouponUseExplain(CouponActivityOutputVo couponActivityOutputVo) {
        try {
            StringBuilder sb = new StringBuilder();
            if(couponActivityOutputVo.getUsedType() == 6){
            	sb.append("免邮券");
            	return sb.toString();
            }
            
            if(couponActivityOutputVo.getIsUsedForMobile() == 1){
            	sb.append("【无线专享】");
            }
            
            if(couponActivityOutputVo.getUseScope() == 1){  //使用范围在1号店 - 1号店券
            	sb.append("1号店-");
            	
            	if(couponActivityOutputVo.getUsedType() == 1){
            		sb.append("指定产品券");
            	}else if(couponActivityOutputVo.getUsedType() == 2){
            		sb.append("指定分类券");
            	}else if(couponActivityOutputVo.getUsedType() == 5){
            		sb.append("排除分类券");
            	}else if(couponActivityOutputVo.getUsedType() == 3){
            		sb.append("指定品牌券");
            	}else if(couponActivityOutputVo.getUsedType() == 4){
            		sb.append("指定分类+品牌券");
            	}
            	
            	sb.append("，不支持团购、闪购、预售、二手品、礼品卡。");
            	return sb.toString();
            }

            if(couponActivityOutputVo.getUseScope() == 2 && couponActivityOutputVo.getMerchantId() == -1L){//平台券: 使用范围在1号商城 且商家为-1时
            	sb.append("平台-");
            		
            	if(couponActivityOutputVo.getUsedType() == 1){
            		if(couponActivityOutputVo.getMallType() == 0){
                		sb.append("指定产品券，不支持团购、闪购、预售、二手品、礼品卡。");
                	}else if(couponActivityOutputVo.getMallType() == 2){//团购券
                		sb.append("团购产品券，只用于团购商品上。");
                	}else if(couponActivityOutputVo.getMallType() == 1){//名品特卖券
                		sb.append("名品特卖产品券，只用于名品特卖商品上。");
                	}
            		return sb.toString();
                }
            		
            	if(couponActivityOutputVo.getUsedType() == 2){
                	sb.append("指定分类券");
                }else if(couponActivityOutputVo.getUsedType() == 5){
                	sb.append("排除分类券");
                }else if(couponActivityOutputVo.getUsedType() == 3){
                	sb.append("指定品牌券");
                }else if(couponActivityOutputVo.getUsedType() == 4){
                	sb.append("指定分类+品牌券");
                }
            		
            	sb.append("，不支持团购、闪购、预售、二手品、礼品卡。");
            		
            	return sb.toString();
            }
            
            if(couponActivityOutputVo.getUseScope() == 2 && couponActivityOutputVo.getMerchantId() !=-1L){//商家券
            	sb.append("商家-");
            	
            	if(couponActivityOutputVo.getUsedType() == 0){
                	sb.append("全场券");
                }else if(couponActivityOutputVo.getUsedType() == 1){
                	sb.append("指定产品券");
                }else if(couponActivityOutputVo.getUsedType() == 3){
                	sb.append("指定品牌券");
                }
            	
            	if(couponActivityOutputVo.getIsGroupPurchase() == 1){
            		sb.append("，支持本商家团购商品，不支持闪购、预售、二手品、礼品卡。");
            	}else{
            		sb.append("，不支持团购、闪购、预售、二手品、礼品卡。");
            	}
            	
            	return sb.toString();
            }
            
		} catch (Exception e) {
			logger.error(" composeCouponUseExplain has error ", e);
		}
        return "";
    }
    
    public static List<ShareCouponVo> queryCouponActiveInfoForShare(Long userId , Long couponId){
    	try {
    		QueryCouponActiveInfoForShareInputVo queryCouponActiveInfoForShareInputVo = new QueryCouponActiveInfoForShareInputVo();
    		queryCouponActiveInfoForShareInputVo.setUserId(userId);
    		List<Long> couponIds = new ArrayList<Long>();
    		couponIds.add(couponId);
    		queryCouponActiveInfoForShareInputVo.setCouponIds(couponIds);
    		PromotionReturn<List<ShareCouponVo>> result = couponClientService.queryCouponActiveInfoForShare(queryCouponActiveInfoForShareInputVo);
    		List<ShareCouponVo> shareCouponVoList = new ArrayList<ShareCouponVo>();
    		
    		if(ResultStatusConstants.SUCCESS.equals(result.getStatus())){
    			shareCouponVoList = result.getOut();
    		}else{
    			//接口查询失败
    			logger.error(result.getMessage());
    		}
    		return shareCouponVoList;
            
		} catch (Exception e) {
			logger.error(" queryCouponActiveInfoForShare has error ", e);		
	    }
    	return null;
    }
    
    /**
     * 批量查询用户抵用券详细信息
     * @param userId
     * @param couponIdList
     * @return
     */
    public static Map<Long , ShareCouponVo> queryCouponActiveInfoForShareList(Long userId , List<Long> couponIdList){
    	try {
    		if(couponIdList!=null&&couponIdList.size()>0){
    			Map<Long , ShareCouponVo> map = new HashMap<Long, ShareCouponVo>();
    			//如果长度大于10，则循环获取
    			int count = couponIdList.size()%10==0 ? (couponIdList.size())/10 : (couponIdList.size()/10+1);
    			for(int i=0;i<count;i++){
    				int start = i*10;
    				int end = i==(count-1)? couponIdList.size() : (i+1)*10;
    				List<Long> subList = couponIdList.subList(start, end);
    				QueryCouponActiveInfoForShareInputVo queryCouponActiveInfoForShareInputVo = new QueryCouponActiveInfoForShareInputVo();
    				queryCouponActiveInfoForShareInputVo.setUserId(userId);
    				queryCouponActiveInfoForShareInputVo.setCouponIds(subList);
    				PromotionReturn<List<ShareCouponVo>> result = couponClientService.queryCouponActiveInfoForShare(queryCouponActiveInfoForShareInputVo);
    				List<ShareCouponVo> shareCouponVoList = new ArrayList<ShareCouponVo>();
    				
    				if(ResultStatusConstants.SUCCESS.equals(result.getStatus())){
    					shareCouponVoList = result.getOut();
    				}else{
    					//接口查询失败
    					logger.error(result.getMessage());
    				}
    				if(shareCouponVoList!=null&&shareCouponVoList.size()>0){
    					for(ShareCouponVo shareCouponVo : shareCouponVoList){
    						map.put(shareCouponVo.getUserCouponInfoVo().getCouponId(), shareCouponVo);
    					}
    				}
    			}
    			return map;
    		}
            
		} catch (Exception e) {
			logger.error(" queryCouponActiveInfoForShare has error ", e);		
	    }
    	return null;
    }
    
    public static String getCouponActivityDesc(CouponActivityOutputVo couponActivityInputInfoVo){
		if(couponActivityInputInfoVo.getUsedType()!=6){
			return getCouponDescription(couponActivityInputInfoVo.getUsedType()) +"满"+MathUtil.formatPrice(couponActivityInputInfoVo.getThresholdAmount().doubleValue())+"抵扣"+MathUtil.formatPrice(couponActivityInputInfoVo.getDeductAmount().doubleValue())+"元";
		}else{
			if(couponActivityInputInfoVo.getIsUsedForMobile()!=null&&couponActivityInputInfoVo.getIsUsedForMobile()==1){
				return "【掌上专享】"+MathUtil.formatPrice(couponActivityInputInfoVo.getDeductAmount().doubleValue())+"元免邮券";									
			}else{
				return MathUtil.formatPrice(couponActivityInputInfoVo.getDeductAmount().doubleValue())+"元免邮券";
			}
		}
    }
    
	private static String getCouponDescription(int type){
		if(type==0){
			return "全场商品";
		}else if(type==1||type==5){
			return "指定商品";
		}else if(type==2){
			return "指定分类";
		}else if(type==3||type==4){
			return "指定品牌";
		}else if (type==6){
			return "免邮券";
		}else {
			return "";
		}
	}
}
