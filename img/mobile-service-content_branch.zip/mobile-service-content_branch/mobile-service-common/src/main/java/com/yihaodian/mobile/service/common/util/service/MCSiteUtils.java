package com.yihaodian.mobile.service.common.util.service;

import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;

public class MCSiteUtils {

    public static Long getMCSiteId() {
        Long mcsiteid = 1L;
        String str = YccGlobalPropertyConfigurer.getPropertyByKey("remoteServiceMobile.properties",
            "mcsiteid");
        if (str == null) {
            mcsiteid = 1L;
        } else {
            mcsiteid = Long.parseLong(str);
            if (mcsiteid < 1 || mcsiteid > 2) {
                mcsiteid = 1L;
            }
        }
        return mcsiteid;
    }
}
