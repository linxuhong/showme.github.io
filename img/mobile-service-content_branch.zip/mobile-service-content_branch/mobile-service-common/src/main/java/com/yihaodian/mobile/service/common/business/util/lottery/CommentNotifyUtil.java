package com.yihaodian.mobile.service.common.business.util.lottery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.sby.app.cmt.hedwig.factory.CmtGiftServiceFactory;
import com.yihaodian.sby.app.cmt.hedwig.service.spi.CommentNotifyService;
import com.yihaodian.sby.app.cmt.hedwig.service.spi.enums.SiteIdEnum;
import com.yihaodian.sby.app.cmt.hedwig.service.spi.model.LotteryProvide;
import com.yihaodian.sby.app.cmt.hedwig.service.spi.resultVo.LoginProvideResult;

/**
 * userToken获取sessionId方法
 * @author zhangwei5
 * @version $Id: CommentNotifyUtil.java, v 0.1 2014-4-26 下午1:36:22 zhangwei5 Exp $
 */
public class CommentNotifyUtil {

    private static Logger logger = LoggerFactory.getLogger(CommentNotifyUtil.class);

    /**
     * 通过得到虚拟业务的sessionId
     * @param userToken
     * @param code
     * @param userId
     * @return
     */
    public static String getSessionId(String userToken, SiteIdEnum code, Long userId) {
        try {
            LotteryProvide lotteryPrivide = new LotteryProvide();
            lotteryPrivide.setSiteId(code); //siteId枚举类
            lotteryPrivide.setEndUserId(userId); //用户id
            lotteryPrivide.setEndUserUt(userToken);
            // usertoken
            CommentNotifyService commentNotifyService = CmtGiftServiceFactory
                .getCommentNotifyService();
            LoginProvideResult vo = commentNotifyService.findSessionIdByUserId(lotteryPrivide);
            //取sessionId
            String sessionId = vo.getSessionId();
            return sessionId;
        } catch (Exception e) {
            logger.error("getSessionId has error ", e);
        }
        return "";
    }
}
