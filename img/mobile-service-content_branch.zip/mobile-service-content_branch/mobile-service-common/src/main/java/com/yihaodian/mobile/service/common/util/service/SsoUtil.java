package com.yihaodian.mobile.service.common.util.service;

import org.apache.log4j.Logger;

import com.yihaodian.front.sso.client.util.SsoClientCacheUtil;
import com.yihaodian.front.sso.common.enums.McSiteIdEnum;
import com.yihaodian.front.sso.common.enums.UserTypeEnum;
import com.yihaodian.front.sso.common.vo.SsoUser;

/**
 * sso工具类
 * @author zhangwei5
 * @version $Id: SsoUtil.java, v 0.1 2013-12-10 下午2:48:06 zhangwei5 Exp $
 */
public class SsoUtil {

	private static Logger logger = Logger.getLogger(SsoUtil.class);
	
	/**
	 * 根据token获取当前登录用户Id
	 * @param token
	 * @return
	 */
	public static Long getCurrentMobileLoginUserId(String token){
		try {
			//通过
			SsoUser ssoUser = SsoClientCacheUtil.getSsoUser(token, UserTypeEnum.FRONT_USER,McSiteIdEnum.YHD );
			if(ssoUser==null){
				return null;
			}
			Long userId = ssoUser.getId();
			if(userId==null||userId<=0l){
				return null;
			}
			return userId;
		} catch (Exception e) {
			logger.error("getCurrentMobileLoginUserId has error ", e);
		}
		return null;
	}
	
	/**
	 * 根据token获取当前登录用户信息
	 * @param token
	 * @return
	 */
	public static SsoUser getCurrentMobileLoginUserInfo(String token){
		try {
			//通过
			SsoUser ssoUser = SsoClientCacheUtil.getSsoUser(token, UserTypeEnum.FRONT_USER,McSiteIdEnum.YHD);
			if(ssoUser==null||ssoUser.getId()<=0l){
				return null;
			}
			return ssoUser;
		} catch (Exception e) {
			logger.error("getCurrentMobileLoginUserId has error ", e);
		}
		return null;
	}
	
	/**
	 * 获取微店用户Id
	 * @param token
	 * @return
	 */
	public static Long getCurrentMobileLoginVUserId(String token){
		try {
			//通过
			SsoUser ssoUser = SsoClientCacheUtil.getSsoUser(token, UserTypeEnum.FRONT_USER,McSiteIdEnum.YHD);
			if(ssoUser==null){
				return null;
			}
			Long userId = ssoUser.getId();
			if(userId==null||userId<=0l){
				return null;
			}
			return userId;
		} catch (Exception e) {
			logger.error("getCurrentMobileLoginVUserId has error ", e);
		}
		return null;
	}

}
