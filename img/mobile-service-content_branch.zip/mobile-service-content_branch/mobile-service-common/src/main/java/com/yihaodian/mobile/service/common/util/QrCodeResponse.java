package com.yihaodian.mobile.service.common.util;

public class QrCodeResponse {
	private String message = null;
	private String resultCode = null;
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

}
