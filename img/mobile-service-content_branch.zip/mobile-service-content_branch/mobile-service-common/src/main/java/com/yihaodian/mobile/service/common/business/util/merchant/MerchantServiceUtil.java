package com.yihaodian.mobile.service.common.business.util.merchant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.yhd.pss.spi.common.vo.Response;
import com.yhd.pss.spi.merchant.service.QueryMerchantRemoteService;
import com.yhd.pss.spi.merchant.vo.Merchant;
import com.yhd.pss.spi.merchant.vo.input.QueryBaseMerchantByIdRequest;
import com.yhd.pss.spi.merchant.vo.input.QueryMerchantIdMapProvinceIdsByMerchantIdsRequest;
import com.yhd.pss.spi.merchant.vo.input.QueryProvinceIdByMerchantIdRequest;
import com.yhd.pss.spi.merchant.vo.input.QueryVipMerchantByProvinceIdRequest;
import com.yhd.store.decorate.model.StoreReturn;
import com.yhd.store.decorate.model.output.GenericStoreDto;
import com.yhd.store.decorate.service.GenericStoreClientService;
import com.yhd.store.decorate.util.GenericStoreServiceUtil;
import com.yihaodian.mobile.common.ex.CentralMobileParamsException;
import com.yihaodian.mobile.service.common.util.service.MemcachedProxy;
import com.yihaodian.mobile.service.domain.business.emuns.MerchantInfoCode;
import com.yihaodian.mobile.vo.constant.CommonKey;
import com.yihaodian.pss.client.PssClient;
import com.yihaodian.pss.client.PssClientConfiguration;
import com.yihaodian.store.client.remote.store.MerchantStoreRemoteClient;
import com.yihaodian.store.dto.MerchantStoreParamDto;
import com.yihaodian.store.dto.MerchantStoreResultDto;

public class MerchantServiceUtil {

    private static Logger logger = LoggerFactory.getLogger(MerchantServiceUtil.class);
    
    private static QueryMerchantRemoteService queryMerchantRemoteService = null;
    
    private static MerchantStoreRemoteClient merchantStoreRemoteClient = null;
    
    private static GenericStoreClientService genericStoreClientService = null;
    
    static{
         queryMerchantRemoteService = PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getQueryMerchantRemoteService();
         merchantStoreRemoteClient = new MerchantStoreRemoteClient();
         genericStoreClientService = GenericStoreServiceUtil.getInstance(GenericStoreClientService.class);
    }
    
    /**
     * 通过上架Id查询商家详情
     * @param merchantId
     * @return
     */
    public static Merchant  queryBaseMerchantById(Long merchantId){
        try {
            String key = new StringBuffer("queryBaseMerchantById_").append(merchantId).toString();
            MemcachedProxy me = MemcachedProxy.getInstance();
            Object obj = me.get(key);
            if(obj!=null){
                return (Merchant) obj;
            }
            QueryBaseMerchantByIdRequest request = new QueryBaseMerchantByIdRequest();
            request.setMerchantId(merchantId);
            Response<Merchant> response = queryMerchantRemoteService.queryBaseMerchantById(request);
             if(response!=null&&response.getResult()!=null){
                Merchant merchant = response.getResult();
                me.put(key, merchant, CommonKey.MEMCACHE_INVALID_TIME_ONE_HOUR);
                return merchant;
             }
        } catch (Exception e) {
            logger.error("queryBaseMerchantById", e);
        }   
         return new Merchant();
    }
    
    /**
     * 通过省份获取VIP商家 --默认返回上海
     * @param provinceId
     * @return
     */
    public static Long getVipMerchantId(Long provinceId){
        try {
            String key = new StringBuffer("getVipMerchantId_").append(provinceId).toString();
            MemcachedProxy me = MemcachedProxy.getInstance();
            Object obj = me.get(key);
            if(obj!=null){
                return (Long) obj;
            }
            QueryVipMerchantByProvinceIdRequest request = new QueryVipMerchantByProvinceIdRequest();
            request.setProvinceId(provinceId.intValue());
            request.setMcsiteId(1l);
            Response<List<Merchant>> vipMerchantResponse = queryMerchantRemoteService.queryVipMerchantByProvinceId(request);
            if(vipMerchantResponse!=null&&vipMerchantResponse.getResult()!=null){
                //暂时只取第一个VIP商家
                List<Merchant> merchantList = vipMerchantResponse.getResult();
                if(merchantList!=null&&merchantList.size()>0){
                    Merchant merchant = merchantList.get(0);
                    Long vipMerchantId = merchant.getId();
                    me.put(key, vipMerchantId, CommonKey.MEMCACHE_INVALID_TIME_ONE_HOUR);                    
                    return vipMerchantId;
                }
            }
        } catch (Exception e) {
            logger.error("getVipMerchantId has error ", e);
        }
        return MerchantInfoCode.VIP_MERCHANT_SHANGHAI.getCode();
    }
    
    /**
     * 检查指定商家列表是否支持当前省份
     * @param provinceId
     * @return
     */
    public static Boolean checkMerchantIdProvinceId(Long provinceId,List<Long> merchantIds){
        try {
            if(provinceId!=null&&!CollectionUtils.isEmpty(merchantIds)){
                QueryMerchantIdMapProvinceIdsByMerchantIdsRequest request = new QueryMerchantIdMapProvinceIdsByMerchantIdsRequest();
                //商家列表
                request.setMerchantIds(merchantIds);
                Response<Map<Long, Set<Long>>> response = queryMerchantRemoteService.queryMerchantIdMapProvinceIdsByMerchantIds(request); 
                if(response!=null){
                    //得到每个商家对应省份列表
                    Map<Long, Set<Long>> provinceIdMap = response.getResult();
                    for (Map.Entry<Long, Set<Long>> entry : provinceIdMap.entrySet()) {
                        Set<Long> value = entry.getValue();
                        //如果覆盖该商家
                        if(value.contains(provinceId)){
                            return true;
                        }
                    }
                }
            }
        }catch (Exception e) {
            logger.error("getProvinceCoverMerchant has error ", e);
        }
        return false;
    }
    
    /**
     * 检查指定商家列表是否支持当前省份
     * @param provinceId
     * @return key 商家Id value 是否支持当前省份
     */
    public static Map<Long, Boolean> checkMerchantIdProvinceIdReturnMap(Long provinceId,Set<Long> merchantIds){
    	Map<Long, Boolean> map = new HashMap<Long, Boolean>();
        try {
            if(provinceId!=null&&!CollectionUtils.isEmpty(merchantIds)){
                QueryMerchantIdMapProvinceIdsByMerchantIdsRequest request = new QueryMerchantIdMapProvinceIdsByMerchantIdsRequest();
                //商家列表
                List<Long> idList = new ArrayList<Long>();
                idList.addAll(merchantIds);
                request.setMerchantIds(idList);
                Response<Map<Long, Set<Long>>> response = queryMerchantRemoteService.queryMerchantIdMapProvinceIdsByMerchantIds(request); 
                if(response!=null){
                    //得到每个商家对应省份列表
                    Map<Long, Set<Long>> provinceIdMap = response.getResult();
                    if(merchantIds != null){
                    	for(Long mId : merchantIds){
                    		Set<Long> value = provinceIdMap.get(mId);
                    		//如果覆盖该商家
                            if(value != null && value.contains(provinceId)){
                            	map.put(mId, true);
                            }else{
                            	map.put(mId, false);
                            }
                    	}
                    }
                }
            }
        }catch (Exception e) {
            logger.error("getProvinceCoverMerchant has error ", e);
            return map;
        }
        return map;
    }
    
    /**
     * 商家支持的省份列表
     * @param merchantIds
     * @return
     */
    public static Map<Long, List<Long>> checkMerchantIdProvinceIdReturnMap(Set<Long> merchantIds){
    	Map<Long, List<Long>> map = new HashMap<Long, List<Long>>();
    	MemcachedProxy me = MemcachedProxy.getInstance();
    	String key = "MerchantServiceUtil:checkMerchantIdProvinceIdReturnMap:";
    	for(Long merchantId : merchantIds){
    		List<Long> list = (List<Long>)me.get(key+merchantId);
    		if(list!=null){
    			map.put(merchantId, list);
    		}else{
    			QueryProvinceIdByMerchantIdRequest req = new QueryProvinceIdByMerchantIdRequest();
    			req.setMerchantId(merchantId);
    			Response<List<Long>> res = queryMerchantRemoteService.queryProvinceIdByMerchantId(req);
    			if (res.isSuccess()) {
    				me.put(key+merchantId, res.getResult(), CommonKey.MEMCACHE_INVALID_EIGHT_HOUR);
    				map.put(merchantId, res.getResult());
    			}
    		}
    	}
    	return map;
    }
    
    /**
     * 获取商家店铺信息
     * @param merchantId
     * @return
     */
    public static MerchantStoreResultDto getMerchantStoreInfoByMerchantId(Long merchantId) {
    	if (merchantId==null) {
    		throw new CentralMobileParamsException("merchant id is null");
    	}
    	
    	MemcachedProxy me = MemcachedProxy.getInstance();
    	String key = "MerchantServiceUtil:getMerchantStoreInfoByMerchantId:"+merchantId;
    	MerchantStoreResultDto cached = (MerchantStoreResultDto)me.get(key);
    	
    	if (cached==null) {
	    	MerchantStoreParamDto paramDto = new MerchantStoreParamDto();
	    	paramDto.setMerchantId(merchantId);
	    	MerchantStoreResultDto dto =  merchantStoreRemoteClient.getMerchantStoreInfoByMerchantId(paramDto);
	    	if (dto!=null) {
	    		me.put(key, dto, CommonKey.MEMCACHE_INVALID_TIME_MINUTE_30);
	    	}
	    	
	    	return dto;
    	}

    	return cached;
    }
    
    public static List<GenericStoreDto> getStoreInfoListByCategoryId(Long categoryId, Long topN) {
    	logger.error("Before calling getStoreInfoListByCategoryId:"+System.currentTimeMillis());
    	StoreReturn<List<GenericStoreDto>> response = genericStoreClientService.getStoreInfoListByCategoryId(categoryId, topN);
    	logger.error("After calling getStoreInfoListByCategoryId:"+System.currentTimeMillis());
    	
    	if (response!=null && 0==response.getCode()) {
    		return response.getOut();
    	}
    	
    	return null;
    }
    
    public static List<GenericStoreDto> getGoldMerchantTop50List() {
    	logger.error("Before calling getGoldMerchantTop50List:"+System.currentTimeMillis());
    	StoreReturn<List<GenericStoreDto>> response = genericStoreClientService.getGoldMerchantTop50List();
    	logger.error("After calling getGoldMerchantTop50List:"+System.currentTimeMillis());
    	
    	if (response!=null && 0==response.getCode()) {
    		return response.getOut();
    	}
    	
    	return null;
    }

}
