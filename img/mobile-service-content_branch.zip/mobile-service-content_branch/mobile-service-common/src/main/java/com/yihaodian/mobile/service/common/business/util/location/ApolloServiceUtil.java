package com.yihaodian.mobile.service.common.business.util.location;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.mobile.service.common.util.service.MemcachedProxy;
import com.yihaodian.mobile.vo.constant.CommonKey;

/**
 * 阿波罗定位服务service
 * @author zhangwei5
 * @version $Id: ApolloServiceUtil.java, v 0.1 2014-4-21 下午3:53:53 zhangwei5 Exp $
 */
public class ApolloServiceUtil {

    private static Logger logger = LoggerFactory.getLogger(ApolloServiceUtil.class);
    
    /**
     * 通过城市名称查询阿波罗推送消息
     * @param cityName
     */
    public static void getApolloPromotionInfo(String cityName) {
        /*try {
            MemcachedProxy me = MemcachedProxy.getInstance();
            String key = new StringBuffer("getApolloPromotionInfo").append(cityName).toString();
            Object obj = me.get(key);
            if (obj != null) {
                return (UnionMobileSite) obj;
            }
            UnionMobileSiteResult unionMobileSiteResult = unionMobileSiteService
                .findUnionMobileSiteByCity(cityName);
            if (unionMobileSiteResult != null && unionMobileSiteResult.getResultFlag() == 1) {
                UnionMobileSite unionMobileSite = unionMobileSiteResult.getMobileSite();
                me.put(key, unionMobileSite, CommonKey.MEMCACHE_INVALID_TIME_ONE_HOUR);
                return unionMobileSite;
            }
        } catch (Exception e) {
            logger.error("getApolloPromotionInfo has error ", e);
        }
        return null;*/
    }
}
