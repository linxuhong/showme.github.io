package com.yihaodian.mobile.service.common.util.service;

public class MoblileStringUtil {
	//过滤特殊符号
	public static  String transCategoryName(String name){
		if(name!=null){
			name = name.replaceAll("/", "-");
			name = name.replaceAll("，", "-");
			name = name.replaceAll("、", "-");
			name = name.replaceAll(",", "-");
			name = name.replace(".", "");
			name = name.replaceAll(" ", "");
			name = name.trim();
		}
		return name;
	}
}
