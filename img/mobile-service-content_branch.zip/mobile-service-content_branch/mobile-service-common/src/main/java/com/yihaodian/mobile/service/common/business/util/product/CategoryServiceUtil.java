package com.yihaodian.mobile.service.common.business.util.product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.newheight.common.model.PmsHedwigProduct;
import com.yhd.pss.spi.baseinfo.service.QueryProductRemoteService;
import com.yhd.pss.spi.baseinfo.vo.BaseProduct;
import com.yhd.pss.spi.baseinfo.vo.input.QueryProductByIdsRequest;
import com.yhd.pss.spi.category.service.CategoryService;
import com.yhd.pss.spi.category.service.McsiteCategoryService;
import com.yhd.pss.spi.category.vo.BaseCategory;
import com.yhd.pss.spi.category.vo.BaseMcSiteCategory;
import com.yhd.pss.spi.category.vo.Category;
import com.yhd.pss.spi.category.vo.ProductMcSiteCategoryVo;
import com.yhd.pss.spi.category.vo.input.QueryBaseMcsiteCategoryByBackCategoryIdListRequest;
import com.yhd.pss.spi.category.vo.input.QueryByCategoryIdWithConditionRequest;
import com.yhd.pss.spi.category.vo.input.QueryMcSiteCategoryByParentIdWithCategoryListOrderRequest;
import com.yhd.pss.spi.category.vo.input.QuerySubMcsiteCategorysByIdRequest;
import com.yhd.pss.spi.common.vo.Response;
import com.yhd.pss.spi.common.vo.input.QueryByIdsRequest;
import com.yhd.shareservice.exceptions.HedwigException;
import com.yihaodian.mobile.backend.model.CategoryAdvertisement;
import com.yihaodian.mobile.service.common.util.service.MemcachedProxy;
import com.yihaodian.mobile.vo.ad.CategoryResult;
import com.yihaodian.mobile.vo.constant.CommonKey;
import com.yihaodian.pss.client.PssClient;
import com.yihaodian.pss.client.PssClientConfiguration;

/**
 * 类目服务工具类
 * @author zhangwei5
 * @version $Id: CategoryServiceUtil.java, v 0.1 2014年8月28日 上午10:05:22 zhangwei5 Exp $
 */
public class CategoryServiceUtil {

    private static Logger logger  = LoggerFactory.getLogger(CategoryServiceUtil.class);
    
    /**
     * 后台类目service
     */
    private static CategoryService categoryService = null;
    
    /**
     * 前台类目service
     * @return
     */
    private static McsiteCategoryService mcsiteCategoryService = null;
    
    
    private static CategoryService getCategoryInstance(){
        if(categoryService==null){
            categoryService = PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getCategoryService();
        }
        return categoryService;
    }
    
    private static McsiteCategoryService getMcSiteCategoryInstance(){
        if(mcsiteCategoryService==null){
            mcsiteCategoryService = PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getMcsiteCategoryService();
        }
        return mcsiteCategoryService;
    }
    
    /**
     * 查询某个分类所有下级子分类Id(后台类目)
     * @param parentCategoryId
     * @return
     */
    public static List<Long> queryLowerlayerCategoryTreeById(Long categoryId){
        List<Long> result = null;
        try {
            MemcachedProxy me = MemcachedProxy.getInstance();
            String resultKey = new StringBuffer("queryLowerlayerCategoryTreeByIdList_").append(categoryId).toString();
            result = (List<Long>) me.get(resultKey);
            if(result==null){
                QueryByCategoryIdWithConditionRequest request = new QueryByCategoryIdWithConditionRequest();
                //分类列表
                request.setCategoryId(categoryId);
                //isDelete: 是否删除： 1 已删除, 0 未删除
                request.setIsDelete(0);
                //isVisible: 是否可见： 1 可见, 0 不可见
                request.setIsVisible(1);
                Response<List<Category>> response = getCategoryInstance().queryLowerlayerCategoryTreeById(request);
                if(response!=null&&response.getResult()!=null&&response.getResult().size()>0){
                    List<Category> categoryList = response.getResult();
                    result = new ArrayList<Long>();
                    for(Category category : categoryList){
                        result.add(category.getId());
                    }
                    me.put(resultKey, result, CommonKey.MEMCACHE_INVALID_TIME_ONE_HOUR);
                }  
            }
        } catch (Exception e) {
            logger.error("queryLowerlayerCategoryTreeById has error", e);
        }
        return result;
    }
    
    
    /**
     * 查询某个分类所有下级子分类Id(前台类目)
     * @param parentCategoryId
     * @return
     */
    public static List<Long> querySubMcsiteCategorysById(Long categoryId){
        List<Long> result = null;
        try {
            MemcachedProxy me = MemcachedProxy.getInstance();
            String resultKey = new StringBuffer("queryLowerlayerCategoryTreeByIdList_").append(categoryId).toString();
            result = (List<Long>) me.get(resultKey);
            if(result==null){
                QuerySubMcsiteCategorysByIdRequest  request = new QuerySubMcsiteCategorysByIdRequest();
                //分类列表
                request.setMcsiteCategoryId(categoryId);
                //isDelete: 是否删除： 1 已删除, 0 未删除
                request.setIsDelete(0);
                //isVisible: 是否可见： 1 可见, 0 不可见
                request.setIsVisible(1);
                //mcsiteId
                request.setMcsiteId(1);
                Response<List<BaseMcSiteCategory>> response = getMcSiteCategoryInstance().querySubMcsiteCategorysById(request);
                if(response!=null&&response.getResult()!=null&&response.getResult().size()>0){
                    List<BaseMcSiteCategory> categoryList = response.getResult();
                    result = new ArrayList<Long>();
                    for(BaseMcSiteCategory category : categoryList){
                        result.add(category.getId());
                    }
                    me.put(resultKey, result, CommonKey.MEMCACHE_INVALID_TIME_ONE_HOUR);
                }  
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("queryLowerlayerCategoryTreeById has error", e);
        }
        return result;
    }
    
    /**
     * 查询某个分类下N级子分类Id(前台类目)
     * @param parentCategoryId
     * @return
     */
    public static List<CategoryResult> getMobSubCategorysById(Long categoryId,int size){
        List<CategoryResult> result = null;
        try {
            QueryMcSiteCategoryByParentIdWithCategoryListOrderRequest request = new QueryMcSiteCategoryByParentIdWithCategoryListOrderRequest();
            request.setParentId(categoryId);
            Response<List<BaseMcSiteCategory>> response = getMcSiteCategoryInstance().queryMcSiteCategoryByParentIdWithCategoryListOrder(request);
            if(response!=null&&response.getResult()!=null&&response.getResult().size()>0){
                List<BaseMcSiteCategory> categoryList = response.getResult();
                if(categoryList!=null && categoryList.size()>0){
                	int l = categoryList.size()<size?categoryList.size():size;
                	int t = 0;
                	result = new ArrayList<CategoryResult>();
                	CategoryResult cate = null;
            		for(BaseMcSiteCategory category : categoryList){
            			if(t>l){
            				break;
            			}
            			if(category.getIsVisible()==1 && category.getIsDelete()==0){
            				t++;
            				cate = new CategoryResult();
            				cate.setCategoryId(category.getId());
            				cate.setCategoryKeyword(category.getCategoryKeyword());
            				cate.setCategoryName(category.getCategoryName());
            				cate.setCategoryParentId(category.getCategoryParentId());
            				result.add(cate);
            			}
            		}
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("queryLowerlayerCategoryTreeById has error", e);
        }
        return result;
    }
    
    public static Map<Long , List<Long>> queryLowerlayerCategoryTreeByIdList(List<Long> categoryIdList){
        Map<Long , List<Long>> result = null;
        try {
            if(categoryIdList!=null&&categoryIdList.size()>0){
                result = new HashMap<Long, List<Long>>();
                for(Long categoryId : categoryIdList){
                    List<Long> lowerLayerCategoryList =  queryLowerlayerCategoryTreeById(categoryId);
                    result.put(categoryId, lowerLayerCategoryList);
                }
            }
        } catch (Exception e) {
            logger.error("queryLowerlayerCategoryTreeById has error", e);
        }   
        return result;
    }
    
    /**
     * 查询商品前台类目ID
     * @param productId
     * @return
     */
    public static Long queryBaseMcSiteCategoryByProductIdAndMcSiteId(Long productId){
        try {
        	if(productId==null){
        		return null ;	
        	}
            QueryByIdsRequest request = new QueryByIdsRequest();
            List<Long> list = new ArrayList<Long>();
            list.add(productId) ;
            request.setIds(list);
           // Response<BaseMcSiteCategory> response = getMcSiteCategoryInstance().queryBaseMcSiteCategoryByProductId(request);
            Response<List<ProductMcSiteCategoryVo>> response = getMcSiteCategoryInstance().queryMcsiteCategorySearchNameByProductIds(request) ;
            if(response!=null&& !CollectionUtils.isEmpty(response.getResult()) ){
            	return response.getResult().get(0).getCategoryId();
            }
        } catch (Exception e) {
            logger.error("queryBaseMcSiteCategoryByProductIdAndMcSiteId has error", e);
        }
        return null;
    }
    
    public static List<CategoryAdvertisement> queryBaseMcsiteCategoryByBackCategoryIdList(List<Long> cateIds,Integer isShowInYihaodian,Integer mcsiteId){
    	QueryBaseMcsiteCategoryByBackCategoryIdListRequest request = new QueryBaseMcsiteCategoryByBackCategoryIdListRequest();
    	request.setCategoryIdList(cateIds);
    	request.setIsShowInYihaodian(isShowInYihaodian);
    	request.setMcsiteId(mcsiteId);
    	try {
			Response<List<BaseMcSiteCategory>> response=  getMcSiteCategoryInstance().queryBaseMcsiteCategoryByBackCategoryIdList(request);
			List<BaseMcSiteCategory> baseList = response.getResult();
			List<CategoryAdvertisement> categoryList = new ArrayList<CategoryAdvertisement>();
			CategoryAdvertisement catAd = null; 
			int size =0;
			int bsize=0;
			if(cateIds!=null){
				size = cateIds.size();
			}
			if(baseList!=null){
				bsize = baseList.size();
			}
			for(int count=0; count<size;count++){
				Long caId = cateIds.get(count);
				for(int t=0;t<bsize;t++){
					if(caId.equals(baseList.get(t).getCategoryId())){
						catAd = new CategoryAdvertisement();
						catAd.setCategoryId((baseList.get(t).getId().intValue()));
						catAd.setCategoryName(baseList.get(t).getCategoryName());
						if(baseList.get(t).getExtensionLink()!=null){
							catAd.setDirectUrl(baseList.get(t).getExtensionLink());
						}
						if(baseList.get(t).getCategoryKeyword()!=null){
							catAd.setKeyWord(baseList.get(t).getCategoryKeyword());
						}
						catAd.setCategoryType(1);
						categoryList.add(catAd);
					}
				}
			}	
			return categoryList;
    	} catch (HedwigException e) {
			logger.error("queryBaseMcsiteCategoryByBackCategoryIdList has error", e);
			return null;
		}
    }
    
    public static void changeByBackCategoryIdList(List<PmsHedwigProduct> pms,Integer isShowInYihaodian,Integer mcsiteId ){
    	QueryBaseMcsiteCategoryByBackCategoryIdListRequest request = new QueryBaseMcsiteCategoryByBackCategoryIdListRequest();
    	List <Long> cateIds = new ArrayList<Long>();
    	for(int t=0;t<pms.size();t++){
    		if(pms.get(t).getCateId()!=null){
    			cateIds.add(pms.get(t).getCateId());
    		}
    	}
    	request.setCategoryIdList(cateIds);
    	request.setIsShowInYihaodian(isShowInYihaodian);
    	request.setMcsiteId(mcsiteId);
    	try {
			Response<List<BaseMcSiteCategory>> response=  getMcSiteCategoryInstance().queryBaseMcsiteCategoryByBackCategoryIdList(request);
			List<BaseMcSiteCategory> baseList = response.getResult();
			int size =0;
			int bsize=0;
			if(cateIds!=null){
				size = cateIds.size();
			}
			if(baseList!=null){
				bsize = baseList.size();
			}
			for(int count=0; count<size;count++){
				Long caId = cateIds.get(count);
				for(int t=0;t<bsize;t++){
					if(caId.equals(baseList.get(t).getCategoryId())){
						pms.get(count).setCateId(baseList.get(t).getId());
						pms.get(count).setCateName(baseList.get(t).getCategoryName());
					}
				}
			}
			
    	} catch (HedwigException e) {
			logger.error("queryBaseMcsiteCategoryByBackCategoryIdList has error", e);
		}
    }
    
    public static List<Long> changeByBackCateIdToPreId(List<Long> cateIds,Integer isShowInYihaodian,Integer mcsiteId ){
    	QueryBaseMcsiteCategoryByBackCategoryIdListRequest request = new QueryBaseMcsiteCategoryByBackCategoryIdListRequest();
    	request.setCategoryIdList(cateIds);
    	request.setIsShowInYihaodian(isShowInYihaodian);
    	request.setMcsiteId(mcsiteId);
    	List<Long> preCateIds = new ArrayList<Long>();
    	try {
			Response<List<BaseMcSiteCategory>> response=  getMcSiteCategoryInstance().queryBaseMcsiteCategoryByBackCategoryIdList(request);
			List<BaseMcSiteCategory> baseList = response.getResult();
			for(int count=0; count<cateIds.size();count++){
				Long caId = cateIds.get(count);
				for(int t=0;t<baseList.size();t++){
					if(caId.equals(baseList.get(t).getCategoryId())){
						preCateIds.add(baseList.get(t).getId());
					}
				}
			}
		} catch (HedwigException e) {
			logger.error("changeByBackCateIdToPreId has error", e);
			return null;
		}
    	return preCateIds;
    }
    /**
     * 查询指定类目的所有子类目Id
     * key:叶子节点,value：父类目Id
     * @param categoryId
     * @return
     */
    public static Map<Long,Long> getLeafCategorysByCategoryId(Long categoryId){
    	Map<Long,Long> map = null ;
    	try {
    		if(categoryId == null){
    			return new HashMap<Long,Long>() ;
    		}
    		MemcachedProxy me = MemcachedProxy.getInstance() ;
    		String key = "CategoryServiceUtil_getLeafCategorysByCategoryId_"+categoryId ;
    		map = (HashMap<Long,Long>) me.get(key);
    		if(map != null && map.size()>0){
    			return map ;
    		}
    		map = new HashMap<Long,Long>() ;
    		CategoryService categoryService =  PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getCategoryService();
    		QueryByCategoryIdWithConditionRequest request = new  QueryByCategoryIdWithConditionRequest() ;
    		request.setCategoryId(categoryId);
    		request.setIsDelete(0);//未删除
    		request.setIsVisible(1);//可见
			Response<List<BaseCategory>> response = categoryService.queryLeafCategorysByCategoryId(request);
			if(response != null && CollectionUtils.isNotEmpty(response.getResult())){
				List<BaseCategory>  baseCategoryList = response.getResult() ;
				for(BaseCategory bcVO:baseCategoryList  ){
					if(bcVO.getId()!= null ){
						map.put(bcVO.getId(),categoryId) ;
					}
				}
			}
			if(map != null && map.size()>0){
				me.put(key, map);
			}
			
		} catch (Exception e) {
			logger.error("getLeafCategorysByCategoryId has an error categoryId:"+categoryId,e);
		}
    	return map ;
    }
    
    /**
     * 批量查询商品的类目 ，所有的类目均为叶子类目
     * 返回map key :productId value :catgoryId
     * @param ids 产品Id
     * @return
     */
    public static Map<Long,Long>  getLeafCategoryByProductId(List<Long> ids){
    	Map<Long,Long> map = new HashMap<Long, Long>() ;
    	try {
    		if(CollectionUtils.isEmpty(ids)){
    			return map ;
    		}
    		QueryProductRemoteService service=  PssClient.getInstance(PssClientConfiguration.FRONT_SERVER_GROUP).getQueryProductRemoteService() ;
    		QueryProductByIdsRequest request = new QueryProductByIdsRequest() ;    
    		request.setProductIds(ids);
			Response <List <BaseProduct>> response = service.queryBaseProductByIdList(request);
			if(response != null && CollectionUtils.isNotEmpty(response.getResult())){				
				for(BaseProduct bp:response.getResult()){
					if(bp.getCategoryId()!= null && bp.getId()!= null){
						map.put(bp.getId(), bp.getCategoryId());
					}
				}
			}
		} catch (HedwigException e) {
			logger.error("getLeafCategoryByProductId has an error ids:"+ids,e);
		}
    	return map ;
    }
    
}
