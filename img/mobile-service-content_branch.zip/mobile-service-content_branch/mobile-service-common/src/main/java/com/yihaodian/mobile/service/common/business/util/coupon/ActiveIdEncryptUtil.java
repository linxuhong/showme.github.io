package com.yihaodian.mobile.service.common.business.util.coupon;

import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.encrypt.md5.MD5Support;

public class ActiveIdEncryptUtil {
    private static final String COUPON_ACTIVE_ID_PRIVATE_KEY_STR = YccGlobalPropertyConfigurer.getPropertyByKey("promotion.properties", "coupon_active_id_private_key");
    private static final String MIX_STR = "zBjkwGVqq348XCcv837pacv";
    private static final int MD5_LENGTH = 20;

    public static String entryActiveId(Long activeId)
    {
      StringBuilder sb = new StringBuilder();
      sb.append(new StringBuilder().append("primevalId=").append(activeId).toString());
      sb.append(",mixStr=zBjkwGVqq348XCcv837pacv");
      sb.append(new StringBuilder().append(",privateKey=").append(COUPON_ACTIVE_ID_PRIVATE_KEY_STR).toString());

      String tmpStr = MD5Support.MD5(sb.toString());

      return subCutStr(activeId, tmpStr);
    }

    private static String subCutStr(Long activeId, String preliminary)
    {
      int tmpbyte = Math.abs(activeId.byteValue());

      char[] c = String.valueOf(tmpbyte).toCharArray();
      int sum = 0;

      for (int i = 0; i < c.length; ++i) {
        sum += Integer.valueOf(String.valueOf(c[i])).intValue();
      }

      StringBuilder sb = new StringBuilder();
      if (sum < 20) {
        sb.append(preliminary.substring(preliminary.length() - sum));
        sb.append(preliminary.substring(0, 20 - sum));
      } else if (sum >= 20) {
        sb.append(preliminary.substring(preliminary.length() - 20));
      }

      return sb.toString();
    }

    static
    {
      if (StringUtil.isEmpty(COUPON_ACTIVE_ID_PRIVATE_KEY_STR)){
          throw new RuntimeException("promotion.properties coupon_active_id_private_key config error.");
      }
    }}
