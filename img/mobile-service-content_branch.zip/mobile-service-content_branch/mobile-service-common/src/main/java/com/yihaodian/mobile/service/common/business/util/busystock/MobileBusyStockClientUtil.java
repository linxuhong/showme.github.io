package com.yihaodian.mobile.service.common.business.util.busystock;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Maps;
import com.yihaodian.front.busystock.client.BusyStockClientUtil;
import com.yihaodian.front.busystock.client.facade.BusyGrouponFacadeService;
import com.yihaodian.front.busystock.client.facade.BusyPriceStockFacadeService;
import com.yihaodian.front.busystock.client.facade.BusyPromotionFacadeService;
import com.yihaodian.front.busystock.client.facade.BusyStockFacadeService;
import com.yihaodian.front.busystock.vo.BSAreaVo;
import com.yihaodian.front.busystock.vo.BSGrouponVo;
import com.yihaodian.front.busystock.vo.BSPmStockVo;
import com.yihaodian.front.busystock.vo.BSProductVo;
import com.yihaodian.front.busystock.vo.BSPromotionProductVo;
import com.yihaodian.front.busystock.vo.GetProductInfoByPIdRequest;
import com.yihaodian.front.busystock.vo.GetProductInfosByPIdsRequest;

public class MobileBusyStockClientUtil {
	private static BusyPriceStockFacadeService busyPriceStockFacadeService;
	
	private static BusyGrouponFacadeService busyGrouponGacadeService;
	
	private static BusyPromotionFacadeService busyPromotionFacadeService;
	
	private static BusyStockFacadeService busyStockFacadeService ;
	
	private static Logger logger = LoggerFactory.getLogger(MobileBusyStockClientUtil.class);
	
	/**
	 * channelId  渠道Id 1=1号店 2=药网 101=1号店PC端 102=1号店无线端 103=1闪团
	 */
	public static final Long BUSY_GROUPON_CHANNEL_WIRELESS = 102l;
	
	public static final Long BUSY_YHD_CHANNEL=1l;

	static {
		busyPriceStockFacadeService = BusyStockClientUtil.getBusyPriceStockFacadeService();
		
		busyGrouponGacadeService = BusyStockClientUtil.getBusyGrouponFacadeService();
		
		busyPromotionFacadeService = BusyStockClientUtil.getBusyPromotionFacadeService();
		
		busyStockFacadeService = BusyStockClientUtil.getBusyStockFacadeService() ;
	}

	/**
	 * 批量查询商品库存价格信息
	 * 
	 * @param provinceId
	 *            省份
	 * @param productIds
	 *            产品Id列表
	 * @return
	 */
	public static List<BSProductVo> getProductInfosWithoutMerchant(
			Long provinceId, List<Long> productIds) {
		GetProductInfosByPIdsRequest request = new GetProductInfosByPIdsRequest();
		BSAreaVo areaVo = new BSAreaVo();
		areaVo.setProvinceId(provinceId);
		
		request.setChannelId(BUSY_GROUPON_CHANNEL_WIRELESS);
		request.setProductIds(productIds);
		request.setAreaVo(areaVo);
		
		return busyPriceStockFacadeService.getProductInfosWithoutMerchant(request);
	}
	
	/**
	 * 批量查询商品库存价格
	 * @param provinceId
	 *        省份id
	 * @param pmIds
	 *        商品id列表
	 * bs缓存 10min      
	 * @return
	 */
	public static List<BSProductVo> getProductInfosWithMerchant(Long provinceId,List<Long> pmIds){
		return busyPriceStockFacadeService.getProductInfosWithMerchant(BUSY_GROUPON_CHANNEL_WIRELESS, 
				provinceId, pmIds);
	}
	
	/**
	 * 批量查询商品库存价格，返回pmId和商品库存信息映射
	 * @param provinceId 省份id
	 * @param pmIds 商品pmId列表
	 * @return
	 */
	public static Map<Long, BSProductVo> getProductInfosWithMerchantMap(Long provinceId, List<Long> pmIds) {
		Map<Long, BSProductVo> result = Maps.newHashMap();
		try {
			List<BSProductVo> bsProductList = busyPriceStockFacadeService.getProductInfosWithMerchant(BUSY_GROUPON_CHANNEL_WIRELESS, 
					provinceId, pmIds);
			if (CollectionUtils.isNotEmpty(bsProductList)) {
				for (BSProductVo product: bsProductList) {
					result.put(product.getPmId(), product);
				}
			}
		} catch (Exception e) {
			 logger.error("getProductInfosWithMerchantMap has error ", e);
		}
		
		return result;
	}
	
	public static Map<Long, BSProductVo> getProductInfosWithMerchantMap(Long provinceId, Long cityId, List<Long> pmIds) {
		Map<Long, BSProductVo> result = Maps.newHashMap();
		try {
			BSAreaVo areaVo = new BSAreaVo();
			areaVo.setProvinceId(provinceId);
			if(cityId!=null){
				areaVo.setCityId(cityId);
			}
			List<BSProductVo> bsProductList = busyPriceStockFacadeService.getProductInfosWithMerchant(BUSY_GROUPON_CHANNEL_WIRELESS, areaVo,pmIds,null);
			if (CollectionUtils.isNotEmpty(bsProductList)) {
				for (BSProductVo product: bsProductList) {
					result.put(product.getPmId(), product);
				}
			}
		} catch (Exception e) {
			 logger.error("getProductInfosWithMerchantMap has error ", e);
		}
		
		return result;
	}


	   /**
     * 批量查询商品库存价格信息
     * 
     * @param provinceId
     *            省份
     * @param productIds
     *            产品Id列表
     * @return
     */
    public static Map<Long, BSProductVo> getProductInfosWithoutMerchantMap(Long provinceId, List<Long> productIds) {
        return getProductInfosWithoutMerchantMap(provinceId, productIds, BUSY_GROUPON_CHANNEL_WIRELESS);
    }

    public static Map<Long, BSProductVo> getProductInfosWithoutMerchantMap(Long provinceId, List<Long> productIds,
            Long channelId) {
    	
        return MobileBusyStockClientUtil.getProductInfosWithoutMerchantMap(provinceId, productIds, channelId, null);
    }
    
    public static List<BSProductVo> getProductInfosWithoutMerchantList(Long provinceId, List<Long> productIds,
            Long channelId,Long cityId) {
    	
    	GetProductInfosByPIdsRequest request = new GetProductInfosByPIdsRequest();
		BSAreaVo areaVo = new BSAreaVo();
		areaVo.setProvinceId(provinceId);
		if(cityId != null){
			areaVo.setCityId(cityId);
		}
		
		request.setChannelId(channelId);
		request.setProductIds(productIds);
		request.setAreaVo(areaVo);
    	
        return busyPriceStockFacadeService.getProductInfosWithoutMerchant(request);
    }
    
    public static Map<Long, BSProductVo> getProductInfosWithoutMerchantMap(Long provinceId, List<Long> productIds,
            Long channelId,Long cityId) {
    	
        Map<Long, BSProductVo> resultMap = new HashMap<Long, BSProductVo>();
        List<BSProductVo> bsProdcutVoList = getProductInfosWithoutMerchantList(provinceId,productIds,channelId,cityId);
        if (bsProdcutVoList != null && bsProdcutVoList.size() > 0) {
            for (BSProductVo bSProductVo : bsProdcutVoList) {
                resultMap.put(bSProductVo.getProductId(), bSProductVo);
            }
        }
        return resultMap;
    }
    
	/**
	 * 查询某个商品库存价格信息
	 * 
	 * @param provinceId
	 *            省份ID
	 * @param productId
	 *            产品Id
	 * @return
	 */
	public static BSProductVo getProductInfoWithoutMerchant(Long provinceId,
			Long productId) {
		GetProductInfoByPIdRequest request = new GetProductInfoByPIdRequest();
		BSAreaVo areaVo = new BSAreaVo();
		areaVo.setProvinceId(provinceId);
		
		request.setChannelId(BUSY_GROUPON_CHANNEL_WIRELESS);
		request.setProductId(productId);
		request.setAreaVo(areaVo);
		
		return busyPriceStockFacadeService.getProductInfoWithoutMerchant(request);
	}
	
	
    public static Map<Long, BSPromotionProductVo> getLandingPagePriceStockMapByCity(Long provinceId, Long cityId,List<Long> promotionIds) {
        try {
            if (provinceId == null || CollectionUtils.isEmpty(promotionIds)) {
                return new HashMap<Long, BSPromotionProductVo>();
            }
            BSAreaVo bsAreaVo = new BSAreaVo();
            bsAreaVo.setProvinceId(provinceId);
            bsAreaVo.setCityId(cityId);
            // 通过Bs得到商品列表
            List<BSPromotionProductVo> bSPromotionProductVoList = busyPromotionFacadeService
                    .getLandingPagePriceStockList(BUSY_YHD_CHANNEL, bsAreaVo, promotionIds) ;
            if (bSPromotionProductVoList != null && bSPromotionProductVoList.size() > 0) {
                return bSPromotionProductVoListToMap(bSPromotionProductVoList);
            }
        } catch (Exception e) {
            logger.error("getLandingPagePriceStockMap has error ", e);
        }
        return new HashMap<Long, BSPromotionProductVo>();
    }
	
	/**
	 * 查询某个lp活动在某个省份下的所有商品信息
	 * @param provinceId
	 * @param promotionIds
	 * @return
	 */
    public static Map<Long, BSPromotionProductVo> getLandingPagePriceStockMap(Long provinceId, List<Long> promotionIds) {
        return getLandingPagePriceStockMap(provinceId, promotionIds, BUSY_YHD_CHANNEL);
    }

    public static Map<Long, BSPromotionProductVo> getLandingPagePriceStockMap(Long provinceId, List<Long> promotionIds,
            Long channelId) {
        try {
            if (provinceId == null || CollectionUtils.isEmpty(promotionIds)) {
                return new HashMap<Long, BSPromotionProductVo>();
            }
            // 通过Bs得到商品列表
            List<BSPromotionProductVo> bSPromotionProductVoList = busyPromotionFacadeService
                    .getLandingPagePriceStockList(channelId, provinceId, promotionIds);
            if (bSPromotionProductVoList != null && bSPromotionProductVoList.size() > 0) {
                return bSPromotionProductVoListToMap(bSPromotionProductVoList);
            }
        } catch (Exception e) {
            logger.error("getLandingPagePriceStockMap has error ", e);
        }
        return new HashMap<Long, BSPromotionProductVo>();
    }
    public static List<BSPromotionProductVo> getLandingPagePriceStockList(Long provinceId, Long cityId,List<Long> promotionIds){
    	 try {
             if (provinceId == null || CollectionUtils.isEmpty(promotionIds)) {
                 return null;
             }
             // 通过Bs得到商品列表
             BSAreaVo bsAreaVo = new BSAreaVo();
             bsAreaVo.setProvinceId(provinceId);
             bsAreaVo.setCityId(cityId);
             return busyPromotionFacadeService.getLandingPagePriceStockList(BUSY_YHD_CHANNEL, bsAreaVo, promotionIds);
         } catch (Exception e) {
             logger.error("getLandingPagePriceStockList has error ", e);
         }
    	 return null;
    }
    public static Map<Long, BSPromotionProductVo> getLandingPagePriceStockMap(Long provinceId, Long cityId,List<Long> promotionIds) {
        try {
            if (provinceId == null || CollectionUtils.isEmpty(promotionIds)) {
                return new HashMap<Long, BSPromotionProductVo>();
            }
            List<BSPromotionProductVo> bSPromotionProductVoList = getLandingPagePriceStockList(provinceId, cityId, promotionIds);
            if (bSPromotionProductVoList != null && bSPromotionProductVoList.size() > 0) {
            	  try {
                      if(CollectionUtils.isEmpty(bSPromotionProductVoList)){
                          return new HashMap<Long, BSPromotionProductVo>();
                      }
                      Map<Long , BSPromotionProductVo> result = new HashMap<Long, BSPromotionProductVo>();
                      for(BSPromotionProductVo bsPromotionProductVo : bSPromotionProductVoList){
                          result.put(bsPromotionProductVo.getPmId(), bsPromotionProductVo);
                      }
                      return result;
                  } catch (Exception e) {
                      logger.error("bSPromotionProductVoListToMap has error ", e);
                  }
            }
        } catch (Exception e) {
            logger.error("getLandingPagePriceStockMap has error ", e);
        }
        return new HashMap<Long, BSPromotionProductVo>();
    }
	
	/**
	 * 根据pmId返回促销活动下某个具体商品
	 * @param provinceId
	 * @param promotionId
	 * @param pmId
	 * @return
	 */
	public static BSPromotionProductVo getLandingPagePriceStock(Long provinceId, Long promotionId, Long pmId){
		try{
			BSPromotionProductVo vo = busyPromotionFacadeService.getLandingPagePriceStock(BUSY_YHD_CHANNEL, null, provinceId, promotionId, pmId);
			return vo;
		} catch (Exception e) {
            logger.error("getLandingPagePriceStock has error ", e);
        }
		return null;
	}
	
	private static Map<Long , BSPromotionProductVo> bSPromotionProductVoListToMap(List<BSPromotionProductVo> bSPromotionProductVoList){
	    try {
            if(CollectionUtils.isEmpty(bSPromotionProductVoList)){
                return new HashMap<Long, BSPromotionProductVo>();
            }
            Map<Long , BSPromotionProductVo> result = new HashMap<Long, BSPromotionProductVo>();
            for(BSPromotionProductVo bsPromotionProductVo : bSPromotionProductVoList){
                result.put(bsPromotionProductVo.getProductId(), bsPromotionProductVo);
            }
            return result;
        } catch (Exception e) {
            logger.error("bSPromotionProductVoListToMap has error ", e);
        }
	    return new HashMap<Long, BSPromotionProductVo>();
	}
	
	/**
	 * <del>通过BS查询团购商品详情</del>
	 * 该函数已经废弃掉请使用groupon-interface中的方法
	 * @param channelId
	 * @param proviceId
	 * @param grouponIds
	 * @see com.yihaodian.mobile.core.util#getBSGrouponVOMap
	 */
	@Deprecated
	public static List<BSGrouponVo> getBSGrouponVOList(Long channelId , Long provinceId , List<Long> grouponIds , Long userId){
	    List<BSGrouponVo> bsGrouponVoList = busyGrouponGacadeService.getBSGrouponVoList(BUSY_GROUPON_CHANNEL_WIRELESS, userId, provinceId, grouponIds);
	    return bsGrouponVoList;
	}
	
	/**
	 * <del>查询某个团购活动在某个省份下的所有商品信息</del>
	 * 该函数已经废弃掉请使用groupon-interface中的方法
	 * @param provinceId
	 * @param promotionIds
	 * @return
	 * @see com.yihaodian.mobile.core.util#getBSGrouponVOMap
	 */
	@Deprecated
	public static Map<Long , BSGrouponVo> getBSGrouponVOMap(Long provinceId , List<Long> grouponIds){
	    try {
	        //通过Bs得到商品列表
	    	List<BSGrouponVo> bSGrouponVoList = busyGrouponGacadeService.getBSGrouponVoList(BUSY_GROUPON_CHANNEL_WIRELESS, null, provinceId, grouponIds);
	        if(CollectionUtils.isNotEmpty(bSGrouponVoList)){
	        	Map<Long , BSGrouponVo> result = new HashMap<Long, BSGrouponVo>();
	            for(BSGrouponVo bSGrouponVo : bSGrouponVoList){
	                result.put(bSGrouponVo.getGrouponId(), bSGrouponVo);
	            }
	            return result;
	        }
        } catch (Exception e) {
            logger.error("getBSGrouponVOMap has error ", e);
        }
	    return new HashMap<Long, BSGrouponVo>();
	}
	
	   /**
	    * 读取5个参数 >整合后Landingpage活动的价格、库存、限购数量、已售数量、积分这5个字段的查询和维护接口将都由GPS来提供
* 根据当前省份Id和一组促销活动Id,获取landingpage 促销商品 价格库存信息
* @param channelId    渠道Id 1=1号店， 2=药网 ，101=1号店PC端， 102=1号店无线端 ，103=1闪团， 104=秒杀， 105=支付宝公众平台， 10601=星火砍价第1档， 10601=星火砍价第2档，107=老团购
* @param provinceId   当前省份Id
* @param promotionIds 促销活动Id列表
* @return 返回landingpage 商品价格库存 如果脏数据会返回空
*/
	public static List<BSPromotionProductVo> getLandingPagePriceStockList(Long provinceId ,List<Long> promotionIds){
		if(provinceId == null || CollectionUtils.isEmpty(promotionIds)){
			return null ;
		}
		BusyPromotionFacadeService service = BusyStockClientUtil.getBusyPromotionFacadeService();		
		return service.getLandingPagePriceStockList(1L, provinceId, promotionIds);// 1 表示 1号店
	}
	
	/**
	 * 	 查询库存 实时库存
	 * @param provinceId
	 * @param inputPmIds
	 * @return
	 */
	public static  List<BSPmStockVo> getStockByProvinceIdAndPmid(Long provinceId, List<Long> inputPmIds){
		List<BSPmStockVo> list =null ;
		try{
			if(provinceId == null || CollectionUtils.isEmpty(inputPmIds)){
				return list ;
			}
			list = busyStockFacadeService.getPmStockVoList(provinceId, inputPmIds);			
		}catch(Exception e){
			logger.error("getStockByProvinceIdAndPmid has an error provinceId:"+provinceId+"inputPmIds:"+inputPmIds, e);
		}
		return list ;
	}

}

