package com.yihaodian.mobile.service.common.util;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/*
 * relevancy MerchantTestActivity's Submit method
 * author: guoqiang
 */

public class XmlHttpConnection implements Serializable {
	private static final long serialVersionUID = -8576553457942740493L;
	private final int RESPCODE_SUCCESS = 200;
	private String URL;
	private String recvMsg;
	private HttpURLConnection urlCon;
	private int errCode;
	private String errMsg;
	InputStream in;
	public XmlHttpConnection(String url, int timeOut) {
		this(url, timeOut + "");
	}

	public XmlHttpConnection(String url, String timeOut) {
		this.URL = url;
		System.setProperty("sun.net.client.defaultConnectTimeout", timeOut);
		System.setProperty("sun.net.client.defaultReadTimeout", timeOut);
	}

	private boolean open() {
		try {
			urlCon = (HttpURLConnection) new URL(URL).openConnection();
			return true;
		}catch (Exception e) {
			errCode = -11;
			errMsg = "";
		}
		return false;
	}
	/**
	 * 
	 * @param msgStr
	 *            msg String
	 * @param msgEncoding
	 *            sending encoding
	 * @return boolean
	 */
	public boolean sendMsg(String msgStr) {
		if (!open())
			return false;

		OutputStream os =null;
		InputStream is=null;
		OutputStreamWriter writer = null;
		BufferedReader reader = null;
		try {
			try{
				urlCon.setRequestMethod("POST");
				urlCon.setRequestProperty("content-type", "text/plain");
				urlCon.setDoOutput(true);
				urlCon.setDoInput(true);
				os =urlCon.getOutputStream();
//				os.write(msgStr.getBytes("utf-8"));
//				os.flush();
				writer = new OutputStreamWriter(os);
				writer.write(URLEncoder.encode(msgStr, "utf-8"));
				writer.flush();
			}catch (Exception e) {
				errCode = -21;
				errMsg = "";
				return false;
			}finally{
			    if(writer!=null){
			        try {
			            writer.close();
			            if(os!=null){
			                os.close();   
			            }
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
			    }
			}
			try {
				int respCode = urlCon.getResponseCode();
				if (RESPCODE_SUCCESS != respCode) {
					errCode = -31;
					errMsg="httpState=[" + respCode + "]";	
				} 
				is=urlCon.getInputStream();
				reader = new BufferedReader(new InputStreamReader(is,"utf-8"));
				StringBuilder responseBuilder = new StringBuilder();
				String line = null;
				while ((line = reader.readLine()) != null) {
					responseBuilder.append(line);
				}
				recvMsg=URLDecoder.decode(responseBuilder.toString(),"utf-8");
				SAXReader saxReader = new SAXReader(); 
				Document document = saxReader.read(new ByteArrayInputStream(recvMsg.getBytes("UTF-8")));
				Element element = document.getRootElement();
				for (Iterator i = element.elementIterator(); i.hasNext();) {
					Element node = (Element) i.next();
					if(node.getName().equals("respCode")){
                            if(node.getText().equals("0000")){
                            	return true;
                            }else{
                            	return false;
                            }
					}
				}
			} catch (Exception e) {
				errCode = -31;
				errMsg = "";
				return false;
			}finally{
			    try {
			        if(reader!=null){
			            reader.close(); 
			        }
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
			}
			
		}
		finally {
			close(is);
			close(os);
			urlCon.disconnect();
			urlCon = null;
		}
		return true;
	}
	private void close(InputStream stream) {
		try {
			if (stream != null) {
				stream.close();
			}
		} catch (Exception e) {
		}
	}

	private  void close(OutputStream stream) {
		try {
			if (stream != null) {
				stream.close();
			}
		} catch (Exception e) {
		}
	}

	public int getErrCode() {
		return errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public String getRecvMsg() {
		
		
		return recvMsg;
	}
	public String getReMeg() {
		
		
		return recvMsg;
	}
	InputStream StringToInputStream (String recvMsg){
		
		ByteArrayInputStream stream = new ByteArrayInputStream(recvMsg.getBytes());
		
		
		return stream;
	}
	
}
