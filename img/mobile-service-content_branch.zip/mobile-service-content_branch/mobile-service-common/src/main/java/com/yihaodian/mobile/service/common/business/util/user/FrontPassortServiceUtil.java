package com.yihaodian.mobile.service.common.business.util.user;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSON;
import net.sf.json.xml.XMLSerializer;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.reflect.TypeToken;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.mobile.framework.lang.utils.HttpClientUtil;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.framework.lang.utils.json.GsonUtil;
import com.yihaodian.mobile.service.common.util.client.XStreamUtil;
import com.yihaodian.mobile.vo.bussiness.Trader;

/**
 * passPort service
 * @author zhangwei5
 *
 */
public class FrontPassortServiceUtil {

	private static Logger logger = LoggerFactory.getLogger(FrontPassortServiceUtil.class); 
	
	private static String url = "";
	
	static{
		try {
			url = StringUtil.isNotEmpty(YccGlobalPropertyConfigurer.getPropertyByKey("remoteServiceMobile.properties", "mobile_passport_url")) ? 
					YccGlobalPropertyConfigurer.getPropertyByKey("remoteServiceMobile.properties", "mobile_passport_url") : "http://interface.m.yhd.com";
		} catch (Exception e) {
			url = "http://interface.m.yhd.com";
		}
	}
	
	public static Trader getTrader(String token){
		try {
			StringBuilder methodBodyURL = new StringBuilder();
			methodBodyURL.append("<object-array><string>"+token+"</string></object-array>");
			Map<String  , String> mapParams= new HashMap<String  , String>(); 
			mapParams.put("methodName", "getTrader");
			mapParams.put("methodBody", methodBodyURL.toString());
			String response = HttpClientUtil.doPost(url+"/centralmobile/servlet/CentralMobileFacadeJsonServlet", mapParams,2000,2000);
			if(response!=null){
				JSONObject jsonObject = new JSONObject(response);
				String resultData = jsonObject.get("data").toString();
				Trader trader = (Trader) GsonUtil.paseToObject(resultData, new TypeToken<Trader>() {
				}.getType());
				return trader;
			}
			
		} catch (Exception e) {
			logger.error("", e);
		}
		return null;
	}
	
	public static Integer checkVerifyCode(String code,String sessionId){
		try {
			StringBuilder methodBodyURL = new StringBuilder();
			methodBodyURL.append("<object-array><string>"+code+"</string><string>"+sessionId+"</string></object-array>");
			Map<String  , String> mapParams= new HashMap<String  , String>(); 
			mapParams.put("methodName", "checkVerifyCode");
			mapParams.put("methodBody", methodBodyURL.toString());
			String response = HttpClientUtil.doPost(url+"/centralmobile/servlet/CentralMobileFacadeServlet", mapParams);
			if(response!=null){
				XMLSerializer xmlSerializer = new XMLSerializer();  
				JSON json = xmlSerializer.read(response);  
				JSONObject jsonObject = new JSONObject(json.toString());
				String resultData = jsonObject.get("code").toString();
				return Integer.valueOf(resultData);
			}
			
		} catch (Exception e) {
			logger.error("checkVerifyCode has error ", e);
		}
		return 0;
	}
	
	public static String getVerifyCodeUrl(Trader trader){
		try {
			StringBuilder methodBodyURL = new StringBuilder();
			methodBodyURL.append("<object-array>"+XStreamUtil.objectToXml(trader)+"</object-array>");
			Map<String  , String> mapParams= new HashMap<String  , String>(); 
			mapParams.put("methodName", "getVerifyCodeUrl");
			mapParams.put("methodBody", methodBodyURL.toString());
			String response = HttpClientUtil.doPost(url+"/centralmobile/servlet/CentralMobileFacadeServlet", mapParams);
			return response;
		} catch (Exception e) {
			logger.error("checkVerifyCode has error ", e);
		}
		return "";
	}
	
	public static void main(String[] args) {
        Trader trader = new Trader();
        trader.setTraderName("androidSystem");
        trader.setTraderPassword("sCarce!8");       
        trader.setClientSystem("android");
        trader.setProtocol("HTTPXML");
        trader.setInterfaceVersion("1.3.2");
        trader.setClientAppVersion("3.1.3");
        trader.setClientVersion("5.1.1");
        trader.setDeviceCode("00000000-4363-ead2-a595-a453edccfc");
        trader.setUnionKey("10442025702");
        System.out.println(getVerifyCodeUrl(trader));
	}
}