package com.yihaodian.mobile.service.common.business.util.check;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.service.common.business.util.user.UserCheckUtil;
import com.yihaodian.mobile.service.domain.business.emuns.CommonResultCode;
import com.yihaodian.mobile.vo.HttpHeaderVO;

/**
 * 基本参数校验
 * @author zhangwei5
 * @version $Id: BaseParamCheckUtil.java, v 0.1 2014-4-22 下午4:21:57 zhangwei5 Exp $
 */
public class BaseParamCheckUtil {
    private static Logger logger = LoggerFactory.getLogger(UserCheckUtil.class);
    

    /**
     * 参数校验 HttpHeaderVo
     * @param httpHeaderVO
     * @return
     */
    public static Result headerVOCheck(HttpHeaderVO httpHeaderVO){
        Result result = new ResultModel();
        result.setSuccess(true);
        try {
            if(httpHeaderVO==null||httpHeaderVO.getClientInfo()==null){
                result.setSuccess(false);
                result.setBaseResultCode(CommonResultCode.PARAMS_NULL_EXCEPTION);
            }
        } catch (Exception e) {
            logger.error(" headerVOCheck has error ", e);
            result.setSuccess(false);
            result.setBaseResultCode(CommonResultCode.PARAMS_SYSTEM_ID_ERROR_EXCEPTION);
        }
        return result;
    
    }
}
