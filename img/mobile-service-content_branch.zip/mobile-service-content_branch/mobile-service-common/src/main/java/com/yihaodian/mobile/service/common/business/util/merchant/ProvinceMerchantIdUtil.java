package com.yihaodian.mobile.service.common.business.util.merchant;


public class ProvinceMerchantIdUtil {
	
	/**	 *
	 * wangxiaowu(王肖武) 17:13:04
你现在不关心省份
wangxiaowu(王肖武) 17:13:19
现在是一个商家对应一个省份就可以
1（上海）-> 1
2（北京）-> 2
3（广州）->20
8（武汉）->18
9（成都）->12
11（福建）->14
	 */
	public static Long getProvinceIdByMerchantId(int merchantId){
		switch (merchantId) {
			case 1:
				return 1L;
			case 2:
				return 2L;
			case 3:
				return 20L;
			case 8:
				return 18L;
			case 9:
				return 12L;
			case 11:
				return 14L;
			default:
				return 1L;
			}
	}
}
