package com.yihaodian.mobile.service.common.util.service;

import java.net.URLEncoder;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import com.yihaodian.common.ycache.CacheProxy;
import com.yihaodian.common.util.SpringBeanProxy;
import com.yihaodian.common.ycache.util.MD5Support;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.vo.constant.CommonKey;

/**
 * 
 * @author weip
 * @time Mar 14, 2008 1:07:46 PM
 */
public class MemcachedProxy {
	
//	private static String CURRENTVERSION = "";
	protected static Log sysLogger = LogFactory.getLog("sysLogger");

	private static MemcachedProxy instance;
	private static CacheProxy cacheProxy;

	private static final int defaultExpiryMinutes = 60 * 12; 
	
	/**
	 * 是否是主动缓存模式，默认为否
	 * 主动缓存下将不再从缓存中读取数据，只存数据
	 */
    private boolean isPositiveMemcacheMode=false;
    static final String DATA_CACHE_BEAN_NAME = "mobile201DataCache";
//	private static final int SocketTimeout = 1000 * 3;
//	private static final int socketConnectTO = 1000 * 3;
//
//	private static final int initConn = 50;
//	private static final int mainSleep = 30 * 1000;
//	private static final int minConn = 50;
//	private static final int maxConn = 500;
//	private static final String poolname = "session";
	private static final String AD_KEY_PREFIX="Advertisement";
	
//private static MemCachedClient MC = null;

	/**
	 * 注意多线程中的单例模式问题
	 * @return
	 */
	public synchronized static MemcachedProxy getInstance() {
	    if(instance==null) {
	        instance = new MemcachedProxy();
	        cacheProxy =  (CacheProxy) SpringBeanProxy.getBean(DATA_CACHE_BEAN_NAME);
	        instance.init();
	        return instance;
	    } else {
	        try {
	            return instance;
	        } catch (Exception ex) {
	            ex.printStackTrace();
	            instance.init();
	            return instance;
	            
	        }
	    }
		
	}
	
	public static String getGoodKey(String oldkey) {
		int bylength = 0;
		
		String encodekey = "";
		try {
			encodekey = URLEncoder.encode(oldkey,"UTF-8");
			// oldkey 变为 oldkey+"_"+codeversion
		} catch (Exception e1) {
		    e1.printStackTrace();
		    encodekey = oldkey;
			sysLogger.error("old key can't covent to utf-8 || "+e1.getMessage());
		}
		
		try {
			bylength = encodekey.length();

			if (bylength > 240 || oldkey.indexOf(" ")>-1)  {
				// 经测试memcached最大支持250位key
				sysLogger.debug("this key is too long or have space :" + oldkey
						+ "||  MD5 to 32 bit length!!");
				String headkey = null;
				if(encodekey.length()>=48) {
					headkey = encodekey.substring(0,48);
				} else {
					headkey = encodekey;
				}
				return headkey+"_"+MD5Support.MD5(oldkey);
			} else
				return oldkey;

		} catch (Exception e) {
			e.printStackTrace();
			return oldkey;

		}

	}
	
	public void init() {
    	isPositiveMemcacheMode= StringUtil.isNotBlank(YccGlobalPropertyConfigurer.getPropertyByKey("remoteService.properties","positive_memcache_mode"));
	}

//	public void close() {
//		SockIOPool pool = SockIOPool.getInstance(poolname);
//		pool.getMaxBusy();
//		pool.shutDown();
//	}

    /**
     * 获取对象
     * 如果此服务器被配置为主动缓存，那么将直接返回空，这样就能强制清理缓存
     * 
     * 注意！！！！：线上服务器不能配置成主动缓存
     * 
     * 
     * @param key
     * @return
     */
	public Object get(String key) {
//		sysLogger.info("MemCached is start");
//
//		MemCachedClient mc = MC;
//		// mc.setPoolName(poolname);
//		mc.setCompressEnable(true);
//		long tnTime0 = System.currentTimeMillis();
//		Object obj = mc.get(MemcachedProxy.getGoodKey(key));
//		long tnTime1 = System.currentTimeMillis();
//		sysLogger.info("MemCached is end");
//		return obj;
		
		if(isPositiveMemcacheMode && key.startsWith(AD_KEY_PREFIX)){
		    //如果使用主动缓存的情况下，直接清理返回空，这样就会重新存取数据
			return null;
		}
		return cacheProxy.get(key);
	}

	/**
	 * 存入对象, 缓存时间取默认值
	 * @param key
	 * @param value
	 */
	public void put(String key, Object value) {
		this.put(key, value, defaultExpiryMinutes);
	}

    /**
     * 存入对象
     * @param key
     * @param value
     * @param expirMins 过期时间
     */
	public void put(String key, Object value, int expirMins) {
//		if(value!=null) {
//			MemCachedClient mc = MC;
//			// mc.setPoolName(poolname);
//			mc.setCompressEnable(true);
//
//			long tnTime0 = System.currentTimeMillis();
//			if (expirMins > 0)
//				mc.set(MemcachedProxy.getGoodKey(key), value, new Date(1000 * 60 * expirMins));
//			else
//				mc.set(MemcachedProxy.getGoodKey(key), value,new Date(1000*60*30));
//			long tnTime1 = System.currentTimeMillis();
//			
//		} else {
//			try {
//				throw new Exception("Memcache value is null error! The key is :"+key);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
		if(value!=null){
			cacheProxy.put(key, value, expirMins);
		}
	}

	
	/**
     * add存入对象
     * @param key
     * @param value
     * @param expirMins 过期时间
     */
	public boolean add(String key, Object value, int expirMins) {
		if(value!=null){
			return cacheProxy.add(key, value, expirMins);
		}
		return false;
	}

    /**
     * 从缓存中移除对象
     * @param key
     */
	public void remove(String key) {
//		MemCachedClient mc = MC;
//		// mc.setPoolName(poolname);
//		mc.delete(MemcachedProxy.getGoodKey(key));
		//cacheProxy.remove(MemcachedProxy.getGoodKey(key));
		cacheProxy.remove(key);
	}

	/**
	 * 获取多个键值
	 * @param keys
	 * @return
	 */
	public Map<String, Object> getMulti(String[] keys) {
		return cacheProxy.getMulti(keys);
	}
	
	/**
	 * 存入字符串
	 * @param key
	 * @param value
	 */
	public void putString(String key, String value) {
		cacheProxy.putString(key, value);
	}
	
	/**
	 * 存入字符串
	 * @param key
	 * @param value
	 * @param expirMins
	 */
	public void putString(String key, String value, int expirMins) {
		cacheProxy.putString(key, value, expirMins);
	}
	
	/**
	 * 获取字符串
	 * @param key
	 * @return
	 */
	public String getString(String key) {
		return cacheProxy.getString(key);
	}
	
	public Date getDateAfter(int mins) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, mins);
		return cal.getTime();
	}
	
	public static void main(String [] args) {
	    MemcachedProxy m = new MemcachedProxy();
	    m.init();
	    m.put("aa", "aaaa");
	}
    

	/**
	 * 创建key，方法名，参数列表
	 * @param methodName
	 * @param traderName
	 * @param interfaceVersion
	 * @param provinceId
	 * @param currentPage
	 * @param pageSize
	 * @return
	 */
	public static String createKey(String methodName,String traderName,String interfaceVersion,Long provinceId,String date,Long viewId) {
		StringBuffer sb=new StringBuffer(AD_KEY_PREFIX);
		sb.append("_").append(methodName);
		sb.append("_").append(traderName);
		sb.append("_").append(interfaceVersion);
		if(provinceId!=null){
			sb.append("_").append(provinceId);
		}
		if(StringUtil.isNotEmpty(date)){
			sb.append("_").append(date);
		}
		if(viewId!=null){
			sb.append("_").append(viewId);
		}	
		sb.append("_").append(CommonKey.MEMCACHE_RETURN_RESULT_FLAG);
		return sb.toString();
	}
	
}
