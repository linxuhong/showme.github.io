package com.yihaodian.mobile.service.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class DateUtil.
 */
public class DateUtil {
    
    /** The Constant ONE_MIN_MILL_TIMES. */
    public final static Long ONE_MIN_MILL_TIMES = 60*1000l;
    /** The Constant ONE_HOUR_MILL_TIMES. */
    public final static Long ONE_HOUR_MILL_TIMES = 60*60*1000l;
    
    /** The Constant ONE_DAY_MILL_TIMES. */
    public final static Long ONE_DAY_MILL_TIMES = 24*ONE_HOUR_MILL_TIMES;
    
    /** The Constant TWELVE_HOUR_MILL_TIMES. */
    public final static Long TWELVE_HOUR_MILL_TIMES = 12*ONE_HOUR_MILL_TIMES;
    
    public final static String COMMON_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    
	public static final String DATE_MILLIS_FORMAT = "yyyyMMddHHmmss.SSS";

    /**
     * Parses the date to string.
     *
     * @param date the date
     * @return the string
     */
    public static String parseDateToString(Date date) {
        try {
            final SimpleDateFormat sdf = new SimpleDateFormat(COMMON_DATETIME_FORMAT);
            return sdf.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
    
    /**
     * 获取当天是星期几.
     *
     * @param date the date
     * @return the week day
     */
    public static int getWeekDay(Date date){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int weekDay = calendar.get(Calendar.DAY_OF_WEEK);
        if(weekDay==1){
            return 7;
        }
        return weekDay-1;
    }
    
    /**
     * 格式化日期.
     *
     * @param date the date
     * @param dayFormat the day format
     * @return the day format
     */
    public static String getDayFormat(Date date , String dayFormat){
        SimpleDateFormat sdf = new SimpleDateFormat(dayFormat);
        return sdf.format(date);
    }
    
    /**
     * Gets the date.
     *
     * @param dateStr the date str
     * @param dayFormat the day format
     * @return the date
     */
    public static Date getDate(String dateStr , String dayFormat){
        SimpleDateFormat sdf = new SimpleDateFormat(dayFormat);
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new Date();
    }
    
    /**
     * 获取两个日期相差的天数.
     *
     * @param smdate the smdate
     * @param bdate the bdate
     * @return the int
     */
    public static int daysBetween(String smdate,String bdate){  
        try {
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");  
            Calendar cal = Calendar.getInstance();    
            cal.setTime(sdf.parse(smdate));    
            long time1 = cal.getTimeInMillis();                 
            cal.setTime(sdf.parse(bdate));    
            long time2 = cal.getTimeInMillis();         
            Long between_days=(time2-time1)/(1000*3600*24);  
            return between_days.intValue();     
        }catch (Exception e) {
            e.printStackTrace();
        }
            return 0;
    }
    
    /**
     * 获取两个日期相差的天数.
     *
     * @param smdate the smdate
     * @param bdate the bdate
     * @return the int
     */
    public static int daysBetweenForDate(Date smdate,Date bdate){  
        try {   
            long time1 = smdate.getTime();                  
            long time2 = bdate.getTime();         
            Long between_days=(time2-time1)/(1000*3600*24);  
            return between_days.intValue();     
        }catch (Exception e) {
            e.printStackTrace();
        }
            return 0;
    }
    
    /**
     * 获取两个日期相差的天数.
     *
     * @param smdate the smdate
     * @param bdate the bdate
     * @return the int
     */
    public static int hoursBetweenForDate(Date smdate,Date bdate){  
        try {   
            long time1 = smdate.getTime();                  
            long time2 = bdate.getTime();         
            Long between_days=(time2-time1)/(1000*3600);  
            return between_days.intValue();     
        }catch (Exception e) {
            e.printStackTrace();
        }
            return 0;
    }
    
    /**
     * Gets the today zero time.
     *
     * @return the today zero time
     */
    public static Long getTodayZeroTime(){
        try{
            Date date = new Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH),0,0,0);
            calendar.set(Calendar.MILLISECOND, 0);
            return calendar.getTimeInMillis();
        }catch(Exception e){
            e.printStackTrace();
        }
        return 0l;
    }
    
    /**
     * Gets the calenday buy diff hour.
     *
     * @param startTime the start time
     * @return the calenday buy diff hour
     */
    public static long getCalendayBuyDiffHour(String startTime){
        try{
            Date startDate = getDate(startTime, "yyyy-MM-dd HH");
            long diffTimes = (new Date().getTime()-startDate.getTime())/ONE_HOUR_MILL_TIMES;
            return diffTimes;
        }catch(Exception e){
            e.printStackTrace();
        }
        return 0l;
    }
    
    /**
     * 返回和指定日期相差指定天数的日期.
     *
     * @param date the date
     * @param diffDays the diff days
     * @return the designation date
     */
    public static Date getDesignationDate(Date date , int diffDays){
        try{
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, diffDays);
            return calendar.getTime();
        }catch(Exception e){
            e.printStackTrace();
        }
        return date;
    }
    
    /**
     * 返回和指定日期相差指定时间数的日期
     * @param date
     * @param calendarFlag
     * @param diffCount
     * @return
     */
    public static Date getDesignationDate(Date date, int calendarFlag, int diffCount){
        try{
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(calendarFlag, diffCount);
            return calendar.getTime();
        }catch(Exception e){
            e.printStackTrace();
        }
        return date;
    }

    /**
     * 比较两个日期.
     *
     * @param smdate the smdate
     * @param bdate the bdate
     * @param dateFormat the date format
     * @return 0:equal;1 large;-1 less then
     */
    public static int compareDate(String smdate,String bdate,String dateFormat){  
        try {
            SimpleDateFormat sdf=new SimpleDateFormat(dateFormat);  
            if(smdate.equals(bdate))
                return 0;
            boolean comparedValue= sdf.parse(smdate).after(sdf.parse(bdate));
            return comparedValue?1:-1;
        }catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    /**
     * 和当前时间比较1 大于  -1 小于.
     *
     * @param smdate the smdate
     * @param dateFormat the date format
     * @return the int
     */
    public static int compareWithNow(String smdate,String dateFormat){  
        try {
            SimpleDateFormat sdf=new SimpleDateFormat(dateFormat);  
            boolean comparedValue= sdf.parse(smdate).after(new Date());
            return comparedValue?1:-1;
        }catch (Exception e) {
            e.printStackTrace();
        }
          return 0;
      }
    
    
    /**
     * 获取两个日期相差的小时.
     *
     * @param smdate the smdate
     * @param dateFormat the date format
     * @return the double
     */
    public static double hoursBetweenNow(String smdate,String dateFormat){  
        try {   
            SimpleDateFormat sdf=new SimpleDateFormat(dateFormat);  
            long time1 = sdf.parse(smdate).getTime();                  
            long time2 = System.currentTimeMillis();         
            return (time1-time2)/(1000.0*3600.0);  
            
        }catch (Exception e) {
            e.printStackTrace();
        }
            return 0;
    }
    
    public static Integer getMinsBetweenTimes(Date date,int hour){
        int min = 0 ;
        Date date1 = getDesignationDate(date, 1)  ; 
        date1.setHours(hour);
        date1.setMinutes(0);
        date1.setSeconds(0);
        min = (int)((date1.getTime()-date.getTime())/ONE_MIN_MILL_TIMES);
        return min ;
    }
    
	public static int getMins2NextHour() {
		Calendar calendar = Calendar.getInstance();
		Long now = calendar.getTimeInMillis();
		calendar.add(Calendar.HOUR_OF_DAY, 1);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		Long next = calendar.getTimeInMillis();
		
		return (int)((next-now)/ONE_MIN_MILL_TIMES+1);
	}
	
    /**
     * Parses the date to string.
     *
     * @param date the date
     * @return the string
     */
    public static String parseDateToyyyyMMdd(Date date) {
        try {
            final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            return sdf.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
    
    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        System.out.println(getMinsBetweenTimes(new Date(),10));
    }
}
