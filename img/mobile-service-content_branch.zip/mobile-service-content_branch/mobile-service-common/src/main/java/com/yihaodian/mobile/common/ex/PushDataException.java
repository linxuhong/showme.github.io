package com.yihaodian.mobile.common.ex;

/**
 * 服务推送异常
 * @author oumingzhi
 * @date 2012-12-21 12:58
 */
public class PushDataException extends Exception {

	public PushDataException() {
		super();
	}

	public PushDataException(String msg) {
		super(msg);
	}

	public PushDataException(String msg, Throwable cause) {
		super(msg, cause);
	}

	public PushDataException(Throwable cause) {
		super(cause);
	}
}