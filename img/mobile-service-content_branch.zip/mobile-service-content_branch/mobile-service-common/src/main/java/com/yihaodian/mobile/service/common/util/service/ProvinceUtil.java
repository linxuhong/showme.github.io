package com.yihaodian.mobile.service.common.util.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

public class ProvinceUtil {
    
    public static Long getProvinceIdFormToken(String token) {
        Long pageAddressProvinceId = getProvinceIdBySessionId(ServletActionContext
            .getRequest(), ServletActionContext.getResponse());
        return pageAddressProvinceId;
    }
    

    private static long getProvinceIdBySessionId(HttpServletRequest request, HttpServletResponse response)
    {
      return com.yihaodian.front.global.util.HomeUtil.getProvinceIdBySessionId(request, response);
    }

}
