package com.yihaodian.mobile.service.common.util.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.activation.DataSource;
import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.newheight.hessianService.model.sms.ISmsSend;
import com.newheight.hessianService.model.sms.SmsSend;
import com.newheight.hessianService.model.sms.SmsSendResult;
import com.newheight.hessianService.service.sms.SmsSendService;
import com.newheight.support.EdmServiceContainer;
import com.yihaodian.mobile.framework.common.log.annotation.LogAnnotation;
import com.yihaodian.mobile.vo.EmailVO;
@Service("mailSenderUtil")
public class SmsSendUtil {
	private static Logger logger = Logger.getLogger(SmsSendUtil.class);
	@Resource(name="mailSender")
	private JavaMailSenderImpl mailSender;
	/**
	 * 	发送邮件
	 * @param emailVO
	 */
	@LogAnnotation
	public  void sendMimeMessage(EmailVO emailVO){
 		if(emailVO != null && !StringUtils.isEmpty(emailVO.getFrom()) && !StringUtils.isEmpty(emailVO.getSubject()) && emailVO.getRecipients() != null && emailVO.getRecipients().length > 0){
			MimeMessage mimeMessage = mailSender.createMimeMessage();
			try {
				MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true,"UTF-8");
				mimeMessageHelper.setFrom(emailVO.getFrom());
				mimeMessageHelper.setTo(emailVO.getRecipients());
				if(emailVO.getCcs() != null && emailVO.getCcs().length > 0){
					mimeMessageHelper.setCc(emailVO.getCcs());
				}
				if(emailVO.getBccs() != null && emailVO.getBccs().length > 0){
					mimeMessageHelper.setCc(emailVO.getBccs());
				}
				mimeMessageHelper.setSubject(emailVO.getSubject());
				if(emailVO.getIsHTMLText()){
					emailVO.setContent(getHTMLMailContent(emailVO.getContent()));
				}
				mimeMessageHelper.setText(emailVO.getContent(), emailVO.getIsHTMLText());
				if(emailVO.getFileAttachment() != null && emailVO.getFileAttachment().size() > 0){
					Iterator<Map.Entry<String, File>> fileAttachmentEntry = emailVO.getFileAttachment().entrySet().iterator();
					while(fileAttachmentEntry.hasNext()){
						Map.Entry<String, File> entry = (Map.Entry<String, File>) fileAttachmentEntry.next(); 
						String attachmentName = entry.getKey();
						File attachment = entry.getValue();
						mimeMessageHelper.addAttachment(attachmentName, attachment);
					}
				}
				if(emailVO.getDataSourceAttachment() != null && emailVO.getDataSourceAttachment().size() > 0){
					Iterator<Map.Entry<String, DataSource>> dataSourceAttachmentEntry = emailVO.getDataSourceAttachment().entrySet().iterator();
					while(dataSourceAttachmentEntry.hasNext()){
						Map.Entry<String, DataSource> entry = (Map.Entry<String, DataSource>) dataSourceAttachmentEntry.next(); 
						String attachmentName = entry.getKey();
						DataSource attachment = entry.getValue();
						mimeMessageHelper.addAttachment(attachmentName, attachment);
					}
				}
				if(emailVO.getInputStreamSourceAttachment() != null && emailVO.getInputStreamSourceAttachment().size() > 0){
					Iterator<Map.Entry<String, InputStreamSource>> inputStreamSourceAttachmentEntry = emailVO.getInputStreamSourceAttachment().entrySet().iterator();
					while(inputStreamSourceAttachmentEntry.hasNext()){
						Map.Entry<String, InputStreamSource> entry = (Map.Entry<String, InputStreamSource>) inputStreamSourceAttachmentEntry.next(); 
						String attachmentName = entry.getKey();
						InputStreamSource attachment = entry.getValue();
						mimeMessageHelper.addAttachment(attachmentName, attachment);
					}
				}
				//sleep();
				mailSender.send(mimeMessage);
				logger.info("Mail successfully sent:"+emailVO);
			} catch (MessagingException ex) {
				logger.error("Error occors when sending Mime message " + emailVO, ex);
			} catch (Exception ex) {
				logger.error("Error occors when sending Mime message " + emailVO, ex);
			}
		} else {
			logger.error("Error occors when preparing to send Mime message " + emailVO);
		}
		
	}
	@LogAnnotation
	private static String getHTMLMailContent(String content){
		StringBuffer sbMailContent = new StringBuffer();
		sbMailContent.append("<html><head><style>div.mail-content{margin-left:25px;}table.mail-data{border:1px solid #66CCFF;border-collapse:collapse;width:1200px;text-align:center;}table.mail-data tr.even{background:	#E8EDFF;}table.mail-data td,table.mail-data th{border:1px solid #66CCFF;}table.mail-data th{background:	#E8EDFF;}</style></head><body><div>Hi,</div><div class=\"mail-content\">");
		sbMailContent.append(content);
		sbMailContent.append("</div></body></html>");
		return sbMailContent.toString();
	}
//	@LogAnnotation
//	private static void sleep(){
//		try {
//			Thread.sleep(10000);
//		} catch (InterruptedException ex) {
//			logger.error("Error occors when preparing to send mails", ex);
//		}
//	}
	
	public static boolean sendSingleSMS(String mobile, String content){
		SmsSendService smsService = EdmServiceContainer.getInstance().getService(SmsSendService.class);
		SmsSend smsSend = new SmsSend();
		smsSend.setMobile(mobile);
		smsSend.setContent(content);
		smsSend.setSource(160);
		SmsSendResult<String> result = smsService.smsSend(smsSend);
		if(result.getResultType().getType()==SmsSendResult.RESULTTYPE.SUCCESS.getType()) {
			return true;
		}
		logger.error("sendSingleSMS return error:"+result.getResultType());
		return false;
	}
	
	
}
