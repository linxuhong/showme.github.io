package com.yihaodian.mobile.service.common.business.util.user;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.yihaodian.gold.client.model.Return;
import com.yihaodian.gold.client.model.in.EndUserGoldQueryIn;
import com.yihaodian.gold.client.model.in.GoldBaseIn;
import com.yihaodian.gold.client.model.out.EndUserGoldOut;
import com.yihaodian.gold.client.model.out.GoldBaseOut;
import com.yihaodian.gold.client.service.client.GoldClient;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.service.common.util.SysUtil;
import com.yihaodian.mobile.service.domain.business.dal.backend.GamePromotion;
import com.yihaodian.mobile.service.domain.business.emuns.BusinessResultCode;
import com.yihaodian.myyhdservice.client.service.MyyhdPointServiceClient;
import com.yihaodian.myyhdservice.interfaces.enums.point.PointSendSourceType;
import com.yihaodian.myyhdservice.interfaces.inputvo.point.MyyhdLotteryPointInputVo;
import com.yihaodian.myyhdservice.interfaces.inputvo.point.MyyhdPointSendInputVo;
import com.yihaodian.myyhdservice.interfaces.outputvo.MyyhdServiceResult;


/**
 * 用户积分服务工具类
 * @author zhangwei5
 * @version $Id: UserPointServiceUtil.java, v 0.1 2014年7月18日 上午10:28:18 zhangwei5 Exp $
 */
public class UserPointServiceUtil {
    
    private static Logger logger = LoggerFactory.getLogger(UserPointServiceUtil.class);

    /**
     * 用户积分更新
     * @param costPoint 消耗积分
     * @param winPoint 获取积分
     * @param userId 用户Id
     * @param type //1-加积分；2-加减积分；3-减积分
     * @param productId //类型
     * @return
     */
    public static Boolean updateUserPoint(int costPoint , int winPoint , Long userId , int type ,Long productId){
        try {
            MyyhdLotteryPointInputVo input = new MyyhdLotteryPointInputVo();
            input.setCostPoint(costPoint+1);
            input.setCurrSiteType(1);//入参 1
            input.setTypeExc(type);//1-加积分；2-加减积分；3-减积分
            input.setEndUserId(userId);
            input.setWinPoints(winPoint+1);
            input.setProductId(-1l);//摇一摇传 -1
            MyyhdServiceResult<Boolean> myyhdServiceResult = MyyhdPointServiceClient.getInstance().updatePointLogForPointAddOrCost(input);
            if(myyhdServiceResult.getResult()){
                return myyhdServiceResult.getResult();
            }
        } catch (Exception e) {
            logger.error("updateUserPoint has error ",e);
        }
        return false;
    }
    
    /**
     * 发放积分
     * @param userId 用户Id
     * @param rewardPoints 发放的积分值
     * @param sourceType 类型
     * @return
     */
    public static Boolean pointSendByUserId(Long userId ,int rewardPoints,PointSendSourceType sourceType){
        try {
            MyyhdPointSendInputVo inputVo = new MyyhdPointSendInputVo();

            inputVo.setUserId(userId);

            inputVo.setSourceType(sourceType);

            inputVo.setType(1);

            inputVo.setWinPoint(rewardPoints);

            MyyhdServiceResult<Integer> result = MyyhdPointServiceClient.getInstance().pointSendByUserId(inputVo);
            
            if(result.getServiceResult()!=null&&result.getServiceResult().getCode().equals("00000000")){
                return true;
            }

        } catch (Exception e) {
            logger.error("pointSendByUserId has error ",e);
        }
        return false;
    }

    /**
     * 查金币数
     * @param userid
     * @return
     */
    public static EndUserGoldOut queryGold(Long userid) {
        try {
            EndUserGoldQueryIn in = new EndUserGoldQueryIn();
            in.setEndUserId(userid);
            Return<EndUserGoldOut> result = GoldClient.getQueryGoldHedwigService().findGoldByUserId(in);
            return result.getOut();
        } catch (Exception e) {
             logger.error("invoke getQueryGoldHedwigService err: ",e);
             return null;
        }

    }

    /**
     * 增减金币
     * - optype 
     * GoldTransactionTypeEnum.TRANSACTION_TYPE_OBTAIN_APP_GAME ; +
     * GoldTransactionTypeEnum.TRANSACTION_TYPE_DEDUCT_APP_GAME 
     *  - reqTicketCode 
     *  这个当时需求是 你们的业务流水号 需要保证唯一 chenjunning(陈君宁)
     * 17:48:08 可以区分一个游戏一个用户 第几次操作 最大30
     */
    public static boolean handleGoldGameProcess(Long userid ,Long channelId,Integer goldNum, Integer oprType,Integer maxIssuePoints, String reqTicketCode  ){
        try {
            GoldBaseIn in =new GoldBaseIn();
            in.setEndUserId(userid);
            in.setChannelId(channelId);
            in.setGoldNum(goldNum);
            in.setOprType(oprType);
            in.setReqTicketCode(reqTicketCode);
            if (maxIssuePoints!=null) {
            	in.setMemo(maxIssuePoints.toString());
            }
            Return<GoldBaseOut> result = GoldClient.getGoldHedwigServiceForApp().handleGoldGameProcess(in);
            if (!SysUtil.isProduction()) {
            	System.out.println(JSON.toJSONString(in));
            	System.out.println(JSON.toJSONString(result));
            }
            if(result!=null && result.getOut()!=null && result.getOut().getIsSuccess() ==0 )
                return true;
            
        } catch (Exception e) {
            logger.error("invoke handleGoldGameProcess err: ",e);
        }
        return false;
    }
    
    public static ResultModel handleGoldGameProcess2(Long userid, Long channelId, Integer goldNum, Integer oprType,
            String reqTicketCode, Integer maxIssuePoints) {
        ResultModel result = new ResultModel();
        try {
            GoldBaseIn in = new GoldBaseIn();
            in.setEndUserId(userid);
            in.setChannelId(channelId);
            in.setGoldNum(goldNum);
            in.setOprType(oprType);
            in.setReqTicketCode(reqTicketCode);
            if (maxIssuePoints!=null) {
                in.setMemo(maxIssuePoints.toString());
            }
            Return<GoldBaseOut> res = GoldClient.getGoldHedwigServiceForApp().handleGoldGameProcess(in);
            if (!(res != null && res.getOut() != null && res.getOut().getIsSuccess() == 0)) {
                result.setSuccess(false);
                result.setBaseResultCode(BusinessResultCode.GOLD_EXCHANGE_FAIL);
                if(res!=null)
                result.setResultDesc("金币失败code:"+res.getCode());
                return result;
            }
        } catch (Exception e2) {
            logger.error("handleGoldGameProcess2 Exception.", e2);
            result.setSuccess(false);
            result.setBaseResultCode(BusinessResultCode.ROCK_SYSTEM_EXCEPTION);
            return result;
        }
        return result;
    }
        
    
    
}
