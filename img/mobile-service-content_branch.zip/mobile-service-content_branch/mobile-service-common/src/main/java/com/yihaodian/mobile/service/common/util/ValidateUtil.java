package com.yihaodian.mobile.service.common.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidateUtil {

	/*
	 * 判断是否为整数
	 * 
	 * @param str 传入的字符串
	 * 
	 * @return 是整数返回true,否则返回false
	 */

	public static boolean isInteger(String str) {
		if(null == str || "".equals(str)){
			return false;
		}
		Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
		return pattern.matcher(str).matches();
	}

	/** 
     * 手机号验证 
     *  
     * @param  str 
     * @return 验证通过返回true 
     */  
    public static boolean isMobile(String str) {   
        Pattern p = null;  
        Matcher m = null;  
        boolean b = false;   
        p = Pattern.compile("^[1][2-9][0-9]{9}$"); // 验证手机号  
        m = p.matcher(str);  
        b = m.matches();   
        return b;  
    }  
    
	public static void main(String[] args){
		System.out.println(ValidateUtil.isMobile("12710527468"));
		System.out.println(ValidateUtil.isInteger(""));
		System.out.println(ValidateUtil.isInteger(" "));
		System.out.println(ValidateUtil.isInteger("123"));
	}
}
