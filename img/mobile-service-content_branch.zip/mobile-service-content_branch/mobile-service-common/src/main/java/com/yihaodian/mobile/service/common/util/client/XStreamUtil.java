package com.yihaodian.mobile.service.common.util.client;

import com.thoughtworks.xstream.XStream;

public class XStreamUtil {

    public static XStream x = new XStream();

    public static String objectToXml(Object obj) {
        return x.toXML(obj);
    }
    
    public static Object xmlToObject(String xml) {
        return x.fromXML(xml);
    }

}
