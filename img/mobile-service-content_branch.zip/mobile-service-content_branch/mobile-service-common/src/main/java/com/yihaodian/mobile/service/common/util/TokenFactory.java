package com.yihaodian.mobile.service.common.util;

public class TokenFactory {
    public static String getUserToken() {
        return java.util.UUID.randomUUID().toString();
    }
}
