package com.yihaodian.mobile.service.common.util;

import java.util.Map;
import com.yihaodian.mobile.service.common.util.service.MemcachedProxy;
import com.yihaodian.mobile.vo.constant.CommonKey;

public class UserLoginUtil {
	
	/**
	 * 用户名是否在24小时之内连续错误过3次，如果超过3次返回1否则返回0
	 * @param me
	 * @param userName 用户名
	 * @return
	 */
	public  int  checkIfNeedVerificationCode(String userName) {
		MemcachedProxy me = MemcachedProxy.getInstance();
        String loginAuthenticationMapKey = CommonKey.LOGIN_AUTHENTICATION_MAP_KEY+userName;
        Map<String, Object> loginAuthenticationMap = (Map<String, Object>) me.get(loginAuthenticationMapKey);
        if (loginAuthenticationMap != null) {
            String firstLoginTimeKey = "loginAuthentication_first_login_time" + userName;
            String secondLoginTimeKey = "loginAuthentication_second_login_time" + userName;
            String thirdLoginTimeKey = "loginAuthentication_third_login_time" + userName;
        	Long firstLoginTime = (Long) loginAuthenticationMap.get(firstLoginTimeKey);
        	Long secondLoginTime = (Long) loginAuthenticationMap.get(secondLoginTimeKey);
        	Long thirdLoginTime = (Long) loginAuthenticationMap.get(thirdLoginTimeKey);
        	if (thirdLoginTime != null) {
        		// 已经记录3次的情况
        		if (firstLoginTime != null&&secondLoginTime != null) {
        			// 做一次空指针判断，实际上map存在且第三个不为null时，前两个一定不为null
        			if (thirdLoginTime!=null && (System.currentTimeMillis()-firstLoginTime)<CommonKey.MEMCACHE_INVALID_TIME__ONE_DAY_MILLIS) {
        				return 1;
        			}
        		}
        	}
        }
        return 0;
	}
}
