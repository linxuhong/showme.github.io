package com.yihaodian.mobile.service.common.business.util.product;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.newheight.relatedCategory.client.RelatedCategoryClientPlugin;
import com.newheight.relatedCategory.model.CategoryRecommend;
import com.newheight.relatedCategory.service.RelatedCategoryService;

public class RelatedCategoryUtil {
	private static Logger logger = LoggerFactory.getLogger(RelatedCategoryUtil.class);
	private static RelatedCategoryService relatedCategoryService=null;
	static{
		relatedCategoryService = RelatedCategoryClientPlugin.getRemoteRelatedCategoryService();
	}

	/**
	 * 数据获取：
	 *用户买过的分类id（最多9个）
     *List<Long> buyList = Map.get(“buy”)
     *用户偏好的分类id（最少12个）
     *List<Long> recommendList = Map.get(“recommend”)
	 * @param userId
	 * @param guid
	 * @param provinceId
	 * @return
	 */
	public static Map<String,List<Long>>  getHotCategoryRecommend(Long userId,String guid,Long provinceId){
		Map<String,List<Long>> map = relatedCategoryService. hotCategoryRecommend(userId,guid,provinceId);
		return map;
	}
	
	/**
	 * 
	 * @param userid
	 * @param guid
	 * @param provinceId
	 * @param type  type=1 常用类目 type=2猜你喜欢
	 * @return
	 */
	public static List<CategoryRecommend> hotCategoryRecommendWithPicture(Long userid,String guid,Long provinceId,String type){
		try {
			List<CategoryRecommend> categ = relatedCategoryService.hotCategoryRecommendWithPicture(userid, guid, provinceId, type);
			return categ;
		} catch (Exception e) {
			return null;
		}
	}
}
