package com.yihaodian.mobile.service.common.util;

public class UsernameUtil {
	
	public static String changeUserNametoHidden(String userName){
		if(userName == null || "".equals(userName))
			return "佚名***";
		int index = userName.indexOf('@');
		if(index != -1){
			if(index > 3){
				return userName.substring(0,3)+"***";
			}
			if(index == 3){
				return userName.substring(0,2)+"***";
			}
			if(index == 2){
				return userName.substring(0,1)+"***";
			}
			if(index == 1){
				return userName+"***";
			}
			return "佚名***";
		}else{
			String reg = "^[^u4E00-u9FA5]+$";
			if(userName.matches(reg)){
				int len = userName.length();
				if(len >= 2){
					return userName.substring(0,1)+"**"+userName.substring(len-1,len);
				}else if(len == 1){
					return userName+"**";
				}else{
					return "佚名***";
				}
			}else{
				int len = userName.length();
				if(len > 2){
					return userName.substring(0,3)+"***";
				}else if(len == 2){
					return userName.substring(0,2)+"***";
				}else if(len == 1){
					return userName+"***";
				}else{
					return "佚名***";
				}
			}
	        
		}
//		return "佚名***";
	}

}
