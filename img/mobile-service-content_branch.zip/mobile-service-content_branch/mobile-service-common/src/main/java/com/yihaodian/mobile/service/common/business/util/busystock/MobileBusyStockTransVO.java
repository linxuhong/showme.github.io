package com.yihaodian.mobile.service.common.business.util.busystock;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yhd.pss.spi.merchant.vo.Merchant;
import com.yihaodian.front.busystock.vo.BSProductVo;
import com.yihaodian.front.busystock.vo.BSPromotionProductVo;
import com.yihaodian.mobile.service.common.business.util.merchant.MerchantServiceUtil;
import com.yihaodian.mobile.vo.home.DiaryProductVO;
import com.yihaodian.mobile.vo.product.ProductVO;

/**
 * 设置商品价格库存信息
 * @author zhangwei5
 * @version $Id: MobileBusyStockTransVO.java, v 0.1 2014年10月9日 下午1:25:13 zhangwei5 Exp $
 */
public class MobileBusyStockTransVO {

    private static Logger logger = LoggerFactory.getLogger(MobileBusyStockTransVO.class);
    
    public static DiaryProductVO setBusyStockInfoByBsProductVO(BSProductVo bspVo , DiaryProductVO productVO){
        try {
            if(bspVo!=null){
                //产品销售商Id
                productVO.setPmInfoId(bspVo.getPmId());
                productVO.setMerchantId(bspVo.getMerchantId());
                if(bspVo.getCanShow() ==1 && bspVo.getCanSale()==1 && bspVo.getCurrentStockNum()>0){
                    productVO.setCanBuy(true);
                }else{
                    productVO.setCanBuy(false);
                }
                productVO.setCurrentPrice(new BigDecimal(bspVo.getCurrentPrice()));
                productVO.setPromotePrice(bspVo.getPromNonMemberPrice());
                productVO.setYhdPrice(bspVo.getNonMemberPrice());
                productVO.setMarketPrice(bspVo.getMarketPrice().doubleValue());            
                // 促销类型 1:无数量限制促销 2:限制每个订单以促销价购买数量 3:限制每个会员的购买数量 4:限制商品总共购买数量 5:限制每个订单的总数量
                // 4:限制商品总共购买数量 
                if(bspVo.getPromoteType() == 4){
                    long leftNum = bspVo.getSpecialPriceLimitNumber() - bspVo.getSpecialPriceSoldNum();
                    // 如果剩余库存不足限购剩余个数，则返回最小可用库存
                    if(bspVo.getCurrentStockNum() < leftNum){
                        leftNum = bspVo.getCurrentStockNum();
                    }
                    productVO.setCurrentStock(Long.valueOf(leftNum));
                }else{
                    productVO.setCurrentStock(bspVo.getCurrentStockNum());
                }
                Merchant merchant = MerchantServiceUtil.queryBaseMerchantById(bspVo.getMerchantId());
                if(null !=merchant){
                    productVO.setMerchantName(merchant.getMerchantName());
                }  
                productVO.setPmInfoId(bspVo.getPmId());
                productVO.setChannelId(bspVo.getChannelId());
            }else{
                productVO.setCanBuy(false);
            } 
        } catch (Exception e) {
            logger.error("setBusyStockInfoByBsProductVO has error ", e);
        }
        
        return productVO;
    }
    
    public static DiaryProductVO setBusyStockInfoByBsProductVO(BSPromotionProductVo bspVo , DiaryProductVO productVO){
        try {
            if(bspVo!=null){
                Boolean canBuy = true;
                //产品销售商Id
                productVO.setPmInfoId(bspVo.getPmId());
                productVO.setMerchantId(bspVo.getMerchantId());
                //当前库存小于0
                if(bspVo.getCurrentStockNum().longValue()<=0){
                    canBuy=false;
                }
                //活动尚未开始
                if(bspVo.getStatus()==null||bspVo.getStatus()!=1){
                    canBuy=false;
                }
                if(bspVo.getCurrentCanBuyNum().longValue()<=0){
                    canBuy=false;
                }
                productVO.setCurrentPrice(bspVo.getCurrentPrice());
                productVO.setPromotePrice(bspVo.getPromNonMemberPrice().doubleValue());
                productVO.setYhdPrice(bspVo.getNonMemberPrice().doubleValue());
                productVO.setMarketPrice(bspVo.getMarketPrice().doubleValue());
                // 可购买数量
                productVO.setCurrentStock(bspVo.getCurrentCanBuyNum().longValue());
                Merchant merchant = MerchantServiceUtil.queryBaseMerchantById(bspVo.getMerchantId());
                if(null !=merchant){
                    productVO.setMerchantName(merchant.getMerchantName());
                }  
                productVO.setPmInfoId(bspVo.getPmId());
                productVO.setCanBuy(canBuy);
                productVO.setChannelId(bspVo.getChannelId());
            }else{
                productVO.setCanBuy(false);
            }
        } catch (Exception e) {
            logger.error(" setBusyStockInfoByBsProductVO has error ", e);
        }

        return productVO;
    }
    
    
    public static ProductVO setBusyStockInfoByBsProductVO(BSPromotionProductVo bspVo , ProductVO productVO){
        try {
            if(bspVo!=null){
                Boolean canBuy = true;
                //产品销售商Id
                productVO.setPmId(bspVo.getPmId());
                productVO.setMerchantId(bspVo.getMerchantId());
                //当前库存小于0
                if(bspVo.getCurrentStockNum().longValue()<=0){
                    canBuy=false;
                }
                //活动尚未开始
                if(bspVo.getStatus()==null||bspVo.getStatus()!=1){
                    canBuy=false;
                }
                if(bspVo.getCurrentCanBuyNum().longValue()<=0){
                    canBuy=false;
                }
                productVO.setPrice(bspVo.getCurrentPrice().doubleValue());
                productVO.setYhdPrice(bspVo.getNonMemberPrice().doubleValue());
                productVO.setMaketPrice(bspVo.getMarketPrice().doubleValue());
                productVO.setCanBuy(canBuy);
                productVO.setChannelId(bspVo.getChannelId());
            }else{
                productVO.setCanBuy(false);
            }
        } catch (Exception e) {
            logger.error(" setBusyStockInfoByBsProductVO has error ", e);
        }

        return productVO;
    }
    
    public static ProductVO setBusyStockInfoByBsProductVOV2(BSPromotionProductVo bspVo , ProductVO productVO){
        try {
            if(bspVo!=null){
                Boolean canBuy = true;
                //产品销售商Id
                productVO.setPmId(bspVo.getPmId());
                productVO.setMerchantId(bspVo.getMerchantId());
                productVO.setPromotionId(bspVo.getPromotionId().toString()+"_0_landingpage");
                //当前库存小于0
                if(bspVo.getCurrentStockNum().longValue()<=0){
                    canBuy=false;
                }
                //活动尚未开始
                if(bspVo.getStatus()==null||bspVo.getStatus()!=1){
                    canBuy=false;
                }
                if(bspVo.getCurrentCanBuyNum().longValue()<=0){
                    canBuy=false;
                }
                productVO.setPrice(bspVo.getCurrentPrice().doubleValue());
                productVO.setPromotionPrice(bspVo.getPromNonMemberPrice().doubleValue());
                productVO.setYhdPrice(bspVo.getNonMemberPrice().doubleValue());
                productVO.setMaketPrice(bspVo.getMarketPrice().doubleValue());
                productVO.setCanBuy(canBuy);
                productVO.setChannelId(bspVo.getChannelId());
                productVO.setBuyCount(bspVo.getSoldNum());//销量
            }else{
                productVO.setCanBuy(false);
            }
        } catch (Exception e) {
            logger.error(" setBusyStockInfoByBsProductVO has error ", e);
        }

        return productVO;
    }
}
