package com.yihaodian.mobile.service.common.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.Security;

import org.bouncycastle.jce.provider.BouncyCastleProvider;


public class AliPayUtil {
	
	static {
		Security.addProvider(new BouncyCastleProvider());
	}
	
	/**
	 * 对参数进行签名
	 * 
	 * @param signData 待签名数据，key rsa商户私钥
	 * @return
	 */
	public static String sign(String signData,String key) {
		String sign = "";
		try {
			sign = RSASignature.sign(signData, key);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return sign;
	}
	
	private static String getSignDate(String partner, String seller, String outTradeNo, String subject, String body, 
				String totalFee, String notifyUrl,String accesstoken) {
		
		String signData = "partner=" + "\"" + partner + "\"";
		signData += "&";
		signData += "seller=" + "\"" + seller + "\"";
		signData += "&";
		signData += "out_trade_no=" + "\"" + outTradeNo + "\"";
		signData += "&";
		signData += "subject=" + "\"" + subject+ "\"";
		signData += "&";
		signData += "body=" + "\"" + body + "\"";
		signData += "&";
		signData += "total_fee=" + "\""+ totalFee + "\"";
		signData += "&";
		signData += "notify_url=" + "\""+notifyUrl+ "\"";
		if(accesstoken != null){
			signData += "&";
			signData += "extern_token=" + "\""+accesstoken+ "\"";
		}
		return signData;
	}
	
	/**
	 * 
	 * @param outTraderNo  外部订单号
	 * @param subject      商品主题
	 * @param body         商品描述
	 * @param totalFee     商品价格
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	public static String response(String partner, String seller, String outTradeNo, String subject, String body, 
			String totalFee, String notifyUrl, String key,String accesstoken) throws UnsupportedEncodingException {
		String strReString = "";
		if(!checkInfo(partner, seller)){
			strReString="<result><is_success>F</is_success><error>缺少partner或者seller," +
		    		"请在com/alipay/client/base/PartnerConfig.java中增加</error></result>";
			return strReString;
		}
		String signData = getSignDate(partner, seller, outTradeNo, subject, body, totalFee, notifyUrl,accesstoken);
		String signature = sign(signData, key);
	
		strReString=signData+"&sign=\""+URLEncoder.encode(signature,"utf-8")+"\"&sign_type=\"RSA\"";
//		strReString = URLEncoder.encode(strReString,"utf-8");
		return strReString;
	}
	
	private static boolean checkInfo(String partner, String seller) {
        //如果合作商户ID为空或者账号ID为空返回false
        if (com.yihaodian.mobile.framework.lang.utils.StringUtil.isBlank(partner) || com.yihaodian.mobile.framework.lang.utils.StringUtil.isBlank(seller))
            return false;
        return true;
    }
	
	
    public static String getOrderInfo(String subject, String body, String price,String partener ,String seller,String outTradeNo ,String notifyUrl) {
        String orderInfo = "partner=" + "\"" + partener + "\"";
        orderInfo += "&";
        orderInfo += "seller_id=" + "\"" + seller + "\"";
        orderInfo += "&";
        orderInfo += "out_trade_no=" + "\"" + outTradeNo + "\"";
        orderInfo += "&";
        orderInfo += "subject=" + "\"" + subject + "\"";
        orderInfo += "&";
        orderInfo += "body=" + "\"" + body + "\"";
        orderInfo += "&";
        orderInfo += "total_fee=" + "\"" + price + "\"";
        orderInfo += "&";
        orderInfo += "notify_url=" + "\"" +notifyUrl+ "\"";

        // 接口名称， 定值
        orderInfo += "&service=\"mobile.securitypay.pay\"";

        // 支付类型，定值
        orderInfo += "&payment_type=\"1\"";

        // 字符集，默认utf-8
        orderInfo += "&_input_charset=\"utf-8\"";

        // 超时时间 ，默认30分钟.
        // 设置未付款交易的超时时间，一旦超时，该笔交易就会自动被关闭。
        // 取值范围：1m～15d。
        // m-分钟，h-小时，d-天，1c-当天（无论交易何时创建，都在0点关闭）。
        // 该参数数值不接受小数点，如1.5h，可转换为90m。
        // 该功能需要联系支付宝配置关闭时间。
        orderInfo += "&it_b_pay=\"1d\"";

        return orderInfo;
    }
    
    /**
     * get the sign type we use. 获取签名方式
     * 
     * @return
     */
    public static String getSignType() {
        return "sign_type=\"RSA\"";
    }

}
