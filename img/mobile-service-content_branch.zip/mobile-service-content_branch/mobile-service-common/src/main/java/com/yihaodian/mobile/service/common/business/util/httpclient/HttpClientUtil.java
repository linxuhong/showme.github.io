package com.yihaodian.mobile.service.common.business.util.httpclient;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.google.common.collect.Lists;

/**
 * httpClient工具类
 * @author zhangwei5
 * @version $Id: HttpClientUtil.java, v 0.1 2014-3-4 上午10:08:46 zhangwei5 Exp $
 */
public class HttpClientUtil {
	private static Logger logger = LoggerFactory.getLogger(HttpClientUtil.class);
	public static final String DEFAULT_CHARSET = "utf-8";
	public static final String DEFAULT_CONTENT_TYPE = "application/zip";

	public static String httpClientPost(String url ,  Map<String, Object> parameters , Map<String , String> headers){
        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse response = null;
        HttpPost method = new HttpPost(url);
        
        if(headers!=null&&headers.values().size()>0){
        	for(Entry<String, String> en : headers.entrySet()){
        		method.setHeader(en.getKey(), en.getValue());
        	}
        }
        
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

        for(Entry<String, Object> entry : parameters.entrySet()){
        	String key = entry.getKey();
        	String value = entry.getValue().toString();
        	nameValuePairs.add(new BasicNameValuePair(key, value));
        }
        /*Set<String> keys = parameters.keySet();
        for (String key : keys) {
            nameValuePairs.add(new BasicNameValuePair(key, parameters.get(key).toString()));

        }*/
        UrlEncodedFormEntity rentity = null;
        try {
            rentity = new UrlEncodedFormEntity(nameValuePairs, "UTF-8");
        } catch (UnsupportedEncodingException e) {
        	logger.error("UnsupportedEncodingException when try to encode data for ".concat(url), e);
        }
        try {
            method.setEntity(rentity);
            response = httpClient.execute(method);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity);
            }

        } catch (ClientProtocolException e) {
            logger.error("ClientProtocolException when try to post data to ".concat(url), e);
        } catch (IOException e) {
            logger.error("IOException when try to post data to ".concat(url), e);
        }
        return null;
	}
	
	public static HttpResponse doPost(String url, Map<String, String> params) {
		return doPost(url, params, null);
	}
	
	public static HttpResponse doPost(String url, Map<String, String> params, Map<String, String> headers) {
		HttpClient httpClient = new DefaultHttpClient();
		HttpResponse response = null;
		HttpPost method = new HttpPost(url);
		try {
			httpClient.getParams().setParameter("http.connection.timeout", 1000);	
			httpClient.getParams().setParameter("http.socket.timeout", 1000);
			if (params != null) {
				List<NameValuePair> nameValuePairs = Lists.newArrayList();
				for (Map.Entry<String, String> entry : params.entrySet()) {
					NameValuePair n = new BasicNameValuePair((String)entry.getKey(), (String)entry.getValue());
					nameValuePairs.add(n);
				}
				if (!CollectionUtils.isEmpty(nameValuePairs)) {
					UrlEncodedFormEntity rentity = null;
					rentity = new UrlEncodedFormEntity(nameValuePairs, "UTF-8");
		    		method.setEntity(rentity);
		    	}
		    }
			if (headers != null) {
				for (Map.Entry<String, String> entry : headers.entrySet()) {
					method.setHeader(entry.getKey(), entry.getValue());
				}
			}
		    response = httpClient.execute(method);
		    return response;
		} catch (UnsupportedEncodingException e) {
			logger.error("httpclient ution has error UnsupportedEncodingException ", e);
		} catch (ClientProtocolException e) {
			logger.error("httpclient ution has error ClientProtocolException ", e);
		} catch (IOException e) {
			logger.error("httpclient ution has error IOException ", e);
		} finally {
			if (method != null) {
			  method.abort();
			}
			if ((httpClient != null) && (httpClient.getConnectionManager() != null)) {
			  httpClient.getConnectionManager().shutdown();
			}
		}
		if (method != null) {
		  method.abort();
		}
		if ((httpClient != null) && (httpClient.getConnectionManager() != null)) {
		  httpClient.getConnectionManager().shutdown();
		}

		return null;
	} 
	
	public static String doMultipartPost(String url, Map<String, String> params, Map<String, String> headers, File file) {
		org.apache.commons.httpclient.HttpClient httpClient = new org.apache.commons.httpclient.HttpClient();
		PostMethod method = new PostMethod(url);
		try {
			if (headers != null) {
				for (Map.Entry<String, String> entry : headers.entrySet()) {
					method.setRequestHeader(entry.getKey(), entry.getValue());
				}
			}
			List<Part> parts = Lists.newArrayList();
			if (params != null) {
				for (Map.Entry<String, String> entry : params.entrySet()) {
					Part part = new StringPart((String)entry.getKey(), (String)entry.getValue(), DEFAULT_CHARSET);
					parts.add(part);
				}
		    }
			if (file != null) {
				Part fPart = new FilePart(file.getName(), file, DEFAULT_CONTENT_TYPE, FilePart.DEFAULT_CHARSET);
				parts.add(fPart);
			}
			method.setRequestEntity(new MultipartRequestEntity(parts.toArray(new Part[0]), method.getParams()));
			int statusCode = httpClient.executeMethod(method);
			if (statusCode!=HttpStatus.SC_OK) {
				logger.error("PostMethod failed in doPostWithFile: "+method.getStatusLine());
			}
			return method.getResponseBodyAsString();
		} catch (HttpException e) {
			logger.error("HttpException in doPostWithFile", e);
		} catch (IOException e) {
			logger.error("IOException in doPostWithFile", e);
		} finally {
			method.releaseConnection();
		}
		return null;
	}
}
