package com.yihaodian.mobile.service.common.business.util.user;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.front.sso.common.vo.SsoUser;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.service.common.util.MobileCommonUtil;
import com.yihaodian.mobile.service.domain.business.emuns.CommonResultCode;

/**
 * 用户信息检查工具类
 * @author zhangwei5
 * @version $Id: UserCheckUtil.java, v 0.1 2014-4-4 上午10:18:15 zhangwei5 Exp $
 */
public class UserCheckUtil {
    private static Logger logger = LoggerFactory.getLogger(UserCheckUtil.class);
    
    public static Result checkTokenInfo(String token){
        Result result = new ResultModel();
        result.setSuccess(true);
        try {
            SsoUser user = MobileCommonUtil.getSessionUser(token);
            if(user==null){
                result.setSuccess(false);
                result.setBaseResultCode(CommonResultCode.PARAMS_TOKEN_FAIL_EXCEPTION);
            }
        } catch (Exception e) {
            logger.error(" validateParams has error ", e);
            result.setSuccess(false);
            result.setBaseResultCode(CommonResultCode.PARAMS_TOKEN_FAIL_EXCEPTION);
        }
        return result;
    
    }
}
