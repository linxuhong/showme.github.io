package com.yihaodian.mobile.service.common.business.util.queue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yhd.yqs.client.YqsClient;
import com.yhd.yqs.input.DecrTaskCountRequest;
import com.yhd.yqs.input.TaskRequest;
import com.yhd.yqs.output.TaskResponse;
import com.yhd.yqs.output.TaskStatusResponse;
import com.yhd.yqs.output.YQSResponse;
import com.yhd.yqs.service.QueueProcessFacadeService;
import com.yhd.yqs.vo.QueueMetaData;
import com.yhd.yqs.vo.TaskStatusVo;
import com.yhd.yqs.vo.TimeLimitedSalesMetaData;
import com.yihaodian.front.busystock.vo.BSProductPromRuleVo;
import com.yihaodian.mobile.framework.model.Result;
import com.yihaodian.mobile.framework.model.ResultModel;
import com.yihaodian.mobile.vo.seckill.TaskResponseVo;
import com.yihaodian.mobile.vo.seckill.TaskStatusResponseVo;

public class QueueProcessUtil {
	private static final Logger logger = LoggerFactory.getLogger(QueueProcessUtil.class);

	private static QueueProcessFacadeService queueProcessService;

	static {
		queueProcessService = YqsClient.getInstance().getQueueProcessFacadeService();
	}

	/**
	 * 获取任务状态
	 * 
	 * @param token 任务token
	 * @return
	 */
	public static Result getTaskStatus(String token) {
		Result result = new ResultModel();
		YQSResponse<TaskStatusResponse> resp = queueProcessService.getTaskStatus(token);
		if (resp.getHandleStatus() == Boolean.TRUE) {
			result.setSuccess(true);

			TaskStatusResponse model = resp.getResult();
			TaskStatusResponseVo vo = new TaskStatusResponseVo();
			vo.setBussinessResultJson(model.getBussinessResultJson());
			vo.setFrontReqCount(model.getFrontReqCount());
			vo.setStatusCode(model.getStatusCode());
			vo.setTaskType(model.getTaskType());
			vo.setWaitTime(model.getWaitTime());

			result.setDefaultModel(vo);
			return result;
		} else {
			if (resp.getException() != null) {
				logger.error(resp.getMessage(), resp.getException());
			} else {
				logger.error(resp.getMessage());
			}
			result.setSuccess(false);
			result.setResultDesc(resp.getMessage());
			return result;
		}
	}

	/**
	 * 获取任务列表
	 * 
	 * @param taskType 任务类型
	 * @param count 获取条数
	 * @return
	 */
	public static Result fetchTasks(Integer taskType, Integer count) {
		Result result = new ResultModel();
		YQSResponse<List<TaskResponse>> resp = queueProcessService.fetchTasks(taskType, count);
		if (resp.getHandleStatus() == Boolean.TRUE) {
			result.setSuccess(true);

			if (resp.getResult() == null || resp.getResult().isEmpty()) {
				result.setDefaultModel(Lists.newArrayList());
			} else {
				List<TaskResponseVo> list = new ArrayList<TaskResponseVo>(count);
				for (TaskResponse item : resp.getResult()) {
					TaskResponseVo vo = new TaskResponseVo();
					vo.setDataJson(item.getDataJson());
					vo.setTaskType(item.getTaskType());
					vo.setToken(item.getToken());
					list.add(vo);
				}
	
				result.setDefaultModel(list);
			}
			return result;
		} else {
			if (resp.getException() != null) {
				logger.error(resp.getMessage(), resp.getException());
			} else {
				logger.error(resp.getMessage());
			}
			result.setSuccess(false);
			result.setResultDesc(resp.getMessage());
			return result;
		}
	}

	/**
	 * 入队操作
	 * 
	 * @param type 队列类型
	 * @param json
	 * @return
	 * @see com.yhd.yqs.common.YQSConstants
	 */
	public static Result sendTask(Integer taskType, String dataJson, TimeLimitedSalesMetaData meta) {
		Result result = new ResultModel();
		TaskRequest<QueueMetaData> req = new TaskRequest<QueueMetaData>();
		req.setTaskType(taskType);
		req.setDataJson(dataJson);
		req.setQueueMetaData(meta);
		YQSResponse<String> resp = queueProcessService.sendTask(req);
		if (resp.getHandleStatus() == Boolean.TRUE) {
			result.setSuccess(true);
			Map<String, String> map = Maps.newHashMap();
			map.put("token", resp.getResult());
			result.setDefaultModel(map);
			return result;
		} else {
			if (resp.getException() != null) {
				logger.error(resp.getMessage(), resp.getException());
			} else {
				logger.error(resp.getMessage());
			}
			result.setSuccess(false);
			result.setResultDesc(resp.getMessage());
			return result;
		}
	}

	/**
	 * 从排队系统中取消任务
	 * 
	 * @param token
	 * @return
	 */
	public static Result cancelTask(String token) {
		Result result = new ResultModel();
		YQSResponse<TaskStatusResponse> resp = queueProcessService.cancelTask(token);
		if (resp.getHandleStatus() == Boolean.TRUE) {
			result.setSuccess(true);

			TaskStatusResponse model = resp.getResult();
			TaskStatusResponseVo vo = new TaskStatusResponseVo();
			vo.setBussinessResultJson(model.getBussinessResultJson());
			vo.setFrontReqCount(model.getFrontReqCount());
			vo.setStatusCode(model.getStatusCode());
			vo.setTaskType(model.getTaskType());
			vo.setWaitTime(model.getWaitTime());

			result.setDefaultModel(vo);
			return result;
		} else {
			if (resp.getException() != null) {
				logger.error(resp.getMessage(), resp.getException());
			} else {
				logger.error(resp.getMessage());
			}
			result.setSuccess(false);
			result.setResultDesc(resp.getMessage());
			return result;
		}
	}

	/**
	 * 回写任务状态
	 * 
	 * @param taskStatusVo
	 * @return
	 */
	public static Result setTaskStatus(TaskStatusVo taskStatusVo) {
		Result result = new ResultModel();
		YQSResponse<Boolean> resp = queueProcessService.setTaskStatus(taskStatusVo);
		if (resp.getHandleStatus() == Boolean.TRUE) {
			result.setSuccess(true);
			Map<String, Boolean> map = Maps.newHashMap();
			map.put("success", resp.getResult());
			result.setDefaultModel(map);
			return result;
		} else {
			if (resp.getException() != null) {
				logger.error(resp.getMessage(), resp.getException());
			} else {
				logger.error(resp.getMessage());
			}
			result.setSuccess(false);
			result.setResultDesc(resp.getMessage());
			return result;
		}
	}

	/**
	 * 设置促销价信息
	 * 
	 * @param productPromRuleVos
	 * @return
	 */
	public static Result initRuleInfo(List<BSProductPromRuleVo> productPromRuleVos) {
		Result result = new ResultModel();
		YQSResponse<Boolean> resp = queueProcessService.initRuleInfo(productPromRuleVos);
		if (resp.getHandleStatus() == Boolean.TRUE) {
			result.setSuccess(true);
			Map<String, Boolean> map = Maps.newHashMap();
			map.put("success", resp.getResult());
			result.setDefaultModel(map);
			return result;
		} else {
			if (resp.getException() != null) {
				logger.error(resp.getMessage(), resp.getException());
			} else {
				logger.error(resp.getMessage());
			}
			result.setSuccess(false);
			result.setResultDesc(resp.getMessage());
			return result;
		}
	}

	/**
	 * 取消订单扣减购买计数
	 * 
	 * @param productPromRuleVos
	 * @return
	 */
	public static Result decrTaskCount(Integer taskType, TimeLimitedSalesMetaData meta) {
		Result result = new ResultModel();
		DecrTaskCountRequest<QueueMetaData> req = new DecrTaskCountRequest<QueueMetaData>();
		req.setTaskType(taskType);
		req.setQueueMetaData(meta);
		YQSResponse<Boolean> resp = queueProcessService.decrTaskCount(req);
		if (resp.getHandleStatus() == Boolean.TRUE) {
			result.setSuccess(true);
			Map<String, Boolean> map = Maps.newHashMap();
			map.put("success", resp.getResult());
			result.setDefaultModel(map);
			return result;
		} else {
			if (resp.getException() != null) {
				logger.error(resp.getMessage(), resp.getException());
			} else {
				logger.error(resp.getMessage());
			}
			result.setSuccess(false);
			result.setResultDesc(resp.getMessage());
			return result;
		}
	}
}
