package com.yihaodian.mobile.service.common.util;

import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONArray;
import net.sf.json.JSONNull;
import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;

// TODO: Auto-generated Javadoc
/**
 * The Class JsonUtil.
 */
public class JsonUtil {
	  
  	/**
  	 * Gets the json array.
  	 *
  	 * @param obj the obj
  	 * @return the json array
  	 */
  	public static JSONArray getJsonArray(Object obj){
			JSONArray arrayjson ;//定义一个jsonarray型的对象
			JsonConfig jsonConfig= new JsonConfig();
			jsonConfig.registerJsonValueProcessor(String.class,new JsonUtil.NullValueProcesser());			   	
			arrayjson = JSONArray.fromObject(obj, jsonConfig);	
		    return arrayjson;
	  }
	
	  /**
  	 * The Class NullValueProcesser.
  	 */
  	public static class NullValueProcesser implements JsonValueProcessor
	  {
	    
    	/* (non-Javadoc)
    	 * @see net.sf.json.processors.JsonValueProcessor#processArrayValue(java.lang.Object, net.sf.json.JsonConfig)
    	 */
    	public Object processArrayValue(Object arg0, JsonConfig arg1) {
	      if (arg0 == null) {
	        return JSONNull.getInstance();
	      }
	      return arg0;
	    }

	    /* (non-Javadoc)
    	 * @see net.sf.json.processors.JsonValueProcessor#processObjectValue(java.lang.String, java.lang.Object, net.sf.json.JsonConfig)
    	 */
    	public Object processObjectValue(String arg0, Object arg1, JsonConfig arg2)
	    {
	      if (arg1 == null) {
	        return JSONNull.getInstance();
	      }
	      return arg1;
	    }
	  }
	  
	  /**
  	 * Object to json.
  	 *
  	 * @param obj the obj
  	 * @return the string
  	 */
  	public static String objectToJson(Object obj) {
	        StringBuilder json = new StringBuilder();
	        if (obj == null) {
	            json.append("\"\"");
	        }
	        return json.toString();
	    }
}
