package com.yihaodian.mobile.service.common.util.my;

import com.yihaodian.mobile.framework.lang.utils.encrypt.des.DesEncrypter;

public class MyyhdMobileDesEncrypterVirtualUtil {

    public static String getDesDecryptVirtualCode(String virtualCode) {
        String key = "012345678901234567890123";
        DesEncrypter desEncrypter = new DesEncrypter(key);
        String rs = "";
        try {
            rs = desEncrypter.decrypt(virtualCode);
        } catch (Exception e) {
            rs = virtualCode;
        }
        return rs;
    }
}
