package com.yihaodian.mobile.service.common.business.util.location;

import com.yihaodian.ip.tool.IPUtil;
import com.yihaodian.ip.vo.IPVo;

/**
 * 通过Ip查询省份信息工具类
 * @author zhangwei5
 * @version $Id: IpLocationUtil.java, v 0.1 2014-4-21 下午3:41:49 zhangwei5 Exp $
 */
public class IpLocationUtil {

    /**
     * 通过Ip查询地区信息
     * @param ip
     * @return
     */
    public static IPVo getIpVOByIp(String ip){
        IPVo ipVo = IPUtil.getIPVoByIpString(ip);
        return ipVo;
    }
}
