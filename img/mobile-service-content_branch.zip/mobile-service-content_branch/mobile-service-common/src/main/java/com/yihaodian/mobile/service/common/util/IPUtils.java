package com.yihaodian.mobile.service.common.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


// TODO: Auto-generated Javadoc
/**
 * The Class IPUtils.
 */
public class IPUtils {
	
	/** The ip maps. */
	private static Map ipMaps = new HashMap(); 
	
	/** The buf maps. */
	private static Map bufMaps= new HashMap();
	
	/**
	 * Inits the finished.
	 */
	public static void initFinished() {
		ipMaps = bufMaps; 
		bufMaps = new HashMap();
	}
	
	/**
	 * Adds the ip info.
	 *
	 * @param ip the ip
	 * @return true, if successful
	 */
	public static boolean addIpInfo(String ip) {
		if(ip == null)
			return false;
		String startIp[] = ip.split("\\.");
		if(startIp.length != 4)
			return false;
		String key = startIp[0]+"." +startIp[1];
		Map map =(Map) bufMaps.get(key); 
		if(map == null){
			map = new HashMap();
			bufMaps.put(key, map);
		}
		Set set = (Set) map.get(startIp[2]);
		if(set == null){
			set = new HashSet();
			map.put(startIp[2],set);
		}
		if(set.contains(startIp[3]))
			return false;
		set.add(startIp[3]);
		return true;
	}
	
	/**
	 * Find ip info.
	 *
	 * @param ip the ip
	 * @return true, if successful
	 */
	public static boolean findIpInfo(String ip) {
		if(ip == null)
			return false;
		String startIp[] = ip.split("\\.");
		if(startIp.length != 4)
			return false;
		String key = startIp[0]+"." +startIp[1];
		Map map =(Map) ipMaps.get(key); 
		if(map == null){
			return false;
		}
		Set set0 = (Set) map.get("*");
		if(set0 != null)
			return true;
		Set set1 = (Set) map.get(startIp[2]);
		if(set1 == null){
			return false;
		}
		if(set1.contains("*")||set1.contains(startIp[3])){
			return true;
		}

		return false;
	}
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String args[] ){
		IPUtils.addIpInfo("127.0.0.1");
		IPUtils.addIpInfo("127.0.0.3");
		IPUtils.addIpInfo("192.168.1.*");
		IPUtils.addIpInfo("192.168.*.*");
		IPUtils.addIpInfo("192.167.*.*");
		IPUtils.initFinished();
		System.out.println(IPUtils.findIpInfo("127.0.0.1"));
		System.out.println(IPUtils.findIpInfo("127.0.0.2"));
		System.out.println(IPUtils.findIpInfo("127.0.0.3"));
		System.out.println(IPUtils.findIpInfo("192.168.1.1"));
		System.out.println(IPUtils.findIpInfo("192.168.2.1"));
		System.out.println(IPUtils.findIpInfo("192.167.2.1"));
		System.out.println(IPUtils.findIpInfo("192.166.2.1"));
	}
}
