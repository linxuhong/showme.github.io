package com.yihaodian.mobile.common.ex;

public class CentralMobileParamsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9047136776305939138L;

	public CentralMobileParamsException(String exception) {
        if(RuntimeExceptionThreadVO.getMessage()==null) {
            RuntimeExceptionThreadVO.setMessage(exception);
        }
    }

    @Override
    public String getMessage() {
        return RuntimeExceptionThreadVO.getMessage();
    }
}
