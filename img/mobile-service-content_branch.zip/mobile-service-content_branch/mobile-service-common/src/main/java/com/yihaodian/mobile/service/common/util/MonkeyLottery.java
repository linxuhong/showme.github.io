package com.yihaodian.mobile.service.common.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 判断是否中奖
 * @author zhangwei5
 *
 */
public class MonkeyLottery {

	/**
	 * 抽奖
	 * @param winningRate
	 * @return
	 */
	public static Integer getLotteryResult(double winningRate) 
	{
		if(winningRate>=100){
			return 1;
		}else if(winningRate<=0){
			return 0;
		}
		Random rand = new Random();
		double randResult = rand.nextDouble()*100;	
		if(randResult<winningRate){
			return 1;
		}else{
			return 0;
		}
	}

	
	public static Integer getRandCount(double winningRate){
		String   winningRateStr= winningRate+""; 
		String[] winningRateArr = winningRateStr.split("\\.");
		if(winningRateArr.length==2){
			return winningRateArr[1].length();
		}
		return 0;
	}
	
	/**
	 * 获取当前时间到下周一0点0分0秒的时间差 
	 * @return
	 */
	public static Long getNextMondayTimeInM(){
		Calendar cal = Calendar.getInstance();
		Calendar cal1 = Calendar.getInstance();
		if(cal.get(Calendar.DAY_OF_WEEK)>1){
			cal1.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)+9-cal.get(Calendar.DAY_OF_WEEK), 0, 0, 0);			
		}else{
			cal1.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)+1, 0, 0, 0);
		}
		return cal1.getTimeInMillis()-cal.getTimeInMillis();
	}
	
	/**
	 * 获取当前时间到下周一0点0分0秒的时间差 
	 * @return
	 */
	public static Long getNextDayTimeInM(){
		Calendar cal = Calendar.getInstance();
		Calendar cal1 = Calendar.getInstance();
		cal1.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)+1, 0, 0, 0);
		return cal1.getTimeInMillis()-cal.getTimeInMillis();
	}	
	
	public static void main(String[] args) {
//		String reg= "^((\\d){1,4})?1[3,5,8](\\d){9}$";
//		Pattern p = Pattern.compile(reg);
//		Matcher m = p.matcher("8615871722183");
//		System.out.println(m.find());
		int num=100;

		final java.util.concurrent.atomic.AtomicInteger count=new java.util.concurrent.atomic.AtomicInteger(0);
	    for(int j=0;j<num;j++){

	    	new Thread(new Runnable(){

	    		public void run(){

	    			if(getLotteryResult(0.1)>0)

    		    		count.addAndGet(1);

	    		}

	    	}).start();

	    }

	    System.out.println("ss"+count+"  "+(count.get()*1.0/num));
	}
}
