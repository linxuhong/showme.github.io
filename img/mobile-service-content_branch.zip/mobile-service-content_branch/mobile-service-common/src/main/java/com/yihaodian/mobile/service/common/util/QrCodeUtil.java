package com.yihaodian.mobile.service.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.log4j.Logger;

import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.mobile.common.ex.CentralMobileRuntimeException;

// TODO: Auto-generated Javadoc
/**
 * The Class QrCodeUtil.
 */
public class QrCodeUtil {
	
	/** The logger. */
	private static Logger logger = Logger.getLogger(QrCodeUtil.class);
	
	/** The qr code host. */
	private static String qrCodeHost = null;
	
	/** The qr code text. */
	String qrCodeText = null;
	
	/** The product id. */
	String productId = null;
	
	/** The tracking id. */
	String trackingId = null;
	
	/** The image size. */
	String imageSize = null;
	
	/**
	 * Gets the qr code text.
	 *
	 * @return the qr code text
	 */
	public String getQrCodeText() {
		return qrCodeText;
	}
	
	/**
	 * Sets the qr code text.
	 *
	 * @param qrCodeText the new qr code text
	 */
	public void setQrCodeText(String qrCodeText) {
		this.qrCodeText = qrCodeText;
	}
	
	/**
	 * Gets the product id.
	 *
	 * @return the product id
	 */
	public String getProductId() {
		return productId;
	}
	
	/**
	 * Sets the product id.
	 *
	 * @param productId the new product id
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	/**
	 * Gets the tracking id.
	 *
	 * @return the tracking id
	 */
	public String getTrackingId() {
		return trackingId;
	}
	
	/**
	 * Sets the tracking id.
	 *
	 * @param trackingId the new tracking id
	 */
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	
	/**
	 * Gets the image size.
	 *
	 * @return the image size
	 */
	public String getImageSize() {
		return imageSize;
	}
	
	/**
	 * Sets the image size.
	 *
	 * @param imageSize the new image size
	 */
	public void setImageSize(String imageSize) {
		this.imageSize = imageSize;
	}
	
	/**
	 * Instantiates a new qr code util.
	 */
	public QrCodeUtil(){
		 
	}
	
	/**
	 * Gets the host url.
	 *
	 * @return the host url
	 */
	protected static String getHostUrl()
	{
		if (qrCodeHost == null) {
			String host = "http://m.yihaodian.com";
	        host = YccGlobalPropertyConfigurer.getPropertyByKey("remoteServiceMobile.properties", "qrCodeHost");
			if (host == null) {
				qrCodeHost = "http://m.yihaodian.com/interface/service/checkqrcode.do";
			} else {
				qrCodeHost = host +  "/interface/service/checkqrcode.do";
			}
		}
		return qrCodeHost;
	}
	
	/**
	 * Gets the qrcode url.
	 *
	 * @return the qrcode url
	 */
	public String getQrcodeUrl(){
		String SERVLET_URL = qrCodeHost;
		SERVLET_URL += "?1=1";
		if (qrCodeText != null) {
			SERVLET_URL += "&qrText=" + qrCodeText;
		}
		if (productId != null) {
			SERVLET_URL += "&productId=" + productId;
		}
		if (trackingId != null) {
			SERVLET_URL += "&trackingId=" + trackingId;
		}
		if (imageSize != null) {
			SERVLET_URL += "&imageSize=" + imageSize;
		}
		
		HttpPost httpPost = getHttpPost(SERVLET_URL);
		DefaultHttpClient httpClient = new DefaultHttpClient(httpPost.getParams());
		try {
			HttpResponse httpResponse = httpClient.execute(httpPost);
		    if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	String ret = getResultString(httpResponse);
		    	return ret;
		    } else {
		    	httpPost.abort();
		    }
		} catch (IOException e) {
			e.printStackTrace();
	    	logger.error(" getQrcodeUrl has error", e);
		}
		return null;
	}
	
	/**
	 * Gets the http post.
	 *
	 * @param url the url
	 * @return the http post
	 */
	private HttpPost getHttpPost(String url) {
		HttpPost httpPost;
		try {
			httpPost = new HttpPost(url);
			
			BasicHttpParams httpParams = new BasicHttpParams();
		    HttpConnectionParams.setConnectionTimeout(httpParams, 10*1000);
		    HttpConnectionParams.setSoTimeout(httpParams, 15*1000);
		    httpPost.setParams(httpParams);
		    return httpPost;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets the result string.
	 *
	 * @param httpResponse the http response
	 * @return the result string
	 */
	private String getResultString(HttpResponse httpResponse) {
		StringBuffer result = new StringBuffer();
		try {
			InputStream is = httpResponse.getEntity().getContent();
		    BufferedReader bfrReader = new BufferedReader(new InputStreamReader(is));
		    String line = bfrReader.readLine();
		    while (line != null) {
		    	result.append(line).append("\n");
		    	line = bfrReader.readLine();
		    }
		    bfrReader.close();
		    is.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	

}
