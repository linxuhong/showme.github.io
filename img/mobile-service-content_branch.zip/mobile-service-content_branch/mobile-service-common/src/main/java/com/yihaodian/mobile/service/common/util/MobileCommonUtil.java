package com.yihaodian.mobile.service.common.util;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.struts2.ServletActionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.common.passport.CookieWrapper;
import com.yihaodian.common.vo.Constant;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
import com.yihaodian.front.sso.client.util.SsoClientCacheUtil;
import com.yihaodian.front.sso.common.enums.McSiteIdEnum;
import com.yihaodian.front.sso.common.enums.UserTypeEnum;
import com.yihaodian.front.sso.common.vo.SsoUser;
import com.yihaodian.mandy.service.MandyRequest;
import com.yihaodian.mobile.common.ex.CentralMobileSessionException;
import com.yihaodian.mobile.service.common.business.util.user.FrontPassortServiceUtil;
import com.yihaodian.mobile.service.common.util.service.SsoUtil;
import com.yihaodian.mobile.vo.bussiness.Trader;

// TODO: Auto-generated Javadoc
/**
 * 代码来源：com.yihaodian.front.passport.action.BaseAction
 * @author yhd2
 *
 */
public class MobileCommonUtil {
    
    private static Logger logger = LoggerFactory.getLogger(MobileCommonUtil.class);

	/** The site type. */
	public static int siteType;
	
	/** The mc site id. */
	public static Integer mcSiteId;
	
	static {
        try {
            String str = YccGlobalPropertyConfigurer.getPropertyByKey(
                "remoteServiceMobile.properties", "mcsiteid");
            siteType = Constant.getSiteType();
            if (str == null) {
                mcSiteId = 1;
            } else {
                mcSiteId = Integer.parseInt(str);
            }
        } catch (Exception e) {
            logger.error("init MobileCommonUtil has error ", e);
            mcSiteId = 1;
            siteType=1;
        }
	}
	
	/**
	 * 站点Id.
	 *
	 * @return the curr site id
	 */
	public static long getCurrSiteId() {
		return 1l;
	}

	/**
	 * Gets the cookie wrapper.
	 *
	 * @return the cookie wrapper
	 */
	public static CookieWrapper getCookieWrapper() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		return new CookieWrapper(request, response);
	}

	/**
	 * Gets the client ip.
	 *
	 * @param request the request
	 * @return the client ip
	 */
	public static String getClientIP(HttpServletRequest request){
		String ip = request.getHeader("x-forwarded-for");
		if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (StringUtils.isBlank(ip) || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		// 多个路由时，取第一个非unknown的ip
		final String[] arr = ip.split(",");
		for (final String str : arr) {
			if (!"unknown".equalsIgnoreCase(str)) {
				ip = str;
				break;
			}
		}
		return ip;
	}
	
	/**
	 * Use device code.
	 *
	 * @param deviceCode the device code
	 * @return true, if successful
	 */
	public static boolean useDeviceCode(String deviceCode) {
		// 不用封设备号策略
		return false;
	}
    
    public static Trader getTrader(String token) throws CentralMobileSessionException {
    	Trader result = FrontPassortServiceUtil.getTrader(token);

    	if (result != null) {
    		return result;
    	} else {
            throw new CentralMobileSessionException("用户Token过期,请重新登录");
    	}
        
    }
	
    /**
     * Gets the session user.
     *
     * @param token the token
     * @return the session user
     * @throws CentralMobileSessionException the central mobile session exception
     */
    public static SsoUser getSessionUser(String token) throws CentralMobileSessionException {
        
        //通过SSO获取用户Id
        SsoUser ssoUser = SsoUtil.getCurrentMobileLoginUserInfo(token);
        
        if (ssoUser != null) {
        	return ssoUser;
        } else {
        	throw new CentralMobileSessionException("用户Token过期,请重新登录");
        }
    }
    
    public static SsoUser getSessionUser(String token,Integer siteType) throws CentralMobileSessionException {
        
        //通过SSO获取用户Id
    	SsoUser ssoUser = null;
    	if (siteType.intValue() == 1) { // 1-yhd
    		ssoUser = SsoUtil.getCurrentMobileLoginUserInfo(token);
    	} else if (siteType.intValue() == 3) { // 3-sam
    		ssoUser = SsoClientCacheUtil.getSsoUser(token, UserTypeEnum.FRONT_USER,
                    McSiteIdEnum.SAM);
    	} else { // 4-购物清单
    		ssoUser = SsoClientCacheUtil.getSsoUser(token, UserTypeEnum.FRONT_USER,
                    McSiteIdEnum.SHOPPINGLIST);
    	}
        
        if (ssoUser != null) {
        	return ssoUser;
        } else {
        	throw new CentralMobileSessionException("用户Token过期,请重新登录");
        }
    }
    
    /**
     * Adjust mandy request.
     *
     * @param req the req
     */
    public static void adjustMandyRequest(MandyRequest req){
   		//begin:fixed bug 0109310: [搜索]同步前台的搜索参数，过滤掉海鲜食品。added by oumingzhi,date 20130106
   		//(1L:1号店,2L:1号商城)
   		if(siteType == 1){
   			req.setSiteType(1);
   			req.setSiteFlag(1);
   		}
   		else if(siteType == 2){
   			req.setSiteType(2);
   			req.setSiteFlag(1); 
   		}
   	    //end:fixed bug 0109310: [搜索]同步前台的搜索参数，过滤掉海鲜食品。added by oumingzhi,date 20130106
    }
    
}
