package com.yihaodian.mobile.service.common.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.yihaodian.mobile.service.domain.business.dal.backend.MobileMonkeyStore;
import com.yihaodian.mobile.vo.monkey.MobileCentralMonkeyStore;
public class MonkeyUtil {

	/**
	 * 根据经纬度计算距离
	 * @param lo1 经度1
	 * @param la1 纬度1
	 * @param lo2 经度2
	 * @param la2 纬度2
	 * @return
	 */
	public static double distanceByLBS(double lo1, double la1, double lo2, double la2) {
		double radLat1 = la1 * Math.PI / 180;
		double radLat2 = la2 * Math.PI / 180;
		double a = radLat1 - radLat2;
		double b = lo1 * Math.PI / 180 - lo2 * Math.PI / 180;
		double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
		s = s * 6378137.0;
		s = Double.valueOf(String.valueOf(Math.round(s * 10000) / 10000));// Math.round(s * 10000) / 10000;
		return s;
	}
	
	public static List<MobileMonkeyStore> getMonkeyStoreVOListSort(List<MobileMonkeyStore> monkyeStroeList,double currentLo, double currentLa){
		List<MobileMonkeyStore> retList = new ArrayList<MobileMonkeyStore>();
		try {
			if(monkyeStroeList!=null&&monkyeStroeList.size()>0){
				HashMap<Double, MobileMonkeyStore> map= new HashMap<Double, MobileMonkeyStore>();
				List<Double> disntanceList = new ArrayList<Double>();
				for(MobileMonkeyStore monkeyStroeVO : monkyeStroeList){
					double distance=  distanceByLBS(monkeyStroeVO.getGearthLongitude(), monkeyStroeVO.getGearthLatitude(), currentLo, currentLa);
					map.put(distance, monkeyStroeVO);
					disntanceList.add(distance);
				}
				Collections.sort(disntanceList);
				if(disntanceList!=null&&disntanceList.size()>0){
					for(double sortDistance : disntanceList){
						retList.add(map.get(sortDistance));
					}
				}
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retList;
	}
}
