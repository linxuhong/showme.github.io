package com.yihaodian.mobile.service.common.business.util.gson;

import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

public class GsonUtil {

    private static final Gson gson = new GsonBuilder().registerTypeAdapter(Date.class,
                                       new DateDeserializer()).create();

    private static Logger logger = LoggerFactory.getLogger(GsonUtil.class);
    
    private static class DateDeserializer implements JsonDeserializer<Date> {
        @Override
        public Date deserialize(JsonElement json, java.lang.reflect.Type typeOfT,
                                JsonDeserializationContext context) throws JsonParseException {
            if (!isNumeric(json.getAsString())) {
                // for eg: 2013-10-15 00:00:00 以后如果返回Date类型需要以这种格式
                DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String dateStr = json.getAsString();
                try {
                    return format.parse(dateStr);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                return null/* gson.fromJson(json, Date.class) */;
            } else {
                return new Date(json.getAsLong());
            }
        }

    }

    public static Object paseToObject(String data , Type t){
        try {
            Object resultObject = gson.fromJson(data, t);
            return resultObject;
        } catch (Exception e) {
            logger.error("paseToObject has error ", e);
        }
        return new Object();
    }
    
    /**
     * 判断是否为纯数字
     * @param str
     * @return
     */
    public static boolean isNumeric(String str) {
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(str);
        if (!isNum.matches()) {
            return false;
        }
        return true;
    }
}
