package com.yihaodian.mobile.service.common.business.util.scalper;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yhd.platform.merchant.manager.center.api.interfaces.risk.UserRiskLevelService;
import com.yhd.platform.merchant.manager.center.api.interfaces.tns.TnsPunishService;
import com.yhd.platform.merchant.manager.center.api.model.risk.UserRiskLevelDto;
import com.yhd.platform.merchant.manager.center.api.model.risk.UserRiskLevelResult;
import com.yhd.platform.merchant.manager.center.api.model.risk.UserRiskLevelVo;
import com.yhd.platform.merchant.manager.center.api.model.tns.dto.TnsUserDto;
import com.yhd.platform.merchant.manager.center.api.model.tns.vo.TnsPunishResult;
import com.yhd.platform.merchant.manager.center.api.model.tns.vo.TnsUserVo;
import com.yihaodian.common.util.SpringBeanFactory;
import com.yihaodian.mobile.service.domain.vo.business.scalper.ScalperResultVO;

public class ScalperUtil {

	private static TnsPunishService tnsPunishService = null;
	
	private static UserRiskLevelService  userRiskLevelService = null;

	private static Logger logger = LoggerFactory.getLogger(ScalperUtil.class);
	
	/**
	 * 调用成功
	 */
	public static final Integer SUCCESS = 0;
	/**
	 * 调用失败
	 */
	public static final Integer FAIL = 1;
	/**
	 * 调用来源（0-抵用券；1-砸金蛋；2-摇一摇）
	 */
	public static final Integer INVOKE_RESOURCE_EGG = 15;//1改成15,新接口
	/**
	 * 调用来源（0-抵用券；1-砸金蛋；2-摇一摇）
	 */
	public static final Integer INVOKE_RESOURCE_ROCK = 2;
	/**
	 * 调用来源（0-抵用券；1-砸金蛋；2-摇一摇）
	 */
	public static final Integer INVOKE_RESOURCE_BIG_WHEEL = 1;
	
	/**
	 * 调用来源  (114-下单红包登录发券)
	 */
	public static final Integer INVOKE_RESOURCE_ORDER_RED = 114;
 
	static {
		tnsPunishService = (TnsPunishService) SpringBeanFactory.getBean("tnsPunishService");
		userRiskLevelService = (UserRiskLevelService) SpringBeanFactory.getBean("userRiskLevelService");
	}
 
	
	public static ScalperResultVO findTnsUser(Long endUserId,Long activeId,Integer invokeResource, String ip){
	    ScalperResultVO result = new ScalperResultVO();
        try{
            TnsUserDto tnsUserDto = new TnsUserDto();
            tnsUserDto.setEndUserId(endUserId);
            tnsUserDto.setActiveId(activeId);
            tnsUserDto.setInvokeResource(invokeResource);
            if(ip!=null)
                tnsUserDto.setIp(ip); 
            TnsPunishResult<TnsUserVo> tnsPunishResult = tnsPunishService.findTnsUser(tnsUserDto);
            //调用服务失败默认非黄牛用户
            if(null == tnsPunishResult){
                result.setResultCode(ScalperUtil.SUCCESS);
                result.setLevel(ScalperUtil.SUCCESS.intValue());
                result.setResultMsg("tnsPunishService.findTnsUser return null");
            }else{
                if(tnsPunishResult.getResultCode().intValue() == ScalperUtil.SUCCESS.intValue()){
                    result.setResultCode(tnsPunishResult.getResultCode());
                    result.setResultMsg(tnsPunishResult.getResultMsg());
                    result.setLevel(tnsPunishResult.getResult().getCouponAdviceEnums().getLevel());
                    result.setAdvice(tnsPunishResult.getResult().getCouponAdviceEnums().getAdvice());
                    
                }else if(tnsPunishResult.getResultCode().intValue() == ScalperUtil.FAIL.intValue()){
                    result.setResultCode(tnsPunishResult.getResultCode());
                    result.setResultMsg(tnsPunishResult.getResultMsg());
                }
            }
            return result;
            
        }catch(Exception ex){
            logger.error("ScalperUtil.findTnsUser has Exception endUserId:"+endUserId+",activeId:"+activeId,ex);
            result.setResultCode(ScalperUtil.SUCCESS);
            result.setLevel(ScalperUtil.SUCCESS.intValue());
            result.setResultMsg(ex.getMessage());
            return result;
            
        }catch(Error ex){
            logger.error("ScalperUtil.findTnsUser has error endUserId:"+endUserId+",activeId:"+activeId,ex);
            result.setResultCode(ScalperUtil.SUCCESS);
            result.setLevel(ScalperUtil.SUCCESS.intValue());
            result.setResultMsg(ex.getMessage());
            return result;
        }
	}
	
	public static ScalperResultVO findTnsUser(Long endUserId,Long activeId,Integer invokeResource){
		return findTnsUser(endUserId, activeId, invokeResource,null);
	}
	
	
	
	
    public static UserRiskLevelVo getScalperObj(Long endUserId, Integer riskPointId) {
        try {
            UserRiskLevelDto userRiskLevelDto = new UserRiskLevelDto();
            userRiskLevelDto.setEndUserId(endUserId);
            userRiskLevelDto.setRiskPointId(riskPointId);
            UserRiskLevelResult<UserRiskLevelVo> userRiskLevelResult = userRiskLevelService
                    .getScalperRiskLevel(userRiskLevelDto);
            if (userRiskLevelResult.getResultCode().intValue() == UserRiskLevelResult.SUCCESS.intValue()) {
                return userRiskLevelResult.getResult();
            } 
        } catch (Exception ex) {
            logger.error("ScalperUtil.getScalperObj has Exception endUserId:" + endUserId + ",riskPointId:"
                    + riskPointId, ex);
        }
        return null;
    }
	
	/**
	 * 分裂红包验证黄牛+小号
	 * @param fromUserId
	 * @param ToUserId
	 * @param riskPointId
	 * @return  ture - is scalper  , false - not
	 */
    public static boolean splitGiftScalper(Long fromUserId, Long toUserId, Integer riskPointId) {
        try {
            UserRiskLevelVo toUser = getScalperObj(toUserId, riskPointId);
            if (toUser == null)
                return false;

            if (toUser.getLimitActionLevel() != 0) {
                return true;
            }
            // 小号验证
            UserRiskLevelVo fromUser = getScalperObj(fromUserId, riskPointId);
            if (fromUser == null)
                return false;

            if (toUser.getClusterLevel() == 1 && fromUser.getClusterId().equals(toUser.getClusterId()))
                return true;
        } catch (Exception e) {
            logger.error("splitGiftScalper err ", e);
        }

        return false;
    }
	
    /**
     * 判断是否为黄牛，riskLevel =0
     * @param endUserId
     * @param riskPointId
     * @return
     */
	public static boolean getScalperRiskLevel(Long endUserId,Integer riskPointId){
		return getScalperRiskLevel(endUserId, riskPointId, 0);
	}
	
	/**
	 * 判断是否为黄牛
	 * @param endUserId
	 * @param riskPointId
	 * @param maxRiskLevel 最大风险等级，低于该等级不视为黄牛
	 * @return
	 */
	public static boolean getScalperRiskLevel(Long endUserId, Integer riskPointId, Integer maxRiskLevel) {
		boolean isScalper  =  false; //默认返回是不是黄牛用户
		try{
			UserRiskLevelDto userRiskLevelDto = new UserRiskLevelDto();
			userRiskLevelDto.setEndUserId(endUserId);
			userRiskLevelDto.setRiskPointId(riskPointId);
			UserRiskLevelResult<UserRiskLevelVo> userRiskLevelResult = userRiskLevelService.getScalperRiskLevel(userRiskLevelDto);
			if(userRiskLevelResult.getResultCode().intValue() == UserRiskLevelResult.SUCCESS.intValue()){
            	UserRiskLevelVo userRiskLevelVo = userRiskLevelResult.getResult();          
            	if (null == userRiskLevelVo
                        || (Integer.valueOf(0).equals(userRiskLevelVo.getLimitActionLevel())
                        && Integer.valueOf(0).equals(userRiskLevelVo.getClusterLevel())
                        && Integer.valueOf(maxRiskLevel).compareTo(userRiskLevelVo.getUserRiskLevel())>=0)) {
                    isScalper = false;
                }else{
                    isScalper = true;
                }
 
            }else{
            	logger.error("ScalperUtil.getScalperRiskLevel return FAIL endUserId:"+endUserId+",riskPointId:"
            			     +riskPointId+",resultMsg:"+userRiskLevelResult.getResultMsg());
            }
            return isScalper;
        }catch(Exception ex){
            logger.error("ScalperUtil.getScalperRiskLevel has Exception endUserId:"+endUserId+",riskPointId:"+riskPointId,ex);
            return isScalper;
            
        }
	}
	
	//判断是否为黄牛
    public static boolean isLimitActionLevel(Long endUserId, Integer riskPointId) {
        boolean isScalper = false; // 默认返回是不是黄牛用户
        try {
            UserRiskLevelDto userRiskLevelDto = new UserRiskLevelDto();
            userRiskLevelDto.setEndUserId(endUserId);
            userRiskLevelDto.setRiskPointId(riskPointId);
            UserRiskLevelResult<UserRiskLevelVo> userRiskLevelResult = userRiskLevelService
                    .getScalperRiskLevel(userRiskLevelDto);

            if (userRiskLevelResult.getResultCode().intValue() == UserRiskLevelResult.SUCCESS.intValue()) {
                UserRiskLevelVo userRiskLevelVo = userRiskLevelResult.getResult();

                if (null == userRiskLevelVo || (Integer.valueOf(0).equals(userRiskLevelVo.getLimitActionLevel()))) {
                    isScalper = false;
                } else {
                    isScalper = true;
                }

            } else {
                logger.error("ScalperUtil.isLimitActionLevel return FAIL endUserId:" + endUserId + ",riskPointId:"
                        + riskPointId + ",resultMsg:" + userRiskLevelResult.getResultMsg());
            }
            return isScalper;
        } catch (Exception ex) {
            logger.error("ScalperUtil.isLimitActionLevel has Exception endUserId:" + endUserId + ",riskPointId:"
                    + riskPointId, ex);
            return isScalper;

        }
    }
	
}
