package com.yihaodian.mobile.service.common.business.util;

public class Constant {

	public static String getDefaultPicURL()
	  {
	    return "/images/defaultproduct.jpg";
	  }
}
