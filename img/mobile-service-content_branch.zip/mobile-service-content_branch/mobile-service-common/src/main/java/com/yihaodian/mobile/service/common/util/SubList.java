package com.yihaodian.mobile.service.common.util;

import java.util.ArrayList;
import java.util.List;

public class SubList<T>{
	
	public List<T> subList(List<T> list,int start,int end){
		List<T> subList = list.subList(start, end);
		List<T> resultList = new ArrayList<T>();
		for(int i=0;i<subList.size();i++){
			resultList.add(subList.get(i));
		}
		return resultList;
	}

}
