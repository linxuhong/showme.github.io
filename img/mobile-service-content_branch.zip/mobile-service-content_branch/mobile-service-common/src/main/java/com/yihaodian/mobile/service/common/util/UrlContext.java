package com.yihaodian.mobile.service.common.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 * The Class UrlContext.
 */
public class UrlContext {
	/**
	 * 拼接无线2.0客户端页面对应的url
	 *
	 * @param url the url
	 * @param map the map
	 * @return the url intent
	 */
	public static String getUrlIntent(String url ,HashMap<String, String> map){
		int i=0;
		StringBuffer buffer = new StringBuffer(url);
		if(map != null){
			buffer.append("?").append("body").append("=").append("{");
			Iterator<Entry<String, String>> iter = map.entrySet().iterator();
			while (iter.hasNext()) {
				Entry<String, String> entry = (Entry<String, String>) iter.next();
				if(entry.getValue()!=null){
					i++;
					buffer.append("\"").append(entry.getKey()).append("\"").append(":");
					if(entry.getValue().startsWith("{") || entry.getValue().startsWith("[")){
						buffer.append(entry.getValue()).append(",");
					}else{
						buffer.append("\"").append(entry.getValue()).append("\"").append(",");
					}
				}
			}
			buffer.deleteCharAt(buffer.length()-1);
			buffer.append("}");
		}
		//没有值时返回：yhd://mobilecharge?body=}   会导致app闪退
		return i>0?buffer.toString():url;
	}
	
	/**
	 * 拼接track的bd参数
	 * @param map
	 * @return
	 */
	public static String getTrackUrlBD(HashMap<String, Object> map){
		StringBuffer buffer = new StringBuffer("{");
		if(map != null){
			for(Map.Entry<String, Object> entry:map.entrySet()){
				buffer.append(entry.getKey()).append("=").append(entry.getValue()).append("|");
			}
			buffer.deleteCharAt(buffer.length()-1);
			buffer.append("}");
		}
		return buffer.toString();
	}

}
