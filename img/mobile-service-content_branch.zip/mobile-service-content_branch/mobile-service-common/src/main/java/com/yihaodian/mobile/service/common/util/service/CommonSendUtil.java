package com.yihaodian.mobile.service.common.util.service;

import java.util.Calendar;
import java.util.Random;

import com.caucho.hessian.client.HessianProxyFactory;
import com.newheight.hessianService.model.CommonSend;
import com.newheight.hessianService.model.ConstantSMS;
import com.newheight.hessianService.service.CommonSms;
import com.yihaodian.common.vo.Constant;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.vo.constant.CommonKey;

// TODO: Auto-generated Javadoc
/**
 * The Class CommonSendUtil.
 */
public class CommonSendUtil {
	
	/** The base. */
	public static String base = "0123456789";  //构建随机码的字符串
	//手机注册源
	/** The Constant PHONEREGISTERSOURCE. */
	public static final int PHONEREGISTERSOURCE = 63;
//	public static final int UPDATEPASSWORDSOURCE = 63;
	/** The Constant UPDATEPASSWORDSOURCE. */
public static final int UPDATEPASSWORDSOURCE = 98;
	
	/**
	 * 发送单条短信.
	 *
	 * @param mobile            手机号
	 * @param content            短信内容
	 * @param SMSSourceCode the SMS source code
	 * @return 1-发送成功；2-失败
	 */
	public static String sendSingleSMS(String mobile, String content,int SMSSourceCode) {
		String url = ConstantSMS.url;
		HessianProxyFactory factory = new HessianProxyFactory();
		factory.setChunkedPost(false);
		String ret = "0";
		try {
			CommonSms hello = (CommonSms) factory.create(CommonSms.class, url);
			CommonSend commonSend = new CommonSend();
			// 写入短信内容
			commonSend.setContent(content);
			// 写入手机号码
			commonSend.setMobile(mobile);
			// 写入优先级
			commonSend.setPriority(ConstantSMS.priority_NO1);
			// 写入系统来源
			commonSend.setSource(SMSSourceCode);
			// 调用单挑短信插入接口
			ret = hello.insertCommonSend(commonSend);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}
	
	//根据类型获取短信源
    /**
	 * Gets the SMS source code.
	 *
	 * @param type the type
	 * @return the SMS source code
	 */
	public static int getSMSSourceCode(String type){
        long mcsiteid = 1l;
        int SMSSourceCode = 0;
        if (1 == mcsiteid) {
            // 一号店
            int siteType = Constant.getSiteType();
            if (siteType == 1) {
            	if(StringUtil.isNotEmpty(type)&&type.equals("phoneRegister")){
            		SMSSourceCode = PHONEREGISTERSOURCE;
            	}
            	if(StringUtil.isNotEmpty(type)&&type.equals("updatePassword")){
            		SMSSourceCode = UPDATEPASSWORDSOURCE;
            	}
            } 
        }
        return SMSSourceCode;
    }
	
	
    //获取上次发送验证码的时间
    /**
     * Gets the last send to user mobile time.
     *
     * @param mobile the mobile
     * @param SMSSourceCode the SMS source code
     * @return the last send to user mobile time
     */
    public static long getLastSendToUserMobileTime(String mobile,int SMSSourceCode) {
        long result = 0;
        MemcachedProxy me = MemcachedProxy.getInstance();
        Object time = me.get("lastTime_sendVerifyCodeByMobile_"+ mobile+"source_"+SMSSourceCode);
        if (time != null) {
            result = (Long) time;
        }
        return result;
    }

    //设置上次发送验证码的时间
    /**
     * Sets the last send to user mobile time.
     *
     * @param mobile the mobile
     * @param SMSSourceCode the SMS source code
     */
    public static void setLastSendToUserMobileTime(String mobile,int SMSSourceCode) {
        MemcachedProxy me = MemcachedProxy.getInstance();
        String cacheKey = "lastTime_sendVerifyCodeByMobile_"+ mobile+"source_"+SMSSourceCode;
        me.remove(cacheKey);
        me.put(cacheKey, System.currentTimeMillis(), CommonKey.MEMCACHE_INVALID_TIME_ONE_DAY);
    }
    
    //获取随机验证码
	/**
     * Gen ramon code.
     *
     * @param codeLen the code len
     * @return the string
     */
    public static String genRamonCode(int codeLen) {
		Random random = new Random();   
        StringBuffer sb = new StringBuffer();   
        for (int i = 0; i < codeLen; i++) {   
            int number = random.nextInt(base.length());   
            sb.append(base.charAt(number));   
        }   
        return sb.toString();  
	}
	
	/**
	 * Increase verify times today by mobile.
	 *
	 * @param mobile the mobile
	 * @param type the type
	 * @return the int
	 */
	public static int increaseVerifyTimesTodayByMobile(String mobile, String type){
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		// 区分一号店、一号商城、药网    bolink 
		String key = "SMSMobileTimes_" + type + "_" + day + "_" + mobile + "_" + Constant.getSiteType();
		MemcachedProxy me = MemcachedProxy.getInstance();
		Object times = me.get(key);
		int updateTimes = 0;
		if (times == null) {
			updateTimes = 0;
		}else{
			updateTimes = (Integer) times;
		}
		updateTimes++;
		me.put(key, Integer.valueOf(updateTimes), CommonKey.MEMCACHE_INVALID_TIME_ONE_DAY);
		return updateTimes;
	}
	
	//TODO: 并发问题
	/**
	 * Gets the verify times today by mobile.
	 *
	 * @param mobile the mobile
	 * @param type the type
	 * @return the verify times today by mobile
	 */
	public static int getVerifyTimesTodayByMobile(String mobile, String type){
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		// 区分一号店、一号商城、药网    bolink
		String key = "SMSMobileTimes_" + type + "_" + day + "_" + mobile + "_" + Constant.getSiteType();
		MemcachedProxy me = MemcachedProxy.getInstance();
		Object times = me.get(key);
		if (times != null) {
			return (Integer)times;
		}else{
			return 0;
		}
	}
	
	/**
	 * Removes the verify times today by mobile.
	 *
	 * @param mobile the mobile
	 * @param type the type
	 */
	public static void removeVerifyTimesTodayByMobile(String mobile, String type){
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		// 区分一号店、一号商城、药网    bolink
		String key = "SMSMobileTimes_" + type + "_" + day + "_" + mobile + "_" + Constant.getSiteType();
		MemcachedProxy me = MemcachedProxy.getInstance();	
		me.remove(key);
	}
	
	/**
	 * Increase send times today by mobile.
	 *
	 * @param mobile the mobile
	 * @param type the type
	 * @return the int
	 */
	public static int increaseSendTimesTodayByMobile(String mobile, String type){
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		// 区分一号店、一号商城、药网    bolink 
		String key = "SMSMobileSendTimes_" + type + "_" + day + "_" + mobile + "_" + Constant.getSiteType();
		MemcachedProxy me = MemcachedProxy.getInstance();
		Object times = me.get(key);
		int updateTimes = 0;
		if (times == null) {
			updateTimes = 0;
		}else{
			updateTimes = (Integer) times;
		}
		updateTimes++;
		me.put(key, Integer.valueOf(updateTimes), CommonKey.MEMCACHE_INVALID_TIME_ONE_DAY);
		return updateTimes;
	}
	
	//TODO: 并发问题
	/**
	 * Gets the send times today by mobile.
	 *
	 * @param mobile the mobile
	 * @param type the type
	 * @return the send times today by mobile
	 */
	public static int getSendTimesTodayByMobile(String mobile, String type){
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		// 区分一号店、一号商城、药网    bolink
		String key = "SMSMobileSendTimes_" + type + "_" + day + "_" + mobile + "_" + Constant.getSiteType();
		MemcachedProxy me = MemcachedProxy.getInstance();
		Object times = me.get(key);
		if (times != null) {
			return (Integer)times;
		}else{
			return 0;
		}
	}
	
	
	//TODO: 并发问题
	/**
	 * Gets the times today with out site type.
	 *
	 * @param type the type
	 * @param vmId the vm id
	 * @return the times today with out site type
	 */
	public static int getTimesTodayWithOutSiteType(String type, String vmId){
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		// 区分一号店、一号商城、药网    bolink
		String key = "timesToday_" + type + "_" + day +"_"+vmId;
		MemcachedProxy me = MemcachedProxy.getInstance();
		Object times = me.get(key);
		if (times != null) {
			return (Integer)times;
		}else{
			return 0;
		}
	}
	
	
	/**
	 * Increase times today with out site type.
	 *
	 * @param type the type
	 * @param vmId the vm id
	 * @return the int
	 */
	public static int increaseTimesTodayWithOutSiteType(String type, String vmId){
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		// 区分一号店、一号商城、药网    bolink 
		String key = "timesToday_" + type + "_" + day +"_"+vmId;
		MemcachedProxy me = MemcachedProxy.getInstance();
		Object times = me.get(key);
		int updateTimes = 0;
		if (times == null) {
			updateTimes = 0;
		}else{
			updateTimes = (Integer) times;
		}
		updateTimes++;
		me.put(key, Integer.valueOf(updateTimes), CommonKey.MEMCACHE_INVALID_TIME_ONE_DAY);
		return updateTimes;
	}
}
