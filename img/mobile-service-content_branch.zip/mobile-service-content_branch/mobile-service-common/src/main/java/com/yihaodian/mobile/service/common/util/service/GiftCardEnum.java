/**
 * www.yhd.com-402 Inc.
 * Copyright (c) 2008-2015 All Rights Reserved.
 */
package com.yihaodian.mobile.service.common.util.service;

import java.util.Date;
import java.util.List;

import oracle.sql.DATE;

/**
 * 
 * @author huangqihui
 * @version $Id: GiftCardEnum.java, v 0.1 2015年6月24日 下午2:37:47 huangqihui Exp $
 */
public enum GiftCardEnum { 
    productCode_1("0070253406"),
    productCode_2("0090251028"),
    productCode_3("0090251039"),
    productCode_4("0377125081"),
    productCode_5("0090251051"),
    productCode_6("0039543969"),
    productCode_7("0090251062"),
    productCode_8("0090251073"),
    productCode_9("0090251084"),
    productCode_10("0090251095"),
    productCode_11("0030559490"),
    productCode_12("0303675947"),
    productCode_13("0087896626"),
    productCode_14("0021696173"),
    productCode_15("0410790635"),
    productCode_16("0410790646"),
    productCode_17("0390863748"),
    productCode_18("0021696184"),
    productCode_19("0410790657"),
    productCode_20("0410790668"),
    productCode_21("0390863759"),
    productCode_22("0412549703"),
    productCode_23("0090251108"),
    productCode_24("0087896648"),
    productCode_25("0021696195"),
    productCode_26("0410790679"),
    productCode_27("0377538028"),
    productCode_28("0410790680"),
    productCode_29("0045246024"),
    productCode_30("0410790691"),
    productCode_31("0091227995"),
    productCode_32("0045246035"),
    productCode_33("0410790704"),
    productCode_34("0090251119"),
    productCode_35("0087896682"),
    productCode_36("0021696208"),
    productCode_37("0410790715"),
    productCode_38("0304093810"),
    productCode_39("0237060570"),
//    productCode_40("0237060570"),
    productCode_41("0410790726"),
    productCode_42("0297910884"),
    productCode_43("0410790737"),
    productCode_44("0410790748"),
    productCode_45("0427424031"),
    productCode_46("0410790759"),
    productCode_47("0297910873"),
    productCode_48("0392633124"),
    productCode_49("0410790760"),
    productCode_50("0410790771"),
    productCode_51("0410790782"),
    productCode_52("0410790793"),
    productCode_53("0410790806"),
    productCode_54("0297910862"),
    productCode_55("0427171673"),
    productCode_56("0291295039"),
    productCode_57("0087896740"),
    productCode_58("0410790817"),
    productCode_59("0021696219"),
    productCode_60("0410790828"),
    productCode_61("0410790839"),
    productCode_62("0410790840"),
    productCode_63("0410790851"),
    productCode_64("0410790862"),
    productCode_65("0410790873"),
    productCode_66("0297910851"),
    productCode_67("0297910840"),
    productCode_68("0304093763"),
    productCode_69("0045246046"),
    productCode_70("0379938633"),
    productCode_71("0071834156"),
    productCode_72("0297910839"),
    productCode_73("0304093638"),
    productCode_74("0427424020"),
    productCode_75("0052100546"),
    productCode_76("0297910828"),
    productCode_77("0375728635"),
    productCode_78("0087896784"),
    productCode_79("0021696220"),
    productCode_80("0304093683"),
    productCode_81("0297910817"),
    productCode_82("0052100557"),
    productCode_83("0297910806"),
    productCode_84("0376296092"),
    productCode_85("0052100568"),
    productCode_86("0304093729"),
    productCode_87("0375728624"),
    productCode_88("0297910793"),
    productCode_89("0427424042"),
    productCode_90("0052100579"),
    productCode_91("0297910782"),
    productCode_92("0052100580"),
    productCode_93("0087896853"),
    productCode_94("0377538017"),
    productCode_95("0021696231");
    //test
   // productCode_96("0123889054");           
    
    private String code ;
    
    GiftCardEnum (String code){
        this.setCode(code) ;
    }
    
    public static Boolean isExist(List<String> codes){    
        for(String code:codes){
            for(GiftCardEnum gif:GiftCardEnum.values()){
                if(gif.getCode().equals(code)){
                    return true ;
                    }
                }     
            }
        return false ;
        }

        /**
         * Getter method for property <tt>code</tt>.
         * 
         * @return property value of code
         */
    public String getCode() {
        return code;
    }

        /**
         * Setter method for property <tt>code</tt>.
         * 
         * @param code value to be assigned to property code
         */
    public void setCode(String code) {
        this.code = code;
    }
}
