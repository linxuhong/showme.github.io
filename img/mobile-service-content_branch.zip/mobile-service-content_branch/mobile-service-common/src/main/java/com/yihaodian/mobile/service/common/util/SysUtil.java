package com.yihaodian.mobile.service.common.util;

import org.apache.commons.lang.StringUtils;

public class SysUtil {

	public static String getRuntimeEnv() {
		String evn = System.getProperty("env");
		return evn;
	}

	public static boolean isTest() {
		String evn = System.getProperty("env");
		if (StringUtils.isNotBlank(evn)
				&& (evn.equals("test") || evn.equals("base"))) {
			return true;
		}
		return false;
	}

	public static boolean isStg() {
		String evn = System.getProperty("env");
		if (StringUtils.isNotBlank(evn) && evn.equals("staging")) {
			return true;
		}
		return false;
	}

	public static boolean isProduction() {
		String evn = System.getProperty("env");
		if (StringUtils.isNotBlank(evn) && evn.equals("production")) {
			return true;
		}
		return false;
	}

}
