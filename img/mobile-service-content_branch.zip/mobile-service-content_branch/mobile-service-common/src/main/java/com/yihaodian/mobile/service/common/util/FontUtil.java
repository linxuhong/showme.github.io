package com.yihaodian.mobile.service.common.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Transparency;
import java.awt.font.FontRenderContext;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
  
public  class FontUtil {   
	public static final Log LOG = LogFactory.getLog(FontUtil.class);
	private static File  file ;
	private static Font  font ;
	private static final String dictionary = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	private static final List<Font> fontList = new ArrayList<Font>();
	private static final int width =122;
	private static final int height=50;
	private static final int bgColor = 0xFFFFFF; //验证码的背景色，采用一个int型表示， 这个值的 16-23 位表示红色分量，8-15 位表示绿色分量，0-7 位表示蓝色分量
	private static final int fontSizeRangeMax = 35;//字体随机大小最大值
	private static final int fontSizeRangeMin = 25;//字体随机大小最小值
	private static final int[] fgColorRange = new int[] { 0, 155 };//验证码前景色的各个分量范围, 大小为0-255 ，由小到大排列，包括R,G,B三个值 
	private static final int[] rotateRange = new int[] {-30,30};//验证码各个字符进行变换时的旋转因子范围，单位为度
	private static final int cloudSize=4;//字体重叠像素
	
    static {
       try {
    	   file = YccGlobalPropertyConfigurer.getFile("kxfont.ttf");
    	   font = Font.createFont(Font.TRUETYPE_FONT, file);
           for(int i=fontSizeRangeMin;i<=fontSizeRangeMax;i++)
           {
        	   fontList.add(font.deriveFont(Font.PLAIN, i)); 
           }
       } catch (Exception e) {
    	   LOG.error(e);
       } 
    }
    
    private FontUtil() {
	}

	public static Object[]  generateCheckCodeImage() throws Exception {
		Object[] obj=new Object[2];
		String code=generateCodeString();
		char[] codeChars = code.toCharArray();
		BufferedImage[] images = new BufferedImage[codeChars.length];//待处理的字符图片
		Color fgColor = getColor(fgColorRange);//在生成验证码时，使用同一种颜色更不易被识别软件识别
		int countFontWidth=0;
		for (int i = 0; i < codeChars.length; i++) {
			images[i] = new BufferedImage(height, height, BufferedImage.TYPE_INT_RGB);//首先创建一个height * height 的图片
			Graphics2D g2d = images[i].createGraphics();
			images[i] = g2d.getDeviceConfiguration().createCompatibleImage(height, height, Transparency.TRANSLUCENT);//使得绘制的图片背景透明
			g2d.dispose();
			g2d = images[i].createGraphics();
			//字体随机大小
			int r=(int)(Math.random() * fontList.size());
			g2d.setFont(fontList.get(r));
			g2d.setColor(fgColor);
			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);//消除锯齿
//			FontRenderContext fontRenderContext = g2d.getFontRenderContext();
//			int p_x = (int) ((height - g2d.getFontMetrics().charWidth(codeChars[i])) / 2);
//			int p_y = (int) (height / 2 + font.getLineMetrics(Character.toString(codeChars[i]), fontRenderContext).getAscent() / 2);
			countFontWidth+=g2d.getFontMetrics().charWidth(codeChars[i]);
	        int rand=(int)(Math.random()*(height-fontSizeRangeMax));//随机上下浮动
	        int p_y=fontSizeRangeMax+rand;
	        g2d.drawString(Character.toString(codeChars[i]), 0, p_y);
			g2d.dispose();
			images[i]=rotateImage(images[i]);//随机旋转角度
		}
		BufferedImage bi=appendImages(images);
		obj[0]=bi;
		obj[1]=code;
		return obj;
	}
	
	public static String generateCheckCode() throws Exception {
		return generateCodeString();
	}
	
	public static BufferedImage generateCheckCodeImage(String checkCode) throws Exception {
		char[] codeChars = checkCode.toCharArray();
		BufferedImage[] images = new BufferedImage[codeChars.length];//待处理的字符图片
		Color fgColor = getColor(fgColorRange);//在生成验证码时，使用同一种颜色更不易被识别软件识别
		for (int i = 0; i < codeChars.length; i++) {
			images[i] = new BufferedImage(height, height, BufferedImage.TYPE_INT_RGB);//首先创建一个height * height 的图片
			Graphics2D g2d = images[i].createGraphics();
			images[i] = g2d.getDeviceConfiguration().createCompatibleImage(height, height, Transparency.TRANSLUCENT);//使得绘制的图片背景透明
			g2d.dispose();
			g2d = images[i].createGraphics();
			//字体随机大小
			int r=(int)(Math.random() * fontList.size());
			g2d.setFont(fontList.get(r));
			g2d.setColor(fgColor);
			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);//消除锯齿
			FontRenderContext fontRenderContext = g2d.getFontRenderContext();
			int p_x = (int) ((height - g2d.getFontMetrics().charWidth(codeChars[i])) / 2);
			int p_y = (int) (height / 2 + font.getLineMetrics(Character.toString(codeChars[i]), fontRenderContext).getAscent() / 2);
			g2d.drawString(Character.toString(codeChars[i]), p_x, p_y);
			g2d.dispose();
			images[i]=rotateImage(images[i]);//随机旋转角度
		}
		BufferedImage bi=appendImages(images);
		return bi;
	}
	
	/**
	 *  图片随机旋转角度旋转
	 * @param bufferedimage
	 * @return
	 */
	private static BufferedImage rotateImage(final BufferedImage bufferedimage) {
        int w = bufferedimage.getWidth();
        int h = bufferedimage.getHeight();
        int type = bufferedimage.getColorModel().getTransparency();
        BufferedImage img = new BufferedImage(w, h, type);
        Graphics2D graphics2d =img.createGraphics();
        graphics2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2d.rotate(Math.toRadians(getRandomInRange(rotateRange)), (double)w / 2, (double)h / 2);
        graphics2d.drawImage(bufferedimage, 0, 0, null);
        graphics2d.dispose();
        return img;
    }

	/**
	 * 拼接验证码图片
	 * 
	 * @param images
	 * @return
	 */
	private static  BufferedImage appendImages(BufferedImage[] images) {
		BufferedImage bgImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_BGR);
		Graphics2D g2d = bgImage.createGraphics();
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setColor(new Color(bgColor));
		g2d.fillRect(0, 0, width, height);
		g2d.setColor(Color.white);
		g2d.drawRect(0, 0, width, height);
		int index = 0;// 当前正在处理的图片
		// 绘制下一个图片时的位置
		int drawX = (int)(Math.random() * 10);//随机初始x轴位置
		if (images != null && images.length != 0) {
			g2d.drawImage(images[index], drawX, 0, images[index].getWidth(), images[0].getHeight(), null);
			drawX += images[index].getWidth();
			index++;
			while (index < images.length) {
			    int distance = calculateDistanceBetweenChar2(images[index - 1], images[index]);
			    g2d.drawImage(images[index], drawX - distance, 0, images[index].getWidth(), images[0].getHeight(), null);
			    drawX += images[index].getWidth() - distance;
			    index++;
			}
		}
		g2d.dispose();
		return bgImage;
	}

	private static int min(int[] array) {
		int result = Integer.MAX_VALUE;
		for (int item : array) {
			if (item < result) {
				result = item;
			}
		}
		return result;
	}

	/**
	 * 计算每个图片每行的左右空白像素个数. int[row][0]存储左边空白像素个数 int[row][1]存储右边空白像素个数
	 * 
	 * @param image
	 * @return
	 */
	private static int[][] calculateBlankNum(BufferedImage image) {
		int width = image.getWidth();
		int height = image.getHeight();
		int[][] result = new int[height][2];
		for (int i = 0; i < result.length; i++) {
			result[i][0] = 0;
			result[i][1] = width;
		}
		int[] colorArray = new int[4];
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				colorArray = image.getRaster().getPixel(j, i, colorArray);
				if (!checkArray(colorArray, new int[] { 0, 0, 0, 0 })) {
					if (result[i][0] == 0) {
						result[i][0] = j;
					}
					result[i][1] = width - j + cloudSize;
				}
			}
		}
		return result;
	}

	/**
	 * 计算两个相邻图片上字符的碰撞间距
	 * 
	 * @param leftImage
	 * @param rightImage
	 * @return
	 */
	private static int calculateDistanceBetweenChar2(BufferedImage leftImage, BufferedImage rightImage) {
		int[][] left = calculateBlankNum(leftImage);// 左图每行右侧空白字符个数列表
		int[][] right = calculateBlankNum(rightImage);// 右图每行左侧空白字符个数列表
		int[] tempArray = new int[leftImage.getHeight()];
		for (int i = 0; i < left.length; i++) {
			if (right[i][0] == 0) {
				tempArray[i] = left[i][1] + leftImage.getWidth();
			} else {
				tempArray[i] = left[i][1] + right[i][0];
			}
		}
		return min(tempArray);
	}

	/**
	 * 判断两个数组是否相等，要求长度相等，每个元素的值也相等
	 * 
	 * @param colorArray
	 * @param colorArray2
	 * @return
	 */
	private static  boolean checkArray(int[] arrayA, int[] arrayB) {
		if (arrayA == null || arrayB == null) {
			return false;
		}
		if (arrayA.length != arrayB.length) {
			return false;
		}
		for (int i = 0; i < arrayA.length; i++) {
			if (arrayA[i] != arrayB[i]) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 根据一个范围生成一个随机颜色，其中颜色分量的最大值为255
	 * 
	 * @param colorRange
	 * @return
	 */
	private static Color getColor(int[] colorRange) {
		int r = getRandomInRange(colorRange);
		int g = getRandomInRange(colorRange);
		int b = getRandomInRange(colorRange);
		return new Color(r, g, b);
	}

	/**
	 * 返回一个在参数指定范围内的随机数
	 * 
	 * @param range
	 * @return
	 */
	private static  int getRandomInRange(int[] range) {
		if (range == null || range.length != 2) {
			throw new RuntimeException("范围参数不合法，必须包含两个元素");
		}
		return (int) (Math.random() * (range[1] - range[0]) + range[0]);
	}
	/**
	 * 随机生成4个字符串
	 * @return
	 */
	private static String generateCodeString() {	
		char[] dictionaryChars = dictionary.toCharArray();
		int index1 = (int) (dictionaryChars.length * Math.random());
		int index2 = (int) (dictionaryChars.length * Math.random());
		int index3 = (int) (dictionaryChars.length * Math.random());
		int index4 = (int) (dictionaryChars.length * Math.random());
		char[] codeChars = new char[]{dictionaryChars[index1],dictionaryChars[index2],dictionaryChars[index3],dictionaryChars[index4]};
		return String.valueOf(codeChars, 0, codeChars.length);
	}
	
	
}