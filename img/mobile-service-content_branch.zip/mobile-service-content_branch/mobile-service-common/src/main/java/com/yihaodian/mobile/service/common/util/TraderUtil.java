package com.yihaodian.mobile.service.common.util;

import com.yihaodian.mobile.service.common.util.service.VersionUtil;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.constant.CommonKey;

public class TraderUtil {
	/**
	 * 1mall环境traderName转为对应的1mallName
	 * @param trader
	 * @param siteType
	 * @return
	 */
	public static Trader transTrader(Trader trader , int siteType) {
      try{
    	  if(trader.getTraderName()==null){
    		  return trader;
    	  }
    	  if(trader.getTraderName().equals(CommonKey.TRADER_NAME_IPHONE)&&siteType==2){
    		  trader.setTraderName(CommonKey.TRADER_NAME_IPHONE_MALL);
    	  }else if(trader.getTraderName().equals(CommonKey.TRADER_NAME_ANDROID)&&siteType==2){
    		  trader.setTraderName(CommonKey.TRADER_NAME_ANDROID_MALL);
    	  }
      }catch (Exception e) {
	}
      return trader;
	}
	

	/**
	 * ios7devicecode替换为deviceCodeNotEncrypt
	 * @param trader
	 * @return
	 */
	public static Trader transTraderForIos7(Trader trader){
		try {
			if((trader.getTraderName().equals(CommonKey.TRADER_NAME_IPHONE)||trader.getTraderName().equals(CommonKey.TRADER_NAME_IPHONE_MALL)||trader.getTraderName().equals(CommonKey.TRADER_NAME_IPAD))&&trader.getClientVersion()!=null&&VersionUtil.compare(CommonKey.IPHONE_CLIENT_SYSTEM_VERSION_7_0, trader.getClientVersion())>=0){
				trader.setDeviceCode(trader.getDeviceCodeNotEncrypt());
				return trader;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return trader;
	}
}
