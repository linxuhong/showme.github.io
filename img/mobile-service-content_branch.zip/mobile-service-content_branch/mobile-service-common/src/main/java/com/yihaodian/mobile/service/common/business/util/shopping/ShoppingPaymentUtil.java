package com.yihaodian.mobile.service.common.business.util.shopping;

import java.util.ArrayList;
import java.util.List;

import com.yihaodian.myyhdservice.client.service.mobile.MyyhdOrderServiceForMobileClient;
import com.yihaodian.myyhdservice.interfaces.enums.invoker.InvokerSource;
import com.yihaodian.myyhdservice.interfaces.inputvo.order.MyyhdGetGatewayInputVo;
import com.yihaodian.myyhdservice.interfaces.outputvo.MyyhdServiceListResult;
import com.yihaodian.myyhdservice.interfaces.outputvo.order.mobile.MyMobilePaymentBank;
import com.yihaodian.shoppingmobileinterface.input.checkout.MobileGetGatewayInputVo;
import com.yihaodian.shoppingmobileinterface.vo.checkout.MobileBank;

/**
 * 购物流程支付工具类
 * @author zhangwei5
 * @version $Id: ShoppingPaymentUtil.java, v 0.1 2014-4-25 上午11:20:53 zhangwei5 Exp $
 */
public class ShoppingPaymentUtil {

    /**
     * 获取支持的网关信息列表
     */
    public static List<MobileBank> getPaymentGatwayList(MobileGetGatewayInputVo mobileGetGatewayInputVo) {
		MyyhdGetGatewayInputVo input = new MyyhdGetGatewayInputVo();
		input.setGateWayMode(mobileGetGatewayInputVo.getGateWayMode());
		input.setDeviceCode(mobileGetGatewayInputVo.getDeviceCode());
		input.setUserToken(mobileGetGatewayInputVo.getUserToken());
		input.setProvinceId(mobileGetGatewayInputVo.getProvinceId());
		input.setInterfaceVersion(mobileGetGatewayInputVo.getInterfaceVersion());
		input.setClientSystem(mobileGetGatewayInputVo.getClientSystem());
		input.setClientVersion(mobileGetGatewayInputVo.getClientVersion());
		input.setInvokerSource(InvokerSource.MOBILECLIENT);
		MyyhdServiceListResult<MyMobilePaymentBank> result = MyyhdOrderServiceForMobileClient
				.getInstance().payGateWayList(input);

		List<MobileBank> mobileBankList = new ArrayList<MobileBank>();
		if(result.getResultList()!=null){
			for (MyMobilePaymentBank bank : result.getResultList()) {
				MobileBank mb = new MobileBank();
				mb.setId(bank.getId());
				mb.setCode(bank.getCode());
				mb.setDescription(bank.getDescription());
				mb.setName(bank.getName());
				mb.setImgSrc(bank.getImgSrc());
				mobileBankList.add(mb);
			}
		}
        return mobileBankList;
    }
}
