package com.yihaodian.front.i.util.img;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.yihaodian.front.global.util.UrlPrefix;

import org.apache.commons.lang.StringUtils;

public class ConvertSiteImgPathUtil {
	  public static final int SITE_FLAG_UNITE = 0;
	  public static final int SITE_FLAG_SEPARATE = 1;
	  public static final int SITE_TYPE_YHD = 1;
	  public static final int SITE_TYPE_MALL = 2;
	  public static final String IMG_DOMAIN_CENTRAL = "centralImgDomain";
	  public static final String IMG_DOMAIN_MALL = "mallImgDomain";
	  public static final String YHD_DOMAIN_CENTRAL = "centralYhdDomain";
	  public static final String IMG_DOMAIN_CENTRAL_DEFAULT = ".yihaodianimg.com";
	  public static final String IMG_DOMAIN_MALL_DEFAULT = ".51ap.cn";
	  public static final String IMG_DOMAIN_CENTRAL_YHD = ".yihaodian.com";

	  public static String matchHeguiImgUrl(String originalUrl)
	  {
	    if (StringUtils.isBlank(originalUrl)) {
	      return originalUrl;
	    }
	    String regex = null;

	    String replacement = getContextImgDomain(originalUrl);

	    String centralRegex = getCentralContextImgDomain(originalUrl);
	    if (centralRegex.equals(replacement)) {
	      regex = getMallContextImgDomain();
	    }
	    else {
	      regex = centralRegex;
	    }
	    Pattern pattern = Pattern.compile(regex);
	    Matcher matcher = pattern.matcher(originalUrl);
	    if (matcher.find()) {
	      return matcher.replaceAll(replacement);
	    }
	    return originalUrl;
	  }

	  private static String getContextImgDomain(String originalUrl)
	  {
	    String domain =getCentralContextImgDomain(originalUrl);
	    return domain;
	  }

	  private static String getMallContextImgDomain() {
	    String domain = null;
	    domain = (String)UrlPrefix.getValues().get("mallImgDomain");

	    if (StringUtils.isBlank(domain)) {
	      domain = ".51ap.cn";
	    }
	    return domain;
	  }

	  private static String getCentralContextImgDomain(String originalUrl) {
	    String domain = null;
	    Pattern pattern = Pattern.compile(".yihaodian.com");
	    Matcher matcher = pattern.matcher(originalUrl);
	    if (matcher.find()) {
	      domain = (String)UrlPrefix.getValues().get("centralYhdDomain");
	      if (StringUtils.isBlank(domain)) {
	        return ".yihaodian.com";
	      }

	      return domain;
	    }

	    domain = (String)UrlPrefix.getValues().get("centralImgDomain");
	    if (StringUtils.isBlank(domain)) {
	      return ".yihaodianimg.com";
	    }

	    return domain;
	  }
}
