package com.yihaodian.mobile.service.common.util.service;

public class AppADConstants {
    public static enum AD_LAYOUT{
    	NO_USE,//0 不使用
    	H5_CMS,//1 H5 CMS调转(CMS列表页，CMS专题页面
    	DECREASE_UNDER_CONDITION,//2满减
    	GIFT_UNDER_CONDITION,//3满赠
    	N2N_ACTIVITY, //4 N元N件
    	COUPON_LIST,//5 抵用券页面
    	NO_USE2,//6
    	NO_USE3,//7
    	CMS_MAX,//8 CMS聚合页面，逐步废弃，转为H5_CMS
    	SEARCH,//9 搜索词类型
    	BRAND_LIST,  //10 品牌旗舰
    	BRAND_SHOP,//11 品牌店铺页面
    	MOBILE_CHARGE_INDEX, //12  //手机充值
    	IMPORT_GOODS_INDEX, //13  //进口馆页面
    	NOLINK_AD,//* 无链接广告                            14
    	OUTLINK_AD,//* 外部链接广告                              15
    	FUNCTION,//* 自定义功能类型                          16
    	BRAND,//* 品牌广告                              17
    	CATEGORY,//* 类目广告                              18
    	MALLSHOP,//* 商城店铺广告                           19
    	DISCOUNT_UNDER_CONDITION, //* 满折                 20
    	GROUPON_CATEGORY,  //  团购类目               21
    	GROUPON_CHANNEL,//       团购频道                           22 
    	GROUPON_BRAND,//                         品牌团购广告     23
    	GROUPON_LABEL,//                                    24,
    	GROUPON,//* 团购商品列表                             25
    	PROMOTION_LD_PRODUCTS,//* 普通产品列表或lp活动           26
    	CMS_NATIVE,     //  cms natvie页                  27
    	PC_CMS,         // pc cms 活动                        28
    	TOP100_CATEGORY,//TOP100
	    LOW_PRICE_CATEGORY; //一贵就赔
    }
  
}
