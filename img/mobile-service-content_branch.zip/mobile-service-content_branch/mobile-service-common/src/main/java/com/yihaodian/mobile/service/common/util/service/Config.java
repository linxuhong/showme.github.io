package com.yihaodian.mobile.service.common.util.service;
import java.util.Properties;

import com.yihaodian.configcentre.client.utils.YccGlobalPropertyConfigurer;
// TODO: Auto-generated Javadoc

/**
 * The Class Config.
 */
public class Config {
	
	/** The prop names. */
	private static String[] propNames = new String[] {"remoteService.properties"};
	
	/** The properties. */
	private static Properties properties = new Properties();
	static {
		String poolId = "yihaodian/yihaodian_mobile-service-content";
		for (int i = 0; i < propNames.length; i++) {
			String data = YccGlobalPropertyConfigurer.loadConfigString(poolId,
					propNames[i], true);
			if (data == null){
				continue;
			}
			Properties prop = YccGlobalPropertyConfigurer
					.loadPropertiesFromString(data);
			if (prop != null) {
				properties.putAll(prop);
			}
		}
	}
	
	/**
	 * Gets the properties.
	 *
	 * @return the properties
	 */
	public static Properties getProperties(){
		return properties;
	}
	
	/**
	 * Gets the.
	 *
	 * @param name the name
	 * @return the string
	 */
	public static String get(String name) {
		if (name == null){
			return null;
		}
		String value = properties.getProperty(name);
		return value;
	}

	/**
	 * Gets the.
	 *
	 * @param name the name
	 * @param def the def
	 * @return the string
	 */
	public static String get(String name, String def) {
		String val = get(name);
		return val != null ? val : def;
	}

	/**
	 * Gets the int.
	 *
	 * @param name the name
	 * @return the int
	 */
	public static int getInt(String name) {
		String val = get(name);
		return val == null ? 0 : Integer.parseInt(val);
	}
	
	/**
	 * Gets the int.
	 *
	 * @param name the name
	 * @param def the def
	 * @return the int
	 */
	public static int getInt(String name, int def) {
		String val = get(name);
		return val != null ? Integer.parseInt(val) : def;
	}
   
	/**
	 * Gets the long.
	 *
	 * @param name the name
	 * @return the long
	 */
	public static long getLong(String name) {
		String val = get(name);
		return val == null ? 0l : Long.parseLong(val);
	}
	
	/**
	 * Gets the long.
	 *
	 * @param name the name
	 * @param def the def
	 * @return the long
	 */
	public static long getLong(String name, long def) {
		String val = get(name);
		return val != null ? Long.parseLong(val) : def;
	}
	
	/**
	 * Gets the bool.
	 *
	 * @param name the name
	 * @return the bool
	 */
	public static boolean getBool(String name) {
		String val = get(name);
		return val == null ? false : Boolean.parseBoolean(val);
	}

	/**
	 * Gets the bool.
	 *
	 * @param name the name
	 * @param def the def
	 * @return the bool
	 */
	public static boolean getBool(String name, boolean def) {
		String val = get(name);
		return val != null ? Boolean.parseBoolean(val) : def;
	}

	/**
	 * Gets the float.
	 *
	 * @param name the name
	 * @return the float
	 */
	public static float getFloat(String name) {
		String val = get(name);
		return val == null ? 0f : Float.parseFloat(val);
	}

	/**
	 * Gets the float.
	 *
	 * @param name the name
	 * @param def the def
	 * @return the float
	 */
	public static float getFloat(String name, float def) {
		String val = get(name);
		return val != null ? Float.parseFloat(val) : def;
	}

	/**
	 * Gets the double.
	 *
	 * @param name the name
	 * @return the double
	 */
	public static double getDouble(String name) {
		String val = get(name);
		return val == null ? 0 : Double.parseDouble(val);
	}

	/**
	 * Gets the double.
	 *
	 * @param name the name
	 * @param def the def
	 * @return the double
	 */
	public static double getDouble(String name, double def) {
		String val = get(name);
		return val != null ? Double.parseDouble(val) : def;
	}

}
