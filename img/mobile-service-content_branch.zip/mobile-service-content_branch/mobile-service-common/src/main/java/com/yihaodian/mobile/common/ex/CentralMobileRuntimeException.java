package com.yihaodian.mobile.common.ex;

public class CentralMobileRuntimeException extends RuntimeException {
    /**
     * <pre>
     * 
     * </pre>
     */
    private static final long serialVersionUID = 8136266661435849877L;

    public CentralMobileRuntimeException(String exception) {
        if(RuntimeExceptionThreadVO.getMessage()==null) {
            RuntimeExceptionThreadVO.setMessage(exception);
        }
    }

    @Override
    public String getMessage() {
        return RuntimeExceptionThreadVO.getMessage();
    }

}
