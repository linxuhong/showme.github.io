package com.yihaodian.mobile.service.common.business.util.tools;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TimeoutTaskTool {
    private static Logger log = LoggerFactory.getLogger(TimeoutTaskTool.class);
    public static final long Default_ExpairedTime = 1;

    /**
     * 一个timeout任务方法
     * 注意 callbale 回调方法内的错误处理，FutureTask方法是延迟执行callable回调并未捕获callable的异常信息 .
     * 所以在程序中还应对callable内的代码进行try catch处理。
     * @param callable  回调方法
     * @param timeout   timeout时间，单位秒
     * @returnf
     */
    public static<T> T executeTimeoutTask(Callable<T> callable,long timeout){
        T result = null;
        try {
            FutureTask<T> futureTask = new FutureTask<T>(callable);
            futureTask.run();
            if(timeout<=0)
                timeout = Default_ExpairedTime;
            result = futureTask.get(timeout, TimeUnit.SECONDS);
        } catch (Exception e) {
            log.error("it is failed to execute the future task.", e);
        }
        return result;
    }
    
    /**
     * 与上面的方法一样，增加了一个参数变量
     * @param callable
     * @param timeout
     * @param obj
     * @return
     */
    public static<T> T executeTimeoutTask(Callable<T> callable, long timeout, Object params){
        T result = null;
        try {
//          long currTime = System.currentTimeMillis();
            FutureTask<T> futureTask = new FutureTask<T>(callable);
            futureTask.run();
            if(timeout<=0)
                timeout = Default_ExpairedTime;
            result = futureTask.get(timeout, TimeUnit.SECONDS);
            /*if(System.currentTimeMillis() - timeout >= currTime){
                System.out.println("促销接口调用超时.......................................................................");
                log.error("促销接口调用超时.......................................................................");
            }*/
        } catch (Exception e) {
            log.error("促销接口调用超时.......................................................................", e);
        }
        return result;
    }
}
