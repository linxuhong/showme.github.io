package com.yihaodian.mobile.service.common.util;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.home.CalendarBuyDetail;
import com.yihaodian.mobile.vo.home.CalendarBuyVO;
import com.yihaodian.mobile.vo.home.DailyTimeVO;
import com.yihaodian.mobile.vo.home.HomeFloorPromotion;
import com.yihaodian.mobile.vo.home.HomePromotionDetailVO;
import com.yihaodian.mobile.vo.home.HomePromotionVO;
import com.yihaodian.mobile.vo.product.ProductVO;
import com.yihaodian.mobile.vo.promotion.CmsColumnVO;
import com.yihaodian.mobile.vo.promotion.CmsPromotionVO;
import com.yihaodian.mobile.vo.promotion.PromotionSortAttributes;

public class HttpGetMethodsConstant {
	
	public enum ParamTypeEnum{
		None, 
		
		String,
		
		Integer,
		
		Long
	}
	
	public static Map<String, Map<String, ParamTypeEnum>[]> methodMap = new HashMap();
	static{
		//AddressService
		methodMap.put("getAllProvince", null);
		LinkedHashMap<String, ParamTypeEnum> map0 = new LinkedHashMap();
		map0.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getCityByProvinceId", new LinkedHashMap[]{map0});
		LinkedHashMap<String, ParamTypeEnum> map1 = new LinkedHashMap();
		map1.put("cityId", ParamTypeEnum.Long);
		methodMap.put("getCountyByCityId", new LinkedHashMap[]{map1});
		
		//GrouponService
		LinkedHashMap<String, ParamTypeEnum> map2 = new LinkedHashMap();
		map2.put("areaId", ParamTypeEnum.Long);
		methodMap.put("getGrouponCategoryList", new LinkedHashMap[]{map2});
		LinkedHashMap<String, ParamTypeEnum> map3 = new LinkedHashMap();
		map3.put("grouponId", ParamTypeEnum.Long);
		map3.put("areaId", ParamTypeEnum.Long);
		methodMap.put("getGrouponDetail", new LinkedHashMap[]{map3});
		methodMap.put("getGrouponAreaList", null);
		LinkedHashMap<String, ParamTypeEnum> map4 = new LinkedHashMap();
		map4.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getGrouponAreaIdByProvinceId", new LinkedHashMap[]{map4});
		LinkedHashMap<String, ParamTypeEnum> map5 = new LinkedHashMap();
		map5.put("areaId", ParamTypeEnum.Long);
		methodMap.put("getGroupOnSortAttribute", new LinkedHashMap[]{map5});
		
		//HomeService
		LinkedHashMap<String, ParamTypeEnum> map6 = new LinkedHashMap();
		map6.put("provinceId", ParamTypeEnum.Long);
		map6.put("currentPage", ParamTypeEnum.Integer);
		map6.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getHomeSelection", new LinkedHashMap[]{map6});
		LinkedHashMap<String, ParamTypeEnum> map7 = new LinkedHashMap();
		map7.put("type", ParamTypeEnum.Integer);
		methodMap.put("getHomeHotElement", new LinkedHashMap[]{map7});
		methodMap.put("getHomeModuleList", null);
		LinkedHashMap<String, ParamTypeEnum> map8 = new LinkedHashMap();
		map8.put("currentPage", ParamTypeEnum.Integer);
		map8.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getQualityAppList", new LinkedHashMap[]{map8});
		
		//PayService
		LinkedHashMap<String, ParamTypeEnum> map9 = new LinkedHashMap();
		map9.put("name", ParamTypeEnum.String);
		map9.put("type", ParamTypeEnum.Long);
		map9.put("currentPage", ParamTypeEnum.Integer);
		map9.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getBankVOList", new LinkedHashMap[]{map9});
		
		//ProductService
		LinkedHashMap<String, ParamTypeEnum> map10 = new LinkedHashMap();
		LinkedHashMap<String, ParamTypeEnum> map28 = new LinkedHashMap();
		map10.put("productId", ParamTypeEnum.Long);
		map10.put("provinceId", ParamTypeEnum.Long);
		map28.put("productId", ParamTypeEnum.Long);
		map28.put("provinceId", ParamTypeEnum.Long);
		map28.put("promotionId", ParamTypeEnum.String);
		methodMap.put("getProductDetail", new LinkedHashMap[]{map10, map28});
		methodMap.put("getProductDetailDescription", new LinkedHashMap[]{map10});
		methodMap.put("getProductDetailDescriptionV2", new LinkedHashMap[]{map10});
		methodMap.put("getProductDetailComment", new LinkedHashMap[]{map10});
		LinkedHashMap<String, ParamTypeEnum> map11 = new LinkedHashMap();
		map11.put("barcode", ParamTypeEnum.String);
		map11.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getProductByBarcode", new LinkedHashMap[]{map11});
		LinkedHashMap<String, ParamTypeEnum> map12 = new LinkedHashMap();
		map12.put("mcsiteId", ParamTypeEnum.Long);
		map12.put("rootCategoryId", ParamTypeEnum.Long);
		map12.put("currentPage", ParamTypeEnum.Integer);
		map12.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getCategoryByRootCategoryId", new LinkedHashMap[]{map12});
		LinkedHashMap<String, ParamTypeEnum> map13 = new LinkedHashMap();
		map13.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getHomeHotProductTop5List", new LinkedHashMap[]{map13});
		methodMap.put("getHotRandomProducts", new LinkedHashMap[]{map13});
		LinkedHashMap<String, ParamTypeEnum> map14 = new LinkedHashMap();
		map14.put("productId", ParamTypeEnum.Long);
		map14.put("currentPage", ParamTypeEnum.Integer);
		map14.put("pageSize", ParamTypeEnum.Integer);
		map14.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getPackageProducts", new LinkedHashMap[]{map14});
		LinkedHashMap<String, ParamTypeEnum> map15 = new LinkedHashMap();
		LinkedHashMap<String, ParamTypeEnum> map16 = new LinkedHashMap();
		map15.put("productId", ParamTypeEnum.Long);
		map15.put("currentPage", ParamTypeEnum.Integer);
		map15.put("pageSize", ParamTypeEnum.Integer);
		map16.put("productId", ParamTypeEnum.Long);
		map16.put("provinceId", ParamTypeEnum.Long);
		map16.put("currentPage", ParamTypeEnum.Integer);
		map16.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getMoreInterestedProducts", new LinkedHashMap[]{map15, map16});
		methodMap.put("getUserInterestedProductsCategorys", null);
		LinkedHashMap<String, ParamTypeEnum> map17 = new LinkedHashMap<String, ParamTypeEnum>();
		map17.put("provinceId", ParamTypeEnum.Long);
		map17.put("currentPage", ParamTypeEnum.Integer);
		map17.put("pageSize", ParamTypeEnum.Integer);
		//methodMap.put("getMoreInterestedProducts", new LinkedHashMap[]{map17});
		//methodMap.put("getPromotionGiftList", null); //参数不支持
		methodMap.put("getAdvertisementList",  new LinkedHashMap[]{map17});
		
		//SearchService
		LinkedHashMap<String, ParamTypeEnum> map18 = new LinkedHashMap();
		map18.put("barcode", ParamTypeEnum.String);
		map18.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getProductByBarcode", new LinkedHashMap[]{map18});
		methodMap.put("getRelateProductByBarcode", new LinkedHashMap[]{map18});
		LinkedHashMap<String, ParamTypeEnum> map19 = new LinkedHashMap();
		map19.put("mcsiteid", ParamTypeEnum.Long);
		map19.put("provinceId", ParamTypeEnum.Long);
		map19.put("keyword", ParamTypeEnum.String);
		map19.put("categoryId", ParamTypeEnum.Long);
		map19.put("brandId", ParamTypeEnum.Long);
		map19.put("sortType", ParamTypeEnum.Integer);
		map19.put("currentPage", ParamTypeEnum.Integer);
		map19.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("searchProduct", new LinkedHashMap[]{map19});
		LinkedHashMap<String, ParamTypeEnum> map20 = new LinkedHashMap();
		LinkedHashMap<String, ParamTypeEnum> map21 = new LinkedHashMap();
		map20.put("mcsiteid", ParamTypeEnum.Long);
		map20.put("keyword", ParamTypeEnum.String);
		map21.put("mcsiteid", ParamTypeEnum.Long);
		map21.put("keyword", ParamTypeEnum.String);
		map21.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getSearchKeyWord", new LinkedHashMap[]{map20, map21});
		methodMap.put("getSearchKeyword", new LinkedHashMap[]{map21});
		
		//PromotionService
		LinkedHashMap<String, ParamTypeEnum> map22 = new LinkedHashMap();
		map22.put("provinceId", ParamTypeEnum.Long);
		map22.put("type", ParamTypeEnum.Integer);
		map22.put("currentPage", ParamTypeEnum.Integer);
		map22.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getAdvertisingPromotionVOByType", new LinkedHashMap[]{map22});
		LinkedHashMap<String, ParamTypeEnum> map23 = new LinkedHashMap();
		map23.put("id", ParamTypeEnum.Long);
		methodMap.put("getPromotionByTopicID", new LinkedHashMap[]{map23});
		LinkedHashMap<String, ParamTypeEnum> map24 = new LinkedHashMap();
		map24.put("provinceId", ParamTypeEnum.Long);
		map24.put("currentPage", ParamTypeEnum.Integer);
		map24.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getRockProductList", new LinkedHashMap[]{map24});
		methodMap.put("getHomeHotPointListNew", new LinkedHashMap[]{map24});
		LinkedHashMap<String, ParamTypeEnum> map25 = new LinkedHashMap();
		map25.put("provinceId", ParamTypeEnum.Long);
		map25.put("activityId", ParamTypeEnum.Long);
		map25.put("currentPage", ParamTypeEnum.Integer);
		map25.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getCmsPageList", new LinkedHashMap[]{map25});
		LinkedHashMap<String, ParamTypeEnum> map26 = new LinkedHashMap();
		LinkedHashMap<String, ParamTypeEnum> map29 = new LinkedHashMap();
		map26.put("provinceId", ParamTypeEnum.Long);
		map26.put("cmsPageId", ParamTypeEnum.Long);
		map26.put("type", ParamTypeEnum.String);
		map26.put("currentPage", ParamTypeEnum.Integer);
		map26.put("pageSize", ParamTypeEnum.Integer);
		map29.put("provinceId", ParamTypeEnum.Long);
		map29.put("cmsPageId", ParamTypeEnum.Long);
		map29.put("type", ParamTypeEnum.String);
		map29.put("cmsType", ParamTypeEnum.String);
		map29.put("currentPage", ParamTypeEnum.Integer);
		map29.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getCmsColumnList", new LinkedHashMap[]{map26, map29});
		methodMap.put("getCmsColumnListV2", new LinkedHashMap[]{map26});
		LinkedHashMap<String, ParamTypeEnum> map27 = new LinkedHashMap();
		map27.put("provinceId", ParamTypeEnum.Long);
		map27.put("updateTag", ParamTypeEnum.String);
		methodMap.put("getCmsAdvertisingPromotion", new LinkedHashMap[]{map27});
		
		//for website index
		LinkedHashMap<String, ParamTypeEnum> map_index = new LinkedHashMap();
		map_index.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getIndexProfile", new LinkedHashMap[]{map_index});
		
		//for website calendar
		LinkedHashMap<String, ParamTypeEnum> map_calendar_index = new LinkedHashMap();
		map_calendar_index.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getCalendarProfile", new LinkedHashMap[]{map_calendar_index});
		
		//for website calendar detail
		LinkedHashMap<String, ParamTypeEnum> map_calendar_detail = new LinkedHashMap();
		map_calendar_detail.put("provinceId", ParamTypeEnum.Long);
		map_calendar_detail.put("date", ParamTypeEnum.String);
		methodMap.put("getCalendarDetailProfile", new LinkedHashMap[]{map_calendar_detail});
		
		//for website view
		LinkedHashMap<String, ParamTypeEnum> map_view = new LinkedHashMap();
		map_view.put("linkId", ParamTypeEnum.Long);
		map_view.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getViewProfile", new LinkedHashMap[]{map_view});
		
		LinkedHashMap<String, ParamTypeEnum> map_exportgoods= new LinkedHashMap();
		map_exportgoods.put("linkId", ParamTypeEnum.Long);
		map_exportgoods.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getExportGoodsView", new LinkedHashMap[]{map_exportgoods});
		
		LinkedHashMap<String, ParamTypeEnum> map_exportgoods_category= new LinkedHashMap();
		map_exportgoods_category.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getExportGoodsCategory", new LinkedHashMap[]{map_exportgoods_category});
		
		LinkedHashMap<String, ParamTypeEnum> map_exportgoods_brand= new LinkedHashMap();
		map_exportgoods_brand.put("categoryId", ParamTypeEnum.Long);
		map_exportgoods_brand.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getExportGoodsBrand", new LinkedHashMap[]{map_exportgoods_brand});
		
		LinkedHashMap<String, ParamTypeEnum> map_activityrule= new LinkedHashMap();
		map_activityrule.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getActivityRule", new LinkedHashMap[]{map_activityrule});
		
		//for website daily one
		LinkedHashMap<String, ParamTypeEnum> map_dailyone = new LinkedHashMap();
		map_dailyone.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getDailyOneProfile", new LinkedHashMap[]{map_dailyone});
		
		//for website daily one
		LinkedHashMap<String, ParamTypeEnum> map_getdata = new LinkedHashMap();
		map_getdata.put("provinceId", ParamTypeEnum.Long);
		map_getdata.put("linkId", ParamTypeEnum.Long);
		map_getdata.put("currentPage", ParamTypeEnum.Integer);
		map_getdata.put("pageSize", ParamTypeEnum.Integer);
		map_getdata.put("sortType", ParamTypeEnum.Integer);
		methodMap.put("getActivityProductList", new LinkedHashMap[]{map_getdata});
		
		/**
		 * 首页广告(Banner、楼层、关键字、底部活动)
		 * @param trader系统
		 * @param provinceId省份
		 * @return
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getHomePagePromotionList = new LinkedHashMap();
		map_getHomePagePromotionList.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getHomePagePromotionList", new LinkedHashMap[]{map_getHomePagePromotionList});
		
		/**
		 * 获取首页BannerPage
		 * @param trader
		 * @param currentPage
		 * @param pageSize
		 * @return Page<HomePromotionDetailVO>
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getHomeBannerPage = new LinkedHashMap();
		map_getHomeBannerPage.put("provinceId", ParamTypeEnum.Long);
		map_getHomeBannerPage.put("currentPage", ParamTypeEnum.Integer);
		map_getHomeBannerPage.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getHomeBannerPage", new LinkedHashMap[]{map_getHomeBannerPage});
		
		/**
		 * 获取首页楼层列表
		 * @param trader
		 * @return List<HomePromotionDetailVO>
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getHomeFloorList = new LinkedHashMap();
		map_getHomeFloorList.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getHomeFloorList", new LinkedHashMap[]{map_getHomeFloorList});
		
		/**
		 * 获取首页底部促销活动
		 * @param trader
		 * @param currentPage
		 * @param pageSize
		 * @return Page<HomePromotionDetailVO>
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getBottomPage = new LinkedHashMap();
		map_getBottomPage.put("provinceId", ParamTypeEnum.Long);
		map_getBottomPage.put("currentPage", ParamTypeEnum.Integer);
		map_getBottomPage.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getBottomPage", new LinkedHashMap[]{map_getHomeBannerPage});
		
		/**
		 * 查询日历购列表
		 * @param trader
		 * @param provinceId
		 * @param startDay 日期类型 格式为 2013/06/01
		 * @param endDay 日期类型 格式为 2013/06/01
		 * @return
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getCalendarBuyList = new LinkedHashMap();
		map_getCalendarBuyList.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getCalendarBuyList", new LinkedHashMap[]{map_getCalendarBuyList});
		
		/**
		 * 日历购活动详情
		 * @param trader
		 * @param dateDay
		 * @return
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getCalendarBuyDetail = new LinkedHashMap();
		map_getCalendarBuyDetail.put("provinceId", ParamTypeEnum.Long);
		map_getCalendarBuyDetail.put("dateDay", ParamTypeEnum.String);
		methodMap.put("getCalendarBuyDetail", new LinkedHashMap[]{map_getCalendarBuyDetail});
		
		/**
		 * 获取每日一款商品详情
		 * @param trader
		 * @param dateDay
		 * @return ProductVO
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getCalendarBuyProduct = new LinkedHashMap();
		map_getCalendarBuyProduct.put("provinceId", ParamTypeEnum.Long);
		map_getCalendarBuyProduct.put("dateDay", ParamTypeEnum.String);
		methodMap.put("getCalendarBuyProduct", new LinkedHashMap[]{map_getCalendarBuyProduct});
		
	    /**
	     * <h2>查询CMS活动详情</h2><br/>
	     * <br/>
	     * 功能点：CMS促销;<br/>
	     * 异常：服务器错误;Trader错误;<br/>
	     * 必填参数：trader,provinceId,promotionId<br/> 
	     * 返回值：CmsPromotionVO<br/> 
	     * @param trader
	     * @param provinceId 省份id
	     * @param promotionId CMS活动ID
	     * @return 查询CMS活动详情
	     */
		LinkedHashMap<String, ParamTypeEnum> map_getCmsPromotionVO = new LinkedHashMap();
		map_getCmsPromotionVO.put("provinceId", ParamTypeEnum.Long);
		map_getCmsPromotionVO.put("promotionId", ParamTypeEnum.Long);
		methodMap.put("getCmsPromotionVO", new LinkedHashMap[]{map_getCmsPromotionVO});
		
		/**
		 * 获取品牌旗舰、品牌店铺活动列表
		 * @param trader
		 * @param provinceId 省份
		 * @param promotionId CMS活动Id
		 * @return List<HomePromotionDetailVO>
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getBrandFlagshipPromotion = new LinkedHashMap();
		map_getBrandFlagshipPromotion.put("provinceId", ParamTypeEnum.Long);
		map_getBrandFlagshipPromotion.put("promotionId", ParamTypeEnum.Long);
		map_getBrandFlagshipPromotion.put("currentPage", ParamTypeEnum.Integer);
		map_getBrandFlagshipPromotion.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getBrandFlagshipPromotion", new LinkedHashMap[]{map_getBrandFlagshipPromotion});
		
	    /**
	     * <h2>查询CMS栏目详情(包含商品信息)</h2><br/>
	     * <br/>
	     * 功能点：CMS活动页、栏目详情页;<br/>
	     * 异常：服务器错误;Trader错误;<br/>
	     * 必填参数：trader,provinceId,cmsColumnId,currentPage,pageSize<br/> 
	     * 返回值：CmsColumnVO<br/> 
	     * @param trader
	     * @param provinceId 省份id
	     * @param cmsColumnId CMS栏目id
	     * @param sortType 排序方式 人气、价格、销量
	     * @param currentPage
	     * @param pageSize
	     * @return 查询CMS栏目详情(包含商品信息)
	     */
		LinkedHashMap<String, ParamTypeEnum> map_getCmsColumnDetail = new LinkedHashMap();
		map_getCmsColumnDetail.put("provinceId", ParamTypeEnum.Long);
		map_getCmsColumnDetail.put("cmsColumnId", ParamTypeEnum.Long);
		map_getCmsColumnDetail.put("sortType", ParamTypeEnum.Integer);
		map_getCmsColumnDetail.put("currentPage", ParamTypeEnum.Integer);
		map_getCmsColumnDetail.put("pageSize", ParamTypeEnum.Integer);
		methodMap.put("getCmsColumnDetail", new LinkedHashMap[]{map_getCmsColumnDetail});
		
	    /**
	     * 查询当前日期
	     * @param trader
	     * @return
	     */
		LinkedHashMap<String, ParamTypeEnum> map_getDailyTimeVO = new LinkedHashMap();
		methodMap.put("getDailyTimeVO", new LinkedHashMap[]{map_getDailyTimeVO});
		
		/**
		 * 查询CMS排序属性
		 * @param trader
		 * @return PromotionSortAttributes
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getPromotionSortAttributes = new LinkedHashMap();
		methodMap.put("getPromotionSortAttributes", new LinkedHashMap[]{map_getPromotionSortAttributes});
		
		/**
		 * CMS精简版活动列表
		 * @param trader
		 * @param provinceId 省份
		 * @param promotionId 促销活动Id
		 * @return HomeLiteCmsPromotion
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getLiteCmsPromotion = new LinkedHashMap();
		map_getLiteCmsPromotion.put("provinceId", ParamTypeEnum.Long);
		map_getLiteCmsPromotion.put("promotionId", ParamTypeEnum.Long);
		methodMap.put("getLiteCmsPromotion", new LinkedHashMap[]{map_getLiteCmsPromotion});	
		
		/**
		 * 雪梨首页商品
		 */
		LinkedHashMap<String, ParamTypeEnum> map_getSherryIndexProductList = new LinkedHashMap();
		map_getSherryIndexProductList.put("provinceId", ParamTypeEnum.Long);
		methodMap.put("getSherryIndexProductList", new LinkedHashMap[]{map_getSherryIndexProductList});		
		
		//for website index by type
		LinkedHashMap<String, ParamTypeEnum> map_index_bytype = new LinkedHashMap();
		map_index_bytype.put("provinceId", ParamTypeEnum.Long);
		map_index_bytype.put("viewType", ParamTypeEnum.Long);
		methodMap.put("getIndexProfileByType", new LinkedHashMap[]{map_index_bytype});
	}
	

}
