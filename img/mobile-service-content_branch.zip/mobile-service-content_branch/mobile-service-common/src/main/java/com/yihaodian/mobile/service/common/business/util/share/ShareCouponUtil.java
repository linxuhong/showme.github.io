package com.yihaodian.mobile.service.common.business.util.share;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yihaodian.front.user.common.model.EndUser;
import com.yihaodian.mobile.service.common.business.util.promotion.PromotionCouponUtil;
import com.yihaodian.mobile.service.common.business.util.user.GUSUtil;
import com.yihaodian.mobile.service.common.util.UsernameUtil;
import com.yihaodian.mobile.service.domain.business.dal.MobileCouponShare;
import com.yihaodian.mobile.service.domain.business.emuns.CouponInfoCode;
import com.yihaodian.mobile.service.domain.vo.business.share.ShareCouponDO;
import com.yihaodian.mobile.service.domain.vo.business.user.MobileUserDO;
import com.yihaodian.promotion.coupon.outputVo.CouponActivityOutputVo;
import com.yihaodian.promotion.coupon.outputVo.couponShare.ShareCouponVo;

/**
 * 分享券特有工具类
 * @author zhangwei5
 * @version $Id: ShareCouponUtil.java, v 0.1 2014-2-24 上午9:30:08 zhangwei5 Exp $
 */
public class ShareCouponUtil {
	
    private final static Logger logger = LoggerFactory.getLogger(ShareCouponUtil.class);

	/**
	 * 抵用券活动VO转换 
	 * @param couponActivityOutputVo
	 * @return
	 */
	public static ShareCouponDO couponActivityOutputVoToShareCouponDO(CouponActivityOutputVo couponActivityOutputVo , MobileCouponShare mobileCouponShare){
		try {
			ShareCouponDO shareCouponDO = new ShareCouponDO();
			//抵用券活动Id
			shareCouponDO.setCouponActiveId(couponActivityOutputVo.getActiveId());
			//面额
			shareCouponDO.setCouponAmount(couponActivityOutputVo.getDeductAmount().doubleValue());
			//抵用券活动开始时间
			shareCouponDO.setStartTime(couponActivityOutputVo.getActivityBeginDate());
			//抵用券活动结束时间
			shareCouponDO.setEndTime(couponActivityOutputVo.getActivityEndDate());
			//描述
			shareCouponDO.setDescription(PromotionCouponUtil.getCouponActivityDesc(couponActivityOutputVo));
			//名称
			shareCouponDO.setTitle(couponActivityOutputVo.getActiveName());
			//规则
			shareCouponDO.setRuleDescription(PromotionCouponUtil.composeCouponUseExplain(couponActivityOutputVo));
			//判断是否为掌上专享活动
			if(couponActivityOutputVo.getIsUsedForMobile()!=null&&couponActivityOutputVo.getIsUsedForMobile()==1){
    			//设置券类型
    			shareCouponDO.setCouponType(Integer.valueOf(CouponInfoCode.SHARE_COUPON_TYPE_MOBILE.getCode()));
    			//设置券类型描述
    			shareCouponDO.setCouponTypeDesc(CouponInfoCode.SHARE_COUPON_TYPE_MOBILE.getDetail());
			}
			if(mobileCouponShare!=null){
				shareCouponDO.setShareStatus(mobileCouponShare.getShareStatus());
			}
			return shareCouponDO;
		} catch (Exception e) {
			logger.error("CouponActivityOutputVoToShareCouponVO has error ", e);
		}
		return null;
	}
	
	public static ShareCouponDO shareCouponVoToShareCouponDO(ShareCouponVo shareCouponVo , MobileCouponShare mobileCouponShare){
		try {
			ShareCouponDO shareCouponDO = new ShareCouponDO();
			//抵用券id
			shareCouponDO.setCouponId(shareCouponVo.getUserCouponInfoVo().getCouponId());
			//抵用券活动Id
			shareCouponDO.setCouponActiveId(shareCouponVo.getUserCouponInfoVo().getActiveId());
			//抵用券金额
			shareCouponDO.setCouponAmount(shareCouponVo.getCouponActivityOutputVo().getDeductAmount().doubleValue());
			//结束时间
			shareCouponDO.setEndTime(shareCouponVo.getUserCouponInfoVo().getCouponExpiredTime());
			//时间
			shareCouponDO.setStartTime(shareCouponVo.getUserCouponInfoVo().getCouponBeginTime());
			//名称
			shareCouponDO.setTitle(shareCouponVo.getCouponActivityOutputVo().getActiveName());
			//描述
			shareCouponDO.setDescription(PromotionCouponUtil.getCouponActivityDesc(shareCouponVo.getCouponActivityOutputVo()));
			//规则
			shareCouponDO.setRuleDescription(PromotionCouponUtil.composeCouponUseExplain(shareCouponVo.getCouponActivityOutputVo()));
			//判断是否为掌上专享活动
			if(shareCouponVo.getCouponActivityOutputVo().getIsUsedForMobile()!=null&&shareCouponVo.getCouponActivityOutputVo().getIsUsedForMobile()==1){
    			//设置券类型
    			shareCouponDO.setCouponType(Integer.valueOf(CouponInfoCode.SHARE_COUPON_TYPE_MOBILE.getCode()));
    			//设置券类型描述
    			shareCouponDO.setCouponTypeDesc(CouponInfoCode.SHARE_COUPON_TYPE_MOBILE.getDetail());
			}
			if(mobileCouponShare!=null){
				//分享状态
				shareCouponDO.setShareStatus(mobileCouponShare.getShareStatus());
			}
			
			return shareCouponDO;
		} catch (Exception e) {
			logger.error("CouponActivityOutputVoToShareCouponVO has error ", e);
		}
		return null;
	}
	
	/**
	 * 
	 * @param mobileCouponShare 数据库中已保存的信息
	 * @param activityInfoMap 抵用券活动信息
	 * @param vipCouponMap vip券信息
	 * @param receiveUserInfoMap 收券人用户信息
	 * @param sharedUserInfoMap 分享者用户信息
	 * @param couponInfoMap 抵用券信息
	 * @param type 1-普通调用；2-微信列表页
	 * @param shareType 1-已分享券详情；2-已获得券详情
	 * @return
	 */
	public static ShareCouponDO mobileCouponShareToShareCouponDO(
			MobileCouponShare mobileCouponShare,
			Map<Long, CouponActivityOutputVo> activityInfoMap,
			Map<Long, Integer> vipCouponMap,
			Map<Long, EndUser> receiveUserInfoMap,
			Map<Long, EndUser> sharedUserInfoMap,Map<Long, ShareCouponVo> couponInfoMap , int type) {
		try {
			ShareCouponDO shareCouponDO = null;
			if(type==3){
				if(mobileCouponShare.getShareCreatedCouponid()!=null&&couponInfoMap!=null&&couponInfoMap.get(mobileCouponShare.getShareCreatedCouponid())!=null){
					shareCouponDO = shareCouponVoToShareCouponDO(couponInfoMap.get(mobileCouponShare.getCouponId()) , mobileCouponShare);
				}
			}else{
				if(mobileCouponShare.getCouponId()!=null&&couponInfoMap!=null&&couponInfoMap.get(mobileCouponShare.getCouponId())!=null){
					shareCouponDO = shareCouponVoToShareCouponDO(couponInfoMap.get(mobileCouponShare.getCouponId()) , mobileCouponShare);
				}
			}
			if(shareCouponDO==null&&mobileCouponShare.getCouponActiveDefId()!=null&activityInfoMap!=null&&activityInfoMap.get(mobileCouponShare.getCouponActiveDefId())!=null){
				shareCouponDO = couponActivityOutputVoToShareCouponDO(activityInfoMap.get(mobileCouponShare.getCouponActiveDefId()) , mobileCouponShare);
			}
            if(shareCouponDO==null){
            	return null;
            }
			
			//先判断是否为活动券
			if(mobileCouponShare.getCouponId()==null&&vipCouponMap!=null&&vipCouponMap.get(mobileCouponShare.getCouponActiveDefId())!=null){
				//设置券类型
				shareCouponDO.setCouponType(Integer.valueOf(CouponInfoCode.SHARE_COUPON_TYPE_VIP.getCode()));
				//设置券类型描述
				shareCouponDO.setCouponTypeDesc(CouponInfoCode.SHARE_COUPON_TYPE_VIP.getDetail());
			}
			shareCouponDO = setShareType(mobileCouponShare, shareCouponDO);
			if(type!=2){
				if(receiveUserInfoMap!=null&&receiveUserInfoMap.get(mobileCouponShare.getReceiveUserId())!=null){
					EndUser endUser = receiveUserInfoMap.get(mobileCouponShare.getReceiveUserId());
					MobileUserDO shareUserInfo = new MobileUserDO();
					shareUserInfo.setUserId(endUser.getId());
					shareUserInfo.setUserName(UsernameUtil.changeUserNametoHidden(endUser.getEndUserName()));
					
					ShareCouponDO childShareCouponDo = new ShareCouponDO();
					//设置返利券信息
					if(mobileCouponShare.getShareRewardCouponId()!=null&&couponInfoMap.get(mobileCouponShare.getShareRewardCouponId())!=null){
						childShareCouponDo = shareCouponVoToShareCouponDO(couponInfoMap.get(mobileCouponShare.getCouponId()) , mobileCouponShare);
					}
					childShareCouponDo = setShareType(mobileCouponShare, childShareCouponDo);
					shareUserInfo.setShareCouponDo(childShareCouponDo);
					List<MobileUserDO> receiveUserList = new ArrayList<MobileUserDO>();
					receiveUserList.add(shareUserInfo);
					shareCouponDO.setReceiveUserList(receiveUserList);
				}
				//设置赠券人用户信息
				if(sharedUserInfoMap!=null&&sharedUserInfoMap.get(mobileCouponShare.getShareUserId())!=null){
					EndUser endUser = sharedUserInfoMap.get(mobileCouponShare.getShareUserId());
					MobileUserDO shareUserInfo = new MobileUserDO();
					shareUserInfo.setUserId(endUser.getId());
					shareUserInfo.setUserName(UsernameUtil.changeUserNametoHidden(endUser.getEndUserName()));
					shareCouponDO.setShareUserInfo(shareUserInfo);
				}
			}
			//设置收券人用户信息
		   return shareCouponDO;
		} catch (Exception e) {
			logger.error("getActivityCount", e);
		}
	    return null;
	}
	
	private static ShareCouponDO setShareType(MobileCouponShare mobileCouponShare ,ShareCouponDO shareCouponDO){
		//设置返利状态
		if(mobileCouponShare.getShareStatus()!=null){
			//设置返利类型
			shareCouponDO.setShareStatus(mobileCouponShare.getShareStatus());
			//设置返利类型描述
			if(mobileCouponShare.getShareStatus()==1){
    			shareCouponDO.setShareStatusDesc("已分享");
			}else if(mobileCouponShare.getShareStatus()==2){
				shareCouponDO.setShareStatusDesc("已返利");
			}else if(mobileCouponShare.getShareStatus()==3){
				shareCouponDO.setShareStatusDesc("返利取消");
			}else if(mobileCouponShare.getShareStatus()==4){
				shareCouponDO.setShareStatusDesc("已完成");
			}
		}
		return shareCouponDO;
	}
	
	/**
	 * 微信查询已分享券工具类
	 * @param userId
	 * @param couponActivityMap
	 * @param userInfoList
	 * @param sharedCouponList
	 * @param couponIdList
	 * @return
	 */
	public static List<ShareCouponDO> getShareCouponDoForWeChat( Map<Long, CouponActivityOutputVo> couponActivityMap , Map<Long, EndUser> userInfoList,List<MobileCouponShare> sharedCouponList , Map<Long, ShareCouponVo> couponInfoMap,Map<Long, Integer> vipCouponMap){
		try {
			List<ShareCouponDO>  shareCouponDOList = new ArrayList<ShareCouponDO>();
			for(MobileCouponShare mobileCouponShare : sharedCouponList){
				ShareCouponDO shCouponDO = mobileCouponShareToShareCouponDO(mobileCouponShare, couponActivityMap, vipCouponMap, userInfoList, null, couponInfoMap , 2);
				if(shCouponDO!=null){
					shareCouponDOList.add(shCouponDO);
				}
			}
			if(shareCouponDOList.size()>0){
				//信息分组，将抵用券Id或者分享活动ID相同的分享信息汇总
				List<ShareCouponDO>  filterShareCouponDOList = new ArrayList<ShareCouponDO>();
				filterShareCouponDOList.addAll(shareCouponDOList);
				//标记该元素是否已经处理过
				Map<Long , Integer> map = new HashMap<Long, Integer>();
				List<ShareCouponDO> groupCouponDOList = new ArrayList<ShareCouponDO>();
				for(ShareCouponDO shareCouponDO : shareCouponDOList){
					//首先判断该元素是否已经处理过
					if(shareCouponDO.getCouponActiveId()!=null||shareCouponDO.getCouponId()!=null){
						if(shareCouponDO.getCouponActiveId()!=null){
							Integer sign = map.get(shareCouponDO.getCouponActiveId());
							if(sign!=null){
								continue;
							}
						}else if(shareCouponDO.getCouponId()!=null){
							Integer sign = map.get(shareCouponDO.getCouponId());
							if(sign!=null){
								continue;
							}
						}else{
							continue;
						}
					}else{
						continue;
					}
					List<ShareCouponDO> groupList = getGrouponShareCouponDo(filterShareCouponDOList, shareCouponDO);
					//移除重复的元素
					filterShareCouponDOList.removeAll(groupList);
					//拼接数据
					if(groupList!=null&&groupList.size()>0){
						int rebatesNumber = 0;
						//分组用户信息
						for(ShareCouponDO groupShareCouponDO : groupList){
							if(groupShareCouponDO!=null&&groupShareCouponDO.getShareStatus()!=null&&(groupShareCouponDO.getShareStatus()==2||groupShareCouponDO.getShareStatus()==4)){
								rebatesNumber++;
							}
						}
						shareCouponDO.setRebatesNumber(rebatesNumber);
						shareCouponDO.setSharedNumber(groupList.size());
						groupCouponDOList.add(shareCouponDO);
					}
				}
				return groupCouponDOList;
			}
			return shareCouponDOList;
		} catch (Exception e) {
			logger.error("getActivityCount", e);
		}
		return null;
	}
	
	private static List<ShareCouponDO> getGrouponShareCouponDo(List<ShareCouponDO>  shareCouponDOList , ShareCouponDO groupShareCouponDO){
		if(groupShareCouponDO==null) return null;
		List<ShareCouponDO> groupList = new ArrayList<ShareCouponDO>(); 
		for(ShareCouponDO  shareCouponDO : shareCouponDOList){
			//抵用券Id相同或者活动ID相同的活动分组
//			if((shareCouponDO.getCouponId()!=null&&groupShareCouponDO.getCouponId()!=null&&shareCouponDO.getCouponId().equals(groupShareCouponDO.getCouponId()))){
//				groupList.add(shareCouponDO);
//			}
			if((shareCouponDO.getCouponActiveId()!=null&&groupShareCouponDO.getCouponActiveId()!=null&&shareCouponDO.getCouponActiveId().equals(groupShareCouponDO.getCouponActiveId()))){
				groupList.add(shareCouponDO);
			}
		}
		return groupList;
	}
	
	public static  ShareCouponDO getShareCouponDoGroupInfoForWechat(List<MobileCouponShare> mobileCouponShareList , ShareCouponDO shareCouponDO){
		try {
			if(mobileCouponShareList!=null&&mobileCouponShareList.size()>0){
				List<Long> couponIdList = new ArrayList<Long>();
				List<Long> receiverUserIdList = new ArrayList<Long>();
				//遍历得到收券人用Id和已分享抵用券Id
				for(MobileCouponShare mobileCouponShare : mobileCouponShareList){
					if(mobileCouponShare.getShareRewardCouponId()!=null){
						couponIdList.add(mobileCouponShare.getShareRewardCouponId());
					}
					if(mobileCouponShare.getReceiveUserId()!=null){
						receiverUserIdList.add(mobileCouponShare.getReceiveUserId());
					}
				}	
				Map<Long, ShareCouponVo> couponInfo = PromotionCouponUtil.queryCouponActiveInfoForShareList(mobileCouponShareList.get(0).getShareUserId(), couponIdList);
				Map<Long, EndUser> userInfoMap = GUSUtil.getUserList(receiverUserIdList);
				if(userInfoMap!=null){
					List<MobileUserDO> mobileUserDoList = new ArrayList<MobileUserDO>();
					for(MobileCouponShare mobileCouponShare : mobileCouponShareList){
						if(((shareCouponDO.getCouponActiveId()!=null&&mobileCouponShare.getCouponActiveDefId()!=null&&shareCouponDO.getCouponActiveId().equals(mobileCouponShare.getCouponActiveDefId())))){
							MobileUserDO mobileUserDO = new MobileUserDO();
							ShareCouponDO childeShareCouponDO = new ShareCouponDO();
							if(couponInfo!=null&&couponInfo.get(mobileCouponShare.getShareRewardCouponId())!=null){
								childeShareCouponDO= shareCouponVoToShareCouponDO(couponInfo.get(mobileCouponShare.getShareRewardCouponId()), mobileCouponShare);
							}
							childeShareCouponDO = setShareType(mobileCouponShare, childeShareCouponDO);
							mobileUserDO.setShareCouponDo(childeShareCouponDO);
							if(userInfoMap.get(mobileCouponShare.getReceiveUserId())!=null){
								EndUser endUser = userInfoMap.get(mobileCouponShare.getReceiveUserId());
								mobileUserDO.setUserName(UsernameUtil.changeUserNametoHidden(endUser.getEndUserName()));
								mobileUserDO.setUserId(endUser.getId());
							}
							mobileUserDoList.add(mobileUserDO);
						}
					}
					shareCouponDO.setReceiveUserList(mobileUserDoList);
				}
			}
			
		} catch (Exception e) {
			logger.error("getShareCouponDoForWechat has error", e);
		}
		return shareCouponDO;
	}
}
