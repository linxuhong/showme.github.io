package com.yihaodian.mobile.service.common.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.lang3.StringUtils;

// TODO: Auto-generated Javadoc
/**
 * The Class StringUtil.
 */
public class StringUtil {
	
    public static String convertIso2Utf8(String isoStr) {
    	try {
    		if (StringUtils.isNotBlank(isoStr)) {
    			return new String(isoStr.getBytes("ISO-8859-1"), "utf-8");
    		}
		} catch (UnsupportedEncodingException e) {}
    	
    	return isoStr;
    }
	
    public static String convertDefault2Utf8(String isoStr) {
    	try {
    		if (StringUtils.isNotBlank(isoStr)) {
    			return new String(isoStr.getBytes(Charset.defaultCharset()), "utf-8");
    		}
		} catch (UnsupportedEncodingException e) {}
    	
    	return isoStr;
    }
    
    /**
     * Checks if is not empty.
     *
     * @param args the args
     * @return true, if is not empty
     */
    public static boolean isNotEmpty(String args) {
        if(args!=null) {
            if(!args.trim().equals("")) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Checks if is empty.
     *
     * @param args the args
     * @return true, if is empty
     */
    public static boolean isEmpty(String args) {
        if(args!=null) {
            if(!args.trim().equals("")) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Checks if is not empty.
     *
     * @param args the args
     * @return true, if is not empty
     */
    public static boolean isNotEmpty(Object args) {
        if(args!=null) {
            if(!args.toString().equals("null")) {
                return true;
            }
        }
        return false;
    }

    /**
     * Clear width.
     *
     * @param input the input
     * @return the string
     */
    public static String clearWidth(String input)
	{
		if(input == null)
			return "";
		StringBuffer ret = new StringBuffer();
		int start =0;
		int pos = 0;
		while(pos >=0)
		{
			pos = input.indexOf(" width",start);
			if(pos <0){
				ret.append(input.substring(start));
				break;
			}
			ret.append(input.substring(start,pos ));
			int p0 = pos + 6;
			pos = input.indexOf("=",p0);
			if(pos <0){
				ret.append(input.substring(p0));
				break;
			}
			String s = input.substring(p0,pos);
			if(s == null )
				continue;
			if(s.trim().length() != 0)
			{
			    ret.append(input.substring(start,pos));
				start = pos;
				continue;
			}
			
			int p1 = pos+1;
			pos = input.indexOf("\"",p1);
			if(pos <0)
			{
			    ret.append(input.substring(start));
				break;
			}
			
			s = input.substring(p1,pos);
			if(s == null )
				continue;
			if(s.trim().length() != 0){
			    ret.append(input.substring(start,pos));
				start = pos;
				continue;
			}
			p1 = pos+1;
			pos = input.indexOf("\"",p1);
			if(pos <0)
			{
			    ret.append(input.substring(start));
				break;
			}
			
			s = input.substring(p1,pos);
			if(s == null )
				continue;
			
			start = pos +1;
		}
		return ret.toString();
	}
    
    /**
     * Not null.
     *
     * @param str the str
     * @return the string
     */
    public static String notNull(String str) {
    	if (str == null) {
    		return "";
    	} else {
    		return str;
    	}
    }

	/**
	 * 根据提供的字符个数截取字符串，如果字符串字符数小于截取的个数则返回全部，如果大于截取个数则超过部分由more代替.
	 *
	 * @author zhangwei5 2012-04-12 09:36
	 * @param str 截取的字符串
	 * @param toCount 截取的字符个数
	 * @param more 超过部分的替代字符串
	 * @return 截取后的字符串，如果字符串字符数小于截取的个数则返回全部，如果大于截取个数则超过部分由more代替
	 */
	 public static String substring(String str, int toCount,String more)
	    {
	      int reInt = 0;
	      StringBuffer reStr = new StringBuffer();
	      if (str == null){
	          return ""; 
	      }
	      char[] tempChar = str.toCharArray();
	      int length =  tempChar.length;
	      for (int kk = 0; (kk < length && toCount > reInt); kk++) {
	        String s1 = str.valueOf(tempChar[kk]);
	        byte[] b;
			try {
				b = s1.getBytes("GBK");
				reInt += b.length;
				reStr.append(tempChar[kk]);
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
	      }
	      if (toCount == reInt || (toCount == reInt - 1)&&more!=null){
	          reStr.append(more);
	      }
	      return reStr.toString();
	    }    
    
	
	/**
	 * 数据压缩.
	 *
	 * @param data the data
	 * @return the byte[]
	 */
	public  static byte[] dataCompress(byte[] data) {
		GZIPOutputStream gos;
		try {
			ByteArrayInputStream bais = new ByteArrayInputStream(data);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			gos = new GZIPOutputStream(baos);
			
			byte[] buf = new byte[1024];
			int num;
			while ((num = bais.read(buf)) != -1) {
				gos.write(buf, 0, num);
			}
			gos.finish();
			gos.flush();
			gos.close();
			byte[] output = baos.toByteArray();  
			baos.close();
			return output;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 数据解压缩.
	 *
	 * @param a the a
	 * @return the byte[]
	 */
	public static byte[] dataDecompress(byte[] a){
		try {
			ByteArrayInputStream bais = new ByteArrayInputStream(a);
			GZIPInputStream gis = new GZIPInputStream(bais);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] buf = new byte[1024];
			int num;
			while((num=gis.read(buf))!=-1){
				baos.write(buf, 0, num);
			}
			gis.close();
			byte[] ret = baos.toByteArray();
			baos.close();
			return ret;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 数据解压缩.
	 *
	 * @param in the in
	 * @param length the length
	 * @return the byte[]
	 */
	public static byte[] dataDecompress(InputStream in,int length){
		if(length>0){
			try {
				GZIPInputStream gis = new GZIPInputStream(in);
				byte[] buf = new byte[length];
				gis.read(buf);
				gis.close();
				return buf;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		}
		return  null;
	}    
	
	/**
	 * 将String型的超时时间转换为Integer；null或者""返回1000.
	 *
	 * @param timeOutStr the time out str
	 * @return the time out data
	 */
	public static int getTimeOutData(String timeOutStr){
		try{
			if(isNotEmpty(timeOutStr)){
				return Integer.parseInt(timeOutStr);
			}
		}catch (Exception e) {
		}
		return 1000;
	}
	
	public static String removeSpecailChar(String str){        
        Pattern pat = Pattern.compile("\\|\n|\r|\t|#|\'|$|,|%");
        Matcher mat = pat.matcher(str);
        return  mat.replaceAll("");       
    }
}
