package com.yihaodian.mobile.service.common.util;

/**
 * 表情符号处理
 * 
 * ■ ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■<br>
 * 1. ( 0x1F300...0x1F5FF ) Misc Symbols and Pictographs<br>
 * 2. ( 0x1F600...0x1F64F ) Emoticons<br>
 * 3. ( 0x1F680...0x1F6FF ) Transport and Map<br>
 * 4. ( 0x1F900...0x1F9FF ) Various<br>
 * 5. ( 0x02600...0x026FF ) Misc symbols<br>
 * 6. ( 0x02700...0x027BF ) Dingbats<br>
 * 7. ( 0x0FE00...0x0FE0F ) Variation Selectors<br>
 * ■ ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■<br>
 *
 * @see http://apps.timwhitlock.info/emoji/tables/unicode<br>
 * @author xujun4<br>
 * 
 */
public class EmojiUtil {
	public static boolean isEmoji(int ch) {
		if ((0x1F300 <= ch && ch <= 0x1F9FF) || (0x02600 <= ch && ch <= 0x027FF) || (0x0FE00 <= ch && ch <= 0x0FE0F)) {
			return true;
		}
		return false;
	}

	public static String filterEmoji(String str) {
		if (str == null || str.isEmpty()) {
			return "";
		}
		try {
			int len = str.length();
			StringBuffer s = new StringBuffer(str.codePointCount(0, len));
			for (int i = 0, cp; i < len; i += Character.charCount(cp)) {
				cp = str.codePointAt(i);
				if (!isEmoji(cp)) {
					s.appendCodePoint(cp);
				}
			}
			return s.toString();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return str;
	}
}
