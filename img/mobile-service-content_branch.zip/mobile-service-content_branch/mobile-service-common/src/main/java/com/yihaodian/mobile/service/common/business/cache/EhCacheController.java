package com.yihaodian.mobile.service.common.business.cache;

import java.net.URL;
import java.util.Properties;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import com.ibatis.sqlmap.engine.cache.CacheController;
import com.ibatis.sqlmap.engine.cache.CacheModel;

public class EhCacheController implements CacheController {

    /** 
     * The EhCache CacheManager. 
     */
    private CacheManager       cacheManager;

    public static final String CONFIG_LOCATION = "configLocation";

    /** 
     * Default Configure Location 
     */
    public static final String DEFAULT_CONFIG_LOCATION = "/ehcache/ehcache.xml";

    /** 
     * Flush a cache model. 
     *  
     * @param cacheModel 
     *            - the model to flush. 
     */
    public void flush(CacheModel cacheModel) {
        getCache(cacheModel).removeAll();
    }

    /** 
     * Get an object from a cache model. 
     *  
     * @param cacheModel 
     *            - the model. 
     * @param key 
     *            - the key to the object. 
     * @return the object if in the cache, or null(?). 
     */
    public Object getObject(CacheModel cacheModel, Object key) {
        Object result = null;
        Element element = null;
        Cache cache = getCache(cacheModel);
        if(cache != null){
        	element = cache.get(key);
        }
        if (element != null) {
            result = element.getObjectValue();
        }
        return result;

    }

    /** 
     * Put an object into a cache model. 
     *  
     * @param cacheModel 
     *            - the model to add the object to. 
     * @param key 
     *            - the key to the object. 
     * @param object 
     *            - the object to add. 
     */
    public void putObject(CacheModel cacheModel, Object key, Object object) {
        getCache(cacheModel).put(new Element(key, object));
    }

    /** 
     * Remove an object from a cache model. 
     *  
     * @param cacheModel 
     *            - the model to remove the object from. 
     * @param key 
     *            - the key to the object. 
     * @return the removed object(?). 
     */
    public Object removeObject(CacheModel cacheModel, Object key) {
        Object result = this.getObject(cacheModel, key);
        getCache(cacheModel).remove(key);
        return result;
    }

    /** 
     * Gets an EH Cache based on an iBatis cache Model. 
     *  
     * @param cacheModel 
     *            - the cache model. 
     * @return the EH Cache. 
     */
    private Cache getCache(CacheModel cacheModel) {
        String cacheName = cacheModel.getId();
        Cache cache = cacheManager.getCache(cacheName);
        return cache;
    }

    /** 
     * Shut down the EH Cache CacheManager. 
     */
    public void finalize() {
        if (cacheManager != null) {
            cacheManager.shutdown();
        }
    }

    /** 
     * Configure a cache controller. Initialize the EH Cache Manager as a 
     * singleton. 
     *  
     * @param props 
     *            - the properties object continaing configuration information. 
     */
    public void configure(Properties props) {
    	String configLocation = props.getProperty(CONFIG_LOCATION);
    	// if can not found ehcache.xml from configLocaion,  
    	// use default configure file.  
    	if (configLocation == null) {
    		configLocation = DEFAULT_CONFIG_LOCATION;
    	}
    	URL url = getClass().getResource(configLocation);
    	cacheManager = CacheManager.create(url);
    }

	@Override
	public void setProperties(Properties props) {
		String configLocation = props.getProperty(CONFIG_LOCATION);
		// if can not found ehcache.xml from configLocaion,  
		// use default configure file.  
		if (configLocation == null) {
			configLocation = DEFAULT_CONFIG_LOCATION;
		}
		URL url = getClass().getResource(configLocation);
		cacheManager = CacheManager.create(url);
		// TODO Auto-generated method stub
		
	}
    
    /*public void setProperties(Properties props) {
        String configLocation = props.getProperty(CONFIG_LOCATION);
        // if can not found ehcache.xml from configLocaion,  
        // use default configure file.  
        if (configLocation == null) {
            configLocation = DEFAULT_CONFIG_LOCATION;
        }
        URL url = getClass().getResource(configLocation);
        cacheManager = CacheManager.create(url);
    }*/

}
