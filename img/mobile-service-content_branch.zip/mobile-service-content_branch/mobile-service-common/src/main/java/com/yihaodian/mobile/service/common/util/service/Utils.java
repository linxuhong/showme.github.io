package com.yihaodian.mobile.service.common.util.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.yihaodian.front.busystock.vo.BSProductVo;
import com.yihaodian.front.busystock.vo.BSPromotionProductVo;
import com.yihaodian.mobile.framework.lang.utils.StringUtil;
import com.yihaodian.mobile.service.common.util.MathUtil;
import com.yihaodian.mobile.service.domain.business.dal.backend.ThunderGo;
import com.yihaodian.mobile.service.domain.business.dal.backend.ThunderProduct;
import com.yihaodian.mobile.vo.bussiness.Trader;
import com.yihaodian.mobile.vo.constant.CommonKey;
import com.yihaodian.mobile.vo.constant.Constants.DATA_TYPE;
import com.yihaodian.mobile.vo.constant.Constants.VIEW_TYPE;
import com.yihaodian.mobile.vo.core.Page;
import com.yihaodian.mobile.vo.groupon.GrouponVO;
import com.yihaodian.mobile.vo.home.ContainerVO;
import com.yihaodian.mobile.vo.home.HomePromotionDetailVO;
import com.yihaodian.mobile.vo.home.ViewVO;
import com.yihaodian.mobile.vo.product.ProductVO;
import com.yihaodian.mobile.vo.thunder.MobileProductVO;
import com.yihaodian.mobile.vo.thunder.ThunderProductResult;

// TODO: Auto-generated Javadoc
/**
 * The Class Utils.
 */
public class Utils {
    
    /** The logger. */
    private static Logger logger = Logger.getLogger(Utils.class);
	
	/**
	 * Sub list.
	 *
	 * @param input the input
	 * @param start the start
	 * @param end the end
	 * @return the list
	 */
	public static List<?> subList(List<?> input,int start,int end){
		List<?> subList = input.subList(start, end);
		List resultList = new ArrayList();
		for(int i=0;i<subList.size();i++){
			resultList.add(subList.get(i));
		}
		return resultList;
	}
	
	/**
	 * Sub page.
	 *
	 * @param page the page
	 * @param currentPage the current page
	 * @param pageSize the page size
	 * @return true, if successful
	 */
	public static boolean subPage(Page<?> page,int currentPage,int pageSize){
		if(page==null)
			return false;
		page.setCurrentPage(currentPage);
		page.setPageSize(pageSize);
		List<?> data=page.getObjList();
		if(data==null || data.size()==0)
			return false;
		int totalSize = data.size();
		int start  = (currentPage - 1) * pageSize;
		if(start>=totalSize){
			return false;
		}else{
			int end = currentPage * pageSize > totalSize ? totalSize : currentPage * pageSize;
			if(start==0 && end==totalSize){
				//没有变化
				return true;
			}
	
			page.setObjList((List)subList(data,start,end));
			return true;
		}
	
	}
	
	/**
	 * 获得商品列表id.
	 *
	 * @param productIdArray the product id array
	 * @return the product id list by json array1
	 */
	public static List<Long> getProductIdListByJsonArray1(JsonArray productIdArray) {
		try{
			List<Long> prodList = new ArrayList<Long>();
			for(int i= 0 ; i<productIdArray.size();i++){
				JsonObject jsonObject = productIdArray.get(i).getAsJsonObject();
				if(jsonObject==null||(jsonObject.get("productid")==null)){
					continue;
				}
				
				if(jsonObject.get("productid")!=null)
				   prodList.add(jsonObject.get("productid").getAsLong());
				
				if(jsonObject.get("productid")!=null)
					   prodList.add(jsonObject.get("productid").getAsLong());
			}
			return prodList;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Transfer long list from json array.
	 *
	 * @param data the data
	 * @return the list
	 */
	public static List<Long> transferLongListFromJsonArray(JsonElement data){
		if(data==null || !data.isJsonArray())
			return null;
		JsonArray arrayData=data.getAsJsonArray();
		List<Long> longDatas=new ArrayList<Long>(arrayData.size());
		for(int i=0;i<arrayData.size();i++){
			longDatas.add(arrayData.get(i).getAsLong());
		}
		return longDatas;
	}
	
	/**
	 * 获得商品列表id,同时可以返回商品列表
	 * 如果需要返回商品vo列表，则productVOList不能为空.
	 *
	 * @param productIdArray the product id array
	 * @param productVOMap the product vo map
	 * @return the product id list by json array
	 */
	public static List<Long> getProductIdListByJsonArray(JsonArray productIdArray,Map<Long,ProductVO> productVOMap) {
		return getProductIdListByJsonArray(productIdArray,productVOMap,productIdArray.size());
	}
	
	/**
	 * 获得商品列表id,同时可以返回商品列表
	 * 如果需要返回商品vo列表，则productVOList不能为空
	 * size 获取多少个商品.
	 *
	 * @param productIdArray the product id array
	 * @param productVOMap the product vo map
	 * @param size the size
	 * @return the product id list by json array
	 */
	public static List<Long> getProductIdListByJsonArray(JsonArray productIdArray,Map<Long,ProductVO> productVOMap,int size) {
		try{
		
			List<Long> prodList = new ArrayList<Long>();
			size=productIdArray.size()>size ? size : productIdArray.size();
			for(int i= 0 ; i<size;i++){
				JsonObject jsonObject = productIdArray.get(i).getAsJsonObject();
				if(jsonObject==null||(jsonObject.get("productid")==null)){
					continue;
				}
				long productId=0;
				if(jsonObject.get("productid")!=null){
					productId=jsonObject.get("productid").getAsLong();
					if(prodList.contains(productId)){
					   //相同id的商品过滤，容错避免重复显示
						continue;
					}else
					   prodList.add(productId);   
				}
						
				if(productVOMap!=null){
				    ProductVO productVO=new ProductVO();
				    productVO.setProductId(productId);
				    productVO.setCnName(getJsonStringAttribute(jsonObject,"name"));
				    productVO.setSubCnName(getJsonStringAttribute(jsonObject,"description"));
				    productVO.setTag(getJsonStringAttribute(jsonObject,"tag"));
				    productVO.setMidleDefaultProductUrl(getJsonStringAttribute(jsonObject,"imgurl"));
				    productVO.setIsIntoCart(getJsonIntegerAttribute(jsonObject,"buytype"));
				    productVOMap.put(productId, productVO);
				}
			}
			return prodList;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 获得商品列表id,同时可以返回商品列表
	 * 如果需要返回商品vo列表，则productVOList不能为空.
	 *
	 * @param productIdArray the product id array
	 * @param grouponVOMap the groupon vo map
	 * @return the groupon id list by json array
	 */
	public static List<Long> getGrouponIdListByJsonArray(JsonArray productIdArray,Map<Long,GrouponVO> grouponVOMap) {
		return getGrouponIdListByJsonArray(productIdArray,grouponVOMap,productIdArray.size());
	}
	
	/**
	 * 获得商品列表id,同时可以返回商品列表
	 * 如果需要返回商品vo列表，则productVOList不能为空.
	 *
	 * @param productIdArray the product id array
	 * @param grouponVOMap the groupon vo map
	 * @param size the size
	 * @return the groupon id list by json array
	 */
	public static List<Long> getGrouponIdListByJsonArray(JsonArray productIdArray,Map<Long,GrouponVO> grouponVOMap,int size) {
		try{
		
			List<Long> grouponIdList = new ArrayList<Long>();
			size=productIdArray.size()>size?size:productIdArray.size();
			for(int i= 0 ; i<size;i++){
				JsonObject jsonObject = productIdArray.get(i).getAsJsonObject();
				if(jsonObject==null||(jsonObject.get("productid")==null)){
					continue;
				}
				long grouponId=0;
				if(jsonObject.get("productid")!=null){
					grouponId=jsonObject.get("productid").getAsLong();
					if(grouponIdList.contains(grouponId)){
						   //相同id的商品过滤，容错避免重复显示
						continue;
					}else
					   	grouponIdList.add(grouponId);   
				}
						
				if(grouponVOMap!=null){
				    GrouponVO grouponVO=new GrouponVO();
				    grouponVO.setId(grouponId);
				    grouponVO.setName(getJsonStringAttribute(jsonObject,"name"));
				    grouponVO.setSubName(getJsonStringAttribute(jsonObject,"description"));
				    grouponVO.setTag(getJsonStringAttribute(jsonObject,"tag"));
				    grouponVO.setMiniImageUrl(getJsonStringAttribute(jsonObject,"imgurl"));
				    grouponVO.setIsIntoCart(getJsonIntegerAttribute(jsonObject,"buytype"));
				    grouponVOMap.put(grouponId, grouponVO);
				}
			}
			return grouponIdList;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Calculate discount.
	 *
	 * @param original the original
	 * @param current the current
	 * @return the double
	 */
	public static double calculateDiscount(double original,double current){
		if(original==0){
		    return 10.0;
		}
		double tmp=100-Math.round((((original-current)/original*100.0)));
		return tmp/10.0;
	}
	
	/**
	 * Calculate sub.
	 *
	 * @param left the left
	 * @param right the right
	 * @return the double
	 */
	public static double calculateSub(double left,double right){
		double tmp=Math.round((((left-right)*10.0)));
		if(tmp<0)
			return 0;
		return tmp/10.0;
	}
	
	/**
	 * 后台的类型和前端app类型进行转化.
	 *
	 * @param data the data
	 * @return the promotion type
	 */
	public static int getPromotionType(JsonObject data){
		int type  = data.get("type").getAsInt();
		DATA_TYPE[] dataTypes=DATA_TYPE.values();
		if(31==type ||32==type || 34==type || 35 ==type || 36 == type 
		   ||37==type || type==60 || type==61 || type==62){
			  return type;//新增31,32 top100 一贵就赔
		}	
		if(type>0 && type<dataTypes.length){
		 switch (dataTypes[type]) {
		  case CMS:
			 //check link
			 int linktype= data.get("linktype")==null ? 0 : data.get("linktype").getAsInt();
			 VIEW_TYPE[] viewTypes=VIEW_TYPE.values();
			 if(linktype>0 && linktype<viewTypes.length){
				 switch(viewTypes[linktype]){
				     case CMS:  //普通cms页面
				     case CMS_ALL: //新版cms页面，专题类型
					     return  AppADConstants.AD_LAYOUT.H5_CMS.ordinal();  //1;
				     case CMS_MAX:
							//聚合活动
						 return AppADConstants.AD_LAYOUT.CMS_MAX.ordinal(); //  8;
				     case COUPON_LIST:
							//抵用券促销
						 return AppADConstants.AD_LAYOUT.COUPON_LIST.ordinal(); // 5;
				     case BRAND_LIST:
				    	 //品牌旗舰
				    	 return AppADConstants.AD_LAYOUT.BRAND_LIST.ordinal();// 10;
				     case BRAND_SHOP:
				    	 //品牌店铺
				    	 return AppADConstants.AD_LAYOUT.BRAND_SHOP.ordinal();  //11
				     //手机充值
				     case MOBILE_CHARGE_INDEX:
				    	 return AppADConstants.AD_LAYOUT.MOBILE_CHARGE_INDEX.ordinal();  //12;
				     //进口馆:	 
				     case IMPORT_GOODS_INDEX:
				    	 return AppADConstants.AD_LAYOUT.IMPORT_GOODS_INDEX.ordinal();// 13;
				     case CMS_NATIVE:
				    	 //cms native
				    	 return AppADConstants.AD_LAYOUT.CMS_NATIVE.ordinal();  // 27;
				     default:
						 return AppADConstants.AD_LAYOUT.NO_USE.ordinal();  //0	
				 }
			 }
			 return AppADConstants.AD_LAYOUT.NO_USE.ordinal();  //0	
		case DECREASE_UNDER_CONDITION:
			//满减
			return AppADConstants.AD_LAYOUT.DECREASE_UNDER_CONDITION.ordinal();  // 2;
		case GIFT_UNDER_CONDITION:
			//赠品
			return AppADConstants.AD_LAYOUT.GIFT_UNDER_CONDITION.ordinal(); // 3;
		case N2N_ACTIVITY :
			//N元n件
			return AppADConstants.AD_LAYOUT.N2N_ACTIVITY.ordinal();  // 4;
		case COUPON:
			//抵用券促销
			return AppADConstants.AD_LAYOUT.COUPON_LIST.ordinal(); // 5;
		case NOLINK_AD:
			//无连接
			return AppADConstants.AD_LAYOUT.NOLINK_AD.ordinal(); //14;
		case OUTLINK_AD:
			//外链广告
			return AppADConstants.AD_LAYOUT.OUTLINK_AD.ordinal(); // 15;
		case SEARCH:	
			//搜索类型关键字
			return AppADConstants.AD_LAYOUT.SEARCH.ordinal();    // 9;
		case SECKILL://CMS 秒杀广告
		case REDEEM://CNS 积分换购
		case PROMOTION: //CMS 普通促销活动
		case PROMOTION_LIST_PRODUCT: //商品列表
			return AppADConstants.AD_LAYOUT.PROMOTION_LD_PRODUCTS.ordinal();// 26;
		case FUNCTION: 
			//功能广告
			return AppADConstants.AD_LAYOUT.FUNCTION.ordinal();// 16;
		case CATEGORY: 
			//类目广告
			return AppADConstants.AD_LAYOUT.CATEGORY.ordinal();  //18;
		case BRAND: 
			//品牌广告
			return AppADConstants.AD_LAYOUT.BRAND.ordinal(); // 17;
		case MALLSHOP:
			//店铺广告
			return AppADConstants.AD_LAYOUT.MALLSHOP.ordinal();//19;
		case DISCOUNT_UNDER_CONDITION:
			//满折
			return AppADConstants.AD_LAYOUT.DISCOUNT_UNDER_CONDITION.ordinal();// 20;
		case GROUPON_LABEL:
			//团购聚类标签
			return AppADConstants.AD_LAYOUT.GROUPON_LABEL.ordinal(); // 24;
		case GROUPON_BRAND:
			//团购品牌
			return AppADConstants.AD_LAYOUT.GROUPON_BRAND.ordinal();//  //23;
		case GROUPON_CATEGORY:
			//团购类目
			return AppADConstants.AD_LAYOUT.GROUPON_CATEGORY.ordinal();// 21;
		case GROUPON_CHANNEL:
			//团购频道
			return AppADConstants.AD_LAYOUT.GROUPON_CHANNEL.ordinal();// 22;
		case GROUPON:
			//团购列表
			return AppADConstants.AD_LAYOUT.GROUPON.ordinal(); // 25;
		case PC_CMS:
			//pc_cms活动
		    //update by zuodeng PCcms类型调整为链接广告
			return AppADConstants.AD_LAYOUT.H5_CMS.ordinal(); // 1;
		default:
			return AppADConstants.AD_LAYOUT.NO_USE.ordinal();
		}
	  }
		return AppADConstants.AD_LAYOUT.NO_USE.ordinal();
	}
	
	/**
	 * Gets the json string attribute.
	 *
	 * @param obj the obj
	 * @param key the key
	 * @return the json string attribute
	 */
	public static String getJsonStringAttribute(JsonObject obj,String key){
		if(obj==null)
			return null;
		if(obj.get(key)!=null){
			return obj.get(key).getAsString();
		}
		return null;
	}
	
	/**
	 * Gets the json integer attribute.
	 *
	 * @param obj the obj
	 * @param key the key
	 * @return the json integer attribute
	 */
	public static Integer getJsonIntegerAttribute(JsonObject obj,String key){
		if(obj==null)
			return null;
		if(obj.get(key)!=null){
			return obj.get(key).getAsInt();
		}
		return null;
	}
	
	/**
	 * copy baseProductVO's cnName, subCnName Middleimg to productVO.
	 *
	 * @param productVO the product vo
	 * @param baseProductVO the base product vo
	 */
	public static void merge(ProductVO productVO, ProductVO baseProductVO) {
		if(baseProductVO==null || productVO==null)
			return;
		if(StringUtil.isNotEmpty(baseProductVO.getCnName())){
			productVO.setCnName(baseProductVO.getCnName());
		}
		if(StringUtil.isNotEmpty(baseProductVO.getSubCnName())){
			productVO.setSubCnName(baseProductVO.getSubCnName());
		}
		if(StringUtil.isNotEmpty(baseProductVO.getTag())){
			productVO.setTag(baseProductVO.getTag());
		}else if(productVO.getMaketPrice()!=null && productVO.getPrice()!=null){
			if(productVO.getPromotionId()!=null && productVO.getPromotionPrice()!=null){
				//landing page price
				productVO.setTag(Utils.calculateDiscount(productVO.getMaketPrice(),productVO.getPromotionPrice())+"折");
			}else if(productVO.getPrice()!=null){
				//common price
		    	productVO.setTag(Utils.calculateDiscount(productVO.getMaketPrice(),productVO.getPrice())+"折");
			}
		}
		if(StringUtil.isNotEmpty(baseProductVO.getMidleDefaultProductUrl())){
			productVO.setMidleDefaultProductUrl(baseProductVO.getMidleDefaultProductUrl());
		}
		
		if(baseProductVO.getIsIntoCart()!=null){
		    productVO.setIsIntoCart(baseProductVO.getIsIntoCart()); 
		}
	}
	
	/**
	 * copy baseProductVO's cnName, subCnName Middleimg to productVO.
	 *
	 * @param productVO the product vo
	 * @param baseProductVO the base product vo
	 */
	public static void merge(MobileProductVO productVO, ThunderProduct baseProductVO) {
		if(baseProductVO==null || productVO==null)
			return;
		if(StringUtil.isNotEmpty(baseProductVO.getProductName())){
			productVO.setCnName(baseProductVO.getProductName());
		}	
		if(StringUtil.isNotEmpty(baseProductVO.getSpecification())){
			productVO.setSpecification(baseProductVO.getSpecification());
		}
	}
	
	/**
	 * copy baseProductVO's product name to productVO.
	 *
	 * @param productVO the product vo
	 * @param baseProductVO the base product vo
	 */
	public static void merge(MobileProductVO productVO, ThunderGo baseProductVO) {
		if(baseProductVO==null || productVO==null)
			return;
		if(StringUtil.isNotEmpty(baseProductVO.getProductName())){
			productVO.setCnName(baseProductVO.getProductName());
		}	
		if(StringUtil.isNotEmpty(baseProductVO.getSpecification())){
			productVO.setSpecification(baseProductVO.getSpecification());
		}
	}
	
	/**
	 * Merge.
	 *
	 * @param grouponVO the groupon vo
	 * @param baseGrouponVO the base groupon vo
	 */
	public static void merge(GrouponVO grouponVO,GrouponVO baseGrouponVO) {
		if(grouponVO==null || baseGrouponVO==null)
		   return;
		if(StringUtil.isNotEmpty(baseGrouponVO.getName())){
			grouponVO.setName(baseGrouponVO.getName());
		}
		if(StringUtil.isNotEmpty(baseGrouponVO.getSubName())){
			grouponVO.setSubName(baseGrouponVO.getSubName());
		}
		if(StringUtil.isNotEmpty(baseGrouponVO.getMiniImageUrl())){
			grouponVO.setMiniImageUrl(baseGrouponVO.getMiniImageUrl());
		}
		if(StringUtil.isNotEmpty(baseGrouponVO.getTag())){
			grouponVO.setTag(baseGrouponVO.getTag());
		}else if(grouponVO.getDiscount()!=null){
	       //tag如果没有设置，则默认为折扣
	       grouponVO.setTag(grouponVO.getDiscount()+"折");
	    }
		if(baseGrouponVO.getIsIntoCart()!=null)
		    grouponVO.setIsIntoCart(baseGrouponVO.getIsIntoCart());
	}
	
	/**
	 * 从BS获取商品的库存数据.
	 *
	 * @param trader the trader
	 * @param bspVo the bsp vo
	 * @param productVO the product vo
	 * @param saleProductLimit the sale product limit
	 * @return the product stock number
	 */
	public static void getProductStockNumber(Trader trader,	BSProductVo bspVo, ProductVO productVO, Integer saleProductLimit) {
		if(bspVo==null || productVO==null)
			return;
		if(VersionUtil.compare(CommonKey.Interface_VERSION_1_3_1,trader.getInterfaceVersion())>=0){
		//获取限购 库存量
		   if(saleProductLimit!=null){
		       productVO.setLandingSaleProductLimit(saleProductLimit);
		   }
		   
           //设置促销类型
           productVO.setPromotionType(bspVo.getPromoteType());
           switch(bspVo.getPromoteType()){
               case 2: 
               case 3:
               case 5:
                   //用户限购数量
                   productVO.setLimitNumberPerUser(bspVo.getSpecialPriceLimitNumber());
                   break;
               case 4:
                   //用户限购数量
                   productVO.setLimitNumberPerUser(bspVo.getUserPriceLimitNumber());
                   //剩余促销库存
                   productVO.setRemainPromotionStock(bspVo.getSpecialPriceLimitNumber()-bspVo.getSpecialPriceSoldNum());
                   break;
               default :
                   break;    
           }
		   if(bspVo.getPromoteType() == 4){
				long leftNum = bspVo.getSpecialPriceLimitNumber() - bspVo.getSpecialPriceSoldNum();
				// 如果剩余库存不足限购剩余个数，则返回最小可用库存
				if(bspVo.getCurrentStockNum() < leftNum){
					leftNum = bspVo.getCurrentStockNum();
				}
				productVO.setStockNumber(Long.valueOf(leftNum));
				//雷购展示 剩余百分比
				productVO.setPromotionSalePercent(MathUtil.roundDouble((float)productVO.getStockNumber()/bspVo.getSpecialPriceLimitNumber(),2));
			}else{
				productVO.setStockNumber(bspVo.getCurrentStockNum());
				if(bspVo.getCurrentStockNum()<=0){
				    productVO.setCanBuy(false);
				}
			}
		}
	}
	
	/**
	 * 从BS获取商品的库存数据.
	 *
	 * @param trader the trader
	 * @param bspVo the bsp vo
	 * @param productVO the product vo
	 * @param saleProductLimit the sale product limit
	 * @return the product stock number
	 */
	public static void getProductStockNumberAndPrice(BSProductVo bspVo, MobileProductVO productVO, Integer saleProductLimit) {
		if(bspVo==null || productVO==null)
			return;
        productVO.setMerchantId(bspVo.getMerchantId());
        if(bspVo.getCanShow() ==1 && bspVo.getCanSale()==1 && bspVo.getCurrentStockNum()>0){
            productVO.setCanBuy(true);
        }else{
            productVO.setCanBuy(false);
        }
        //库存小于起购件数
        if(bspVo.getShoppingcount()!=null && bspVo.getShoppingcount()>0 && bspVo.getShoppingcount() >bspVo.getCurrentStockNum() ){
        	productVO.setCanBuy(false);
        }
        productVO.setPmId(bspVo.getPmId());
        productVO.setPrice(bspVo.getCurrentPrice());
        productVO.setYhdPrice(bspVo.getNonMemberPrice());
        productVO.setMaketPrice(bspVo.getMarketPrice().doubleValue()); 
        productVO.setChannelId(bspVo.getChannelId());
		//获取限购 库存量
	   if(saleProductLimit!=null){
	       productVO.setLandingSaleProductLimit(saleProductLimit);
	   }
       //设置促销类型
       productVO.setPromotionType(bspVo.getPromoteType());
//       switch(bspVo.getPromoteType()){
//           case 2: 
//           case 3:
//           case 5:
//               //用户限购数量
//               productVO.setLimitNumberPerUser(bspVo.getSpecialPriceLimitNumber());
//               break;
//           case 4:
//               //用户限购数量
//               productVO.setLimitNumberPerUser(bspVo.getUserPriceLimitNumber());
//               //剩余促销库存
//               productVO.setRemainPromotionStock(bspVo.getSpecialPriceLimitNumber()-bspVo.getSpecialPriceSoldNum());
//               break;
//           default :
//               break;    
//       }
       if(bspVo.getPromoteType() == 2 || bspVo.getPromoteType() == 3 || bspVo.getPromoteType() == 5){
    	   //用户限购数量
    	   productVO.setLimitNumberPerUser(bspVo.getSpecialPriceLimitNumber());
    	   
       }else if(bspVo.getPromoteType() == 4){
    	   //用户限购数量
    	   productVO.setLimitNumberPerUser(bspVo.getUserPriceLimitNumber());
           //剩余促销库存
    	   productVO.setRemainPromotionStock(bspVo.getSpecialPriceLimitNumber()-bspVo.getSpecialPriceSoldNum());
    	   
       }
	   if(bspVo.getPromoteType() == 4){
			long leftNum = bspVo.getSpecialPriceLimitNumber() - bspVo.getSpecialPriceSoldNum();
			// 如果剩余库存不足限购剩余个数，则返回最小可用库存
			if(bspVo.getCurrentStockNum() < leftNum){
				leftNum = bspVo.getCurrentStockNum();
			}
			productVO.setStockNumber(Long.valueOf(leftNum));
			if(productVO.getStockNumber()<=0){
				productVO.setCanBuy(false);
			}
		}else{
			productVO.setStockNumber(bspVo.getCurrentStockNum());
			if(productVO.getStockNumber()<=0){
				productVO.setCanBuy(false);
			}
		}
	}
	
	   /**
   	 * 从BS获取商品的库存数据.
   	 *
   	 * @param trader the trader
   	 * @param bspVo the bsp vo
   	 * @param productVO the product vo
   	 * @param saleProductLimit the sale product limit
   	 * @return the landing product stock number
   	 */
 public static void getlandingProductStockNumber(Trader trader, BSPromotionProductVo bspVo, ProductVO productVO, Integer saleProductLimit) {
     if(bspVo==null || productVO==null)
         return;
     if(VersionUtil.compare(CommonKey.Interface_VERSION_1_3_1,trader.getInterfaceVersion())>=0){
     //获取限购 库存量
        if(saleProductLimit!=null){
            productVO.setLandingSaleProductLimit(saleProductLimit);
        }
        //
        productVO.setStockNumber(bspVo.getCurrentCanBuyNum().longValue());
     }
 }
	
	
    /**
     * 将虚拟业务类型转换为 将功能模块的虚拟业务转为老版本彩票类型  promotionType 16为功能入口  keyword 21表示虚拟业务 17为彩票模块.
     *
     * @param viewVo the view vo
     * @return the view vo
     */
    public static ViewVO transVirtualFunctionType(ViewVO viewVo) {
        try {
            if (viewVo != null) {
                List<ContainerVO> containers = viewVo.getContainers();
                if (containers != null && containers.size() > 0) {
                    for (ContainerVO containerVO : containers) {
                        List<HomePromotionDetailVO> homePageDetailVoList = containerVO.getAds();
                        if (homePageDetailVoList != null && homePageDetailVoList.size() > 0) {
                            for (HomePromotionDetailVO homePromotionDetailVO : homePageDetailVoList) {
                                if (homePromotionDetailVO.getPromotionType() != null
                                    && homePromotionDetailVO.getPromotionType() == 16
                                    && StringUtil.isNotBlank(homePromotionDetailVO.getKeyword())
                                    && homePromotionDetailVO.getKeyword().equals("21")) {
                                    homePromotionDetailVO.setKeyword("17");
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("transVirtualFunctionType has error ", e);
        }
        return viewVo;
    }

}
