package com.yihaodian.mobile.common.ex;

import com.yihaodian.mobile.framework.model.enums.BaseResultCode;

public class CentralMobileBusinessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4863419601131178143L;
	
	private BaseResultCode resultCode;
	
	public CentralMobileBusinessException(BaseResultCode resultCode) {
		super(resultCode.getDetail());
		this.resultCode = resultCode;
	}
	
	public CentralMobileBusinessException(BaseResultCode resultCode, Throwable throwable) {
		super(resultCode.getDetail(), throwable);
		this.resultCode = resultCode;
	}

	public BaseResultCode getResultCode() {
		return resultCode;
	}
	
}
